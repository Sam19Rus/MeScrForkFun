# АРХИВ: HEAVY-сет «MJOLNIR MK VI» (бенч-копия силуэта Мастера Чифа) — v18, заморожен

Статус: **ЗАМОРОЖЕН, НЕ ТРОГАТЬ**. Законсервирован в v19 (2026-09-30) по решению пользователя:
в игре остаётся один сет — ROOKIE MERC; бенч-копия силуэта MJOLNIR Mark VI выведена из активной
кодовой базы, чтобы будущая смена стиля её не задела.

## Что внутри

| путь | содержимое |
|---|---|
| `src/heavy_art_v18.ts` | весь арт сета: части @40 (TORSO/HELMET/limbs/FIST/SUPHAND/NECK40), HEAVY_PAL, 30px-арт, полный entry-объект `ARMOR_SET_ENTRY_HEAVY_V18` (verbatim из `hero_art.ts` v18) |
| `src/ref_replica_v18.ts` | пиксель-трейсы референса `REPLICA_30/36/40` (ground truth бывшего assertTraceMatch) |
| `src/hero_scale_v18.ts` | генератор масштабных артов v18 вместе с heavy-ветками и genHelmet |
| `tools/trace_match_v18.ts` | замороженный `assertTraceMatch` + `TRACE_POSE` + family-классификатор |
| `tools/hero_bench_v18.ts` | замороженный bench v18 (trace_vs_rig, chief-листы, visor micro-spec и т.д.) |
| `tools/game_vs_bench_v18.ts` | замороженный assertGameEqualsBench для HEAVY@40 |
| `tools/qa_aa1_v18.ts` | замороженный QA v18 (10 проверок, включая trace-ассерт) |
| `shots/` | 21 heavy-специфичный лист v18 (trace_vs_rig, bench_heavy40, hero_chief*, ref_trace, ...) |

## Метрики на момент заморозки

- `assertTraceMatch` (rig low-ready @40 vs REPLICA_40): IoU **0.8732**; регионы head 1.000 /
  torso 0.913 / arms 0.913 / legs 0.920; belt 7/7; pauldron 30/30.
- `assertGameEqualsBench` (game draw path == bench draw path, HEAVY@40): IoU **0.9953**.
- `npm run qa` v18: ALL GREEN (10 проверок, replay побайтово).

## Режим «не трогается»

- Каталог **не компилируется**: `tsconfig.json` включает только `src/` и `tools/`.
- Никакие активные файлы не импортируют архив; активных ссылок на `heavy` в `src/`/`tools/` нет.
- Правки в архиве запрещены без явного решения пользователя (это слепок эпохи v18).

## Процедура восстановления (если понадобится)

1. Вернуть арт-диапазоны из `src/heavy_art_v18.ts` в `src/game/hero_art.ts` (константы + entry в `ARMOR_SETS`).
2. Вернуть `src/game/ref_replica.ts` и `tools/trace_match.ts` из копий `_v18`.
3. Переподключить heavy-секции bench/QA по `tools/hero_bench_v18.ts` / `game_vs_bench_v18.ts` / `qa_aa1_v18.ts`.
4. Ожидать ручную адаптацию: активный `src/` уйдёт вперёд (смена стиля), замороженные инструменты
   ссылаются на API v18 (сигнатуры `buildScaleArts`, состав `ARMOR_SETS`, имена shots).

## Юридическая пометка

Имена «MJOLNIR / Mark VI» и силуэт-бенч — внутренние, для приватной разработки. До публичного
билда сет требовал полного рестайла; архив эту задачу не отменяет, а откладывает навсегда.
