/**
 * AA1 validation bench (BUILD -> INSPECT -> VALIDATE):
 *  1. deterministic replay: two identical runs produce byte-identical frames;
 *  2. combat loop: bot lands kills and earns credits;
 *  3. guild confiscation rule: worse item -> credits, not inventory;
 *  4. pickup rule: better item -> equipped;
 *  5. guild shuttle: drop scheduled at the 50-kill milestone;
 *  6. capsule: companion joins after opening.
 */
import { runHeadless } from '../src/shell/headless.js';
import { assertGameEqualsBench } from './game_vs_bench.js';
import { assertTraceMatch } from './trace_match.js';
import { readFileSync, rmSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const dirA = join(here, '..', 'shots_qa_a');
const dirB = join(here, '..', 'shots_qa_b');
rmSync(dirA, { recursive: true, force: true });
rmSync(dirB, { recursive: true, force: true });
mkdirSync(dirA, { recursive: true });
mkdirSync(dirB, { recursive: true });

const shots = [
  { tick: 10, name: 'menu' }, { tick: 60 * 5, name: 'fight' }, { tick: 60 * 27 + 20, name: 'conf' },
  { tick: 60 * 36, name: 'shuttle' }, { tick: 60 * 54, name: 'comp' },
];
const interventions = [
  { tick: 60 * 20, kind: 'goto_box' as const },
  { tick: 60 * 26, kind: 'drop_common' as const },
  { tick: 60 * 30, kind: 'kills_49' as const },
  { tick: 60 * 40, kind: 'drop_legendary' as const },
  { tick: 60 * 50, kind: 'goto_capsule' as const },
];
const a = runHeadless({ outDir: dirA, ticks: 60 * 58, shots, interventions });
const b = runHeadless({ outDir: dirB, ticks: 60 * 58, shots, interventions });

const checks: [string, boolean, string][] = [];
const sameStats = JSON.stringify(a) === JSON.stringify(b);
checks.push(['replay: stats identical', sameStats, JSON.stringify(a)]);
let sameBytes = true;
for (const s of shots) {
  const ha = createHash('md5').update(readFileSync(join(dirA, `${s.name}.png`))).digest('hex');
  const hb = createHash('md5').update(readFileSync(join(dirB, `${s.name}.png`))).digest('hex');
  if (ha !== hb) sameBytes = false;
}
checks.push(['replay: frames byte-identical', sameBytes, '']);
checks.push(['combat: kills > 10', (a.kills as number) > 10, `kills=${a.kills}`]);
checks.push(['combat: credits earned', (a.credits as number) > 50, `credits=${a.credits}`]);
checks.push(['rule: worse item confiscated', (a.confiscated as number) >= 1, `conf=${a.confiscated}`]);
checks.push(['rule: better item equipped', String(a.weapon2).startsWith('legendary'), `weapon2=${a.weapon2}`]);
checks.push(['shuttle: drop at milestone', (a.drops as number) >= 1, `drops=${a.drops}`]);
checks.push(['capsule: companion active', (a.companion as number) === 1, `companion=${a.companion}`]);

// v17 P0 (permanent): the in-game HEAVY@40 draw must equal the bench render of the authored
// v16 parts (mask IoU >= 0.98) - proves the gameplay path uses the authored set, not a stale one.
try {
  const g = assertGameEqualsBench();
  checks.push(['v17 P0: game==bench heavy@40', true, `IoU=${g.iou.toFixed(4)}`]);
} catch (e) {
  checks.push(['v17 P0: game==bench heavy@40', false, String((e as Error).message).split('\n')[0]]);
}
// v17 P2 (permanent): rig low-ready @40 vs the MJOLNIR reference trace REPLICA_40:
// silhouette IoU >= 0.85 and per-region color-family agreement >= 0.90 (head/torso/arms/legs),
// belt width & pauldron span equal to the trace. Red bench on failure (throws).
try {
  const t = assertTraceMatch();
  const reg = t.regions.map((r) => `${r.name}=${r.agree.toFixed(3)}`).join(' ');
  checks.push(['v17 P2: rig matches ref trace @40', true, `IoU=${t.iou.toFixed(4)} ${reg} belt=${t.beltTrace}/${t.beltTorso} pauldron=${t.pauldronTrace}/${t.pauldronTorso}`]);
} catch (e) {
  checks.push(['v17 P2: rig matches ref trace @40', false, String((e as Error).message).split('\n')[0]]);
}

let fail = 0;
for (const [name, ok, info] of checks) {
  if (!ok) fail++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? '  (' + info + ')' : ''}`);
}
rmSync(dirA, { recursive: true, force: true });
rmSync(dirB, { recursive: true, force: true });
console.log(fail === 0 ? 'QA AA1: ALL GREEN' : `QA AA1: ${fail} FAILURES`);
process.exit(fail === 0 ? 0 : 1);
