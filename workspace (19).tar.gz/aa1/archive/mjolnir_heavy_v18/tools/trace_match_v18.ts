/**
 * v17 P2: assertTraceMatch - rig @40 in the low-ready pose vs the MJOLNIR reference trace
 * (REPLICA_40) at the same scale.
 *   - silhouette IoU >= 0.85 after best-translation alignment (feet/pose may differ by a px);
 *   - per-region color-family agreement (head / torso / arms / legs) >= 0.90, regions taken
 *     from the rig's own part bboxes (DBG), families = green armor / dark hardware
 *     (gunmetal+ink) / amber / leather / other;
 *   - belt width and pauldron span of the trace vs the authored torso art (must be equal);
 *   - on failure: throws with the numbers (red bench); report table goes to docs.
 */
import { writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PixelBuf, rgba } from '../src/core/buf.js';
import { drawSprite, drawHero, type HeroPose } from '../src/game/hero.js';
import { ARMOR_SETS, HERO_PAL } from '../src/game/hero_art.js';
import { REPLICA_40 } from '../src/game/ref_replica.js';
import { TORSO40_HEAVY } from '../src/game/hero_art.js';
import { encodePNG } from '../src/engine/png.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');

export const TRACE_PAL = { ...HERO_PAL, ...(ARMOR_SETS[1].pal ?? {}) };

const W = 220, H = 170;
const RX = 110, RY = 150;

export type Family = 'green' | 'gunmetal' | 'amber' | 'leather' | 'other';
/** Color families for the region agreement check.
 *  v17: pure ink (#12141a) is merged into 'gunmetal' — both are "dark hardware" in the
 *  MJOLNIR reference (seams, frame edges, undersuit shadows read as one dark family),
 *  so a 1px ink outline ring around a green bone must not break the region agreement. */
export function family(c: number): Family {
  const r = c & 255, g = (c >>> 8) & 255, b = (c >>> 16) & 255;
  if (r < 26 && g < 26 && b < 30) return 'gunmetal'; // ink = dark hardware
  if (r > 190 && g > 130 && b < 190 && b < g) return 'amber';
  if (g > r + 6 && g > b + 6) return 'green';
  if (Math.abs(r - g) <= 14 && Math.abs(g - b) <= 14) return 'gunmetal';
  if (r > g + 18 && g > b + 6) return 'leather';
  return 'other';
}

/** v17: QA-only fitted pose (coordinate descent in tools/tmp_fit4.ts, IoU 0.87 @40).
 *  Uses the contract-safe additive channels (stance + boneOverride); default gameplay
 *  pose is untouched. Kept here so the assert is reproducible without the fitter.
 *  v18 hardening: re-fit (tools fitter, objective = threshold-saturated IoU + family
 *  agreement) after the shoulder-tip art fix: gun 2.643 -> 2.703, IoU 0.8588 -> 0.8732. */
export const TRACE_POSE = {
  stance: { footF: [9, -4, 0] as [number, number, number], footB: [-10.5, -5.5, 0] as [number, number, number] },
  boneOverride: { thighF: 1.25, shinF: 1.35, thighB: 1.75, shinB: 1.65, gun: 2.703, uparmF: 1.22, forearmF: 2.074, uparmS: 0.964, forearmS: -1.424 },
};

interface DbgBox { name: string; x0: number; y0: number; x1: number; y1: number }

export interface TraceMatchResult {
  iou: number;
  shift: [number, number];
  regions: { name: string; agree: number; px: number }[];
  beltTrace: number;
  beltTorso: number;
  pauldronTrace: number;
  pauldronTorso: number;
  traceH: number;
  rigH: number;
}

function masks(): { rig: PixelBuf; trace: PixelBuf; dbg: DbgBox[] } {
  const rig = new PixelBuf(W, H);
  const dbg: DbgBox[] = [];
  const pose: HeroPose = {
    aimAng: 2.9, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0,
    set: 'heavy', lowReady: 1, pxm: 40, dbg,
    stance: TRACE_POSE.stance, boneOverride: TRACE_POSE.boneOverride,
  };
  drawHero(rig, RX, RY, pose);
  const trace = new PixelBuf(W, H);
  drawSprite(trace, REPLICA_40, TRACE_PAL, RX - 20, RY - (REPLICA_40.length - 1));
  return { rig, trace, dbg };
}

// v17: the contact shadow blends to pure black (rgba(0,0,0,255) over empty bg) - no palette
// color is #000000, so exact-black == shadow and must NOT count toward the silhouette mask.
const opaque = (c: number) => (c >>> 24) === 255 && (c & 0xffffff) !== 0;

function maskOf(b: PixelBuf): Uint8Array {
  const m = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) m[i] = opaque(b.px[i]) ? 1 : 0;
  return m;
}

export function runTraceMatch(opts: { dumpImages?: boolean; outDir?: string } = {}): TraceMatchResult {
  const { rig, trace, dbg } = masks();
  const mR = maskOf(rig), mT = maskOf(trace);
  // best translation of the trace over the rig (small window; both are sole-grounded already)
  let best = -1, bx = 0, by = 0, bi = 0, bu = 1;
  for (let sy = -6; sy <= 6; sy++) {
    for (let sx = -8; sx <= 8; sx++) {
      let inter = 0, union = 0;
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          const tx = x + sx, ty = y + sy;
          const t = tx >= 0 && ty >= 0 && tx < W && ty < H ? mT[ty * W + tx] : 0;
          const r = mR[y * W + x];
          if (r && t) inter++;
          if (r || t) union++;
        }
      }
      const iou = union ? inter / union : 0;
      if (iou > best) { best = iou; bx = sx; by = sy; bi = inter; bu = union; }
    }
  }
  // per-region family agreement inside rig part bboxes (trace sampled at +shift)
  const groups: [string, string[]][] = [
    ['head', ['head']],
    ['torso', ['torso', 'neck']],
    ['arms', ['uparmF', 'uparmS', 'forearmF', 'forearmS', 'handF', 'handS']],
    ['legs', ['thighF', 'thighB', 'shinF', 'shinB', 'bootF', 'bootB']],
  ];
  const regions = groups.map(([name, names]) => {
    let agree = 0, px = 0;
    for (const box of dbg.filter((d) => names.includes(d.name))) {
      for (let y = Math.max(0, box.y0); y <= Math.min(H - 1, box.y1); y++) {
        for (let x = Math.max(0, box.x0); x <= Math.min(W - 1, box.x1); x++) {
          const i = y * W + x;
          const tx = x + bx, ty = y + by;
          if (tx < 0 || ty < 0 || tx >= W || ty >= H) continue;
          const j = ty * W + tx;
          if (!mR[i] || !mT[j]) continue;
          px++;
          if (family(rig.px[i]) === family(trace.px[j])) agree++;
        }
      }
    }
    return { name, agree: px ? agree / px : 1, px };
  });
  // belt / pauldron widths: FIXED row windows (v17 fix: the old selectors matched visor /
  // helmet rows). belt = longest gunmetal '3'/'4' run: trace rows 42-48 vs torso rows 32-38;
  // pauldron = max opaque span: trace rows 13-19 vs torso rows 3-9.
  const beltTrace = maxRun(REPLICA_40.slice(42, 49));
  const beltTorso = maxRun(TORSO40_HEAVY.slice(32, 39));
  const pauldronTrace = maxSpan(REPLICA_40.slice(13, 20));
  const pauldronTorso = maxSpan(TORSO40_HEAVY.slice(3, 10));
  // heights
  const hOf = (m: Uint8Array) => { let y0 = H, y1 = -1; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (m[y * W + x]) { if (y < y0) y0 = y; if (y > y1) y1 = y; } return y1 - y0 + 1; };

  if (opts.dumpImages) {
    const outDir = opts.outDir ?? join(root, 'shots');
    mkdirSync(outDir, { recursive: true });
    // side-by-side + overlay of the aligned pair
    const sheet = new PixelBuf(W * 2 + 30, H + 20, rgba(18, 20, 26));
    sheet.blit(rig, 10, 10);
    sheet.blit(trace, W + 20 + bx, 10 + by);
    writeFileSync(join(outDir, 'trace_match_align.png'), encodePNG(sheet));
  }
  return {
    iou: best, shift: [bx, by], regions,
    beltTrace, beltTorso, pauldronTrace, pauldronTorso,
    traceH: hOf(mT), rigH: hOf(mR),
  };
}

/** longest contiguous run of gunmetal belt chars ('3'/'4') over the given rows */
function maxRun(rows: string[]): number {
  let best = 0;
  for (const row of rows) {
    let cur = 0;
    for (const ch of row) {
      if (ch === '3' || ch === '4') { cur++; if (cur > best) best = cur; } else cur = 0;
    }
  }
  return best;
}
/** horizontal span of opaque art across the top `n` rows (pauldron width incl. torso) */
function maxSpan(rows: string[]): number {
  let best = 0;
  for (const r of rows) {
    let x0 = -1, x1 = -1;
    for (let x = 0; x < r.length; x++) if (r[x] !== '.') { if (x0 < 0) x0 = x; x1 = x; }
    if (x0 >= 0) best = Math.max(best, x1 - x0 + 1);
  }
  return best;
}

export function assertTraceMatch(minIoU = 0.85, minFamily = 0.9): TraceMatchResult {
  const r = runTraceMatch({ dumpImages: true });
  const bad = r.regions.filter((g) => g.agree < minFamily);
  if (r.iou < minIoU) throw new Error(`assertTraceMatch FAILED: silhouette IoU ${r.iou.toFixed(4)} < ${minIoU} (shift ${r.shift}) - see shots/trace_match_align.png`);
  if (bad.length) throw new Error(`assertTraceMatch FAILED: region family agreement ${bad.map((g) => `${g.name}=${g.agree.toFixed(3)}`).join(', ')} < ${minFamily}`);
  if (r.beltTrace !== r.beltTorso) throw new Error(`assertTraceMatch FAILED: belt width trace=${r.beltTrace} vs torso art=${r.beltTorso}`);
  if (r.pauldronTrace !== r.pauldronTorso) throw new Error(`assertTraceMatch FAILED: pauldron span trace=${r.pauldronTrace} vs torso art=${r.pauldronTorso}`);
  return r;
}

if (process.argv[1] && process.argv[1].endsWith('trace_match.ts')) {
  const r = runTraceMatch({ dumpImages: true });
  console.log(JSON.stringify(r, null, 2));
}
