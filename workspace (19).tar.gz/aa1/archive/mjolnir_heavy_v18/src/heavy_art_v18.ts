/**
 * FROZEN ARCHIVE - HEAVY set "MJOLNIR MK VI" (Master Chief silhouette benchmark), art as of v18.
 * Archived 2026-09-30 (v19): the game ships a single set (ROOKIE MERC); this file is a frozen
 * record and is NOT compiled (tsconfig includes only src/ and tools/). DO NOT EDIT.
 *
 * Restore procedure (if ever needed): merge ranges back into src/game/hero_art.ts (art consts +
 * HEAVY_PAL + ARMOR_SETS entry), re-add tools/trace_match.ts + src/game/ref_replica.ts from this
 * archive, re-wire tools/hero_bench_v18.ts / game_vs_bench_v18.ts / qa_aa1_v18.ts. Expect manual
 * adaptation: active src will have moved on (style change planned).
 *
 * Metrics at freeze: assertTraceMatch IoU 0.8732 (regions head 1.000 / torso 0.913 / arms 0.913 /
 * legs 0.920, belt 7/7, pauldron 30/30); assertGameEqualsBench IoU 0.9953; npm run qa ALL GREEN.
 */
import { rgba } from '../../src/core/buf.js';

export function row(w: number, ...segs: [number, string][]): string {
  const a = new Array<string>(w).fill('.');
  for (const [x, s] of segs) {
    for (let i = 0; i < s.length; i++) a[x + i] = s[i];
  }
  return a.join('');
}
const rep = (n: number, ch: string) => ch.repeat(n);

// ---------------------------------------------------------------- HEAVY @40 px/m hand-authored parts (v16/P1)
// Geometry/masses taken from ref_trace @40; game-read rules: <=4 tones per material + 1 highlight,
// ink outline at mass joints, clean plate edges, trace palette family preserved.
const r40h = (...segs: [number, string][]) => row(19, ...segs);
export const HELMET40_UP: string[] = [
  r40h([8, '88']),
  r40h([5, '77888877']),
  r40h([3, '7766666677']),
  r40h([2, '76666666667']),
  r40h([1, '7666666666667']),
  r40h([1, '76666666666667']),
  r40h([1, '75555555555557']),
  r40h([1, '34'], [3, 'nnnnnnnnnn'], [13, '43']),
  r40h([1, '34'], [3, 'n'], [4, 'vveeeeeeee'], [12, 'n'], [13, '43']),
  r40h([1, '34'], [3, 'n'], [4, 'eeeeeeeeee'], [12, 'n'], [13, '43']),
  r40h([1, '34'], [3, 'nnnnnnnnnn'], [13, '43']),
  r40h([1, '34'], [3, '5555555555'], [13, '43']),
  r40h([1, '66555555555566']),
  r40h([1, '66657722775666']),
  r40h([2, '66655555666']),
  r40h([3, '666666666']),
  r40h([4, '6666666']),
];
export const HELMET40_PROFILE: string[] = [
  // v17 P2: verbatim mirror of REPLICA_40 rows 0..9 (cols 14..29, reversed) so the profile
  // helmet IS the trace head pixel-for-pixel in the low-ready pose; interior gaps filled '5'.
  r40h([7, '9877789']),        // r0 = trace 0
  r40h([6, '866677779']),      // r1 = trace 1
  r40h([4, '976667777779']),   // r2 = trace 2
  r40h([3, '9766667677779']),  // r3 = trace 3
  r40h([2, '96666666556769']), // r4 = trace 4
  r40h([1, '997657nnnnnn779']),// r5 = trace 5 (visor frame top)
  r40h([1, '997653nevven379']),// r6 = trace 6 (glass g0, glints v)
  r40h([1, '997653neeeen379']),// r7 = trace 7 (glass g1 solid)
  r40h([1, '997657nnnnnn779']),// r8 = trace 8 (visor frame bottom)
  r40h([3, '9963nnnnn378']),   // r9 = trace 9 (jaw line)
];export const HELMET40_DOWN: string[] = [
  r40h([4, '88777777']),
  r40h([3, '766666667']),
  r40h([2, '76666666667']),
  r40h([1, '7666666666667']),
  r40h([1, '7666666666667']),
  r40h([1, '7666666666667']),
  r40h([1, '7666666666667']),
  r40h([1, '75555555555557']),
  r40h([1, '34'], [3, 'nnnnnnnnnn'], [13, '43']),
  r40h([1, '34'], [3, 'n'], [4, 'veeeeeeee'], [12, 'n'], [13, '43']),
  r40h([1, '34'], [3, 'n'], [4, 'eeeeeeeeee'], [12, 'n'], [13, '43']),
  r40h([1, '34'], [3, 'nnnnnnnnnn'], [13, '43']),
  r40h([1, '66555555555566']),
  r40h([2, '66657775666']),
  r40h([3, '666666666']),
  r40h([4, '6666666']),
  r40h([5, '66666']),
];
export const TORSO40_HEAVY: string[] = [
  row(37, [14, '6555565769'], [26, '6279']), // r0 = trace 10 (+ v18: shoulder tip = mirror trace c9-12)
  row(37, [14, '4255555524'], [24, '995578']), // r1 = trace 11 (+ v18: shoulder tip = mirror trace c9-14)
  row(37, [14, '6555122212'], [24, '5667779']), // r2 = trace 12 (+ v18: shoulder tip = mirror trace c8-14)
  row(37, [12, '955552112125567677679']), // r3 = trace 13
  row(37, [6, '596113555211111255666476667855']), // r4 = trace 14
  row(37, [6, '975112666111125666753366666795']), // r5 = trace 15
  row(37, [6, '962116776522556667763112666795']), // r6 = trace 16
  row(37, [6, '861116666555666667632111676785']), // r7 = trace 17
  row(37, [6, '851116666555666667631111266679']), // r8 = trace 18
  row(37, [6, '821116665525566677631111156669']), // r9 = trace 19
  row(37, [5, '5928886525535525666631112888675']), // r10 = trace 20
  row(37, [5, '5965215255525522566311112677685']), // r11 = trace 21
  row(37, [5, '5565216625552225566511112267779']), // r12 = trace 22
  row(37, [5, '5562115512552222256611112257778']), // r13 = trace 23
  row(37, [5, '5952112155555555156662221226668']), // r14 = trace 24
  row(37, [5, '5552112126525551215552211122667']), // r15 = trace 25
  row(37, [5, '5561111126212522222222111112226']), // r16 = trace 26
  row(37, [5, '5821111136311123231111133111116']), // r17 = trace 27
  row(37, [6, '211111164652123243111343311']), // r18 = trace 28
  row(37, [6, '511121246666256475613446312']), // r19 = trace 29
  row(37, [6, '521156765656666222254443115']), // r20 = trace 30
  row(37, [6, '221157756655667776534442126']), // r21 = trace 31
  row(37, [6, '211156556666566222264431256']), // r22 = trace 32
  row(37, [6, '211112125555111233334421556']), // r23 = trace 33
  row(37, [6, '211116325552111222234615665']), // r24 = trace 34
  row(37, [6, '112134325551112323344216777']), // r25 = trace 35
  row(37, [6, '115154325221113333343122779']), // r26 = trace 36
  row(37, [6, '115513212211133443223111275']), // r27 = trace 37
  row(37, [6, '116611111111243443324215455']), // r28 = trace 38
  row(37, [6, '116611111111434433346395555']), // r29 = trace 39
  row(37, [6, '116551111113334331163695555']), // r30 = trace 40
  row(37, [6, '796551111124344311126685555']), // r31 = trace 41
  row(37, [7, '57551111143443311127785']), // r32 = trace 42
  row(37, [7, '56521113344444222267775']), // r33 = trace 43
  row(37, [7, '56611113344544115567775']), // r34 = trace 44
  row(37, [7, '96611211344443115562779']), // r35 = trace 45
  row(37, [7, '95511211234441112562779']), // r36 = trace 46
  row(37, [7, '95211213313443112552679']), // r37 = trace 47
  row(37, [7, '85521211334413115552679']), // r38 = trace 48
];
export const THIGH40_HEAVY: string[] = [
  row(15, [1, '566666675']),
  row(15, [1, '566666675']),
  row(15, [1, '566666675']),
  row(15, [1, '566666675']),
  row(15, [2, '56666675']),
  row(15, [2, '56666675']),
  row(15, [2, '56666675']),
  row(15, [2, '56666675']),
  row(15, [2, '56666675']),
  row(15, [2, '56666675']),
  row(15, [1, '567777775']),
  row(15, [1, '567777775']),
  row(15, [1, '567777775']),
  row(15, [1, '522222275']),
  row(15, [1, '566666675']),  // v17: knee gap = 1 gunmetal row
];
export const SHIN40_HEAVY: string[] = [
  row(12, [1, '5555555']),
  row(12, [1, '5667765']),
  row(12, [1, '56667765']),
  row(12, [1, '56667765']),
  row(12, [1, '56667765']),
  row(12, [1, '56667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5667765']),
  row(12, [2, '5222265']),  // v17: knee seam = 1 deep-green row (trace family)
  row(12, [2, '5555565']),
  row(12, [2, '5555565']),
  row(12, [2, '5555565']),
];
export const BOOT40_HEAVY: string[] = [
  row(13, [1, '5665']),
  row(13, [1, '5677665']),
  row(13, [0, '566777665']),
  row(13, [0, '566777665']),
  row(13, [0, '5666622225']),
  row(13, [0, '2222222222']),
];
export const UPARM40_HEAVY: string[] = [
  row(9, [1, '57775']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '52265']),
  row(9, [1, '52265']),
  row(9, [1, '52225']),
];
export const FOREARM40_HEAVY: string[] = [
  row(9, [1, '55555']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '52225']),
  row(9, [1, '52225']),
  row(9, [1, '52225']),
];
export const UPARMS40_HEAVY: string[] = [
  row(9, [1, '57775']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '52265']),
  row(9, [1, '52265']),
  row(9, [1, '52225'])
];
export const FOREARMS40_HEAVY: string[] = [
  row(9, [1, '55555']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '56765']),
  row(9, [1, '52225']),
  row(9, [1, '52225']),
  row(9, [0, '5222225'])
];
// v17 P1/P2: gauntlets are GREEN armor family (ref trace rows 44-51: chars 5/6/7/8/9 on both
// hands); gunmetal stays only in the joint seams. '5' ring = green shadow outline.
export const FIST40: string[] = [
  row(11, [0, '55'], [2, '67776'], [7, '5']),
  row(11, [0, '55'], [2, '67775']),
  row(11, [0, '55'], [2, '67775']),
  row(11, [0, '55'], [2, '66675']),
  row(11, [1, '56665']),
  row(11, [1, '5665']),
  row(11, [2, '55']),
];
export const SUPHAND40: string[] = [
  row(9, [1, '5775']),
  row(9, [0, '567775']),
  row(9, [0, '556775']),
  row(9, [0, '557775']),
  row(9, [1, '57775']),
  row(9, [1, '5665']),
  row(9, [2, '55']),
];
export const NECK40: string[] = [
  row(8, [1, 'hhhh']),
  row(8, [1, 'hhhh']),
  row(8, [1, 'hhhh']),
  row(8, [1, 'gghh']),
  row(8, [1, 'gghh']),
  row(8, [1, '1111']),
];

// ---- HEAVY = MJOLNIR Mark VI silhouette benchmark (internal; restyle before public build).
const HEAVY_PAL: Record<string, number> = {
  '2': rgba(0x1c, 0x24, 0x18), // green deep
  '3': rgba(0x2b, 0x30, 0x36), // undersuit gunmetal
  '4': rgba(0x4a, 0x52, 0x5a), // undersuit light
  '5': rgba(0x2a, 0x36, 0x24), // green shadow
  '6': rgba(0x46, 0x58, 0x3c), // green base
  '7': rgba(0x6a, 0x7f, 0x52), // green light
  '8': rgba(0x8a, 0x9a, 0x70), // green highlight (+1 value, top edges)
  '9': rgba(0x8a, 0x9a, 0x70), // knuckle/buckle light green
  a: rgba(0x46, 0x58, 0x3c),   // gloves green
  b: rgba(0x6a, 0x7f, 0x52),
  e: rgba(0xff, 0xd2, 0x7a),   // visor amber-gold
  n: rgba(0xc8, 0x87, 0x1e),   // visor rim
  v: rgba(0xff, 0xf2, 0xc0),   // visor specular 1px
};
// Helmet 14x13: rounded dome, flat-ish top, dark brow ridge over the visor, amber visor band at
// mid-face with 1px rim + 1px specular top-left, green chin with light line, gunmetal ear intakes
// with light dots at the sides. Profile: dome depth at the back, shorter visor, ear disc.
const HEAVY_HELMET: Record<HeadOrient, string[]> = {
  // Front: flat-top dome with raised crown panel (H frame), side facet S-columns, brow shadow,
  // amber visor in a fused intake frame with rim+specular, cheek shadow, chin light line with a
  // dark chin-vent block in the center.
  up: [
    '......88......', // y0  narrow raised crown strip (1-2 px), integrated
    '...77888877...', // y1  plateau + strip base blended into the dome
    '.76686668667..', // y3  crown bottom frame + facet start
    '.656666666656.', // y3  side facet S-columns
    '.655555555556.', // y4  BROW shadow ridge
    '.34nnnnnnnn43.', // y5  frame TOP around the glass
    '.34neveeeen43.', // y6  glass g0: solid e + v at (g0,c0+1)
    '.34neeeeeen43.', // y7  glass g1: solid e only
    '.34nnnnnnnn43.', // y8  frame BOTTOM
    '.665555555566.', // y9  cheek shadow
    '.666572275666.', // y10 chin light line + dark chin-vent
    '..6665555666..', // y11 taper
    '...66666666...', // y12 neck joint (covers neck)
  ],
  // Profile: brow OVERHANGS the visor by 1-2 px; visor = slanted wedge (top row forward under the
  // brow, bottom row receding into the jaw), rim v on the BACK edge, specular on top; angular jaw
  // plate sloping down-back; occiput sloped with an H-ridge along the top-back; ear disc fused.
  profile: [
    '...777777.....', // y0  FLAT plateau top (no dome arc), slight forward lean
    '..77777777....', // y1  plateau widens forward
    '.7766666677...', // y2  plateau edge into brow mass
    '.7666666667...', // y3
    '776666666677..', // y4  STRONG angular brow, overhang tip x11-12
    '775555nnnnn7..', // y5  brow + frame TOP (c0-1..c1+1)
    '766346neven7..', // y6  wedge glass g0: v at (g0,c0+1), frame sides n
    '766346neeen7..', // y7  wedge glass g1 solid e
    '766346nnnnn7..', // y8  frame BOTTOM into jaw
    '77655566777...', // y9  angular jaw + rear vent ridge x0-1
    '.766557777....', // y10 jaw light line; occiput plane recedes
    '..76655566....', // y11 slanted occiput plane down to neck
    '...7666667....', // y12 neck hidden
  ],
  // Down: dome mass + crown hint + low visor band with rim, intakes at the sides.
  down: [
    '......88......', // y0  narrow crown strip
    '...77888877...', // y1  plateau + strip base
    '..7766666677..', // y2  dome
    '.76666666667..', // y2
    '.656666666656.', // y3
    '7666666666667.', // y4
    '7666666666667.', // y5
    '7666666666667.', // y6
    '7655555555567.', // y7  brow low
    '76nnnnnnnnnn67', // y8  frame TOP
    '76neveeeeeen67', // y9  glass g0 + v at (g0,c0+1)
    '76neeeeeeeen67', // y10 glass g1 solid
    '76nnnnnnnnnn67', // y11 frame BOTTOM
    '.66655555666..', // y12 chin light
    '..666666666...', // y12
  ],
};
// Torso 28x22 by the reference mass-map: trap plates + gunmetal neck gap (rows 0-1); ANGULAR
// pauldrons with top edge sloped down-outward + H (rows 2-6); CHEST-LOCK raised block x12-15 with
// dark frame (rows 3-5); pectorals with H edges sloped down-outward from the lock + center groove
// (rows 6-10); belly: DARK ribbed undersuit center x11-16 framed by green oblique side plates
// (rows 11-14); gunmetal waist row 15 (V-taper); pelvis: raised codpiece x12-15 + side plates
// sloped in-down, leg gap y20-21.
const hrow = (...segs: [number, string][]) => row(28, ...segs);
// 3/4 CHEST view, 28 wide: BACK zone x0-8 plain darker plate with ONE vertical H ridge (back plate);
// MID zone x9-18 armor wrap with seam shadows; FRONT zone x19-27: chest-lock + pectorals + belly
// ribs + codpiece. Angular pauldrons top both zones; V-taper to the gunmetal waist.
const HEAVY_TORSO: string[] = [
  hrow([1, '7888887'], [12, '3443'], [20, '7888887']),                                       // y0  pauldron tops + neck gap
  hrow([2, '7666667'], [12, '3443'], [21, '7666667']),                                       // y1
  hrow([0, '7667777766665566666667666667']), // y2  chest top H front
  hrow([0, '7667777765665566656667677776']), // y3  back ridge + seams
  hrow([0, '7666778865664444656667677776']), // y4  lock frame top + pect H
  hrow([0, '6677277665774774656667677776']), // y5  lock + groove
  hrow([0, '6677277665774774656667677776']), // y6
  hrow([0, '6677267765774444656'], [20, '6767776']), // y7  lock bottom
  hrow([0, '6677267765776666656'], [21, '76776']), // y8
  hrow([0, '6677267765776666656'], [21, '7676']), // y9
  hrow([0, '5566266555556666656'], [21, '767']), // y10 chest shade
  hrow([1, '666666665666666656']),  // y11 belly ribs front-center
  hrow([1, '665555565666666656']),  // y12 rib groove 1
  hrow([1, '666666665666666656']),  // y13
  hrow([1, '665555565666666656']),  // y14 rib groove 2
  hrow([7, '34444444443']),                                                                  // y15 WAIST gunmetal (V-taper)
  hrow([3, '6687785556666656']),     // y16 codpiece FRONT + H
  hrow([3, '6667765556666656']),     // y17
  hrow([3, '6667765556666656']),     // y18
  hrow([5, '6676555666665']),       // y19 taper
  hrow([9, '666'], [14, '6666']),                                                             // y20 leg split (gap opens down)
  hrow([9, '666'], [15, '666']),                                                              // y21
];

export const ARMOR_SET_ENTRY_HEAVY_V18 = {
  id: 'heavy', name: 'HEAVY / MJOLNIR MK VI BENCH',
  torso: HEAVY_TORSO, torsoAnchor: [-14, -45],
  pack: null, packOff: [0, 0],
  helmet: HEAVY_HELMET, helmOff: [-7, -58],
  thigh: HEAVY_THIGH, shin: HEAVY_SHIN, boot: HEAVY_BOOT,
  uparm: HEAVY_UPARM, forearm: HEAVY_FOREARM,
  uparmS: HEAVY_UPARM_S, forearmS: HEAVY_FOREARM_S,
  pal: HEAVY_PAL,
  arts40: {
    torso: TORSO40_HEAVY, neck: NECK40,
    heads: HELMET40_UP ? { up: HELMET40_UP, profile: HELMET40_PROFILE, down: HELMET40_DOWN } : { up: HELMET40_UP, profile: HELMET40_PROFILE, down: HELMET40_DOWN },
    helmet: { up: HELMET40_UP, profile: HELMET40_PROFILE, down: HELMET40_DOWN },
    thigh: THIGH40_HEAVY, shin: SHIN40_HEAVY, boot: BOOT40_HEAVY,
    uparm: UPARM40_HEAVY, forearm: FOREARM40_HEAVY, uparmS: UPARMS40_HEAVY, forearmS: FOREARMS40_HEAVY,
    fist: FIST40, suphand: SUPHAND40,
    pal: HEAVY_PAL,
    meta: {
      k: 4 / 3,
      thighLen: 13, shinLen: 12, uparmLen: 15, forearmLen: 10,
      uparmSLen: 19, forearmSLen: 16,
      thighP: [5, 0], thighD: [5, 13], shinP: [4, 0], shinD: [4, 12], bootP: [3, 0],
      uparmP: [3, 1], uparmD: [3, 16], forearmP: [3, 0], forearmD: [3, 10],
      uparmSP: [3, 1], uparmSD: [3, 20], forearmSP: [3, 0], forearmSD: [3, 16],
      fistP: [3, 4], supP: [3, 4],
      hipF: [5, -30], hipB: [-7, -31],
      // v17 P1/P2: taller authored torso (39 rows, traced from REPLICA_40): raise the upper
      // stack so pauldron top / helmet land on the trace rows; hips & legs untouched.
      torsoA: [-17, -67], neckA: [-4, -70], headA: [-8, -78], helmA: [-7, -78], // v17: profile helm = trace rows 0..9 mirror, r40h 19-wide (flip: dx+18-c == 104+(29-c) => dx=105-2)
      shF: [11, -62], supIk: [-11, -62],
      wristD: 11, wristUp: 9, wristDown: 15, footK: 4 / 3,
    },
  },
};
