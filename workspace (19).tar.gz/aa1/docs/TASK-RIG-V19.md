# TASK-RIG-V19 — консервация HEAVY/MJOLNIR в архив, один сет в игре, готовность к смене стиля

Дата: 2026-09-30. Статус: **доставлено**.
Триггер: визуальная ревизия сета Мастера Чифа (оценка 4/5, слабая зона — грудь в фас) и решение
пользователя: *«ничего не доводить, закинь сет мастера чифа в архив, место где не будет трогаться;
подготовься к тому что будем менять стиль; оставь только один сет — базовый сет наёмника»*.

## 1. Что сделано

### 1.1 Архив (нетронутое место): `archive/mjolnir_heavy_v18/`
- `src/heavy_art_v18.ts` — весь арт HEAVY verbatim: части @40, HEAVY_PAL, 30px-арт, полный
  entry-объект сета (`ARMOR_SET_ENTRY_HEAVY_V18`);
- `src/ref_replica_v18.ts` — трейсы референса REPLICA_30/36/40;
- `src/hero_scale_v18.ts` — генератор v18 с heavy-ветками и genHelmet;
- `tools/{trace_match,hero_bench,game_vs_bench,qa_aa1}_v18.ts` — замороженные инструменты v18;
- `shots/` — 21 heavy-лист v18 (trace_vs_rig, bench_heavy40, hero_chief*, ref_trace, ...);
- `README.md` архива: статус FROZEN, метрики на заморозке (trace IoU 0.8732, game==bench 0.9953),
  процедура восстановления, юридическая пометка про рестайл до публики.
- Каталог не компилируется: `tsconfig.json` включает только `src/` и `tools/`.

### 1.2 Активная кодовая база: один сет ROOKIE MERC
- `src/game/hero_art.ts`: удалены HEAVY-диапазоны (части @40, HEAVY_PAL/30px-арт, entry в
  `ARMOR_SETS`); `ARMOR_SETS` = [rookie].
- `src/game/hero_scale.ts`: сигнатура `buildScaleArts(pxm)`; heavy-ветки генераторов и genHelmet
  удалены (helmet в scale-артах более не генерируется, `helmet: null`).
- `src/game/hero.ts`: `getArts40` → ROOKIE40 для единственного сета; вызов buildScaleArts обновлён.
- `src/game/pose_editor.ts`: set всегда 'rookie'.
- `tools/game_vs_bench.ts`: без шага [B]; ожидает rookie; дампы переименованы
  (`game_rookie40.png`, `bench_rookie40.png`, `game_rookie40_crop4x.png`).
- `tools/qa_aa1.ts`: trace-ассерт снят из QA (уехал в архив вместе с сетом); перманентный
  game==bench перенацелен на rookie@40 (`v19 P0`); проверок 9.
- `tools/hero_bench.ts`: удалены heavy/trace-секции (trace_vs_rig, visor micro-spec, ref trace,
  MJOLNIR-лист, chief-дампы, heavy-toast); все листы пересобраны только для ROOKIE
  (parts40, rig40, sets, silhouette, angles, scale bench, idle-scaled).
- Горячая клавиша [B] оставлена (контракт по хоткеям): с одним сетом циклит в себя, тост
  показывает имя единственного сета — поведение безопасное, детерминизм не затронут.

## 2. Проверки

| проверка | результат |
|---|---|
| Контрольный снимок: сгенерированные арты ROOKIE 36/40 (14 арт-массивов + meta + helmet-nullness) до и после чистки hero_scale | **IDENTICAL** (побайтово, md5 по каждому арту) |
| `npx tsc --noEmit` | чисто |
| `npm run qa` | ALL GREEN, 9 проверок; replay побайтово; `v19 P0: game==bench rookie@40 IoU=0.9941 set=rookie` |
| `tools/hero_bench.ts`, `tools/headless.ts`, `tools/contact_sheet.ts` | перегенерированы (shots/, 15 кадров contact) |
| `grep heavy` в `src/`, `tools/` | 0 вхождений (кроме архивных копий и комментариев-указателей на архив) |

## 3. Готовность к смене стиля (карта точек входа)

Когда придёт задача нового стиля, правки локализованы в:

1. `src/game/hero_art40_rookie.ts` — рукописные части ROOKIE @40 (основной боевой масштаб).
2. `src/game/hero_art.ts` — 30px-арт ROOKIE, `HERO_PAL`/`SKIN_VARIANTS`, арт оружия `GUNS`,
   интерфейс `ArmorSet` (точка подключения будущих сетов через `arts40`).
3. `src/game/hero_scale.ts` — генератор bench-масштаба 36 px/m (только листы).
4. `src/game/hero.ts` — bake-пайплайн: `bake()`, `makeBone()` (тени/контуры костей), порядок блитов.
5. `src/core/palette.ts` + `tools/palettes/`, `tools/bake_aa1_ground.py` — палитры мира/земли.

Инварианты, которые смена стиля не должна ломать: детерминизм replay, `assertNoInteriorHoles`,
`assertGameEqualsBench` (rookie@40), контракт метр-пространства геймплея, таблицы ходьбы 8 ключей.

## 4. Самопроверка (чек-лист)

- [x] арт/трейсы/инструменты HEAVY вынесены в архив verbatim, архив не компилируется;
- [x] в `src/`/`tools/` нет активных heavy-ссылок; entry сета удалён из `ARMOR_SETS`;
- [x] rookie-арт побайтово равен до-чисточному (контрольный снимок);
- [x] QA зелёный, перманентный ассерт game==bench сохранён (rookie@40);
- [x] все листы/shots перегенерированы под один сет; heavy-листы уехали в архив;
- [x] временные инструменты удалены (`tmp_*` отсутствуют);
- [x] docs + README обновлены; `/home/user/aa1.zip` пересобран с архивом.
