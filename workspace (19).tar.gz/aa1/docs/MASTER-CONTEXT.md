# PALE MERIDIAN — Master Context (SCI-FI 2D Action RPG / Procedural World)

> Source: `uploads/MASTER_CONTEXT.txt` (converted to Markdown, structure preserved).
> This is a master document: extend on request, do not rewrite silently.

## 0. Role

You are working on a long-term project of an original 2D sci-fi action RPG/slasher with a procedurally generated world.

This is not just a demo of procedural generation and not a usual top-down RPG prototype. The main goal of the project is to create a large living sci-fi world in which environment, buildings, settlements, factions and items look logical, diverse and have a history.

## 1. General concept of the game

Genre:
- 2D sci-fi action RPG / slasher;
- exploration;
- real-time combat;
- dungeons;
- settlements;
- planet exploration;
- factions;
- procedurally generated world;
- interactive environment;
- destructible architecture.

The main character is an ordinary mercenary working on the fringes of civilization.

He is not "chosen", not a god, not a super-important hero of the world.

The world must exist independently of him.

The player travels through various systems, planets, moons, stations, settlements, industrial sites and other places.

Core feeling:
- huge living world;
- technological frontier;
- different cultures and factions;
- sense of real space;
- buildings and settlements must look built by people/creatures with concrete needs;
- objects must have a history;
- the world must not look like a set of identical procedural blocks.

## 2. Scale of the world

Generation is designed as a multi-level system:

STAR SYSTEM → PLANETS / MOONS / LARGE OBJECTS → COLONIZED / INHABITED WORLDS → FACTIONS / POLITICAL TERRITORIES → REGIONS → SETTLEMENTS / OUTPOSTS / STRATEGIC STRUCTURES → LANDSCAPE / ROADS / TERRAIN → BUILDINGS → INTERIORS / ROOMS / OBJECTS → MICRO DETAILS

Each next level must inherit the context of the previous one.

Example:
- system → defines the general context of the world
- planet → climate / resources / development level
- faction territory → technology / wealth / architectural style / materials
- region → local features
- settlement → function / population / infrastructure
- building → purpose / age / history
- interior room → function / equipment / condition / current activity

## 3. Factions and context

Factions differ not only in color. They may differ in:
- technology level; wealth; access to resources; materials;
- architectural culture; infrastructure; attitude to repair; construction standards;
- industrial level; political situation; attitude to others; degree of militarization; character of settlements.

Example: one territory may have high-tech clean buildings, automation, standardized panels, good lighting, developed infrastructure. Another: cheap materials, old tech, numerous repairs, self-made structures, mix of old and new. Third: military architecture, fortifications, airlocks, checkpoints, engineering corridors.

Therefore architecture must depend on context, not pick an external style at random.

## 4. History of the world

Very important principle: OBJECTS MUST HAVE A HISTORY.

History may include: year of construction; original owner; changes of owner; reconstruction; expansion; repurposing; repair; equipment replacement; technological obsolescence; lack of resources; damage; accidents; abandonment; temporary solutions; re-settlement.

History must influence the visual result.

Example: old building → later expanded → later cheap repair → part of equipment replaced → several rooms repurposed → new extension appeared → old elements preserved. Therefore a building must not look completely uniform.

## 5. Important principle of procedural generation

The goal is not maximum randomness. The goal: CONTROLLED VARIETY.

Generation must produce different results but preserve:
- functional logic; architectural plausibility; visual integrity; technological compatibility; context.

You cannot just place 10 decorative objects at random. Each object must have a reason to be exactly there.

## 6. Visual style

The game must remain 2D pixel art.

Main visual references: CrossCode; UNSIGHTED; Hyper Light Drifter; Eastward; Cortex Command; Fallout 2 as an additional analogy for the sense of space.

We need modern quality pixel art, not deliberately rough "retro graphics".

Important:
- high visual density; clear forms; well-readable materials; deliberate pixel clusters;
- limited and controlled palette; no blur; no anti-aliasing; no soft vector-like graphics; no random noise textures.

The image must be detailed but not visually noisy.

## 7. Camera

Camera: 2D; tilted orthographic / top-down 3/4; not strict isometric; spatially similar in feeling to CrossCode / UNSIGHTED; walls have a small lean/batter; camera must allow zooming the scene in and out.

Current production foundation: 640 × 360; 30 px / meter.

Current camera benchmark is based approximately on: pitch ≈ 36°; azimuth ≈ 0°; small wall lean ≈ 2°. These parameters are the current production base. Do not change the camera without necessity.

## 8. Main idea of architecture

Buildings in the game must NOT be generated as a set of square tiles. Free geometry with semantic connections is used.

Conceptual hierarchy: BUILDING → STRUCTURAL / MACRO MODULES → SUBMODULES → MICRO DETAILS.

But visually a building must be perceived as integral architecture. Modules are needed for generation and reuse, but: MODULE BOUNDARY ≠ VISIBLE SEAM. Neighboring modules may technically exist separately, but in the image a wall must look continuous if there is no real architectural seam there.

## 9. Asset ≠ PNG

Production asset is not just an image. An asset must be described through data/code.

An object may have: semantic identity; functional role; geometry; collision geometry; ports; anchors; boundary semantics; visual definition; materials; variants; states; shadow definition; destruction definition; generation parameters; seed; metadata.

A structural asset may have semantic boundaries: interior; left_edge; right_edge; front_edge; back_edge; outer_corner; inner_corner; end_cap; roof_edge; roof_corner; transition; junction. This is needed so the generator understands where the object is inside the system and where the architecture ends.

## 10. Ports and anchors

Use semantic connection ports and functional anchors. Ports are responsible for architectural connection.

Anchors may describe: door; window; light; pipe; cable; equipment; ventilation; service zone; other functional elements.

Important principle: details must be placed taking already occupied areas into account. Not allowed: pipe through a window; panel over a door; fan in a wall without a proper place; equipment over a passage; random intersections.

## 11. Building and its generation

A building must be generated STAGE BY STAGE. Main pipeline:

A — PLAN; B — STRUCTURAL SHELL; C — DOORS / PASSAGES; D — WINDOWS / OPENINGS; E — ROOF / VERTICAL ARCHITECTURE; F — ARCHITECTURAL DETAILS; G — INTERIOR; H — EXTERIOR / LANDSCAPE / PROPS; I — HISTORY / CONDITION / WEAR / DAMAGE; J — LIGHTING / SHADOWS / FINAL SCENE.

Everything must not be merged into one generator. Reason: if everything is created at once, it is impossible to understand which stage creates an error.

## 12. Stage A — building plan

First an abstract semantic BuildingPlan is created. It defines: footprint; external form; rooms; room purposes; connections between rooms; circulation; entrances; potential doors; potential windows; levels; large architectural masses; core; wings; connectors; service zones; other semantic structures.

The plan must not be just a grid. Supported: rectangular; L-shaped; T-shaped; stepped; split mass; courtyard; central core; linear spine; hall band; detached service; tower core; composite forms.

There are modern/futuristic room types: airlock; core; shaft; connector; machine; and ordinary functional rooms.

## 13. Current state of Stage A

The project already has a BuildingPlan / ContextProfile / BuildingHistoryProfile system and related generators. An architectural concept layer was also created. Different types of building organization exist: linear_spine; hall_band; central_core; courtyard; split_mass; detached_service; stepped_mass; tower_core. A benchmark of futuristic plans was done. In particular plan F07 exists; it is chosen as the current benchmark for Stage B.

## 14. Stage B — structural shell

At the current stage the main focus: PLAN → STRUCTURAL SHELL. Before creating the shell a separate stage is needed: B0 — PLAN OVERLAY.

On the landscape are displayed: LANDSCAPE + F07 PLAN. The overlay shows: footprint; room boundaries; main structural boundaries; core/spine/wing structures; circulation; potential entrance markers; potential window markers.

This must be the same world-space geometry that is later used for shell generation. You must not create an approximate copy of the plan specially for the overlay.

## 15. B1 — structural shell

After the overlay, from the same F07 are created: foundation; outer walls; inner walls; room boundaries; floors; levels; necessary structural supports; corners; junctions; stepped masses; structural transitions.

Not yet created: doors; windows; roof; panels; pipes; ventilation; furniture; generators; containers; vehicles; clutter; vegetation; wear; damage; decorative elements. If the plan contains a future door/window, at Stage B it is only a reserved zone.

## 16. Plan — source of truth

Very important principle: BUILDING PLAN = SOURCE OF TRUTH. The shell must not be "approximately similar" to the plan. Must hold: PLAN GEOMETRY → STRUCTURAL GEOMETRY. That is: footprint of the plan = footprint of the shell; rooms of the plan = corresponding structural areas; connectivity of the plan = connectivity of the structural shell.

## 17. Internal logic of the building

The building must not only be beautiful outside. Must be preserved: circulation; reachability; functionality of rooms; neighborhood of rooms; logic of passages; logic of service zones; architectural logic. You must not get a beautiful building whose rooms are randomly disconnected inside.

## 18. Roof

Roof is a separate architectural system. It must be built AFTER the structural shell. You must not just overlay one big plane on top.

The roof must take into account: real footprint of the building; different masses; L-shaped junctions; stepped sections; heights; transitions between sections; structural logic; access to the roof.

Especially important: if a building has L/zigzag/composite form, the roof must really connect these masses architecturally. There must be no visual gap of the roof at a junction.

## 19. Walls

Walls must look like real architecture. Important: surface continuity; correct angles; real junctions; correct edges; end caps; structural termination; correct thickness.

You must not use random vertical columns between every procedural segment. Supports must appear where they are architecturally justified.

## 20. Windows and doors

Windows and doors must not be decals. They are part of the architecture.

Window: wall → structural opening → frame → window system.
Door: wall → opening → threshold / entry transition → door / gate.

Doors and garage gates must be positioned relative to the ground and have a normal threshold/step, not "hang" at the foundation level.

## 21. Roof ≠ floor ≠ ground

It is very important to visually separate: ground; floor; foundation; roof; roof deck; top surface of machinery; top surface of containers. You must not use the same visual language of surface for everything. For example the top of a generator must not look like a piece of concrete floor.

## 22. Microdetails

Detailing must be semantic. Not to do: random pixel noise; uniform spots; identical rust on all objects; random wires; repeating stencils; decorative pixel camouflage.

Wear must tell a story. Example: rust → seams / exposed metal / drainage / damaged areas; dirt → ground contact / recesses / under overhangs; paint wear → edges / contact areas / service zones; repairs → local mismatched panels; drips → rare directional events. Clean areas must also exist.

## 23. Landscape

Landscape must not be just a flat color fill. Needed: large forms; medium forms; small details; disturbed ground; building pads; terrain transitions; paths; rocks; debris; foreground/background structure; functional zones around buildings.

Especially important: the building must really "stand" in the landscape. Foundation, threshold, surrounding ground and paths must be perceived as a single scene.

## 24. Destruction

Destruction must be hybrid. Different levels are required:

1. MATERIAL / VISUAL: holes; damaged surfaces; broken panels; localized destruction.
2. COMPONENT: doors; panels; machines; equipment; structural components.
3. STRUCTURAL: damaged supports; dependency graph; collapse; roof failure; falling structures.

You must not build destruction only on pixel-damage, nor limit it to replacing the object with a "broken variant". In perspective a connection between visual damage and the structural graph is needed.

## 25. Shadows and lighting

Shadows must depend on the scene, not be just drawn PNGs. Conceptually: SCENE GEOMETRY → GLOBAL LIGHT → CAST SHADOWS → CONTACT SHADOW / AO → OCCLUSION → PIXEL RASTERIZATION / STYLIZATION.

That is the system must compute shadows from object geometry and light, then translate the result into the pixel-art visual language. Shadows must be consistent between: buildings; objects; characters; landscape.

## 26. Technical philosophy

Preferred: data-driven; deterministic generation; seed-based; reusable generators; semantic systems; modular architecture; validation; benchmarks.

Do not create a new parallel framework if the needed system already exists. First study the existing architecture of the project. Change existing APIs minimally and compatibly.

## 27. Current production architecture

The project has a production foundation: PALE_MERIDIAN_PRODUCTION. It already has conceptual systems for: core; visual; light; shadows; destruction; assembly; frontier families; validation; benchmark; API.

There is also an asset definition / assembly system with: AssetDef; ports; anchors; roles; variants; seed; createAsset; assembleBuilding; damage. The system is built around free geometry, not a square tile grid.

## 28. Development philosophy

Work in STAGES. Do not try to solve at once: layout; walls; windows; doors; roof; furniture; decor; landscape; destruction. Each stage must have its own benchmark.

Principle: BUILD → INSPECT → VALIDATE → FIX → ONLY THEN MOVE FORWARD.

## 29. Benchmark pipeline

Main pipeline of the project: A — PLAN; B0 — PLAN OVERLAY; B1 — STRUCTURAL SHELL; C — DOORS / PASSAGES; D — WINDOWS / OPENINGS; E — ROOF / VERTICAL ARCHITECTURE; F — ARCHITECTURAL DETAILING; G — INTERIOR; H — EXTERIOR / LANDSCAPE / PROPS; I — HISTORY / CONDITION / DAMAGE; J — LIGHTING / FINAL SCENE.

At each stage it must be possible to understand the result separately.

## 30. What has already been checked

The project has performed separate camera and scale benchmarks. Current production scale: 640 × 360, 30 px / meter. It was also proven that procedural code-generated pixel-art assets can look quality and be flexible enough for further generation. A plan generation system was made. A more complex futuristic architecture concept layer was added. Various futuristic plans were generated. F07 is chosen as the benchmark for the transition from plan to architecture.

## 31. How the agent should think about the project

Do not perceive the project as: "a generator of random pixel-art buildings".

Correct model: "a procedural system that tries to model the origin and existence of a building".

That is: context → function → plan → architecture → construction → details → equipment → history → condition → lighting → visual result.

## 32. What is considered a good result

A good procedural result: diverse; functionally logical; visually integral; corresponds to context; does not look random; does not look LEGO; does not consist of obvious repeating modules; has architectural logic; has convincing transitions; may have history; is capable of being damaged; may be part of a larger world.

## 33. What is considered a bad result

Bad if: the building looks like a set of squares; random seams between modules; roof does not match footprint; windows look glued; doors hang above foundation; details intersect; surfaces look like each other; wear looks like pixel camouflage; everything is covered with the same rust; randomness replaces architectural logic; different parts of the building look made by different artists; plan and real architecture do not match.

## 34. Current task (as of AA1 handoff)

At the moment the whole game does not need to be redone. Current benchmark: F07. Current task: B0 — show F07 on the game landscape as an exact PLAN OVERLAY. Then: B1 — turn the same F07 into STRUCTURAL SHELL.

Important: first check the overlay. After that check the shell. Do not automatically move to doors, windows, roof and detailing. F07 must become proof that the pipeline BUILDING PLAN → WORLD-SPACE PLAN → LANDSCAPE OVERLAY → STRUCTURAL SHELL works correctly.

> Note (AA1 state): the playable AA1 slice (combat/loot) was built on top as a separate runtime; the F07 pipeline remains the production benchmark track. See `aa1/README.md`.

## 35. Main rule for further work

Before implementing any new large system, first:
1. study existing code;
2. find already existing types/systems;
3. do not create duplicates without necessity;
4. formulate the narrow task of the current stage;
5. implement a benchmark;
6. add validation;
7. show the visual result;
8. only after checking move to the next stage.

The main goal of the project is not just to technically generate a scene. The main goal is to achieve the feeling: "This is a real place in a real world that someone built, used, modified, repaired, and now the player has ended up here."
