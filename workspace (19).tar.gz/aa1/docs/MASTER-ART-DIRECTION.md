# PALE MERIDIAN — Master Art Direction (Original 2D Sci-Fi Action RPG / Slasher)

> Source: `uploads/MASTER_ART_DIRECTION.txt` (converted to Markdown, structure preserved).
> Covers characters, NPCs, enemies, robots, weapons, armor, clothing, gear, items, containers,
> vehicles, loot, interactive objects, landscape, nature, small exteriors, debris, activity traces,
> effects, lighting, atmosphere. Buildings/complex architecture are NOT covered here (separate system).

## 1. Visual idea

The game must look like an original, mature, modern sci-fi pixel-art world. It is NOT: generic pixel art; "old 16-bit game"; cheap retro style; a set of random sci-fi objects; acid cyberpunk; generic space opera; cartoon sci-fi; fantasy with lasers; a random set of beautiful sprites.

It must be a world on the technological frontier: advanced tech next to obsolete; expensive tech next to cheap solutions; industry next to nature; people use, repair, modify and reuse things; gear has functional purpose; weapons look like working tools, not decorative toys.

Main impression: "This is a real world of the future that has existed for a long time."

## 2. Main impression

The visual must simultaneously give four feelings: FUNCTIONAL, TACTILE, DANGEROUS, BEAUTIFUL.
- FUNCTIONAL: every detail must look like it is needed for something.
- TACTILE: materials must be visually distinguishable.
- DANGEROUS: weapons, armor, tech and environment must feel capable of really working and causing physical damage.
- BEAUTIFUL: despite all functionality the scene must remain artistically expressive.

## 3. Main visual references

Cortex Command; CrossCode; UNSIGHTED; Hyper Light Drifter; Eastward. Do NOT copy their graphics — use them as reference points:
- Cortex Command: benchmark for character readability, sprite detail, weapons, armor, tech, visual distinction of units, amount of visual information in a small sprite. Its side camera is NOT this game's camera.
- CrossCode / UNSIGHTED: top-down character readability, body forms, weapon readability, spatial placement of items.
- Hyper Light Drifter: atmosphere, expressive silhouettes, color accents, large color masses, visual storytelling, nature + old tech.
- Eastward: richness of environment, object detail, scene density, small items that make space alive.

Take principles, not appearance.

## 4. Pixel art — main rule

Pixel art must be modern and dense. Every pixel must be a meaningful part of a form.

NOT to use: anti-aliasing; blurry edges; random noise; soft vector gradients; painterly smearing; texture noise; automatic dithering; random number of shades. Do not imitate old hardware. Pixel art is an artistic language, not a limitation.

## 5. Size and readability

Production foundation: 640 × 360, 30 px / meter. Game character approximately 50–60 px tall in normal gameplay scale. Size must not be constant for everyone. Hierarchy: MAIN CHARACTER → clearest silhouette; NPC → slightly less contrast; STANDARD ENEMY → readable silhouette; LARGE ENEMY → powerful large mass; SMALL PROP → simplified silhouette.

Main rule: THE OBJECT MUST BE READ BEFORE THE PLAYER EXAMINES DETAILS.

## 6. Silhouette — first level of design

Every character must first look good as an almost black silhouette. If internal colors and details are removed, the character must still be recognizable. Same for weapons, armor, large items, robots, containers, tech. Do not start development from small details. Order: SILHOUETTE → PROPORTION → PRIMARY FORMS → MATERIALS → SECONDARY DETAILS → MICRO DETAILS.

## 7. Characters — main visual priority

Characters are one of the most important elements of the whole game. Aim for quality that in readability, saturation, detail, character design and visual conviction does not look significantly weaker than good Cortex Command sprites. This does not mean copying Cortex Command. It means: DO NOT make "a small pixel human from head, torso, arms and two legs". A character must have a full design.

## 8. Character proportions

A character must have readable: head; neck; torso; shoulders; arms; hands; pelvis; legs; shoes. Realistic anatomy is not mandatory. But anatomy must be intentional. The silhouette must show: mass; pose; equipment; movement direction; weapon position.

## 9. Clothing

Clothing must look real. Use: folds; joins; belts; fasteners; pockets; mounts; protective inserts; seams; areas of different material. But details must not be a random scatter of pixels. Each detail must have a visual function.

## 10. Armor

Armor must be a construction, not a decorative costume. Example chain: helmet → visor → neck protection → shoulder plates → chest plate → abdominal protection → forearm protection → gloves → leg protection → boots. Not all elements on every character. Different classes get different constructions:
- Light armor: less mass, more cloth, mobility, small protective elements.
- Heavy: large forms, thick plates, servos, reinforced joints, powerful mounts.
- Industrial: protective work gear, tools, reinforced elements, utilitarian design.
- Military: functional, modular, unified.
- Self-made: mismatched materials, old details, local repairs, non-standard mounts.

## 11. Every character must have a "visual story"

From a character it must be possible to guess: who he is; what he does; how well-off he is; what technology he uses; where he works; how long he has used his gear. Do not make all people identical. Even two characters of one class may differ in: armor; color; helmet; weapon; backpack; tools; damage; repair method; amount of old equipment.

## 12. Face and head

The face must be minimal but expressive. Do not draw many small features. Better: strong silhouette; hair form; visor; mask; helmet; jaw; distinctive head shape. For NPCs differences may come through: hairstyle; beard; visor; helmet; face shape; headgear.

## 13. Weapons

Weapons are one of the most important asset classes. Every weapon must look FUNCTIONAL + DANGEROUS + DISTINCTIVE. The player must be able to distinguish weapons by silhouette.
- Pistol: compact; one main mass; easily read in the hand.
- Assault rifle: long; clear barrel; magazine / power cell; stock / rear structure.
- Heavy weapon: significantly more massive; large front part; powerful support structures.
- Energy weapon: not just "usual rifle + blue strip". Energy must be built into the design: emitter; capacitor; coolant; conduits; power cell; heat management.

## 14. Weapons must work with the character

A weapon must not be just a separate picture. Take into account: grip; hand position; weight; length; direction; recoil; animation silhouette. A big mistake: weapon beautiful separately but absurd when equipped. Therefore CHARACTER + WEAPON is considered as a single system.

## 15. Equipment

Equipment: backpacks; ammunition; pouches; scanners; helmets; masks; tools; grenades; repair kits; oxygen equipment; utility modules; communication devices. They must change the character's silhouette. Example: ordinary mercenary vs mercenary with a large exploration pack must differ visually even at small size.

## 16. Robots

Robots must NOT look like "human + metal texture". A robot has its own constructive logic: sensor head; central chassis; articulated joints; actuator limbs; power core; weapon mount. Kinds: industrial; military; mining; logistics; maintenance; autonomous; improvised. Main forms must be easily readable.

## 17. Enemies

An enemy must differ from an ally already by silhouette. Not only color change. May differ: proportions; armor; limbs; posture; head shape; weapon configuration; movement style; visual mass. Large enemy → large silhouette; fast enemy → elongated / light silhouette; tank enemy → wide heavy mass; drone → separate compact form.

## 18. Animation

Animation must be a continuation of design. Minimally important states: idle; walk; run; attack; recoil; dodge; hurt; death; interact; reload; equip/unequip. Do not use mechanical "re-gluing" of the body. The character must feel physical. In movement must change: body weight; arms; legs; weapon position; equipment; coat; backpack; recoil.

## 19. Hit and combat readability

Combat actions must be visually understandable. Important to see: attack direction; moment of hit; recoil; muzzle flash; projectile; impact; hit reaction; destruction. Main idea: ACTION → VISUAL RESPONSE.

## 20. Containers

Containers belong to exterior visual, not architecture. They must be full objects. NOT to draw "a rectangle with two lines". Needed: panels; lids; mounts; handles; locks; legs; transport elements; marking; technical joins. At the same time the container silhouette must be simple and readable.

## 21. Industrial objects

Generators; fuel tanks; machinery; pumps; small terminals; crates; barrels; cables; pipes; equipment; communication hardware. Each object has a FUNCTIONAL LOGIC. Example: generator may have housing; control panel; vents; power connection; fuel system; maintenance access. Do not add details just because it is "empty".

## 22. Landscape

Landscape must be a real place, not "green / brown background + a few rocks". First the large composition: LARGE FORMS → MEDIUM FORMS → SMALL DETAILS.
- Large: terrain masses; cliffs; contaminated areas; dry ground; rock fields; water; large vegetation; industrial disturbance.
- Medium: rocks; vegetation clusters; debris; equipment; tracks; small terrain structures.
- Small: grass; pebbles; cracks; leaves; fragments; stains.

## 23. Landscape must not be noise

Very important: DETAIL ≠ NOISE. You must not fill everything with random pixels, spots, grass, pebbles, noise textures. Needed: EMPTY AREAS + FOCAL AREAS + TRANSITION AREAS. Empty space is also part of the composition.

## 24. Nature and technology

An important part of the game's atmosphere: the external world shows technology vs nature. Example: old machine partially overgrown; cable going underground; piece of metal structure among rocks; old container; abandoned tech; local vegetation near an industrial object. Nature must not be just decoration — it interacts with the remains of civilization.

## 25. Environment must tell a story

Useful in a scene: traces of old tech; broken containers; local repairs; old warning signs; damaged machines; remains of infrastructure; fresh traces of use. Not everything must be abandoned. The combination OLD + USED + NEW + DAMAGED is very important.

## 26. Materials

Materials must differ. Minimally: metal; painted metal; rusted metal; plastic; rubber; glass; fabric; rock; soil; sand; vegetation; concrete-like industrial material; energy/emissive materials. Do not make everything one material with different colors.

## 27. Metal

Metal must have: plane changes; edge highlights; darker recesses; joints; bolts; seams; wear. Do not fill metal with noise. A good metal object: PRIMARY SHAPE + EDGE + RECESS + 2–4 MATERIAL VALUES.

## 28. Rust / wear

Wear must appear where it is logical. Rust: seams; exposed edges; water collection; damaged coating; joints. Dirt: lower part; recesses; ground contact; under objects. Paint wear: edges; handles; service zones; contact areas. Do not cover the whole object with the same rust.

## 29. Detailing must be hierarchical

Every asset has: PRIMARY FORM → SECONDARY FORM → TERTIARY DETAIL. Primary: silhouette / mass. Secondary: panels / joints / major components. Tertiary: bolts / markings / scratches / small cables. If tertiary details are removed, the object must still look good.

## 30. Color

Palette must be controlled. No rainbow without reason. Main system: NEUTRAL BASE + MATERIAL COLORS + FACTION COLORS + SIGNAL COLORS + RARE ACCENTS. Bright colors must be valuable visual accents (warning orange; industrial yellow; cold cyan; medical green; faction red; emergency magenta). But not all at once on one object.

## 31. Factions

A faction must be recognized not only by color. Use combination: shape language; materials; construction; equipment; markings; color accents. Two factions may use the same rifle type but: Faction A → clean industrial design; Faction B → rugged frontier modifications.

## 32. Technology levels

Technology level influences visual design.
- LOW TECH: exposed mechanisms; bulky parts; manual controls; old materials; repairs.
- MID TECH: modular equipment; standard electronics; functional panels.
- HIGH TECH: compact systems; advanced materials; integrated electronics; minimal exposed mechanics.
- VERY ADVANCED: unusual geometry; exotic materials; unusual energy behavior; unfamiliar interface design.
But: HIGH TECH ≠ MORE GLOW. Advanced technology does not have to shine.

## 33. Frontier aesthetic

Especially important mood: FRONTIER FUTURE. Not sterile Coruscant-style science fiction. A world of: distant colonies; mercenaries; engineers; miners; traders; military; researchers; smugglers; workers; independent settlements. Therefore technology is often: modified; repaired; mixed; used beyond its term; assembled from different systems.

## 34. A human must remain a human

Even in sci-fi you must not turn all characters into "armor suit with a head". There must be: different bodies; age; height; clothing; gait; poses; equipment; personal items. A human must feel like a living being.

## 35. Not too cyberpunk

Do not automatically turn the game into: neon; wet asphalt; huge holograms; magenta/cyan everywhere; glowing advertisements. Sci-fi here may be: dry; industrial; cold; desert; dirty; natural; military; utilitarian; strange.

## 36. Atmosphere

Main feeling of the world: UNKNOWN FRONTIER. The player must feel: curiosity; danger; loneliness; scale; unknownness; age of some technologies; the feeling that the world exists independently of the player. Beauty must not cancel danger. Danger must not turn into gray mud.

## 37. Lighting

Light must create atmosphere but not replace pixel art. Use: directional light; local lights; emissive materials; contact shadows; cast shadows; occlusion. Light must help to: separate foreground/background; separate character from surface; mark light sources; make materials readable. Do not flood everything with bloom.

## 38. Emissive effects

Glow must be rare and meaningful. Use for: energy weapons; terminals; warning systems; power cores; unusual technology; medical equipment; some faction technologies. "Glowing" does not mean "high-tech". The rarer a strong emissive accent, the stronger its visual effect.

## 39. Important rule for every asset

Before creating an asset define: 1. What is it? 2. What is it used for? 3. Who manufactured it? 4. What technology level does it belong to? 5. What material is it made of? 6. How old is it? 7. Has it been repaired? 8. Is it civilian / military / industrial? 9. What is the silhouette? 10. What is the visual focal point? If there is no answer to these questions, the asset will most likely look random.

## 40. What categorically NOT to do

NOT: random sci-fi greebles; random wires; random panels; random scratches; random glowing parts; random rust; random decals; random color variation; identical containers; identical rocks; identical NPCs; same weapon silhouette with different colors; same robot with different heads; generic sci-fi crates; generic military soldiers. Do not use details to fill empty space. Emptiness is sometimes needed.

## 41. Do not do visual camouflage

Special problem: pixel noise ≠ detail. Do not use many small pixels to make an asset look "detailed". Detailing must be: STRUCTURED + SEMANTIC + HIERARCHICAL. A good asset can be dissected with the eyes: "Here is an armor plate. Here is a mount. Here is a cable. Here is damage. Here is an interface." A bad asset: "Many multicolored pixels."

## 42. Quality of every sprite

Every new important asset must pass three checks. ZOOMED OUT: is it clear what this is? GAMEPLAY SIZE: is it clear what it is for? ZOOMED IN: are there interesting details? An asset is successful only if all three work.

## 43. Character quality bar

For characters especially: do not accept a result that looks like a generic generated sprite. Must achieve: strong silhouette; good anatomy; expressive pose; clear equipment; correct weapon; material separation; controlled palette; intentional highlights; meaningful small details. Goal: approach the level of well-executed Cortex Command sprites or higher in overall visual saturation and readability. Do not copy Cortex Command — use it only as a quality bar.

## 44. Asset variation

Variation must change not only color. For a character: helmet; armor; backpack; weapon; proportions; clothing; accessories; condition. For a weapon: receiver; barrel; stock; magazine; energy module; attachments. For a container: shape; material; lid; handles; markings; damage; age. For environment: geology; vegetation; debris; weathering; technological remains.

## 45. Important rule of variation

VARIATION ≠ RANDOMNESS. The generator must first determine: identity → family → variant → condition → details. Example: MILITARY RIFLE → faction A → standard production → 8-year old → field repaired → scratched → customized sight. This is much better than random rifle → random colors → random panels.

## 46. Visual integrity

All assets must feel like part of one world. Even with different factions / technology levels / age / materials they must share a common language: pixel density; edge treatment; shadow language; highlight logic; palette discipline; level of detail; camera projection; scale.

## 47. Separate important goal: characters must not get lost in the world

Environment may be very detailed, but the character must remain readable. Therefore use: silhouette separation; controlled local contrast; background simplification; clear weapon silhouette; readable animation poses. Do not solve the problem with a huge outer glow around the player.

## 48. Visual hierarchy

Most important elements: 1. Player; 2. Enemy / combat action; 3. Interactive objects; 4. Major environmental landmarks; 5. Supporting environment; 6. Microdetail. Do not let small objects compete with the character.

## 49. General visual formula

For a gameplay scene: LARGE COMPOSITION + CLEAR SILHOUETTES + STRONG MATERIAL SEPARATION + CONTROLLED PALETTE + LOCALIZED DETAIL + ATMOSPHERIC LIGHT + SEMANTIC WEAR = VISUAL STYLE.

## 50. Main principle

Do not try to make the game "beautiful" by adding more details. First make: GOOD SHAPES. Then: GOOD SILHOUETTES. Then: GOOD MATERIALS. Then: GOOD COLOR. Then: GOOD LIGHT. And only after that: DETAILS.

## 51. Final test

Before considering a new visual asset ready, check: A. Is it clear what this is? B. Is it clear what it is for? C. Does the object have its own silhouette? D. Does it differ from other objects of the same class? E. Does it look like part of this world? F. Is there a logic of materials? G. Is the detailing not random noise? H. Is it readable at gameplay distance? I. Does it look good close-up? J. Can its existence in a real frontier sci-fi world be imagined?

## 52. Key feeling

At the sight of any new character, weapon or item the player must feel: "Someone designed, produced, bought, used, repaired, modified or broke this thing." And not: "This is a randomly generated sci-fi pixel asset."

## 53. Final art target

MODERN HIGH-DETAIL PIXEL ART + SCI-FI FRONTIER + STRONG SILHOUETTES + TACTILE MATERIALS + CONTROLLED COLOR + ATMOSPHERIC WORLD + FUNCTIONAL DESIGN + MEANINGFUL DETAIL + EXCELLENT CHARACTER SPRITES.

## 54. Priorities when creating new visual

Always prioritize: 1. Silhouette; 2. Shape language; 3. Readability; 4. Material separation; 5. Character / object identity; 6. Color; 7. Animation; 8. Secondary details; 9. Microdetails. Never sacrifice the first points for the last.
