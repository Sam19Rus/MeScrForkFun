# TASK: Rig v10 — POSE MODE: редактор поз как visual-dev инструмент (PALE MERIDIAN AA1)

> Статус: **ГОТОВО (v10 merged in aa1)**. Реализация: `src/game/pose_editor.ts` (НОВЫЙ модуль),
> `src/game/hero.ts` (`boneOverride` + pixel-precise `dbg`), `src/game/game.ts`
> (`render(poseOverride)`, `cycleSet/cycleHair`), `src/shell/browser.ts` (вход/пауза/хуки),
> `src/engine/input.ts` (`wheel`, `shiftDown`), `tools/hero_bench.ts` (пресеты/round-trip/hit-test).
> Чисто визуальный инструмент: gameplay/ИИ/лут не тронуты; бот никогда не нажимает [P] →
> qa-детерминизм цел (ALL GREEN, headless-кадры байт-идентичны). Скелетная математика НЕ изменена:
> режим использует её через `HeroPose.boneOverride` (углы костей подставляются ДО boneIdx, дети
> цепи следуют той же математикой chain-стыков, что и в бою).

## Вход/выход, пауза
- **[P]** из игры → вход, тост «POSE MODE»; симуляция заморожена (core.update не вызывается,
  acc сбрасывается → без burst при выходе). Выход: **[P]** или **[Esc]** (Esc перехватывается
  редактором до pause-меню).
- KEYMAP browser.ts: + KeyP, KeyM, KeyC, KeyV, KeyL, Digit0, ShiftLeft/Right; wheel → `inp.wheel`.

## Экран режима
- Персонаж по центру, рендер 4x/6x/8x (колесо), нейтральный тёмный фон.
- Малое окно **1x в углу**: тот же персонаж в текущей сцене через `core.render(poseOverride)` —
  проверка читаемости позы в gameplay.
- **[M]** цикл 30/36/40 px/m; **[B]/[H]** сеты/причёски (через `core.cycleSet/cycleHair`);
  **[S]** silhouette-оверлей; **[L]** подписи частей + pivot-точки.
- HUD: подсказки клавиш внизу мелким шрифтом (как в меню), строка SEL/SCALE/SET/HAIR/ZOOM,
  строка POSE JSON (санирована под глифы 4x6: `{}`→`()`, `"`→`'`).

## Выбор и манипуляция
- Hit-test **pixel-precise**: drawHero с `dbg` собирает нарисованные пиксели каждой части
  (16 частей: head/neck/torso/uparmF/forearmF/handF/gun/handS/forearmS/uparmS/thighF/shinF/bootF/
  thighB/shinB/bootB); клик выбирает ВЕРХНИЙ видимый пиксель (часть под оружием не выбирается там,
  где перекрыта — корректное UX-поведение).
- **[Tab]** цикл частей; выбранная подсвечена рамкой; HUD показывает имя + текущий угол.
- Drag = вращение выбранной кости вокруг её pivot (angle = atan2(cursor − pivot)); дети цепи следуют
  chain-математикой. Shift+drag = угол оружия как отдельной кости (`overrides.gun` = local lang).
- Колесо = zoom 4/6/8 для микро-работы.

## Пресеты и экспорт
- **[1]** low-ready, **[2]** aim, **[3]** walk-key 0, **[0]** reset (default idle) — пресеты
  воспроизводят боевые позы 1:1 (те же поля pose: lowReady/aimAng/moving/walk).
- **[C]** копирует pose-JSON в clipboard: `{scale, set, hair, aim, lowReady, moving, walk,
  bones{deg}, gun deg|null}`.
- **[V]** сохраняет PNG (в браузере — download `pose_<n>.png`; в бенче — `shots/pose_0..3.png`):
  4x + окно 1x + JSON строкой в подписи кадра.

## Бенч и тесты (tools/hero_bench.ts)
- `shots/pose_0_lowready.png`, `pose_1_aim.png`, `pose_2_walk0.png`, `pose_3_reset.png`.
- **Round-trip**: json() → applyJson() → рендер байт-идентичен (PASS, падение бенча при mismatch).
- **Hit-test**: 10 частей (head, torso, gun, handF, handS, forearmS, uparmF, thighF, shinF, bootF):
  для каждой найден кликабельный пиксель, где она верхняя; hitTest возвращает именно её (все OK).

## Самопроверка (отметить всё)

- [x] Вход/выход, пауза симуляции, тост
- [x] Hit-test выбирает именно ту часть (10 частей, включая кисти и голову)
- [x] Drag вращает вокруг pivot, дети следуют без разрывов (chain-стыки те же, что в бою)
- [x] Пресеты воспроизводят боевые позы 1:1
- [x] [C]/[V] работают; JSON парсится обратно (round-trip PASS)
- [x] [M] 30/36/40 переключает рендер сета
- [x] qa ALL GREEN; headless-кадры байт-идентичны (режим не влияет)

## Hotfix 2: клики по частям тела не работали + скрытие оружия

- **Причина бага кликов**: `hitTest` сравнивает целочисленные пиксели частей, а `toCell` возвращал
  дробные координаты (mouse − viewOx) / zoom → совпадений не было никогда (бенч-тесты округляли
  точки вручную, поэтому там всё было зелёное). Фикс: `Math.round` в `toCell`.
- **[G] — скрыть оружие** в pose mode: pose.gun = 'none', обе руки остаются позирруемыми раздельно
  (override-углы костей работают без оружия); поле `hideGun` добавлено в pose-JSON и applyJson.
- **Drag-алиасы**: кисть боевая/опорная тянет своё предплечье, ботинок — голень: кликабельна и
  двигаема каждая видимая часть, а не только кости из списка.
- **[Tab]** циклит только части, реально присутствующие в кадре (со скрытым оружием 'gun' пропускает).
- HUD: имя селекта показывает алиас (напр. `HANDF->FOREARMF`) и угол кости-родителя; подсказка [G].
- Бенч: CLICK-тест 10 частей через РЕАЛЬНЫЙ input-путь (screen-координаты → toCell → hitTest),
  DRAG-тест (override записан), HIDEGUN-тест (gun исчез, кисти на месте), лист `pose_4_gunhidden.png`.

## Фикс бага dev-сборки (post-v10 hotfix)

Симптом: `npm run dev` → в консоли `Module "node:zlib" has been externalized... at png.ts`.
Причина: wiring POSE MODE добавил в `src/shell/browser.ts` импорт `encodePNG` из `src/engine/png.ts`,
а тот модуль исторически тянул `node:zlib` (использовался только node-тулзами) → vite externalized
модуль падал в рантайме браузера.
Фикс: `src/engine/png.ts` переписан в **чистый TS-кодек без node-модулей и Buffer**:
encode = zlib stored-blocks (детерминированный, валидный PNG), decode = полный inflate
(stored/fixed/dynamic Huffman, LSB-first bitstream, пропуск zlib-заголовка, unfilter 0–4).
Проверки: inflate побайтово равен node zlib на ground.png IDAT (6.2 MB); encode→decode round-trip
PASS; synthetic stored/fixed/dynamic стримы PASS; `npm run build` → в dist нет `node:zlib`
(decode tree-shakes из browser-бандла, encode остаётся чистым).

## Заметки
- Редактор не сериализует состояние сцены (только позу) — позы переносимы между сетами/масштабами.
- `boneOverride` — единственный хук редактора в боевой рендер; боевые значения углов не меняются.
- Будущее: экспорт поз в walk-таблицы (KF_* из pose-JSON ключей) и ortho-проекции в том же экране.
