# TASK-RIG-V18 — hardening trace-match margins (HEAVY@40 vs REPLICA_40)

Статус: **выполнено**. Цель этапа — убрать тонкую маржу перманентного ассерта
`assertTraceMatch` (v17: IoU 0.8588 при пороге 0.85, regions ~0.911 при пороге 0.90):
любая будущая правка арта HEAVY@40 не должна ронять QA из-за нулевого запаса.

## Контракты (НЕ ТРОГАТЬ) — соблюдены

- IK/chain math, 8-key walk tables, lean/low-ready логика, hotkeys, детерминизм,
  gameplay-контракты (meter-space), пропорции ROOKIE, weapon art/stats @40, враги — не тронуты.
- Все изменения позы — только аддитивные QA-каналы `HeroPose.stance` / `HeroPose.boneOverride`
  через `TRACE_POSE` (используется исключительно в `tools/trace_match.ts` и `tools/hero_bench.ts`;
  геймплейная поза low-ready не изменена).
- Перманентные ассерты `assertGameEqualsBench` и `assertTraceMatch` остались в `npm run qa`.

## P0 — диагностика утечек (по-пиксельная карта)

Метод: маски rig/trace (opaque = a==255 && color!=0, contact-shadow исключён), best-translation
shift (−1,0), далее три класса расхождений: rig-excess / trace-missing / family-mismatch,
локализация по DBG-боксам частей и по строкам. Карта: red/blue/yellow на чёрном.

Найдено 5 структурных утечек (v17-состояние):

| # | Утечка | px | Класс |
|---|--------|----|-------|
| 1 | выступ левого плеча трейса (R40 rows 10–12, cols 8–14) не drawn ригом | ~18 missing | silhouette |
| 2 | приклад винтовки на y107–117 левее трейса на 6–9 px | ~22 excess | silhouette |
| 3 | правый локоть (S-chain) уже трейса на y101–114 на 2–4 px | ~36 missing | silhouette |
| 4 | сложенное предплечье S поверх тёмного нагрудного ремня трейса (rows 14–16) | ~106 mismatch | family |
| 5 | seam бёдер смещён на 1–2 px от seam трейса (OV40 '2') | ~54 mismatch | family |

Ключевой инсайт по #1: `TORSO40_HEAVY` рисовался зеркально (art col c ↔ trace col 38−c),
и строки r0–r2 брали только шейный блок (trace cols 15–24); плечевой выступ trace cols 8–14
в зеркало не попал. Торс рисуется flip-нутом при facing-left, поэтому выступ ложится
точно в missing-зону x98–105, y83–85.

## P1 — арт-фикс выступа плеча

`TORSO40_HEAVY` r0–r2 получили зеркальные сегменты выступа:

```
r0: row(37, [14,'6555565769'], [26,'6279'])    // зеркало trace r10 c9–12
r1: row(37, [14,'4255555524'], [24,'995578'])  // зеркало trace r11 c9–14
r2: row(37, [14,'6555122212'], [24,'5667779']) // зеркало trace r12 c8–14
```

Аддитивно (ничего не удалено), rows 3–9 (pauldron-span assert) и rows 32–38 (belt assert)
не тронуты → belt 7/7, pauldron 30/30 сохраняются. Эффект изолированно: IoU 0.8588 → 0.8680.

## P2 — ре-фит QA-позы с family-aware objective

Coordinate descent по 13 параметрам (`thighF, shinF, thighB, shinB, gun, uparmF, forearmF,
uparmS, forearmS, footF.xy, footB.xy`), objective:

```
J = min(iou/0.85, minRegion/0.90) * 10 + iou + 0.6 * meanFamilyAgree
```

(порогово-насыщенный член первым — нельзя менять красный порог на IoU). 10 мульти-стартов
(база + пертурбации forearmS ±0.35, uparmS ±0.15, gun ±0.12, thighB +0.2, forearmF −0.3),
шаги 0.09→0.01 (overrides) / 1.5→0.25 (stance), затем fine-pass 0.03→0.005 — второй раунд
улучшений не нашёл (бассейн сошёлся). Итог: **gun 2.643 → 2.703**, остальные параметры без изменений.
Эффект: IoU 0.8680 → 0.8732, legs 0.912 → 0.920.

## P3 — регресс и числа

| Метрика | v17 | v18 | порог |
|---------|-----|-----|-------|
| assertTraceMatch IoU | 0.8588 | **0.8732** | ≥0.85 |
| head / torso / arms / legs | 1.000/0.911/0.915/0.912 | **1.000/0.913/0.913/0.920** | ≥0.90 |
| belt / pauldron | 7/7, 30/30 | 7/7, 30/30 | equal |
| assertGameEqualsBench IoU | 0.9952 | **0.9953** | ≥0.98 |
| rig-excess / trace-missing px | 173 / 87 | **162 / 70** | — |
| `npm run qa` | ALL GREEN | ALL GREEN (10 checks) | — |
| `tsc --noEmit` | clean | clean | — |

Перегнано: `tools/hero_bench.ts` (trace_vs_rig.png с новой позой/артом), `npm run headless`
+ `tools/contact_sheet.ts` (15 кадров), дампы qa (`game_heavy40*.png`, `bench_heavy40.png`,
`game_vs_bench_diff.png`, `trace_match_align.png`). Детерминизм: replay byte-identical PASS.

## Остаточные структурные ресидуалы (осознанно приняты)

- gun-excess ~17 px: приклад QA-позы чуть левее трейса; дальнейший доворот gun уводит
  дуло из right-down бассейна (пробовано фиттером).
- S-elbow missing ~36 px: flare правого локтя трейса шире процедурной кости 5 px; уширение
  костей трогает общий `makeBone` (ROOKIE) — вне контракта этапа.
- family chest ~106 px: сложенное предплечье S читается sling-ремнём поверх тёмного нагрудного
  ремня трейса; перенос склада вниз снимает руку S с цевья — принято текущее положение.
- thigh seam ~49 px: seam процедурных бёдер против OV40-'2' трейса, смещение 1–2 px.

## Файлы этапа

- `src/game/hero_art.ts` — TORSO40_HEAVY r0–r2 (+выступ плеча, verbatim-зеркало rows 10–46 полное).
- `tools/trace_match.ts` — TRACE_POSE: gun 2.703 (комментарий v18).
- `README.md` — блок v18 (текущая), v17 раз-помечен.
- Временные инструменты фиттера/диагностики удалены после прогона (tmp_*).
