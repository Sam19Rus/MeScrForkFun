# TASK-RIG-V17 — HEAVY@40: game==bench, limbs/pauldrons по референсу, постоянный assert трейса

Этап v17 закрывает расхождение «путь-в-игру vs путь-в-бенче» для HEAVY@40 (P0), приводит
конечности/перчатки/стыки HEAVY@40 к color-family референса (P1) и вшивает в QA постоянный
assert соответствия рига пиксельному трейсу референса REPLICA_40 (P2). Регресс (P3) — зелёный.

## P0 — game == bench (root cause + fix)

**Симптом:** в игре конечности HEAVY@40 рисовались gunmetal («старый сет»), на бенче — зелёными.
**Root cause:** `makeBone()` в `src/game/hero.ts` пёк кости костей-буферы с дефолтным `HERO_PAL`,
а не с палитрой активного сета (`HEAVY_PAL`): символы '2'/'5'/'6'/'7' брони HEAVY резолвились в
olive/gunmetal MERC-палитры. Бенч-путь (`drawHero` с явной палитрой) и игровой путь
(`ensureSet -> makeBone`) расходились.
**Fix:** параметр `pal` у `makeBone()`/`makeHand()`/`makeBootSet()` + передача палитры сета из
`ensureSet()`; outline-цвет костей конечностей берётся из сета (`a40.pal['5']`).
**Доказательство (перманентно в QA):** `tools/game_vs_bench.ts::assertGameEqualsBench()`:
headless GameCore, кадр A (с игроком) и кадр B (`hidePlayer`), maskGame = A≠B; bench-буфер =
B + `drawHero` с тем же состоянием; IoU масок ≥ 0.98. Текущее значение: **IoU = 0.9952**
(maskGame=1884, maskBench=1893). Дампы: `shots/game_heavy40.png`, `shots/bench_heavy40.png`,
`shots/game_vs_bench_diff.png`, `shots/game_heavy40_crop4x.png`.

## P1 — конечности/перчатки/стыки HEAVY@40 по color-family референса

- Кости конечностей HEAVY@40 (`UPARM/FOREARM/UPARMS/FOREARMS 40_HEAVY`) — зелёная броня
  (символы 5/6/7), gunmetal только в стыках; стыки локтя/колена и toe-cap ботинка переведены в
  deep-green ('2'), т.к. в трейсе эти зоны читаются зелёным семейством (family-требование P2);
  ширина костей 7→5 px — ровно ширина_arm-колонн трейса (кости не перекрывают ink-швы трейса).
- Перчатки `FIST40`/`SUPHAND40` — зелёные краги (5/6/7), как в трейсе (rows 44-51: 5/6/7/8/9).
- Паульдроны живут внутри арта торса (`TORSO40_HEAVY`, verbatim-зеркало трейса rows 10-46);
  ширина пояса = ширине трейса (7), спэн паульдронов = спэну трейса (30) — проверяется ассертом.
- Ботинки: зелёные с тёмно-зелёным toe-cap и D-подошвой ('2').

## P2 — assertTraceMatch (перманентно в QA)

`tools/trace_match.ts::assertTraceMatch()`: rig low-ready @40 (QA-pose каналы `stance` +
`boneOverride`, геймплейная поза не тронута) против `REPLICA_40` на том же масштабе:

| метрика | порог | факт |
|---|---|---|
| silhouette IoU (best translation) | ≥ 0.85 | **0.8588** (shift −1,0) |
| head family agree | ≥ 0.90 | **1.000** |
| torso family agree | ≥ 0.90 | **0.911** |
| arms family agree | ≥ 0.90 | **0.915** |
| legs family agree | ≥ 0.90 | **0.912** |
| belt width trace/torso | равны | 7 / 7 |
| pauldron span trace/torso | равны | 30 / 30 |

Family-правила: green = g>r+6 && g>b+6; ink (#12141a) слит с gunmetal («dark hardware»);
amber/leather/other отдельно. Pure-black тень исключена из масок силуэта.
QA-pose (фит координатным спуском по 5 override + стойке):
`boneOverride = { thighF 1.25, shinF 1.35, thighB 1.75, shinB 1.65, gun 2.643, uparmF 1.22,
forearmF 2.074, uparmS 0.964, forearmS −1.424 }`, `stance = { footF [9,−4,0], footB [−10.5,−5.5,0] }`.
Падение = throw (красный бенч). Отчёт и кропы: `shots/trace_vs_rig.png`
(trace aligned | rig QA | in-game heavy40 2x | 4x кропы head/torso/legs | diff-карта 4x).

## P3 — регресс

- `npm run qa` → **ALL GREEN**, включая новые строки
  `v17 P0: game==bench heavy@40 (IoU=0.9952)` и
  `v17 P2: rig matches ref trace @40 (IoU=0.8588 head=1.000 torso=0.911 arms=0.915 legs=0.912 belt=7/7 pauldron=30/30)`.
- `tools/hero_bench.ts`: все листы перегнаны (visor_crop/angles/walk/grip/silhouette/parts40/rig40/
  trace_vs_rig/pose/zoom); `assertVisorClean` — все визоры чистые; `assertNoInteriorHoles` —
  91 арт без внутренних дыр (30/36/40 px/m).
- `npm run headless` + `tools/contact_sheet.ts` → `shots/00_contact_sheet.png` (15 кадров).
- Детерминизм: replay stats identical + frames byte-identical — PASS.

## Контракты, которые НЕ тронуты

IK/chain-математика, walk-таблицы (8 ключей), lean/low-ready логика, хоткеи, детерминизм,
gameplay-контракты, пропорции ROOKIE, арты оружия @40, враги. QA-pose использует только
аддитивные каналы (`stance`, `boneOverride`), дефолтная геймплейная поза не изменена.

## Как прогнать

```
npm run qa            # весь QA + P0 + P2 ассерты
npx tsx tools/trace_match.ts      # числа trace-match + shots/trace_match_align.png
npx tsx tools/game_vs_bench.ts    # числа game==bench + дампы
npx tsx tools/hero_bench.ts       # все листы + visor/holes ассерты
npm run headless && npx tsx tools/contact_sheet.ts
```
