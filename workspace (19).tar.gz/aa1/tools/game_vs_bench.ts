/**
 * v17 P0: assertGameEqualsBench - mechanical proof that the IN-GAME hero draw path
 * (game.ts -> drawPlayer -> drawHero -> ensureSet) produces the SAME pixels as the
 * bench path (direct drawHero call with the identical pose) for the shipped set @40 px/m.
 * v19: single set (ROOKIE MERC); the HEAVY/MJOLNIR variant of this check is archived
 * (archive/mjolnir_heavy_v18/tools/game_vs_bench_v18.ts).
 *
 * Method:
 *   1. boot GameCore headless, start run, settle (no movement, lean at rest);
 *   2. render frame A (with player) and frame B (hidePlayer=true) from the SAME state;
 *   3. maskGame  = pixels where A != B  (everything the player draw touched);
 *   4. benchBuf  = copy of B, then drawHero(benchBuf, same screen xy, pose mirrored from core);
 *      maskBench = pixels where benchBuf != B;
 *   5. IoU(maskGame, maskBench) must be >= 0.98, else FAIL with the diff region dump.
 *
 * This assert stays in QA forever (guards bench != game regressions).
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { GameCore } from '../src/game/game.js';
import { NullSfx } from '../src/engine/audio.js';
import { decodePNG, encodePNG } from '../src/engine/png.js';
import { emptyInput } from '../src/engine/input.js';
import { DT, PXM } from '../src/game/config.js';
import { drawHero } from '../src/game/hero.js';
import { DIR_VEC } from '../src/game/rig.js';
import { ARMOR_SETS } from '../src/game/hero_art.js';
import { PixelBuf, rgba } from '../src/core/buf.js';
import type { HeroGun, HeroPose } from '../src/game/hero.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');

function cloneBuf(src: PixelBuf): PixelBuf {
  const c = new PixelBuf(src.w, src.h);
  c.px.set(src.px);
  return c;
}

export interface WiringResult {
  iou: number;
  maskGame: number;
  maskBench: number;
  inter: number;
  diffBox: { x0: number; y0: number; x1: number; y1: number } | null;
  set: string;
  pxm: number;
}

/** Pose the game's drawPlayer would submit this frame (mirrors game.ts logic exactly). */
function mirrorGamePose(core: GameCore): HeroPose {
  const cls = core.activeWeapon.cls;
  const gun: HeroGun =
    cls === 'rifle' ? 'rifle' : cls === 'smg' ? 'smg' : cls === 'launcher' ? 'launcher' : cls === 'blade' ? 'blade' : 'pistol';
  return {
    aimAng: core.aimAng, moving: core.moving, walk: core.walk,
    flash: core.pflash > 0, gun, muzzle: core.muzzle > 0 ? 1 : 0,
    moveDir: DIR_VEC[core.dir],
    set: ARMOR_SETS[core.armorSetIdx].id,
    lowReady: core.lowReady,
    pxm: PXM,
  };
}

export function runWiringCheck(opts: { outDir?: string; dumpImages?: boolean; settleTicks?: number } = {}): WiringResult {
  const outDir = opts.outDir ?? join(root, 'shots');
  const core = new GameCore(new NullSfx());
  core.setGround(decodePNG(readFileSync(join(root, 'public', 'assets', 'ground.png'))));
  const inp = emptyInput();
  // menu -> play
  inp.pressed.add('enter'); core.update(DT, inp); inp.pressed.clear();
  if (ARMOR_SETS[core.armorSetIdx].id !== 'rookie') throw new Error(`wiring: expected rookie set, got ${ARMOR_SETS[core.armorSetIdx].id}`);
  // settle: stand still so lean/lowReady converge and no fx are alive
  for (let i = 0; i < (opts.settleTicks ?? 90); i++) core.update(DT, inp);

  const x = core.cam.wx(core.px), y = core.cam.wy(core.py);
  const pose = mirrorGamePose(core);

  core.hidePlayer = false;
  const frameA = core.render();
  core.hidePlayer = true;
  const frameB = core.render();
  core.hidePlayer = false;

  // bench path: same background, direct drawHero at the same screen position
  const bench = cloneBuf(frameB);
  drawHero(bench, x, y, pose);

  const W = frameA.w, H = frameA.h;
  const mA = new Uint8Array(W * H), mB = new Uint8Array(W * H);
  let nA = 0, nB = 0, inter = 0;
  let x0 = W, y0 = H, x1 = -1, y1 = -1;
  for (let py = 0; py < H; py++) {
    for (let px = 0; px < W; px++) {
      const i = py * W + px;
      const g = frameA.px[i] !== frameB.px[i] ? 1 : 0;
      const b = bench.px[i] !== frameB.px[i] ? 1 : 0;
      mA[i] = g; mB[i] = b;
      nA += g; nB += b;
      if (g && b) inter++;
      if (g !== b) { if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py; }
    }
  }
  const union = nA + nB - inter;
  const iou = union > 0 ? inter / union : 1;
  const diffBox = x1 >= 0 ? { x0, y0, x1, y1 } : null;

  if (opts.dumpImages) {
    mkdirSync(outDir, { recursive: true });
    writeFileSync(join(outDir, 'game_rookie40.png'), encodePNG(frameA));
    writeFileSync(join(outDir, 'bench_rookie40.png'), encodePNG(bench));
    // diff overlay: red = game-only, blue = bench-only
    const diff = cloneBuf(frameB);
    for (let i = 0; i < W * H; i++) {
      if (mA[i] && !mB[i]) diff.px[i] = rgba(235, 44, 40, 255);
      else if (mB[i] && !mA[i]) diff.px[i] = rgba(60, 110, 235, 255);
    }
    writeFileSync(join(outDir, 'game_vs_bench_diff.png'), encodePNG(diff));
    // 4x crop of the hero region for the bench sheet
    const hx0 = Math.max(0, x - 40), hy0 = Math.max(0, y - 100), hx1 = Math.min(W, x + 40), hy1 = Math.min(H, y + 12);
    const crop = (src: PixelBuf) => {
      const cw = (hx1 - hx0) * 4, ch = (hy1 - hy0) * 4;
      const c = new PixelBuf(cw, ch);
      for (let py = 0; py < hy1 - hy0; py++)
        for (let px = 0; px < hx1 - hx0; px++) {
          const col = src.px[(hy0 + py) * W + (hx0 + px)];
          for (let qy = 0; qy < 4; qy++) for (let qx = 0; qx < 4; qx++) c.px[(py * 4 + qy) * cw + (px * 4 + qx)] = col;
        }
      return c;
    };
    writeFileSync(join(outDir, 'game_rookie40_crop4x.png'), encodePNG(crop(frameA)));
  }

  return { iou, maskGame: nA, maskBench: nB, inter, diffBox, set: pose.set ?? '?', pxm: PXM };
}

export function assertGameEqualsBench(minIoU = 0.98): WiringResult {
  const r = runWiringCheck({ dumpImages: true });
  if (r.iou < minIoU) {
    const box = r.diffBox ? ` diff-region x[${r.diffBox.x0}..${r.diffBox.x1}] y[${r.diffBox.y0}..${r.diffBox.y1}]` : '';
    throw new Error(`assertGameEqualsBench FAILED: IoU ${r.iou.toFixed(4)} < ${minIoU} (game-mask ${r.maskGame}, bench-mask ${r.maskBench}, inter ${r.inter})${box} - see shots/game_vs_bench_diff.png`);
  }
  return r;
}

// direct run: npx tsx tools/game_vs_bench.ts
if (process.argv[1] && process.argv[1].endsWith('game_vs_bench.ts')) {
  const r = assertGameEqualsBench();
  console.log(`assertGameEqualsBench PASS: IoU=${r.iou.toFixed(4)} set=${r.set} pxm=${r.pxm} maskGame=${r.maskGame} maskBench=${r.maskBench}`);
}
