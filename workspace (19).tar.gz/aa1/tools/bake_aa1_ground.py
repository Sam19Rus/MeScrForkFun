"""AA1 content bridge: bake the biome-field ground texture for the AA1 map.

Content comes from the PRODUCTION pipeline palette (frontier_service ramps) so the
playable slice and the building art share one visual language. No buildings here:
AA1 map = open field with three blended biomes, per user's decision.

  biome A "ash dust"   - ochre dust flats (DIRT ramp), sparse dry scrub, cracks
  biome B "slate rock" - grey rocky ground (SLATE/CONC ramps), rock clusters
  biome C "rust flat"  - rust-red hardpan (COPPER/DIRT dark), scrub, iron pebbles

Output: aa1/assets/ground.png (1920x1080 = 64x36 m @ 30 px/m) + ground_meta.json.
Deterministic: same output bytes on every run (seed fixed).
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
from typing import Dict, List, Tuple

# NOTE: never hardcode the workspace root in file contents - the sandbox maps it per-process.
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))     # aa1/
_WS = os.path.dirname(_ROOT)                                             # workspace root
_PROD = os.path.join(_WS, "PALE_MERIDIAN_PRODUCTION", "pm", "base")
sys.path.insert(0, _PROD if os.path.isdir(_PROD) else os.path.dirname(os.path.abspath(__file__)))

from palettes.frontier_service import CONC, COPPER, DARK, DIRT, SLATE, VERD  # noqa: E402

W, H = 2560, 1440
SEED = 90210
PXM = 40

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "assets")


# ---------------------------------------------------------------- noise
def _h2(x: int, y: int, s: int) -> float:
    n = (x * 374761393 + y * 668265263 + s * 144665) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 1023) / 1023.0


def vnoise(x: float, y: float, s: int) -> float:
    xi, yi = math.floor(x), math.floor(y)
    xf, yf = x - xi, y - yi
    sx, sy = xf * xf * (3 - 2 * xf), yf * yf * (3 - 2 * yf)
    n00, n10 = _h2(xi, yi, s), _h2(xi + 1, yi, s)
    n01, n11 = _h2(xi, yi + 1, s), _h2(xi + 1, yi + 1, s)
    a = n00 + (n10 - n00) * sx
    b = n01 + (n11 - n01) * sx
    return a + (b - a) * sy


def fbm(x: float, y: float, octaves: int, s: int) -> float:
    v, amp, f, norm = 0.0, 0.5, 1.0, 0.0
    for i in range(octaves):
        v += vnoise(x * f, y * f, s + i * 131) * amp
        norm += amp
        amp *= 0.5
        f *= 2.0
    return v / norm


# ---------------------------------------------------------------- palette
RAMPS: Dict[str, List[Tuple[int, int, int]]] = {
    "DIRT": DIRT, "SLATE": SLATE, "CONC": CONC, "COPPER": COPPER, "DARK": DARK, "VERD": VERD,
}
UNION: List[Tuple[int, int, int]] = sorted({c for r in RAMPS.values() for c in r})
_CUBE: Dict[int, int] = {}


def snap(r: int, g: int, b: int) -> int:
    """Nearest palette colour, cached per 4x4x4 cube cell (keeps bake in one pass)."""
    key = ((r >> 2) << 12) | ((g >> 2) << 6) | (b >> 2)
    hit = _CUBE.get(key)
    if hit is not None:
        return hit
    best, bd = UNION[0], 1 << 30
    for c in UNION:
        d = (c[0] - r) ** 2 + (c[1] - g) ** 2 + (c[2] - b) ** 2
        if d < bd:
            best, bd = c, d
    packed = (best[0] << 16) | (best[1] << 8) | best[2]
    _CUBE[key] = packed
    return packed


def _idx(v: float, n: int) -> int:
    return max(0, min(n - 1, int(v * n)))


def ramp_c(name: str, v: float) -> Tuple[int, int, int]:
    r = RAMPS[name]
    return r[_idx(v, len(r))]


# ---------------------------------------------------------------- biome mix
def biome_weights(x: float, y: float) -> Tuple[float, float, float]:
    t = fbm(x / 760.0, y / 760.0, 3, SEED + 7)          # large biome masses
    m = fbm(x / 300.0, y / 300.0, 2, SEED + 29)
    t = t * 0.85 + m * 0.15
    centers = (0.30, 0.50, 0.70)   # A dust, B slate, C rust
    band = 0.13
    ws = [max(0.0, band - abs(t - c)) for c in centers]
    s = sum(ws)
    if s <= 0:
        return (1.0, 0.0, 0.0)
    return (ws[0] / s, ws[1] / s, ws[2] / s)


def base_color(x: int, y: int) -> int:
    wa, wb, wc = biome_weights(x, y)
    # large forms + medium detail + grain
    n1 = fbm(x / 150.0, y / 150.0, 4, SEED)             # medium forms
    n2 = fbm(x / 36.0, y / 36.0, 3, SEED + 3)           # detail
    t = n1 * 0.75 + n2 * 0.25
    ca = ramp_c("DIRT", 0.15 + t * 0.8)
    if t < 0.55:                                        # slate earth, warm-grey
        cs, cc2 = ramp_c("SLATE", t * 0.8), ramp_c("CONC", 0.2 + t * 0.5)
        cb = tuple(cs[i] * 0.55 + cc2[i] * 0.45 for i in range(3))
    else:
        cb = ramp_c("CONC", (t - 0.55) * 1.4 + 0.25)
    if t < 0.45:                                        # rust hardpan, desaturated
        cr, cd = ramp_c("COPPER", t * 0.75), ramp_c("DIRT", t * 0.5)
        cc = tuple(cr[i] * 0.5 + cd[i] * 0.5 for i in range(3))
    else:
        cd, cr = ramp_c("DIRT", t * 0.55), ramp_c("COPPER", 0.15 + t * 0.3)
        cc = tuple(cd[i] * 0.7 + cr[i] * 0.3 for i in range(3))
    r = ca[0] * wa + cb[0] * wb + cc[0] * wc
    g = ca[1] * wa + cb[1] * wb + cc[1] * wc
    b = ca[2] * wa + cb[2] * wb + cc[2] * wc
    # macro shading: very low frequency light variation gives big readable forms
    sh = 0.90 + 0.15 * fbm(x / 460.0, y / 460.0, 2, SEED + 77)
    r *= sh; g *= sh; b *= sh
    # fine grain speckle (rare, subtle)
    hs = _h2(x, y, SEED + 55)
    if hs > 0.955:
        d = 10 if hs > 0.977 else -9
        r += d; g += d; b += d
    return snap(max(0, min(255, int(r))), max(0, min(255, int(g))), max(0, min(255, int(b))))


# ---------------------------------------------------------------- detail painters
px = bytearray(W * H * 3)


def put(x: int, y: int, packed: int) -> None:
    if 0 <= x < W and 0 <= y < H:
        i = (y * W + x) * 3
        px[i] = (packed >> 16) & 255
        px[i + 1] = (packed >> 8) & 255
        px[i + 2] = packed & 255


def get(x: int, y: int) -> int:
    if not (0 <= x < W and 0 <= y < H):
        return 0
    i = (y * W + x) * 3
    return (px[i] << 16) | (px[i + 1] << 8) | px[i + 2]


def darker(packed: int, k: float) -> int:
    r = min(255, int(((packed >> 16) & 255) * k))
    g = min(255, int(((packed >> 8) & 255) * k))
    b = min(255, int((packed & 255) * k))
    return snap(r, g, b)


def paint_crack(x0: int, y0: int, length: int, seed_i: int, thick: bool) -> None:
    x, y, ang = float(x0), float(y0), _h2(x0, y0, seed_i) * 6.283
    for step in range(length):
        ang += (_h2(int(x), int(y), seed_i + step) - 0.5) * 1.1
        x += math.cos(ang)
        y += math.sin(ang) * 0.7
        xi, yi = int(x), int(y)
        if not (0 <= xi < W and 0 <= yi < H):
            return
        put(xi, yi, darker(get(xi, yi), 0.55))
        if thick and step % 2 == 0:
            put(xi, yi + 1, darker(get(xi, yi + 1), 0.62))


def paint_pebbles(cx: int, cy: int, n: int, seed_i: int) -> None:
    for i in range(n):
        a = _h2(cx + i, cy, seed_i) * 6.283
        rr = _h2(cx, cy + i, seed_i + 9) * 9 + 2
        x, y = int(cx + math.cos(a) * rr), int(cy + math.sin(a) * rr * 0.7)
        if not (0 <= x < W and 0 <= y < H):
            continue
        light = _h2(x, y, seed_i + 4) > 0.5
        k = 1.28 if light else 0.72
        put(x, y, darker(get(x, y), k))
        if light and k > 1:
            put(x, y - 1, darker(get(x, y - 1), 1.12))


def paint_rock_cluster(cx: int, cy: int, seed_i: int) -> None:
    n = 5 + int(_h2(cx, cy, seed_i) * 5)
    for i in range(n):
        ox = int((_h2(cx + i * 7, cy, seed_i + i) - 0.5) * 22)
        oy = int((_h2(cx, cy + i * 7, seed_i + i) - 0.5) * 13)
        x, y = cx + ox, cy + oy
        rw = 2 + int(_h2(x, y, seed_i + 3) * 3)
        rh = 1 + int(_h2(y, x, seed_i + 5) * 2)
        tone = _h2(x + i, y, seed_i + 11)
        base = ramp_c("SLATE", 0.35 + tone * 0.5)
        packed = snap(*base)
        for dy in range(-rh, rh + 1):
            for dx in range(-rw, rw + 1):
                if dx * dx + dy * dy * 2 > rw * rh + 1:
                    continue
                k = 1.25 if dy < 0 else (0.7 if dy > 0 else 1.0)
                c = packed
                r = min(255, int(((c >> 16) & 255) * k))
                g = min(255, int(((c >> 8) & 255) * k))
                b = min(255, int((c & 255) * k))
                put(x + dx, y + dy, snap(r, g, b))
        # AO under rock
        for dx in range(-rw, rw + 1):
            put(x + dx, y + rh + 1, darker(get(x + dx, y + rh + 1), 0.6))


def paint_scrub(cx: int, cy: int, seed_i: int, verdant: bool) -> None:
    n = 6 + int(_h2(cx, cy, seed_i) * 8)
    for i in range(n):
        ox = int((_h2(cx + i * 3, cy, seed_i + i) - 0.5) * 14)
        oy = int((_h2(cx, cy + i * 3, seed_i + i) - 0.5) * 9)
        x, y = cx + ox, cy + oy
        if not (0 <= x < W and 0 <= y < H):
            continue
        put(x, y + 1, darker(get(x, y + 1), 0.65))          # soil shadow
        for b in range(3):
            bx = x + b - 1
            hgt = 2 + int(_h2(bx, y, seed_i + b) * 3)
            for dy in range(hgt):
                t = dy / max(1, hgt - 1)
                if verdant:
                    cv, cd = ramp_c("VERD", 0.2 + t * 0.5), ramp_c("DIRT", 0.35 + t * 0.3)
                    c = tuple(int(cv[i] * 0.6 + cd[i] * 0.4) for i in range(3))
                else:
                    c = ramp_c("DIRT", 0.75 + t * 0.25)
                    c = (min(255, c[0] + 12), min(255, c[1] + 4), max(0, c[2] - 10))
                put(bx, y - dy, snap(*c))


def paint_dark_patch(cx: int, cy: int, r: int, seed_i: int) -> None:
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            d2 = dx * dx + dy * dy * 1.6
            if d2 > r * r:
                continue
            x, y = cx + dx, cy + dy
            if not (0 <= x < W and 0 <= y < H):
                continue
            edge = (math.sqrt(d2) / r)
            k = 0.82 + 0.1 * edge + _h2(x, y, seed_i) * 0.06
            put(x, y, darker(get(x, y), k))


# ---------------------------------------------------------------- bake
def main() -> None:
    # 1) base terrain per pixel
    for y in range(H):
        for x in range(W):
            c = base_color(x, y)
            i = (y * W + x) * 3
            px[i] = (c >> 16) & 255
            px[i + 1] = (c >> 8) & 255
            px[i + 2] = c & 255

    # 2) deterministic detail scatter
    import random
    rnd = random.Random(SEED)
    for _ in range(240):                       # dark AO-ish patches
        paint_dark_patch(rnd.randrange(W), rnd.randrange(H), rnd.randrange(6, 16), SEED + 1)
    for _ in range(520):                       # cracks
        x, y = rnd.randrange(W), rnd.randrange(H)
        wa, wb, _ = biome_weights(x, y)
        if wa + wb * 0.4 < rnd.random() * 0.9:
            paint_crack(x, y, rnd.randrange(8, 34), SEED + 2, rnd.random() < 0.4)
    for _ in range(900):                       # pebble clusters
        paint_pebbles(rnd.randrange(W), rnd.randrange(H), rnd.randrange(3, 9), SEED + 3)
    for _ in range(210):                       # rock clusters mostly in biome B
        x, y = rnd.randrange(W), rnd.randrange(H)
        _, wb, _ = biome_weights(x, y)
        if wb > 0.35 or rnd.random() < 0.15:
            paint_rock_cluster(x, y, SEED + 4)
    for _ in range(380):                       # gravel seams on biome boundaries
        x, y = rnd.randrange(W), rnd.randrange(H)
        wa, wb, wc = biome_weights(x, y)
        top = sorted((wa, wb, wc), reverse=True)
        if top[0] - top[1] < 0.22:             # near a boundary -> gravel seam
            paint_pebbles(x, y, rnd.randrange(6, 14), SEED + 6)
    for _ in range(420):                       # scrub: sparse dry in A/C, verdant hints in C
        x, y = rnd.randrange(W), rnd.randrange(H)
        wa, wb, wc = biome_weights(x, y)
        if wb > 0.6:
            continue
        verdant = wc > 0.45 and rnd.random() < 0.4
        if rnd.random() < wa * 0.5 + wc * 0.8:
            paint_scrub(x, y, SEED + 5, verdant)

    # 3) write PNG + meta
    from PIL import Image
    img = Image.frombytes("RGB", (W, H), bytes(px))
    os.makedirs(OUT_DIR, exist_ok=True)
    out_png = os.path.join(OUT_DIR, "ground.png")
    img.save(out_png, optimize=True)
    meta = {
        "w": W, "h": H, "pxm": PXM, "seed": SEED,
        "biomes": ["ash_dust", "slate_rock", "rust_flat"],
        "source": "bake_aa1_ground.py (content bridge from PALE_MERIDIAN_PRODUCTION palette)",
    }
    with open(os.path.join(OUT_DIR, "ground_meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    digest = hashlib.md5(open(out_png, "rb").read()).hexdigest()
    print(f"ground.png {W}x{H} md5={digest}")
    print("meta:", json.dumps(meta))


if __name__ == "__main__":
    main()
