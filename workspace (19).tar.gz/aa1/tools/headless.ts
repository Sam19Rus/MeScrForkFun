import { runHeadless } from '../src/shell/headless.js';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const out = join(here, '..', 'shots');

// Run 1: free play bot (combat feel, death possible)
const res1 = runHeadless({
  outDir: out,
  ticks: 60 * 90,
  shots: [
    { tick: 10, name: '01_menu' },
    { tick: 40, name: '02_spawn' },
    { tick: 60 * 6, name: '03_fight' },
    { tick: 60 * 18, name: '04_mid' },
    { tick: 60 * 40, name: '05_loot' },
    { tick: 60 * 70, name: '06_late' },
    { tick: 60 * 89, name: '07_end' },
  ],
});

// Run 2: showcase - container opening, pickup/confiscation toasts, guild shuttle at 50 kills
const res2 = runHeadless({
  outDir: out,
  ticks: 60 * 60,
  seed: 20260930,
  shots: [
    { tick: 60 * 21, name: '08_container' },
    { tick: 60 * 24, name: '09_pickup' },
    { tick: 60 * 34, name: '10_shuttle' },
    { tick: 60 * 37, name: '11_crate' },
    { tick: 60 * 45, name: '12_zoomed' },
    { tick: 60 * 27 + 20, name: '13_confiscate' },
    { tick: 60 * 41 + 20, name: '14_legendary' },
    { tick: 60 * 54, name: '15_companion' },
  ],
  interventions: [
    { tick: 60 * 20, kind: 'goto_box' },        // stand at first container, bot opens it
    { tick: 60 * 26, kind: 'drop_common' },     // worse gun -> guild confiscation toast
    { tick: 60 * 30, kind: 'kills_49' },        // next kill triggers the guild shuttle
    { tick: 60 * 40, kind: 'drop_legendary' },  // better gun -> pickup toast + equip
    { tick: 60 * 44, kind: 'zoom_out' },
    { tick: 60 * 50, kind: 'goto_capsule' },    // open a capsule -> companion
  ],
});

console.log(JSON.stringify({ run1: res1, run2: res2 }, null, 2));
