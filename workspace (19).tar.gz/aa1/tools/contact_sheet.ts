/**
 * Contact sheet: grid of the headless run frames (shots/01..15) at half scale with captions.
 * Run after `npm run headless`. Usage: npx tsx tools/contact_sheet.ts
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodePNG, encodePNG } from '../src/engine/png.js';
import { PixelBuf, rgba } from '../src/core/buf.js';
import { drawTextS } from '../src/game/font.js';
import { P } from '../src/core/palette.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');
const shots = join(root, 'shots');

const NAMES: [string, string][] = [
  ['01_menu', 'menu'], ['02_spawn', 'spawn'], ['03_fight', 'fight'], ['04_mid', 'mid'],
  ['05_loot', 'loot'], ['06_late', 'late'], ['07_end', 'end'], ['08_container', 'container'],
  ['09_pickup', 'pickup'], ['10_shuttle', 'shuttle'], ['11_crate', 'crate'], ['12_zoomed', 'zoomed'],
  ['13_confiscate', 'confiscate'], ['14_legendary', 'legendary'], ['15_companion', 'companion'],
];

const present = NAMES.filter(([f]) => existsSync(join(shots, `${f}.png`)));
if (!present.length) throw new Error('no headless frames found - run `npm run headless` first');
const imgs = present.map(([f]) => decodePNG(readFileSync(join(shots, `${f}.png`))));
const CW = 320, CH = 180, S = 0.5;
const COLS = 4;
const ROWS = Math.ceil(imgs.length / COLS);
const cellW = Math.round(CW * S), cellH = Math.round(CH * S);
const out = new PixelBuf(COLS * (cellW + 8) + 8, ROWS * (cellH + 20) + 8, rgba(12, 14, 18));
imgs.forEach((im, i) => {
  const cx = 8 + (i % COLS) * (cellW + 8);
  const cy = 8 + Math.floor(i / COLS) * (cellH + 20);
  for (let y = 0; y < cellH; y++) for (let x = 0; x < cellW; x++) {
    const sx = Math.round(x / S), sy = Math.round(y / S);
    if (sx < im.w && sy < im.h) out.px[(cy + y) * out.w + cx + x] = im.px[sy * im.w + sx];
  }
  drawTextS(out, cx, cy + cellH + 4, `${present[i][0]} ${present[i][1]}`, P.text);
});
writeFileSync(join(shots, '00_contact_sheet.png'), encodePNG(out));
console.log('contact sheet ->', join(shots, '00_contact_sheet.png'), `(${imgs.length} frames)`);
