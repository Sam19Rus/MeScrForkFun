import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PixelBuf, rgba } from '../src/core/buf.js';
import { encodePNG, decodePNG } from '../src/engine/png.js';
import { drawHero, drawSprite } from '../src/game/hero.js';
import {
  ART_TORSO, ART_NECK, ART_THIGH, ART_SHIN, ART_BOOT, ART_UPARM, ART_FOREARM,
  ART_HAND_FIST, ART_HAND_SUPPORT,
  HEAD_SET, GUNS, HERO_PAL, SKIN_VARIANTS, ARMOR_SETS,
  type GunKind, type HeadOrient,
} from '../src/game/hero_art.js';
import { buildScaleArts } from '../src/game/hero_scale.js';
import { drawTextS } from '../src/game/font.js';
import { P } from '../src/core/palette.js';
import { GameCore } from '../src/game/game.js';
import { PoseEditor } from '../src/game/pose_editor.js';
import { ROOKIE40_TORSO, ROOKIE40_HEADS, ROOKIE40_THIGH, ROOKIE40_SHIN, ROOKIE40_BOOT, ROOKIE40_UPARM, ROOKIE40_FOREARM, ROOKIE40_UPARMS, ROOKIE40_FOREARMS, ROOKIE40_FIST, ROOKIE40_SUPHAND, ROOKIE40_NECK } from '../src/game/hero_art40_rookie.js';
const PARTS_LOOKUP = ['head', 'neck', 'torso', 'uparmF', 'forearmF', 'handF', 'gun', 'handS', 'forearmS', 'uparmS', 'thighF', 'shinF', 'bootF', 'thighB', 'shinB', 'bootB'];
import type { PartDbg } from '../src/game/hero.js';
import { NullSfx } from '../src/engine/audio.js';
import { emptyInput } from '../src/engine/input.js';
import { DT } from '../src/game/config.js';

/**
 * HERO BENCH v2 - benchmark screenshots for the anatomy/articulation pass:
 *  hero_parts.png      - every authored part at 6x (thigh/shin/boot/upper arm/forearm/glove/neck/
 *                        head 4 orientations) + weapons 4x with GRIP/HANDGUARD anchor marks
 *  hero_walk.png       - 8-keyframe walk cycle strip at 3x
 *  hero_angles.png     - 16 aim angles at 3x over real ground, crosshair proves atan2 aim
 *  hero_grip.png       - 6x crops "both hands on the weapon" per gun class
 *  hero_weapons.png    - all weapon classes at 3x (kept from v1)
 *  hero_silhouette.png - silhouette test: hero flooded black, pose + weapon must read
 *  hero_gameplay.png   - live GameCore frame (1x, gameplay size)
 *  hero_crop4x.png     - 4x crop of the same frame around the player
 */
const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');
const outDir = join(root, 'shots');
mkdirSync(outDir, { recursive: true });
const ground = decodePNG(readFileSync(join(root, 'public', 'assets', 'ground.png')));

/** Nearest-neighbor upscale (pixel art stays crisp). */
function up(src: PixelBuf, k: number): PixelBuf {
  const o = new PixelBuf(src.w * k, src.h * k);
  for (let y = 0; y < src.h; y++)
    for (let x = 0; x < src.w; x++) {
      const c = src.get(x, y);
      for (let dy = 0; dy < k; dy++)
        for (let dx = 0; dx < k; dx++) o.set(x * k + dx, y * k + dy, c);
    }
  return o;
}

function groundSheet(w: number, h: number, gx = 700, gy = 380): PixelBuf {
  const b = new PixelBuf(w, h);
  b.blit(ground, 0, 0, gx % (ground.w - w - 1), gy % (ground.h - h - 1), w, h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) b.blend(x, y, rgba(10, 11, 14, 96)); // darken so the hero pops
  return b;
}
const label = (b: PixelBuf, x: number, y: number, s: string) => drawTextS(b, x, y, s, P.text);

function partBufPal(art: string[], pal: Record<string, number>): PixelBuf {
  const s = new PixelBuf(art[0].length, art.length);
  drawSprite(s, art, pal, 0, 0);
  return s;
}
function partBuf(art: string[]): PixelBuf {
  const s = new PixelBuf(art[0].length, art.length);
  drawSprite(s, art, HERO_PAL, 0, 0);
  return s;
}


/** v6 auto-check: flood-fill transparent pixels from the grid border; any transparent pixel left
 *  unreachable INSIDE the bbox is an interior hole -> bench fails with the art name. */
function assertNoInteriorHoles(art: string[], name: string): void {
  const h = art.length, w = art[0].length;
  const seen = new Uint8Array(w * h);
  const stack: number[] = [];
  const push = (x: number, y: number) => {
    const i = y * w + x;
    if (seen[i]) return;
    seen[i] = 1; stack.push(i);
  };
  for (let x = 0; x < w; x++) { if (art[0][x] === '.') push(x, 0); if (art[h - 1][x] === '.') push(x, h - 1); }
  for (let y = 0; y < h; y++) { if (art[y][0] === '.') push(0, y); if (art[y][w - 1] === '.') push(w - 1, y); }
  while (stack.length) {
    const i = stack.pop()!;
    const x = i % w, y = (i / w) | 0;
    if (x > 0 && art[y][x - 1] === '.' && !seen[i - 1]) push(x - 1, y);
    if (x < w - 1 && art[y][x + 1] === '.' && !seen[i + 1]) push(x + 1, y);
    if (y > 0 && art[y - 1][x] === '.' && !seen[i - w]) push(x, y - 1);
    if (y < h - 1 && art[y + 1][x] === '.' && !seen[i + w]) push(x, y + 1);
  }
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++)
      if (art[y][x] === '.' && !seen[y * w + x])
        throw new Error(`assertNoInteriorHoles: INTERIOR HOLE in ${name} at (${x},${y})`);
}
{
  const audited: [string, string[]][] = [];
  for (const s of ARMOR_SETS) {
    audited.push([`torso_${s.id}`, s.torso]);
    if (s.helmet) for (const o of ['up', 'profile', 'down'] as HeadOrient[]) audited.push([`helmet_${s.id}_${o}`, s.helmet[o]]);
    for (const [nm, art] of [['thigh', s.thigh], ['shin', s.shin], ['boot', s.boot], ['uparm', s.uparm], ['forearm', s.forearm]] as [string, string[] | undefined][])
      if (art) audited.push([`${nm}_${s.id}`, art]);
  }
  for (const hair of ['A', 'B', 'C', 'D', 'E', 'F'] as const)
    for (const o of ['up', 'profile', 'down'] as HeadOrient[])
      audited.push([`head_${hair}_${o}`, HEAD_SET.base.hairs[hair][o]]);
  for (const [nm, art] of [['thigh_base', ART_THIGH], ['shin_base', ART_SHIN], ['boot_base', ART_BOOT],
    ['uparm_base', ART_UPARM], ['forearm_base', ART_FOREARM], ['fist', ART_HAND_FIST], ['suphand', ART_HAND_SUPPORT],
    ['neck', ART_NECK]] as [string, string[]][]) audited.push([nm, art]);
  for (const pxm of [36, 40])
    for (const sid of ['rookie'] as const) {
      const sc = buildScaleArts(pxm);
      audited.push([`torso_${sid}_${pxm}`, sc.torso], [`neck_${sid}_${pxm}`, sc.neck]);
      for (const o of ['up', 'profile', 'down'] as HeadOrient[]) {
        if (sc.helmet) audited.push([`helmet_${sid}_${pxm}_${o}`, sc.helmet[o]]);
        audited.push([`head_${sid}_${pxm}_${o}`, sc.heads[o]]);
      }
      for (const [nm, art] of [['thigh', sc.thigh], ['shin', sc.shin], ['boot', sc.boot],
        ['uparm', sc.uparm], ['forearm', sc.forearm], ['fist', sc.fist], ['suphand', sc.suphand]] as [string, string[]][])
        audited.push([`${nm}_${sid}_${pxm}`, art]);
    }
  // NOTE: full-figure replicas are EXCLUDED from the interior-hole audit on purpose: enclosed
  // transparent gaps (e.g. between the legs behind the crossing near arm) are legitimate
  // background in a composition sprite, unlike part sprites (torso/helmet/bones).
  for (const [nm, art] of audited) assertNoInteriorHoles(art, nm);
  console.log(`assertNoInteriorHoles: ${audited.length} arts clean (30/36/40 px/m)`);
}


/** v16 P0: mechanical visor audit. Glass box = maximal consecutive 'e'-rows; interior must be
 *  solid 'e' except specular 'v' at (g0,c0+1) [and (g0,c0+2) when outer]; frame 'n' ring around
 *  (top/bottom rows + side cols when sides); outer '3' cols at c0-2/c1+2 when outer. */

/** checker background cell for the holes visual check. */
function checker(w: number, h: number): PixelBuf {
  const b = new PixelBuf(w, h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++)
      b.set(x, y, ((x >> 2) + (y >> 2)) & 1 ? rgba(150, 150, 156) : rgba(96, 96, 102));
  return b;
}

// ---------------------------------------------------------------- parts sheet (6x)
{
  const b = new PixelBuf(980, 470, rgba(18, 20, 26));
  label(b, 20, 8, 'AA1 HERO RIG V3 - STOCKY PART SET: TWO-BONE LIMBS / HANDS / NECK / HEAD 4 ORIENTATIONS (6X)');
  const parts: [string, string[]][] = [
    ['THIGH 10X11', ART_THIGH], ['SHIN 8X12', ART_SHIN], ['BOOT 9X5', ART_BOOT],
    ['UPPER ARM 7X14', ART_UPARM], ['FOREARM 7X9', ART_FOREARM], ['NECK 5X5', ART_NECK],
  ];
  let x = 20;
  for (const [name, art] of parts) {
    const s = partBuf(art);
    b.blit(up(s, 6), x, 40);
    label(b, x, 26, name);
    x += s.w * 6 + 22;
  }
  // hands at 8x (weapon space): firing fist + support hand
  const fist = partBuf(ART_HAND_FIST);
  b.blit(up(fist, 8), x + 8, 36);
  label(b, x + 8, 26, 'FIST 8X');
  const suph = partBuf(ART_HAND_SUPPORT);
  b.blit(up(suph, 8), x + 84, 36);
  label(b, x + 84, 26, 'SUPPORT HAND 8X');
  // hair variant sheet at 6x: A (default) / B / C profiles + up/down of the active set + NPC skin
  const hairs: [string, string[]][] = [
    ['HAIR A UNDERCUT', HEAD_SET.base.hairs.A.profile],
    ['HAIR B TAIL', HEAD_SET.base.hairs.B.profile],
    ['HAIR C SPIKES (DEF)', HEAD_SET.base.hairs.C.profile],
    ['UP (A)', HEAD_SET.base.hairs.A.up],
    ['DOWN (A)', HEAD_SET.base.hairs.A.down],
  ];
  let hx = 20;
  for (const [name, art] of hairs) {
    const s = new PixelBuf(art[0].length, art.length);
    drawSprite(s, art, { ...HERO_PAL, ...SKIN_VARIANTS.light }, 0, 0, false);
    b.blit(up(s, 6), hx, 210);
    label(b, hx, 196, name);
    hx += 13 * 6 + 22;
  }
  // skin variants: tan = future NPC slot in the part-set
  const tanArt = HEAD_SET.base.hairs.A.profile;
  const st = new PixelBuf(tanArt[0].length, tanArt.length);
  drawSprite(st, tanArt, { ...HERO_PAL, ...SKIN_VARIANTS.tan }, 0, 0, false);
  b.blit(up(st, 6), hx + 4, 210);
  label(b, hx + 4, 196, 'TAN (NPC)');
  // torso reference at 4x
  const torso = partBuf(ART_TORSO);
  b.blit(up(torso, 4), 600, 196);
  label(b, 600, 182, 'TORSO 25X21 4X (V3 WEDGE)');
  // weapons with GRIP/HANDGUARD marks at 4x (own row)
  const guns: GunKind[] = ['rifle', 'smg', 'pistol', 'launcher', 'blade'];
  let gx = 20;
  for (const gk of guns) {
    const art = GUNS[gk].rows;
    const s = partBuf(art);
    b.blit(up(s, 4), gx, 350);
    const gp = GUNS[gk].grip, hg = GUNS[gk].handguard;
    // GRIP = red cross, HANDGUARD = cyan cross
    const marks: ([[number, number], number])[] = [[gp, rgba(255, 90, 70)]];
    if (hg) marks.push([hg, rgba(90, 220, 232)]);
    for (const [pt, col] of marks) {
      const [px, py] = pt;
      const cx = gx + px * 4 + 2, cy = 350 + py * 4 + 2;
      b.hline(cx - 3, cy, 7, col); b.vline(cx, cy - 3, 7, col);
    }
    label(b, gx, 336, gk.toUpperCase());
    gx += s.w * 4 + 20;
  }
  label(b, 620, 214, 'WEAPONS 4X BELOW: GRIP = RED CROSS,');
  label(b, 620, 224, 'HANDGUARD = CYAN CROSS');
  writeFileSync(join(outDir, 'hero_parts.png'), encodePNG(b));
}

// ---------------------------------------------------------------- walk cycle (3x, 8 keyframes)
{
  const cw = 128, ch = 210, n = 8;
  const b = groundSheet(n * cw + 20, ch + 46, 900, 520);
  label(b, 10, 6, 'WALK CYCLE V3 - 8 AUTHORED KEYFRAMES: STICKY STANCE FOOT, KNEE BEND, TORSO BOB (3X)');
  for (let i = 0; i < n; i++) {
    const ph = (i * Math.PI * 2) / n;
    const cell = new PixelBuf(78, 66);
    drawHero(cell, 26, 62, { aimAng: 0, moving: true, walk: ph, flash: false, gun: 'rifle', muzzle: 0 });
    b.blit(up(cell, 3), 10 + i * cw + 4, 30);
    label(b, 10 + i * cw + 4, 20, `K${i}`);
  }
  writeFileSync(join(outDir, 'hero_walk.png'), encodePNG(b));
}

// ---------------------------------------------------------------- idle low-ready (3x)
{
  const cw = 128, ch = 210, n = 3;
  const b = groundSheet(n * cw + 20, ch + 46, 900, 520);
  label(b, 10, 6, 'IDLE V8 - LOW-READY (MUZZLE ~45 DEG DOWN-FWD, HEAD FORWARD) / BLEND / AIM, 3X');
  const cells: [string, number][] = [['LOW-READY', 1], ['BLEND 0.5', 0.5], ['AIM', 0]];
  cells.forEach(([name, lrv], i) => {
    const cell = new PixelBuf(78, 66);
    drawHero(cell, 26, 62, { aimAng: -0.2, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, lowReady: lrv });
    b.blit(up(cell, 3), 10 + i * cw + 4, 30);
    label(b, 10 + i * cw + 4, 20, name);
  });
  writeFileSync(join(outDir, 'hero_idle.png'), encodePNG(b));
}

// ---------------------------------------------------------------- posture lean (3x): idle vs run
{
  const cw = 128, ch = 210, n = 4;
  const b = groundSheet(n * cw + 20, ch + 46, 900, 520);
  label(b, 10, 6, 'POSTURE V5 - IDLE STRAIGHT (NO CROUCH) VS RUN LEAN (ENTER/EXIT ~150 MS), 3X');
  const cells: [string, boolean, number, [number, number], number][] = [
    ['IDLE', false, 0, [1, 0], 1],
    ['RUN +30MS', true, 0, [1, 0], 2],   // ~2 frames into the 150 ms ramp
    ['RUN LEAN', true, Math.PI / 2, [1, 0], 12],
    ['RUN LEAN DIAG', true, Math.PI, [0.707, 0.707], 1],
  ];
  // lean state is module-level in hero.ts: warm it up exactly like a run would (deterministic)
  for (let i = 0; i < n; i++) {
    const [name, mv, ph, mdir, warm] = cells[i];
    const cell = new PixelBuf(78, 66);
    for (let w = 0; w < warm; w++)
      drawHero(cell, 26, 62, { aimAng: 0, moving: mv, walk: ph, flash: false, gun: 'rifle', muzzle: 0, moveDir: mdir });
    cell.fill(0);
    drawHero(cell, 26, 62, { aimAng: 0, moving: mv, walk: ph, flash: false, gun: 'rifle', muzzle: 0, moveDir: mdir });
    b.blit(up(cell, 3), 10 + i * cw + 4, 30);
    label(b, 10 + i * cw + 4, 20, name);
  }
  writeFileSync(join(outDir, 'hero_lean.png'), encodePNG(b));
}

// ---------------------------------------------------------------- hair sheet: 6 styles 6x + 1x row
{
  const ids = ['A', 'B', 'C', 'D', 'E', 'F'] as const;
  const names: Record<string, string> = {
    A: 'A QUIFF-UNDERCUT', B: 'B SLICK-BACK', C: 'C BUZZ+BEARD', D: 'D TAIL', E: 'E SIDE-SWEPT', F: 'F RIDGE',
  };
  const b = new PixelBuf(6 * 110 + 20, 220, rgba(18, 20, 26));
  label(b, 20, 8, 'HAIR SET V13 - 6 STYLES (6X HEADS + 1X FULL BODY: SILHOUETTES MUST DIFFER)');
  ids.forEach((id, i) => {
    const art = HEAD_SET.base.hairs[id].profile;
    const s = new PixelBuf(art[0].length, art.length);
    drawSprite(s, art, { ...HERO_PAL, ...SKIN_VARIANTS.light }, 0, 0);
    b.blit(up(s, 6), 20 + i * 110, 40);
    label(b, 20 + i * 110, 26, names[id]);
    const cell = new PixelBuf(40, 62);
    HEAD_SET.hair = id;
    drawHero(cell, 18, 58, { aimAng: 0.1, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie' });
    HEAD_SET.hair = 'A';
    b.blit(cell, 30 + i * 110, 140);
    label(b, 20 + i * 110, 130, '1X');
  });
  writeFileSync(join(outDir, 'hero_hair_sheet.png'), encodePNG(b));
}

// ---------------------------------------------------------------- hero parts 40 (6x) rookie (v19)
{
  const b = new PixelBuf(760, 220, rgba(18, 20, 26));
  label(b, 10, 8, 'HERO PARTS 40 PX/M 5X: ROOKIE MERC (hand-stitched seams)');
  const palR = { ...HERO_PAL, ...SKIN_VARIANTS.light };
  const partsR: [string, string[]][] = [
    ['HEAD A', ROOKIE40_HEADS.A.profile], ['HEAD C', ROOKIE40_HEADS.C.profile], ['TORSO', ROOKIE40_TORSO], ['THIGH', ROOKIE40_THIGH],
    ['SHIN', ROOKIE40_SHIN], ['BOOT', ROOKIE40_BOOT], ['UPARM', ROOKIE40_UPARM], ['FORE', ROOKIE40_FOREARM],
    ['UPARM-S', ROOKIE40_UPARMS], ['FORE-S', ROOKIE40_FOREARMS], ['FIST', ROOKIE40_FIST], ['SUP', ROOKIE40_SUPHAND],
  ];
  let x = 16;
  for (const [nm, art] of partsR) {
    const c = new PixelBuf(art[0].length, art.length);
    drawSprite(c, art, palR, 0, 0);
    b.blit(up(c, 5), x, 26); label(b, x, 180, nm);
    x += art[0].length * 5 + 10;
  }
  writeFileSync(join(outDir, 'hero_parts40.png'), encodePNG(b));
}
// ---------------------------------------------------------------- gameplay sheets @40 (angles/walk/grip/silhouette)
{
  const b = new PixelBuf(760, 430, rgba(18, 20, 26));
  label(b, 10, 8, 'RIG @40: ANGLES (16), WALK 8 KEYS, GRIP (under-hand LEFT), SILHOUETTE 4x');
  let y = 30;
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    drawHero(b, 30 + i * 44, y + 92, { aimAng: a, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie', lowReady: 1, pxm: 40 });
  }
  label(b, 10, y + 6, 'ROOKIE');
  y += 120;
  for (let i = 0; i < 8; i++) {
    drawHero(b, 40 + i * 90, y + 100, { aimAng: i % 2 ? 0.4 : 2.7, moving: true, walk: (i / 8) * Math.PI * 2, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie', lowReady: 1, pxm: 40 });
  }
  label(b, 10, y + 6, 'WALK40 ROOKIE');
  y += 130;
  drawHero(b, 120, y + 90, { aimAng: 2.6, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie', lowReady: 0, pxm: 40 });
  label(b, 40, y + 6, 'GRIP40 AIM 2.6');
  y += 120;
  const cell = new PixelBuf(78, 78);
  drawHero(cell, 30, 74, { aimAng: 2.9, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie', lowReady: 1, pxm: 40 });
  for (let yy = 0; yy < cell.h; yy++) for (let xx = 0; xx < cell.w; xx++) {
    const c = cell.get(xx, yy);
    if ((c >>> 24) === 0) continue;
    cell.set(xx, yy, rgba(8, 8, 10));
  }
  b.blit(cell, 200, y + 20);
  label(b, 140, y + 6, 'SILHOUETTE40');
  writeFileSync(join(outDir, 'hero_rig40.png'), encodePNG(b));
}

// ---------------------------------------------------------------- holes visual check (3x, checker bg)
{
  const b = new PixelBuf(700, 300, rgba(18, 20, 26));
  label(b, 10, 8, 'HOLES CHECK V6: TORSOS ON CHECKER 3X (ASSERT ALSO RUNS HEADLESS)');
  let x = 20;
  for (const s of ARMOR_SETS) {
    const cell = checker(s.torso[0].length, s.torso.length);
    const spr = new PixelBuf(s.torso[0].length, s.torso.length);
    drawSprite(spr, s.torso, { ...HERO_PAL, ...(s.pal ?? {}) }, 0, 0);
    cell.blit(spr, 0, 0);
    b.blit(up(cell, 3), x, 30);
    label(b, x, 20, `${s.id.toUpperCase()} TORSO`);
    x += s.torso[0].length * 3 + 40;
  }
  writeFileSync(join(outDir, 'hero_holes.png'), encodePNG(b));
}

// ---------------------------------------------------------------- sets sheet (3x): profile + front
{
  const cw = 250, ch = 240, cols = 2;
  const b = groundSheet(cols * cw + 20, ch + 50, 640, 300);
  label(b, 10, 6, 'EQUIPMENT SETS V6 (3X): ROOKIE MERC (DEFAULT, SINGLE SHIPPED SET)');
  const cells: [string, string, number][] = [
    ['ROOKIE PROFILE', 'rookie', 0], ['ROOKIE FRONT', 'rookie', Math.PI / 2],
  ];
  cells.forEach(([name, setId, a], i) => {
    const cell = new PixelBuf(80, 76);
    drawHero(cell, 40, 70, { aimAng: a, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: setId });
    b.blit(up(cell, 3), 10 + (i % cols) * cw, 28 + Math.floor(i / cols) * ch);
    label(b, 14 + (i % cols) * cw, 18 + Math.floor(i / cols) * ch, name);
  });
  writeFileSync(join(outDir, 'hero_sets.png'), encodePNG(b));
}

// ---------------------------------------------------------------- silhouette: both sets
{
  const poses: { a: number; mv: boolean; ph: number; g: GunKind; s: string }[] = [
    { a: 0, mv: false, ph: 0, g: 'rifle', s: 'rookie' }, { a: Math.PI / 4, mv: true, ph: Math.PI / 2, g: 'rifle', s: 'rookie' },
    { a: -Math.PI / 2, mv: false, ph: 0, g: 'launcher', s: 'rookie' },
  ];
  const cw = 90, ch = 80;
  const b = new PixelBuf(poses.length * cw + 20, ch + 40, rgba(120, 124, 132));
  label(b, 10, 6, 'SILHOUETTE V7: ROOKIE MERC (MUST READ UNASSISTED)');
  poses.forEach((ps, i) => {
    const cell = new PixelBuf(78, 66);
    drawHero(cell, 26, 62, { aimAng: ps.a, moving: ps.mv, walk: ps.ph, flash: false, gun: ps.g, muzzle: 0, set: ps.s });
    for (let y = 0; y < cell.h; y++)
      for (let x = 0; x < cell.w; x++) {
        const c = cell.get(x, y);
        if ((c >>> 24) === 0) continue;
        cell.set(x, y, rgba(8, 8, 10));
      }
    b.blit(cell, 10 + i * cw + 12, 26);
  });
  writeFileSync(join(outDir, 'hero_silhouette.png'), encodePNG(b));
}

// ---------------------------------------------------------------- angles sheet (3x, 16 directions x rifle + smg)
{
  const cw = 250, ch = 240, cols = 4, rowsN = 4;
  const b = groundSheet(cols * cw + 20, rowsN * ch + 60, 640, 300);
  label(b, 10, 6, 'AIM ROTATION V6 - CHAINED JOINTS, 16 FRAMES (3X): ROOKIE BAND');
  const bands: string[] = ['rookie'];
  for (let g = 0; g < bands.length; g++) {
    for (let i = 0; i < 16; i++) {
      const a = (i * Math.PI * 2) / 16;
      const cell = new PixelBuf(80, 76);
      drawHero(cell, 40, 70, { aimAng: a, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: i === 0 && g === 0 ? 1 : 0, set: bands[g] });
      // crosshair at shoulder + 36px along aim (proves the arm tracks the cursor)
      const sx = 40 + Math.round(Math.cos(a) * 36), sy = 70 - 41 + Math.round(Math.sin(a) * 36);
      cell.hline(sx - 3, sy, 7, rgba(255, 90, 70)); cell.vline(sx, sy - 3, 7, rgba(255, 90, 70));
      cell.set(sx, sy, rgba(255, 240, 220));
      const cx = 10 + (i % cols) * cw, cy = 28 + (g * 4 + Math.floor(i / cols)) * ch;
      b.blit(up(cell, 3), cx, cy);
      label(b, cx + 4, cy - 10, `${bands[g].toUpperCase()} ${Math.round((a * 180) / Math.PI)} DEG`);
    }
  }
  writeFileSync(join(outDir, 'hero_angles.png'), encodePNG(b));
}

// ---------------------------------------------------------------- grip crops (6x)
{
  const guns: (GunKind)[] = ['rifle', 'smg', 'launcher', 'blade', 'pistol'];
  const cw = 300, ch = 200;
  const b = new PixelBuf(guns.length * cw + 20, ch + 46, rgba(18, 20, 26));
  label(b, 10, 6, 'TWO-HANDED GRIP 6X: FIRING GLOVE ON GRIP, SUPPORT GLOVE ON HANDGUARD (PISTOL = FREE HAND)');
  guns.forEach((gk, i) => {
    const cell = new PixelBuf(84, 74);
    drawHero(cell, 24, 68, { aimAng: -0.12, moving: false, walk: 0, flash: false, gun: gk, muzzle: 0 });
    // crop around the weapon+hands: root space x -8..40, y -52..-22
    const crop = new PixelBuf(48, 30);
    crop.blit(cell, 0, 0, 24 - 8, 68 - 52, 48, 30);
    b.blit(up(crop, 6), 10 + i * cw + 4, 30);
    label(b, 10 + i * cw + 4, 20, gk.toUpperCase());
  });
  writeFileSync(join(outDir, 'hero_grip.png'), encodePNG(b));
}

// ---------------------------------------------------------------- weapons (3x, kept from v1)
{
  const guns: (GunKind | 'none')[] = ['rifle', 'smg', 'pistol', 'launcher', 'blade', 'none'];
  const cw = 196, ch = 236;
  const b = groundSheet(guns.length * cw + 20, ch + 46, 300, 700);
  label(b, 10, 6, 'WEAPON CLASSES V3 - TWO-BONE ARMS + WEAPON-SPACE HANDS, PER-GUN GRIP ANCHORS (3X)');
  guns.forEach((g, i) => {
    const cell = new PixelBuf(62, 66);
    drawHero(cell, 16, 62, { aimAng: -0.3, moving: false, walk: 0, flash: false, gun: g, muzzle: g === 'smg' ? 1 : 0 });
    b.blit(up(cell, 3), 10 + i * cw + 4, 30);
    label(b, 10 + i * cw + 4, 20, g.toUpperCase());
  });
  writeFileSync(join(outDir, 'hero_weapons.png'), encodePNG(b));
}

// ---------------------------------------------------------------- silhouette test
{
  const poses: { a: number; mv: boolean; ph: number; g: GunKind }[] = [
    { a: 0, mv: false, ph: 0, g: 'rifle' }, { a: Math.PI / 4, mv: false, ph: 0, g: 'smg' },
    { a: -Math.PI / 2, mv: false, ph: 0, g: 'rifle' }, { a: Math.PI / 2, mv: false, ph: 0, g: 'launcher' },
    { a: 0, mv: true, ph: Math.PI / 2, g: 'rifle' }, { a: 0, mv: true, ph: Math.PI, g: 'blade' },
  ];
  const cw = 90, ch = 80;
  const b = new PixelBuf(poses.length * cw + 20, ch + 40, rgba(120, 124, 132));
  label(b, 10, 6, 'SILHOUETTE TEST: FLOODED BLACK - POSE + WEAPON MUST READ');
  poses.forEach((ps, i) => {
    const cell = new PixelBuf(78, 66);
    drawHero(cell, 26, 62, { aimAng: ps.a, moving: ps.mv, walk: ps.ph, flash: false, gun: ps.g, muzzle: 0 });
    for (let y = 0; y < cell.h; y++)
      for (let x = 0; x < cell.w; x++) {
        const c = cell.get(x, y);
        if ((c >>> 24) === 0) continue;
        // shadow pixels stay soft: flood only opaque body pixels to black
        cell.set(x, y, rgba(8, 8, 10));
      }
    b.blit(cell, 10 + i * cw + 12, 26);
  });
  writeFileSync(join(outDir, 'hero_silhouette.png'), encodePNG(b));
}

// ---------------------------------------------------------------- scale bench: 30 / 36 / 40 px/m
{
  const scales = [30, 36, 40];
  const cw = 210;
  const rowScene = 130, rowCrop = 320, rowSil = 130;
  const setH = rowScene + rowCrop + rowSil + 30;
  const b = new PixelBuf(3 * cw + 20, 1 * setH + 40, rgba(18, 20, 26));
  label(b, 10, 8, 'SCALE BENCH V10: 30 / 36 / 40 PX/M (RE-AUTHORED) - ROWS: SCENE 1X / CROP 4X / SILHOUETTE; ROOKIE');
  let base = 20;
  for (const sid of ['rookie'] as const) {
    scales.forEach((pxm, i) => {
      const k = pxm / 30;
      const cx = 10 + i * cw;
      label(b, cx + 60, base, `${sid.toUpperCase()} ${pxm} PX/M`);
      // scene 1x
      const cell = new PixelBuf(120, 120);
      const gnd = groundSheet(120, 120, 500 + i * 37, 400);
      cell.blit(gnd, 0, 0);
      drawHero(cell, 52, 106, { aimAng: 0.2, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: sid, lowReady: 1, pxm });
      b.blit(cell, cx + 40, base + 10);
      // crop 4x full body
      const cropH = Math.round(62 * k) + 6;
      const crop = new PixelBuf(46, cropH);
      crop.blit(cell, 0, 0, 52 - 23, 106 - cropH + 8, 46, cropH);
      b.blit(up(crop, 4), cx + 8, base + rowScene + 10);
      // silhouette
      const scell = new PixelBuf(120, 120);
      drawHero(scell, 52, 106, { aimAng: 0.2, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: sid, lowReady: 1, pxm });
      for (let y = 0; y < scell.h; y++)
        for (let x = 0; x < scell.w; x++) {
          const c = scell.get(x, y);
          if ((c >>> 24) === 0) continue;
          scell.set(x, y, rgba(8, 8, 10));
        }
      b.blit(scell, cx + 40, base + rowScene + rowCrop + 10);
    });
    base += setH;
  }
  writeFileSync(join(outDir, 'scale_compare.png'), encodePNG(b));
}
{
  const cw = 150, ch = 230;
  const b = groundSheet(3 * cw + 20, ch + 46, 900, 520);
  label(b, 10, 6, 'IDLE LOW-READY AT 30 / 36 / 40 PX/M (ROOKIE), 3X SHEET');
  [30, 36, 40].forEach((pxm, i) => {
    const cell = new PixelBuf(90, 100);
    drawHero(cell, 40, 92, { aimAng: 0.2, moving: false, walk: 0, flash: false, gun: 'rifle', muzzle: 0, set: 'rookie', lowReady: 1, pxm });
    b.blit(up(cell, 2), 10 + i * cw + 10, 30);
    label(b, 10 + i * cw + 10, 20, `${pxm} PX/M`);
  });
  writeFileSync(join(outDir, 'hero_idle_scaled.png'), encodePNG(b));
}

// ---------------------------------------------------------------- gameplay frame + 4x crop
{
  const core = new GameCore(new NullSfx());
  core.setGround(ground);
  core.startRun(4242);
  const inp = emptyInput();
  for (let t = 0; t < 150; t++) {
    inp.keys.clear(); inp.pressed.clear();
    if (core.state === 'menu') { inp.pressed.add('enter'); core.update(DT, inp); continue; }
    inp.keys.add('d'); inp.keys.add('w');           // strafe up-right
    // aim at the nearest enemy through the mouse (view space)
    let ne: { x: number; y: number; deadT: number } | null = null, nd = 1e9;
    for (const e of core.enemies) {
      if (e.deadT > 0) continue;
      const d = Math.hypot(e.x - core.px, e.y - core.py);
      if (d < nd) { nd = d; ne = e; }
    }
    if (ne) {
      const z = core.cam.zoom;
      inp.mouseX = Math.max(0, Math.min(639, ((ne.x - core.cam.left) / z.w) * 640));
      inp.mouseY = Math.max(0, Math.min(359, ((ne.y - 14 - core.cam.top) / z.h) * 360));
      if (nd < 13 * 30) inp.mouseDown = true; else inp.mouseDown = false;
    } else { inp.mouseX = 460; inp.mouseY = 130; inp.mouseDown = true; }
    core.update(DT, inp);
  }
  const frame = core.render();
  writeFileSync(join(outDir, 'hero_gameplay.png'), encodePNG(frame));
  // 4x crop around the player
  const px = core.cam.wx(core.px), py = core.cam.wy(core.py);
  const crop = new PixelBuf(170, 130);
  crop.blit(frame, 0, 0, Math.max(0, px - 85), Math.max(0, py - 95), 170, 130);
  writeFileSync(join(outDir, 'hero_crop4x.png'), encodePNG(up(crop, 4)));
  console.log(JSON.stringify({ state: core.state, kills: core.kills, px: Math.round(core.px), py: Math.round(core.py) }));
}

// ---------------------------------------------------------------- POSE MODE bench: presets, round-trip, hit-test
{
  const core = new GameCore(new NullSfx());
  core.setGround(ground);
  core.startRun(4242);
  const inp = emptyInput();
  for (let t2 = 0; t2 < 90; t2++) {
    inp.keys.clear(); inp.pressed.clear();
    if (core.state === 'menu') { inp.pressed.add('enter'); core.update(DT, inp); continue; }
    core.update(DT, inp);
  }
  const ed = new PoseEditor();
  const noop = { copy: (_s: string) => {}, save: (_b: PixelBuf) => {} };
  const presets: [string, string][] = [['1', 'pose_0_lowready'], ['2', 'pose_1_aim'], ['3', 'pose_2_walk0'], ['0', 'pose_3_reset']];
  for (const [key, name] of presets) {
    const pi = emptyInput();
    pi.pressed.add(key);
    ed.tick(pi, core, noop);
    writeFileSync(join(outDir, `${name}.png`), encodePNG(ed.render(core)));
  }
  // round-trip: json -> applyJson -> identical render
  ed.tick(Object.assign(emptyInput(), { pressed: new Set(['2']) }), core, noop);
  ed.overrides.gun = -0.4; ed.overrides.uparmF = 1.1; ed.overrides.shinF = 1.4;
  const j = ed.json(core);
  const bufA = ed.render(core);
  const ed2 = new PoseEditor();
  ed2.applyJson(j);
  const bufB = ed2.render(core);
  let same = bufA.px.length === bufB.px.length;
  for (let i = 0; same && i < bufA.px.length; i++) if (bufA.px[i] !== bufB.px[i]) same = false;
  console.log(`POSE ROUND-TRIP: ${same ? 'PASS' : 'FAIL'}`);
  if (!same) throw new Error('pose json round-trip mismatch');
  // hit-test: characteristic point of 10 parts must select exactly that part
  ed.render(core);
  const dbg: PartDbg[] = ed.parts();
  const names10 = ['head', 'torso', 'gun', 'handF', 'handS', 'forearmS', 'uparmF', 'thighF', 'shinF', 'bootF'];
  for (const name of names10) {
    const pt = ed.clickablePoint(name);
    if (!pt) throw new Error(`hit-test: part ${name} has no clickable pixel`);
    const hit = ed.hitTest(pt[0], pt[1]);
    console.log(`HIT ${name} @(${pt[0]},${pt[1]}): ${hit === name ? 'OK' : 'MISMATCH -> ' + hit}`);
    if (hit !== name) throw new Error(`hit-test mismatch at ${name}: got ${hit}`);
  }
  // real input path: screen-space click must select exactly the clicked part
  const clickNames = ['head', 'torso', 'gun', 'handF', 'handS', 'forearmS', 'uparmF', 'thighF', 'shinF', 'bootF'];
  for (const name of clickNames) {
    ed.render(core);
    const pt = ed.clickablePoint(name);
    if (!pt) throw new Error(`click-test: no clickable pixel for ${name}`);
    const [sx, sy] = ed.toScreen(pt[0], pt[1]);
    const ci = emptyInput();
    ci.mouseX = sx; ci.mouseY = sy; ci.mouseDown = true;
    ed.tick(ci, core, noop);           // edge: select + start drag
    const got = PARTS_LOOKUP[ed.sel];
    console.log(`CLICK ${name} @screen(${sx},${sy}): ${got === name ? 'OK' : 'MISMATCH -> ' + got}`);
    if (got !== name) throw new Error(`click select mismatch: ${name} -> ${got}`);
    const cu = emptyInput();
    cu.mouseX = sx + 30; cu.mouseY = sy - 20; cu.mouseDown = true;
    ed.tick(cu, core, noop);           // drag: bone angle must change
    const cu2 = emptyInput();
    cu2.mouseDown = false;
    ed.tick(cu2, core, noop);
  }
  // drag actually wrote an override for a bone part
  ed.render(core);
  const ptU = ed.clickablePoint('uparmF')!;
  const [ux, uy] = ed.toScreen(ptU[0], ptU[1]);
  const di = emptyInput(); di.mouseX = ux; di.mouseY = uy; di.mouseDown = true;
  ed.tick(di, core, noop);
  const dm = emptyInput(); dm.mouseX = ux + 24; dm.mouseY = uy + 10; dm.mouseDown = true;
  ed.tick(dm, core, noop);
  const dup = emptyInput(); dup.mouseDown = false; ed.tick(dup, core, noop);
  console.log(`DRAG uparmF override: ${ed.overrides.uparmF !== undefined ? 'OK' : 'MISSING'}`);
  if (ed.overrides.uparmF === undefined) throw new Error('drag did not rotate the bone');
  // hideGun: weapon parts disappear, arms stay poseable
  const gi = emptyInput(); gi.pressed.add('g'); ed.tick(gi, core, noop);
  ed.render(core);
  const hasGun = ed.parts().some((d) => d.name === 'gun');
  const hasHand = ed.parts().some((d) => d.name === 'handF');
  console.log(`HIDEGUN: gun=${hasGun ? 'PRESENT' : 'hidden'} hands=${hasHand ? 'ok' : 'MISSING'}`);
  if (hasGun || !hasHand) throw new Error('hideGun toggle broken');
  writeFileSync(join(outDir, 'pose_4_gunhidden.png'), encodePNG(ed.render(core)));
  const gj = emptyInput(); gj.pressed.add('g'); ed.tick(gj, core, noop);
  // labels sheet: anchors R=front / L=back
  const li = emptyInput(); li.pressed.add('l'); ed.tick(li, core, noop);
  writeFileSync(join(outDir, 'pose_5_labels.png'), encodePNG(ed.render(core)));
  const lo = emptyInput(); lo.pressed.add('l'); ed.tick(lo, core, noop);
  console.log('pose bench done');
}
// ---------------------------------------------------------------- zoom tiers at 40 px/m
{
  const core = new GameCore(new NullSfx());
  core.setGround(ground);
  core.startRun(4242);
  const inp = emptyInput();
  for (let t2 = 0; t2 < 120; t2++) {
    inp.keys.clear(); inp.pressed.clear();
    if (core.state === 'menu') { inp.pressed.add('enter'); core.update(DT, inp); continue; }
    inp.keys.add('d');
    core.update(DT, inp);
  }
  const b = new PixelBuf(660, 400, rgba(18, 20, 26));
  label(b, 10, 6, 'ZOOM TIERS AT 40 PX/M: 1.0 / 0.8 / 0.625 / 0.5 (EXPLORATION)');
  for (let zi = 0; zi < 4; zi++) {
    core.cam.zoomIdx = zi;
    const frame = core.render();
    const th = PixelBuf.downscale(frame, 320, 180);
    b.blit(th, 10 + (zi % 2) * 330, 20 + Math.floor(zi / 2) * 190);
    label(b, 12 + (zi % 2) * 330, 12 + Math.floor(zi / 2) * 190, ['1.0', '0.8', '0.625', '0.5'][zi]);
  }
  writeFileSync(join(outDir, 'zoom_tiers.png'), encodePNG(b));
  console.log('zoom tiers done');
}
console.log('hero bench done ->', outDir);
