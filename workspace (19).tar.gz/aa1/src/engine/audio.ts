/** WebAudio procedural SFX - no audio files. All shapes are tiny synth envelopes. */
export interface Sfx {
  shoot(): void; hit(): void; melee(): void; kill(): void; pickup(r: number): void;
  confiscate(): void; hurt(): void; shuttle(): void; ui(): void; capsule(): void; companion(): void;
}
export class NullSfx implements Sfx {
  shoot() {} hit() {} melee() {} kill() {} pickup(_r: number) {} confiscate() {} hurt() {}
  shuttle() {} ui() {} capsule() {} companion() {}
}
export class WebSfx implements Sfx {
  private ctx: AudioContext | null = null;
  private master = 0.5;
  private ac(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const C = window.AudioContext ?? (window as any).webkitAudioContext;
      if (!C) return null;
      this.ctx = new C();
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }
  setVolume(v: number) { this.master = Math.max(0, Math.min(1, v)); }
  private env(dur: number, gain: number, fn: (g: GainNode, t: number) => void) {
    const ac = this.ac(); if (!ac) return;
    const t = ac.currentTime;
    const g = ac.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain * this.master, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    g.connect(ac.destination);
    fn(g, t);
  }
  private noiseBuf(ac: AudioContext, dur: number): AudioBuffer {
    const n = Math.max(1, (ac.sampleRate * dur) | 0);
    const b = ac.createBuffer(1, n, ac.sampleRate);
    const d = b.getChannelData(0);
    let s = 12345;
    for (let i = 0; i < n; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; d[i] = (s / 0x3fffffff) - 1; }
    return b;
  }
  shoot() {
    const ac = this.ac(); if (!ac) return;
    this.env(0.09, 0.22, (g, t) => {
      const src = ac.createBufferSource(); src.buffer = this.noiseBuf(ac, 0.09);
      const f = ac.createBiquadFilter(); f.type = 'bandpass'; f.frequency.setValueAtTime(2400, t);
      f.frequency.exponentialRampToValueAtTime(600, t + 0.08); f.Q.value = 1.2;
      src.connect(f); f.connect(g); src.start(t); src.stop(t + 0.09);
    });
    this.env(0.06, 0.12, (g, t) => {
      const o = ac.createOscillator(); o.type = 'square';
      o.frequency.setValueAtTime(220, t); o.frequency.exponentialRampToValueAtTime(70, t + 0.06);
      o.connect(g); o.start(t); o.stop(t + 0.06);
    });
  }
  hit() {
    this.env(0.05, 0.16, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'triangle';
      o.frequency.setValueAtTime(900 + Math.random() * 300, t);
      o.frequency.exponentialRampToValueAtTime(300, t + 0.05);
      o.connect(g); o.start(t); o.stop(t + 0.05);
    });
  }
  melee() {
    const ac = this.ac(); if (!ac) return;
    this.env(0.12, 0.14, (g, t) => {
      const src = ac.createBufferSource(); src.buffer = this.noiseBuf(ac, 0.12);
      const f = ac.createBiquadFilter(); f.type = 'highpass';
      f.frequency.setValueAtTime(700, t); f.frequency.exponentialRampToValueAtTime(2600, t + 0.1);
      src.connect(f); f.connect(g); src.start(t); src.stop(t + 0.12);
    });
  }
  kill() {
    this.env(0.22, 0.2, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(300, t); o.frequency.exponentialRampToValueAtTime(50, t + 0.22);
      o.connect(g); o.start(t); o.stop(t + 0.22);
    });
  }
  hurt() {
    this.env(0.16, 0.24, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'square';
      o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(60, t + 0.16);
      o.connect(g); o.start(t); o.stop(t + 0.16);
    });
  }
  pickup(r: number) {
    const base = 440 * Math.pow(1.25, Math.min(5, r)); // rarer = higher sparkle chord
    [0, 2, 4].forEach((semi, i) => {
      setTimeout(() => this.env(0.14, 0.14, (g, t) => {
        const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'triangle';
        o.frequency.value = base * Math.pow(2, semi / 12);
        o.connect(g); o.start(t); o.stop(t + 0.14);
      }), i * 55);
    });
  }
  confiscate() {
    this.env(0.12, 0.12, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(880, t); o.frequency.exponentialRampToValueAtTime(1200, t + 0.1);
      o.connect(g); o.start(t); o.stop(t + 0.12);
    });
    setTimeout(() => this.env(0.1, 0.12, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'sine';
      o.frequency.value = 1500; o.connect(g); o.start(t); o.stop(t + 0.1);
    }), 100);
  }
  shuttle() {
    const ac = this.ac(); if (!ac) return;
    this.env(1.6, 0.18, (g, t) => {
      const src = ac.createBufferSource(); src.buffer = this.noiseBuf(ac, 1.6);
      const f = ac.createBiquadFilter(); f.type = 'lowpass';
      f.frequency.setValueAtTime(200, t); f.frequency.linearRampToValueAtTime(900, t + 0.8);
      f.frequency.linearRampToValueAtTime(150, t + 1.6);
      src.connect(f); f.connect(g); src.start(t); src.stop(t + 1.6);
    });
  }
  capsule() {
    [0, 4, 7, 12].forEach((semi, i) => setTimeout(() => this.env(0.18, 0.12, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'sine';
      o.frequency.value = 330 * Math.pow(2, semi / 12); o.connect(g); o.start(t); o.stop(t + 0.18);
    }), i * 70));
  }
  companion() { this.capsule(); }
  ui() {
    this.env(0.05, 0.1, (g, t) => {
      const ac = this.ac()!; const o = ac.createOscillator(); o.type = 'square';
      o.frequency.value = 660; o.connect(g); o.start(t); o.stop(t + 0.05);
    });
  }
}
