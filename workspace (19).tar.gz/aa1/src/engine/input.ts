/** Abstract input state so headless sim can script the exact same struct the browser fills. */
export interface InputState {
  keys: Set<string>;              // lowercase code-ish names: 'w','a','s','d','shift','r','e','q','tab'
  mouseX: number; mouseY: number; // in VIEW space (640x360)
  mouseDown: boolean;             // LMB held
  rmbDown: boolean;               // RMB held
  pressed: Set<string>;           // one-shot presses consumed each tick: 'lmb','rmb','q','e','r','play','zoomin','zoomout','1','2','3'
  wheel: number;                  // mouse wheel delta sign (pose mode zoom); 0 in headless
  shiftDown: boolean;             // shift modifier (pose mode drag modes)
}
export function emptyInput(): InputState {
  return { keys: new Set(), mouseX: 320, mouseY: 180, mouseDown: false, rmbDown: false, pressed: new Set(), wheel: 0, shiftDown: false };
}
