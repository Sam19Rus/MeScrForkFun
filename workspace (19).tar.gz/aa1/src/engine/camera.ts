import { MAP_W, MAP_H, ZOOM_LEVELS } from '../game/config.js';

/** Follow camera with smoothing + map clamp. Position = center of world window in px. */
export class Camera {
  x = MAP_W / 2; y = MAP_H / 2;
  zoomIdx = 0;
  private n = 0;
  shake = 0; shakeX = 0; shakeY = 0;
  get zoom() { return ZOOM_LEVELS[this.zoomIdx]; }
  cycleZoom(dir: number): void {
    this.zoomIdx = Math.max(0, Math.min(ZOOM_LEVELS.length - 1, this.zoomIdx + dir));
  }
  follow(tx: number, ty: number, dt: number, snap = false): void {
    const k = snap ? 1 : 1 - Math.exp(-9 * dt);
    this.x += (tx - this.x) * k;
    this.y += (ty - this.y) * k;
    const z = this.zoom;
    this.x = Math.max(z.w / 2, Math.min(MAP_W - z.w / 2, this.x));
    this.y = Math.max(z.h / 2, Math.min(MAP_H - z.h / 2, this.y));
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt * 30);
      this.n++;
      const s = Math.min(4, this.shake / 8);
      const h = (Math.imul(this.n, 2654435761) >>> 16) & 1023;
      const h2 = (Math.imul(this.n + 7, 40503) >>> 16) & 1023;
      this.shakeX = ((h / 512) - 1) * s | 0;
      this.shakeY = ((h2 / 512) - 1) * s | 0;
    } else { this.shakeX = 0; this.shakeY = 0; }
  }
  /** world px -> window px (integer). */
  wx(x: number): number { return Math.round(x - (this.x - this.zoom.w / 2)) + this.shakeX; }
  wy(y: number): number { return Math.round(y - (this.y - this.zoom.h / 2)) + this.shakeY; }
  get left(): number { return this.x - this.zoom.w / 2 + this.shakeX; }
  get top(): number { return this.y - this.zoom.h / 2 + this.shakeY; }
}
