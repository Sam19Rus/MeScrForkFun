/**
 * Minimal PNG encoder/decoder - PURE TypeScript (no node:zlib, no Buffer): safe to import from
 * browser code (pose-mode [V] export) and from node tools/benches alike.
 *
 * Encode: RGB color type 2, filter 0, zlib stream with STORED deflate blocks (valid PNG/zlib,
 * deterministic, slightly larger files than level-9 deflate - acceptable for dev dumps).
 * Decode: full inflate (stored / fixed / dynamic Huffman) + unfilter 0-4, RGB and RGBA, 8-bit.
 */
import { PixelBuf } from '../core/buf.js';

// ---------------------------------------------------------------- helpers
function crc32(buf: Uint8Array): number {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = c ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function adler32(buf: Uint8Array): number {
  let a = 1, b = 0;
  for (let i = 0; i < buf.length; i++) {
    a = (a + buf[i]) % 65521;
    b = (b + a) % 65521;
  }
  return (((b << 16) | a) >>> 0);
}
function cat(arrs: Uint8Array[]): Uint8Array {
  let n = 0;
  for (const a of arrs) n += a.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const a of arrs) { out.set(a, o); o += a.length; }
  return out;
}
function chunk(type: string, data: Uint8Array): Uint8Array {
  const t = new Uint8Array(4);
  for (let i = 0; i < 4; i++) t[i] = type.charCodeAt(i);
  const len = new Uint8Array(4);
  new DataView(len.buffer).setUint32(0, data.length, false);
  const crc = new Uint8Array(4);
  new DataView(crc.buffer).setUint32(0, crc32(cat([t, data])), false);
  return cat([len, t, data, crc]);
}
/** zlib wrapper with STORED deflate blocks (BTYPE=00). */
function zlibStore(raw: Uint8Array): Uint8Array {
  const blocks: Uint8Array[] = [new Uint8Array([0x78, 0x01])];
  let i = 0;
  while (i < raw.length || i === 0) {
    const n = Math.min(65535, raw.length - i);
    const last = i + n >= raw.length ? 1 : 0;
    const hdr = new Uint8Array(5);
    hdr[0] = last;                       // BFINAL=last, BTYPE=00
    hdr[1] = n & 255; hdr[2] = (n >>> 8) & 255;
    hdr[3] = ~n & 255; hdr[4] = (~n >>> 8) & 255;
    blocks.push(hdr, raw.subarray(i, i + n));
    i += n;
    if (n === 0) break;
  }
  const ad = new Uint8Array(4);
  new DataView(ad.buffer).setUint32(0, adler32(raw), false);
  blocks.push(ad);
  return cat(blocks);
}

// ---------------------------------------------------------------- inflate (pure TS)
class BitReader {
  private pos = 0; private bit = 0;   // deflate packs bits LSB-first within each byte
  constructor(private d: Uint8Array) {}
  bits(n: number): number {
    let v = 0;
    for (let i = 0; i < n; i++) {
      v |= ((this.d[this.pos] >> this.bit) & 1) << i;
      this.bit++;
      if (this.bit === 8) { this.bit = 0; this.pos++; }
    }
    return v;
  }
  align() { if (this.bit) { this.bit = 0; this.pos++; } }
  get bytePos() { return this.pos; }
}
interface Huff { counts: number[]; symbols: number[]; max: number }
function buildHuff(lengths: number[]): Huff {
  const max = Math.max(...lengths, 1);
  const counts = new Array<number>(max + 1).fill(0);
  for (const l of lengths) counts[l]++;
  counts[0] = 0;
  const offs = new Array<number>(max + 1).fill(0);
  for (let l = 1; l < max; l++) offs[l + 1] = offs[l] + counts[l];
  const symbols = new Array<number>(lengths.length).fill(0);
  for (let s = 0; s < lengths.length; s++) if (lengths[s]) symbols[offs[lengths[s]]++] = s;
  return { counts, symbols, max };
}
function decodeSym(br: BitReader, h: Huff): number {
  let code = 0, first = 0, index = 0;
  for (let len = 1; len <= h.max; len++) {
    code |= br.bits(1);
    const cnt = h.counts[len];
    if (code - first < cnt) return h.symbols[index + (code - first)];
    index += cnt;
    first = (first + cnt) << 1;
    code <<= 1;
  }
  throw new Error('png inflate: bad huffman code');
}
const LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const CL_ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
export function inflate(data: Uint8Array): Uint8Array {
  // skip the 2-byte zlib header (CMF/FLG) when present; PNG IDAT is always zlib-wrapped
  const hasZlibHdr = data.length > 2 && (data[0] === 0x78 || data[0] === 0x08 || data[0] === 0x18 || data[0] === 0x28 || data[0] === 0x38 || data[0] === 0x48 || data[0] === 0x58 || data[0] === 0x68) && ((data[0] << 8) | data[1]) % 31 === 0;
  const br = new BitReader(hasZlibHdr ? data.subarray(2) : data);
  const out: number[] = [];
  let final = 0;
  while (!final) {
    final = br.bits(1);
    const type = br.bits(2);
    if (type === 0) {
      br.align();
      const bd = (hasZlibHdr ? data.subarray(2) : data) as Uint8Array;
      const p = br.bytePos;                       // after align: p = LEN lo (HDR byte part-consumed by bits)
      const n = bd[p] | (bd[p + 1] << 8);          // LEN; p+2..3 = NLEN; p+4 = data
      if (p + 4 + n > bd.length) throw new Error('png inflate: stored block past end');
      for (let i = 0; i < n; i++) out.push(bd[p + 4 + i]);
      (br as unknown as { pos: number; bit: number }).pos = p + 4 + n;
      (br as unknown as { bit: number }).bit = 0;
    } else {
      let lit: Huff, dist: Huff;
      if (type === 1) {
        const ll = new Array<number>(288);
        for (let i = 0; i < 144; i++) ll[i] = 8;
        for (let i = 144; i < 256; i++) ll[i] = 9;
        for (let i = 256; i < 280; i++) ll[i] = 7;
        for (let i = 280; i < 288; i++) ll[i] = 8;
        lit = buildHuff(ll);
        dist = buildHuff(new Array<number>(30).fill(5));
      } else {
        const hlit = br.bits(5) + 257, hdist = br.bits(5) + 1, hcl = br.bits(4) + 4;
        const cl = new Array<number>(19).fill(0);
        for (let i = 0; i < hcl; i++) cl[CL_ORDER[i]] = br.bits(3);
        const ch = buildHuff(cl);
        const lens: number[] = [];
        while (lens.length < hlit + hdist) {
          const s = decodeSym(br, ch);
          if (s < 16) lens.push(s);
          else if (s === 16) { const r = 3 + br.bits(2); const prev = lens[lens.length - 1]; for (let i = 0; i < r; i++) lens.push(prev); }
          else if (s === 17) { const r = 3 + br.bits(3); for (let i = 0; i < r; i++) lens.push(0); }
          else { const r = 11 + br.bits(7); for (let i = 0; i < r; i++) lens.push(0); }
        }
        lit = buildHuff(lens.slice(0, hlit));
        dist = buildHuff(lens.slice(hlit));
      }
      for (;;) {
        const s = decodeSym(br, lit);
        if (s === 256) break;
        if (s < 256) out.push(s);
        else {
          const li = s - 257;
          const len = LEN_BASE[li] + br.bits(LEN_EXTRA[li]);
          const di = decodeSym(br, dist);
          const d = DIST_BASE[di] + br.bits(DIST_EXTRA[di]);
          for (let i = 0; i < len; i++) out.push(out[out.length - d]);
        }
      }
    }
  }
  return Uint8Array.from(out);
}

// ---------------------------------------------------------------- API
/** Encode RGB (alpha dropped onto the pixel values as-is; RGBA input keeps color type 6). */
export function encodePNG(img: PixelBuf): Uint8Array {
  const raw = new Uint8Array((img.w * 3 + 1) * img.h);
  let o = 0;
  for (let y = 0; y < img.h; y++) {
    raw[o++] = 0;
    for (let x = 0; x < img.w; x++) {
      const c = img.px[y * img.w + x];
      raw[o++] = c & 255; raw[o++] = (c >>> 8) & 255; raw[o++] = (c >>> 16) & 255;
    }
  }
  const ihdr = new Uint8Array(13);
  const dv = new DataView(ihdr.buffer);
  dv.setUint32(0, img.w, false); dv.setUint32(4, img.h, false);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return cat([
    new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlibStore(raw)),
    chunk('IEND', new Uint8Array(0)),
  ]);
}

/** Decode RGB/RGBA PNG (8-bit, filters 0-4). */
export function decodePNG(data: Uint8Array): PixelBuf {
  let p = 8;
  let w = 0, h = 0, bitDepth = 0, colorType = 0;
  const idat: Uint8Array[] = [];
  while (p + 8 <= data.length) {
    const dv = new DataView(data.buffer, data.byteOffset + p, 8);
    const len = dv.getUint32(0, false);
    const type = String.fromCharCode(data[p + 4], data[p + 5], data[p + 6], data[p + 7]);
    const body = data.subarray(p + 8, p + 8 + len);
    if (type === 'IHDR') {
      const bv = new DataView(body.buffer, body.byteOffset, 8);
      w = bv.getUint32(0, false); h = bv.getUint32(4, false);
      bitDepth = body[8]; colorType = body[9];
    } else if (type === 'IDAT') idat.push(body);
    else if (type === 'IEND') break;
    p += 12 + len;
  }
  if (bitDepth !== 8 || (colorType !== 2 && colorType !== 6)) throw new Error('unsupported png');
  const ch = colorType === 6 ? 4 : 3;
  const raw = inflate(cat(idat));
  const img = new PixelBuf(w, h);
  const stride = w * ch;
  const cur = new Uint8Array(stride);
  const prev = new Uint8Array(stride);
  let o = 0;
  for (let y = 0; y < h; y++) {
    const f = raw[o++];
    for (let x = 0; x < stride; x++) {
      const rv = raw[o + x];
      const a = x >= ch ? cur[x - ch] : 0;
      const b = prev[x];
      const c = x >= ch ? prev[x - ch] : 0;
      let v = rv;
      if (f === 1) v = (rv + a) & 255;
      else if (f === 2) v = (rv + b) & 255;
      else if (f === 3) v = (rv + ((a + b) >> 1)) & 255;
      else if (f === 4) {
        const pp = a + b - c;
        const pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c);
        const pr = pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
        v = (rv + pr) & 255;
      }
      cur[x] = v;
    }
    o += stride;
    for (let x = 0; x < w; x++) {
      const r = cur[x * ch], g = cur[x * ch + 1], bl = cur[x * ch + 2];
      const al = ch === 4 ? cur[x * ch + 3] : 255;
      img.px[y * w + x] = ((r | (g << 8) | (bl << 16) | (al << 24))) >>> 0;
    }
    prev.set(cur);
  }
  return img;
}
