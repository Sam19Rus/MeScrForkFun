import type { HeadOrient, HairId } from './hero_art.js';
import {
  ROOKIE40_TORSO, ROOKIE40_NECK, ROOKIE40_HEADS,
  ROOKIE40_THIGH, ROOKIE40_SHIN, ROOKIE40_BOOT,
  ROOKIE40_UPARM, ROOKIE40_FOREARM, ROOKIE40_UPARMS, ROOKIE40_FOREARMS,
  ROOKIE40_FIST, ROOKIE40_SUPHAND,
} from './hero_art40_rookie.js';

/** Arts40 bundle shape consumed by hero.ts ensureSet at pxm=40. */
export interface Arts40 {
  torso: string[]; neck: string[];
  heads: Record<HeadOrient, string[]>;
  helmet: Record<HeadOrient, string[]> | null;
  thigh: string[]; shin: string[]; boot: string[];
  uparm: string[]; forearm: string[]; uparmS: string[]; forearmS: string[];
  fist: string[]; suphand: string[];
  pal?: Record<string, number>;
  meta: {
    k: number;
    thighLen: number; shinLen: number; uparmLen: number; forearmLen: number;
    uparmSLen: number; forearmSLen: number;
    thighP: [number, number]; thighD: [number, number];
    shinP: [number, number]; shinD: [number, number];
    bootP: [number, number];
    uparmP: [number, number]; uparmD: [number, number];
    forearmP: [number, number]; forearmD: [number, number];
    uparmSP: [number, number]; uparmSD: [number, number];
    forearmSP: [number, number]; forearmSD: [number, number];
    fistP: [number, number]; supP: [number, number];
    hipF: [number, number]; hipB: [number, number];
    shF: [number, number]; supIk: [number, number];
    torsoA: [number, number]; neckA: [number, number]; headA: [number, number]; helmA: [number, number] | null;
    wristD: number; wristUp: number; wristDown: number; footK: number;
  };
}
/** Rookie @40: heads follow the active hair (live-resolved at bake time via hero.ts cache key). */
export const ROOKIE40_HEADS_LIVE = ROOKIE40_HEADS;
export const ROOKIE40: Arts40 = {
  torso: ROOKIE40_TORSO, neck: ROOKIE40_NECK,
  heads: ROOKIE40_HEADS[('A' as HairId)],   // placeholder; hero.ts re-resolves per hair via headsFor()
  helmet: null,
  thigh: ROOKIE40_THIGH, shin: ROOKIE40_SHIN, boot: ROOKIE40_BOOT,
  uparm: ROOKIE40_UPARM, forearm: ROOKIE40_FOREARM, uparmS: ROOKIE40_UPARMS, forearmS: ROOKIE40_FOREARMS,
  fist: ROOKIE40_FIST, suphand: ROOKIE40_SUPHAND,
  meta: {
    k: 4 / 3,
    thighLen: 13, shinLen: 13, uparmLen: 15, forearmLen: 10,
    uparmSLen: 16, forearmSLen: 16,
    thighP: [6, 0], thighD: [6, 13], shinP: [5, 0], shinD: [5, 13], bootP: [3, 0],
    uparmP: [3, 1], uparmD: [3, 16], forearmP: [3, 0], forearmD: [3, 10],
    uparmSP: [3, 1], uparmSD: [3, 17], forearmSP: [3, 0], forearmSD: [3, 16],
    fistP: [3, 4], supP: [3, 4],
    hipF: [5, -32], hipB: [-7, -33],
    shF: [11, -55], supIk: [-11, -55],
    torsoA: [-16, -59], neckA: [-4, -63], headA: [-8, -75], helmA: null,
    wristD: 11, wristUp: 9, wristDown: 15, footK: 4 / 3,
  },
};
export type { HairId };
