import { PixelBuf, rgba, mixc, shade } from '../core/buf.js';
import {
  HERO_PAL, SKIN_VARIANTS, ANCHORS, ART_NECK, HEAD_SET,
  ART_THIGH, ART_SHIN, ART_BOOT, ART_UPARM, ART_FOREARM, ART_HAND_FIST, ART_HAND_SUPPORT,
  ART_UPARM_S, ART_FOREARM_S, UPARM_S_PIVOT, UPARM_S_LEN, FOREARM_S_PIVOT, FOREARM_S_LEN,
  THIGH_PIVOT, THIGH_KNEE, THIGH_LEN, SHIN_PIVOT, SHIN_ANKLE, SHIN_LEN, BOOT_PIVOT,
  UPARM_PIVOT, UPARM_ELBOW, UPARM_LEN, FOREARM_PIVOT, FOREARM_WRIST, FOREARM_LEN,
  FIST_PIVOT, HANDSUP_PIVOT,
  GUNS, headArts, ARMOR_SETS, armorSetById, type GunKind, type HeadOrient, type ArmorSet,
} from './hero_art.js';
import { buildScaleArts, type ScaleArts, type ScaleMeta } from './hero_scale.js';
import { ROOKIE40, ROOKIE40_HEADS_LIVE, type Arts40 } from './hero_art40_bundle.js';

/**
 * HERO RIG v3 - mass/proportion pass + joint-continuity fix (visual only; gameplay untouched).
 *
 * v3 fixes the v2 limb blow-apart:
 *  1. MIRROR BUG: boneIdx used to mirror the bone angle AND blitFrame mirrors pixels -> double
 *     mirror (arms pointed the wrong way on flipped aims). Now boneIdx is mirror-agnostic; the
 *     pixel mirror + mirrored joint positions handle flip.
 *  2. JOINT CONTINUITY: child bones are blitted at the parent's DRAWN distal pixel (quantized-angle
 *     forward offset), not at the independently rounded IK point -> knee/elbow/wrist seams are
 *     continuous at every angle, both mirrors.
 *  3. REACH/HANDGUARD: hands are separate parts living in WEAPON space. The weapon is placed at the
 *     drawn firing wrist, so the fist is ALWAYS on GRIP (over the weapon); the support hand is
 *     ALWAYS on HANDGUARD (fingers over the tube). The support forearm layers BEHIND the weapon, so
 *     its cuff/hand junction is hidden by the tube itself - no floating gloves at any aim.
 *
 * Skeleton (v2 system kept): two-bone IK legs/arms, 64 baked rotation frames per bone, 8-keyframe
 * walk, neck + head part-set with aim orientations, elliptical dithered shadow, pose clamps.
 *
 * Layer order: shadow -> back leg -> front leg -> support upper arm -> torso -> neck ->
 * support forearm -> [weapon + support hand when aiming up] -> head -> weapon -> firing upper arm
 * -> firing forearm -> firing fist -> support hand -> muzzle flash.
 */

export type HeroGun = GunKind | 'none';
export type SkinTone = 'light' | 'tan';

export interface HeroPose {
  aimAng: number;   // radians, screen space: shoulder -> cursor (atan2)
  moving: boolean;
  walk: number;     // walk cycle phase (radians)
  flash: boolean;   // hit flash
  gun: HeroGun;
  muzzle: number;   // >0 while the muzzle flash is up
  moveDir?: [number, number]; // screen-space move direction (posture lean; visual only)
  set?: string;               // armor set id (ARMOR_SETS); visual-only, hotkey [B]
  lowReady?: number;          // 0..1 blend into the low-ready idle pose (visual-only)
  pxm?: number;               // render scale 30/36/40 px/m (visual-only bench; 30 = production)
  boneOverride?: Partial<Record<BoneName, number>>; // POSE MODE: local bone angles (rad)
  /** v17: POSE/QA-only stance channel: explicit foot targets [x, y, tiltIdx] in root space.
   *  Default (undefined) = walk-table samples; combat/low-ready logic untouched. */
  stance?: { footF: [number, number, number]; footB: [number, number, number] } | null;
  dbg?: PartDbg[];            // POSE MODE: collects screen bboxes + pivots for hit-testing
}

/** Selectable/overridable bones (POSE MODE contract; combat math unchanged). */
export type BoneName =
  | 'thighF' | 'shinF' | 'thighB' | 'shinB'
  | 'uparmF' | 'forearmF' | 'uparmS' | 'forearmS' | 'gun';
export interface PartDbg {
  name: string;
  x0: number; y0: number; x1: number; y1: number;   // screen bbox
  px?: number; py?: number;                          // pivot (bones/weapon)
  pix?: number[];                                    // flat [x,y,...] of drawn pixels (pixel-precise hit-test)
}

// ---------------------------------------------------------------- pixel drawing (spec: drawSprite)
/** Draw a string pixel array per-pixel through a palette; '.' = transparent; flip mirrors X. */
export function drawSprite(
  b: PixelBuf, art: string[], pal: Record<string, number>,
  dx: number, dy: number, flip = false,
): void {
  for (let y = 0; y < art.length; y++) {
    const r = art[y];
    for (let x = 0; x < r.length; x++) {
      const ch = r[x];
      if (ch === '.') continue;
      const c = pal[ch];
      if (c === undefined) throw new Error(`hero_art: unknown palette char '${ch}' at (${x},${y})`);
      b.set(flip ? dx + r.length - 1 - x : dx + x, dy + y, c);
    }
  }
}

/** Bake a string grid into a PixelBuf (validates row lengths). */
function bake(art: string[], name: string, pal: Record<string, number> = HERO_PAL): PixelBuf {
  const w = art[0].length;
  for (let i = 0; i < art.length; i++) {
    if (art[i].length !== w) throw new Error(`hero_art ${name}: row ${i} has length ${art[i].length}, expected ${w}`);
  }
  const buf = new PixelBuf(w, art.length);
  drawSprite(buf, art, pal, 0, 0);
  return buf;
}

// ---------------------------------------------------------------- rotation frame baking (v1 system, untouched)
const ROT_N = 64;                                  // bone/weapon rotation steps (5.625 deg)
const FULL_ANGLES = Array.from({ length: ROT_N }, (_, i) => (i * 2 * Math.PI) / ROT_N);

interface Frame { buf: PixelBuf; ox: number; oy: number; x0: number; y0: number; x1: number; y1: number }

/** Bake nearest-sample rotation frames of `src` around pivot (px,py). Deterministic. */
function bakeRot(src: PixelBuf, px: number, py: number, angles: number[]): Frame[] {
  let R = 1;
  for (let y = 0; y < src.h; y++)
    for (let x = 0; x < src.w; x++) {
      if ((src.get(x, y) >>> 24) === 0) continue;
      const d = Math.ceil(Math.hypot(x - px, y - py));
      if (d > R) R = d;
    }
  R += 1;
  const size = R * 2 + 1;
  return angles.map((a) => {
    const c = Math.cos(a), s = Math.sin(a);
    const buf = new PixelBuf(size, size);
    let x0 = size, y0 = size, x1 = -1, y1 = -1;
    for (let fy = 0; fy < size; fy++) {
      const dy = fy - R;
      for (let fx = 0; fx < size; fx++) {
        const dx = fx - R;
        const sx = Math.round(c * dx + s * dy) + px;   // inverse rotation
        const sy = Math.round(-s * dx + c * dy) + py;
        if (sx < 0 || sy < 0 || sx >= src.w || sy >= src.h) continue;
        const col = src.get(sx, sy);
        if ((col >>> 24) === 0) continue;
        buf.set(fx, fy, col);
        if (fx < x0) x0 = fx; if (fx > x1) x1 = fx;
        if (fy < y0) y0 = fy; if (fy > y1) y1 = fy;
      }
    }
    if (x1 < 0) { x0 = y0 = 0; x1 = y1 = 0; }
    return { buf, ox: R, oy: R, x0, y0, x1, y1 };
  });
}

const FLASH_COL = rgba(255, 238, 222);
function tintFrame(fr: Frame): Frame {
  const buf = new PixelBuf(fr.buf.w, fr.buf.h);
  for (let y = fr.y0; y <= fr.y1; y++)
    for (let x = fr.x0; x <= fr.x1; x++) {
      const c = fr.buf.get(x, y);
      if ((c >>> 24) === 0) continue;
      buf.set(x, y, mixc(c, FLASH_COL, 0.62));
    }
  return { ...fr, buf };
}
function tintSpr(spr: PixelBuf): PixelBuf {
  const out = new PixelBuf(spr.w, spr.h);
  for (let i = 0; i < spr.px.length; i++) {
    const c = spr.px[i];
    out.px[i] = (c >>> 24) === 0 ? c : mixc(c, FLASH_COL, 0.62);
  }
  return out;
}
function shadeSpr(spr: PixelBuf, k: number): PixelBuf {
  const out = new PixelBuf(spr.w, spr.h);
  for (let i = 0; i < spr.px.length; i++) {
    const c = spr.px[i];
    out.px[i] = (c >>> 24) === 0 ? c : shade(c, k);
  }
  return out;
}

// ---------------------------------------------------------------- bone sets
/** A bone = 64 baked rotation frames in 4 flavors: normal / back(dark) x plain / hit-flash. */
interface BoneSet { n: Frame[]; d: Frame[]; nf: Frame[]; df: Frame[]; o: Frame[] }
/** 1 px ink dilate of the silhouette: blitted under a bone so masses never merge.
 *  v17 P1: `col` lets a set outline in its own shadow tone (set palette shadow instead of ink)
 *  instead of pure ink, so seams read as armor shadow, not black hardware. */
function outlineSpr(spr: PixelBuf, col?: number): PixelBuf {
  const out = new PixelBuf(spr.w, spr.h);
  const ink = col ?? rgba(0x12, 0x14, 0x1a);
  for (let y = 0; y < spr.h; y++)
    for (let x = 0; x < spr.w; x++) {
      if ((spr.get(x, y) >>> 24) !== 0) { out.set(x, y, ink); continue; }
      const near =
        (x > 0 && (spr.get(x - 1, y) >>> 24) !== 0) || (x < spr.w - 1 && (spr.get(x + 1, y) >>> 24) !== 0) ||
        (y > 0 && (spr.get(x, y - 1) >>> 24) !== 0) || (y < spr.h - 1 && (spr.get(x, y + 1) >>> 24) !== 0);
      if (near) out.set(x, y, ink);
    }
  return out;
}
function makeBone(art: string[], pivot: [number, number], name: string, darkK: number, outline = false, pal: Record<string, number> = HERO_PAL, outlineCol?: number): BoneSet {
  const buf = bake(art, name, pal);
  const n = bakeRot(buf, pivot[0], pivot[1], FULL_ANGLES);
  const d = bakeRot(shadeSpr(buf, darkK), pivot[0], pivot[1], FULL_ANGLES);
  const o = outline ? bakeRot(outlineSpr(buf, outlineCol), pivot[0], pivot[1], FULL_ANGLES) : d;
  return { n, d, nf: n.map(tintFrame), df: d.map(tintFrame), o };
}
/** Boot: a small set of tilt frames (toe-down / flat / heel-strike). */
const BOOT_TILTS = [0, 0.32, 0.18, -0.2];
interface BootSet { n: Frame[]; d: Frame[]; nf: Frame[]; df: Frame[]; o: Frame[] }
function makeBootSet(art: string[], pivot: [number, number], name: string, pal: Record<string, number>): BootSet {
  const buf = bake(art, name, pal);
  const dk = shadeSpr(buf, 0.72);
  const n = BOOT_TILTS.map((t) => bakeRot(buf, pivot[0], pivot[1], [t])[0]);
  const d = BOOT_TILTS.map((t) => bakeRot(dk, pivot[0], pivot[1], [t])[0]);
  return { n, d, nf: n.map(tintFrame), df: d.map(tintFrame), o: d };
}
/** Hand: 64 frames in WEAPON space (rotates with the weapon index). */
interface HandSet { n: Frame[]; d: Frame[]; nf: Frame[]; df: Frame[]; o: Frame[] }
function makeHand(art: string[], pivot: [number, number], name: string, pal: Record<string, number> = HERO_PAL): HandSet {
  const buf = bake(art, name, pal);
  const n = bakeRot(buf, pivot[0], pivot[1], FULL_ANGLES);
  const d = bakeRot(shadeSpr(buf, 0.7), pivot[0], pivot[1], FULL_ANGLES);
  return { n, d, nf: n.map(tintFrame), df: d.map(tintFrame), o: d };
}

interface GunSet { frames: Frame[]; flash: Frame[]; muzzle: [number, number] | null }

// ---------------------------------------------------------------- walk cycle: 8 authored keyframes
// Foot targets live in ROOT space (x forward, y up-negative, sole = 0) so a stance foot is
// screen-sticky by construction; [x, y, bootTiltIdx].
const KF_FOOT: [number, number, number][] = [
  [5, -4, 0],   // 0 contact: heel plant
  [5, -4, 0],   // 1 stance: sticky
  [5, -4, 0],   // 2 stance: sticky, body passes over
  [-4, -5, 1],  // 3 toe-off: heel up, toe down
  [-3, -7, 2],  // 4 swing lift: knee bends
  [-1, -8, 2],  // 5 swing mid
  [3, -6, 3],   // 6 reach: heel strike
  [5, -5, 0],   // 7 descend
];
const KF_HIPX = [0, 1, 1, 0, 0, -1, -1, 0];       // hip sway (makes stance feet sticky)
const KF_BOB = [0, -1, -1, 0, 0, -1, -1, 0];      // torso bob 1 px
const KF_SWAY = [1, 0, -1, 0, 1, 0, -1, 0];       // support shoulder counter-phase
const KF_HEADBOB = [0, 0, -1, -1, 0, 0, -1, -1];  // head bob, phase-shifted from torso
const WALK_N = 8;

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

interface WalkSample {
  footF: [number, number, number]; footB: [number, number, number];
  hipX: number; bob: number; sway: number; headBob: number;
}
function sampleWalk(phase: number): WalkSample {
  const t = (((phase / (2 * Math.PI)) * WALK_N) % WALK_N + WALK_N) % WALK_N;
  const i0 = Math.floor(t) % WALK_N, i1 = (i0 + 1) % WALK_N;
  const f = t - Math.floor(t);
  const j0 = (i0 + 4) % WALK_N, j1 = (i0 + 5) % WALK_N;   // back leg = table offset by half cycle
  const mixFoot = (A: [number, number, number], B: [number, number, number]): [number, number, number] => [
    lerp(A[0], B[0], f), lerp(A[1], B[1], f), f < 0.5 ? A[2] : B[2],
  ];
  return {
    footF: mixFoot(KF_FOOT[i0], KF_FOOT[i1]),
    footB: mixFoot(KF_FOOT[j0], KF_FOOT[j1]),
    hipX: lerp(KF_HIPX[i0], KF_HIPX[i1], f),
    bob: Math.round(lerp(KF_BOB[i0], KF_BOB[i1], f)),
    sway: Math.round(lerp(KF_SWAY[i0], KF_SWAY[i1], f)),
    headBob: Math.round(lerp(KF_HEADBOB[i0], KF_HEADBOB[i1], f)),
  };
}
const IDLE_SAMPLE: WalkSample = {
  footF: [4.5, -4, 0], footB: [-4.5, -4, 0], hipX: 0, bob: 0, sway: 0, headBob: 0, // v8: low-ready staggered feet (+2/-1)
};

// ---------------------------------------------------------------- posture lean (v4)
// Forward lean of the whole upper root while moving; smooth in/out ~150 ms (9 steps at 60 Hz).
// Module state evolves strictly per draw call sequence -> deterministic across identical runs.
let leanCur = 0;
const LEAN_STEP = 1 / 9;
/** Reset the posture-lean blend between runs (qa determinism: module state must not leak). */
export function resetLean(): void { leanCur = 0; }

// ---------------------------------------------------------------- two-bone IK
/** Solve elbow/knee for shoulder->target with lengths l1,l2; sign picks the bend side. */
function ik(sx: number, sy: number, tx: number, ty: number, l1: number, l2: number, sign: number): [number, number] {
  let dx = tx - sx, dy = ty - sy;
  let d = Math.hypot(dx, dy);
  if (d < 1e-6) { dx = 0; dy = 1; d = 1; }
  const dMin = Math.abs(l1 - l2) + 0.6, dMax = l1 + l2 - 0.6;
  const cl = Math.max(dMin, Math.min(dMax, d));
  if (cl !== d) { const s = cl / d; dx *= s; dy *= s; d = cl; }
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  const ux = dx / d, uy = dy / d;
  return [sx + ux * a - uy * sign * h, sy + uy * a + ux * sign * h];
}

// ---------------------------------------------------------------- sets (lazy, cached)
export interface BoneGeo { p: [number, number]; d: [number, number] }
interface SetBundle {
  torso: PixelBuf; torsoF: PixelBuf; pack: PixelBuf | null;
  torsoAnchor: [number, number]; helmOff: [number, number] | null;
  heads: Record<HeadOrient, { n: PixelBuf; f: PixelBuf }>;
  thigh: BoneSet; shin: BoneSet; boot: BootSet; uparm: BoneSet; forearm: BoneSet;
  uparmS: BoneSet; forearmS: BoneSet;
  fist: HandSet; suphand: HandSet;
  neck: PixelBuf; neckF: PixelBuf;
  m: ScaleMeta;
  guns: Record<GunKind, import('./hero_art.js').GunArt>;
}
const setBundles = new Map<string, SetBundle>();
const gunSets = new Map<string, GunSet>();

/** 30 px/m meta = the authored v9 constants (production contract). */
const META_30 = (set: ArmorSet): ScaleMeta => ({
  k: 1,
  thighLen: THIGH_LEN, shinLen: SHIN_LEN, uparmLen: UPARM_LEN, forearmLen: FOREARM_LEN,
  thighP: THIGH_PIVOT, thighD: THIGH_KNEE, shinP: SHIN_PIVOT, shinD: SHIN_ANKLE, bootP: BOOT_PIVOT,
  uparmP: UPARM_PIVOT, uparmD: UPARM_ELBOW, forearmP: FOREARM_PIVOT, forearmD: FOREARM_WRIST,
  uparmSP: UPARM_S_PIVOT, uparmSD: [UPARM_S_PIVOT[0], UPARM_S_LEN],
  forearmSP: FOREARM_S_PIVOT, forearmSD: [FOREARM_S_PIVOT[0], FOREARM_S_LEN],
  fistP: FIST_PIVOT, supP: HANDSUP_PIVOT,
  hipF: ANCHORS.hip_front, hipB: ANCHORS.hip_back,
  shF: ANCHORS.shoulder_front, supIk: ANCHORS.shoulder_back,
  uparmSLen: UPARM_S_LEN, forearmSLen: FOREARM_S_LEN,
  torsoA: set.torsoAnchor ?? ANCHORS.torso, neckA: ANCHORS.neck,
  headA: ANCHORS.head, helmA: set.helmet ? (set.helmOff ?? ANCHORS.head) : null,
  wristD: 8, wristUp: 7, wristDown: 11,
  footK: 1,
});

function ensureSet(set: ArmorSet, pxm = 30): SetBundle {
  // hair is part of the baked head: include it in the cache key ([H] cycle must re-bake)
  const key = `${set.id}@${pxm}@${set.helmet ? 'helm' : HEAD_SET.hair}`;
  const hit = setBundles.get(key);
  if (hit) return hit;
  const a40 = pxm === 40 ? getArts40(set) : null;
  const sc: ScaleArts | null = !a40 && pxm !== 30 ? buildScaleArts(pxm) : null;
  const pal = { ...HERO_PAL, ...(a40 ? a40.pal : (sc?.pal ?? set.pal ?? {})) };
  // v17 P1: outline tone — set shadow color when the @40 art ships its own palette,
  // pure ink otherwise (30px sets keep the current look).
  const oline = a40?.pal ? a40.pal['5'] : undefined;
  const skinPal = { ...HERO_PAL, ...SKIN_VARIANTS.light };
  const torsoArt = a40 ? a40.torso : sc ? sc.torso : set.torso;
  const torso = bake(torsoArt, `torso_${key}`, pal);
  const pack = !sc && !a40 && set.pack ? bake(set.pack, `pack_${key}`, pal) : null;
  const neckArt = a40 ? a40.neck : sc ? sc.neck : ART_NECK;
  const neck = bake(neckArt, `neck_${key}`, (a40?.helmet || sc?.helmet || set.helmet) ? pal : skinPal);
  const heads = {} as Record<HeadOrient, { n: PixelBuf; f: PixelBuf }>;
  for (const o of ['up', 'profile', 'down'] as HeadOrient[]) {
    const arts = a40 ? (a40.helmet ? a40.helmet[o] : ROOKIE40_HEADS_LIVE[HEAD_SET.hair][o]) : sc ? (sc.helmet ? sc.helmet[o] : sc.heads[o]) : (set.helmet ? set.helmet[o] : headArts(o));
    const hpal = (a40 ? a40.helmet : sc ? sc.helmet : set.helmet) ? pal : skinPal;
    const h = bake(arts, `head_${key}_${o}`, hpal);
    heads[o] = { n: h, f: tintSpr(h) };
  }
  const srcArt = {
    thigh: a40 ? a40.thigh : sc ? sc.thigh : (set.thigh ?? ART_THIGH),
    shin: a40 ? a40.shin : sc ? sc.shin : (set.shin ?? ART_SHIN),
    boot: a40 ? a40.boot : sc ? sc.boot : (set.boot ?? ART_BOOT),
    uparm: a40 ? a40.uparm : sc ? sc.uparm : (set.uparm ?? ART_UPARM),
    uparmS: a40 ? a40.uparmS : sc ? sc.uparmS : (set.uparmS ?? ART_UPARM_S),
    forearm: a40 ? a40.forearm : sc ? sc.forearm : (set.forearm ?? ART_FOREARM),
    forearmS: a40 ? a40.forearmS : sc ? sc.forearmS : (set.forearmS ?? ART_FOREARM_S),
    fist: a40 ? a40.fist : sc ? sc.fist : ART_HAND_FIST,
    suphand: a40 ? a40.suphand : sc ? sc.suphand : ART_HAND_SUPPORT,
  };
  const M = a40 ? a40.meta : sc ? sc.meta : META_30(set);
  const bun: SetBundle = {
    torso, torsoF: tintSpr(torso), pack,
    torsoAnchor: M.torsoA,
    helmOff: M.helmA,
    heads, neck, neckF: tintSpr(neck),
    // v17 P0: bones must bake with the SET palette (was HERO_PAL -> limbs read as the wrong set)
    // v17 P1: @40 outlines use the set's own shadow tone (pal['5']) instead of pure ink when shipped.
    thigh: makeBone(srcArt.thigh, M.thighP, `thigh_${key}`, 0.72, false, pal),
    shin: makeBone(srcArt.shin, M.shinP, `shin_${key}`, 0.72, false, pal),
    boot: makeBootSet(srcArt.boot, M.bootP, `boot_${key}`, pal),
    uparm: makeBone(srcArt.uparm, M.uparmP, `uparm_${key}`, 0.7, true, pal, oline),
    uparmS: makeBone(srcArt.uparmS, M.uparmSP, `uparmS_${key}`, 0.7, true, pal, oline),
    forearmS: makeBone(srcArt.forearmS, M.forearmSP, `forearmS_${key}`, 0.7, true, pal, oline),
    forearm: makeBone(srcArt.forearm, M.forearmP, `forearm_${key}`, 0.7, true, pal, oline),
    fist: makeHand(srcArt.fist, M.fistP, `hand_fist_${key}`, pal),
    suphand: makeHand(srcArt.suphand, M.supP, `hand_sup_${key}`, pal),
    m: M,
    guns: sc ? sc.guns : GUNS,
  };
  setBundles.set(key, bun);
  return bun;
}
const R2 = (v: number) => Math.round(v);
function getArts40(set: ArmorSet): Arts40 | null {
  // v19: single shipped set (ROOKIE MERC); the HEAVY/MJOLNIR set lives in archive/mjolnir_heavy_v18.
  if (set.id === 'rookie') return ROOKIE40;
  return (set.arts40 as Arts40 | undefined) ?? null;
}
function ensureGun(gun: HeroGun, pxm: number, guns: Record<GunKind, import('./hero_art.js').GunArt>): GunSet {
  const key = `${gun}@${pxm}`;
  let s = gunSets.get(key);
  if (s) return s;
  const g = gun === 'none' ? null : guns[gun];
  if (!g) {
    s = { frames: [], flash: [], muzzle: null };
  } else {
    const buf = bake(g.rows, `gun_${gun}`);
    const frames = bakeRot(buf, g.grip[0], g.grip[1], FULL_ANGLES);
    s = { frames, flash: frames.map(tintFrame), muzzle: [g.muzzle[0] - g.grip[0], g.muzzle[1] - g.grip[1]] };
  }
  gunSets.set(key, s);
  return s;
}

// ---------------------------------------------------------------- blitting
function blitFrame(b: PixelBuf, fr: Frame, px: number, py: number, flip: boolean): void {
  for (let y = fr.y0; y <= fr.y1; y++) {
    const ty = py + y - fr.oy;
    for (let x = fr.x0; x <= fr.x1; x++) {
      const c = fr.buf.get(x, y);
      if ((c >>> 24) === 0) continue;
      b.set(flip ? px - (x - fr.ox) : px + (x - fr.ox), ty, c);
    }
  }
}
function blitSpr(b: PixelBuf, spr: PixelBuf, dx: number, dy: number, flip: boolean): void {
  for (let y = 0; y < spr.h; y++)
    for (let x = 0; x < spr.w; x++) {
      const c = spr.get(x, y);
      if ((c >>> 24) === 0) continue;
      b.set(flip ? dx + spr.w - 1 - x : dx + x, dy + y, c);
    }
}

const rotIdx = (a: number): number => {
  const i = Math.round((a / (2 * Math.PI)) * ROT_N);
  return ((i % ROT_N) + ROT_N) % ROT_N;
};
/** Bones are authored pointing DOWN (+90 deg); mirror is handled by pixel-flip, NOT by the angle. */
const boneIdx = (theta: number): number => rotIdx(theta - Math.PI / 2);

/** Drawn distal-joint offset of a baked frame (quantized angle), for seamless bone chaining. */
function distalOff(idx: number, local: [number, number], pivot: [number, number]): [number, number] {
  const a = (idx * 2 * Math.PI) / ROT_N;
  const c = Math.cos(a), s = Math.sin(a);
  const dx = local[0] - pivot[0], dy = local[1] - pivot[1];
  return [Math.round(c * dx - s * dy), Math.round(s * dx + c * dy)];
}

/** Elliptical contact shadow: 2 tones + dithered rim (not a bar). */
function shadow(b: PixelBuf, x: number, y: number, k = 1): void {
  for (let dy = -Math.round(2 * k); dy <= Math.round(2 * k); dy++) {
    const w = Math.floor(8 * k * Math.sqrt(Math.max(0, 1 - (dy * dy) / (6.25 * k * k))) + 0.5);
    for (let dx = -w; dx <= w; dx++) {
      const e = Math.abs(dx) / (8 * k);
      if (e < 0.45) b.blend(x + dx, y + dy, rgba(0, 0, 0, 62));
      else if (e < 0.78) b.blend(x + dx, y + dy, rgba(0, 0, 0, 34));
      else if (((x + dx + y + dy) & 1) === 0) b.blend(x + dx, y + dy, rgba(0, 0, 0, 18));
    }
  }
}

/** Head orientation follows the aim (local right-facing angle). */
function headOrient(lang: number): HeadOrient {
  const d = (lang * 180) / Math.PI;
  if (d < -55 && d > -125) return 'up';
  if (d > 55 && d < 125) return 'down';
  return 'profile';
}

// support-arm IK pivot: side-view projection of the back shoulder (torso centerline), so the
// support hand can physically reach the handguard; ANCHORS.shoulder_back stays the authored depth
// offset for the free arm.
const SUP_IK: [number, number] = [3, -41];

// ---------------------------------------------------------------- pose-mode debug capture
let DBG: PartDbg[] | null = null;
function dbgFrame(name: string, fr: Frame, px: number, py: number, flip: boolean): void {
  if (!DBG) return;
  const lx0 = fr.x0 - fr.ox, lx1 = fr.x1 - fr.ox;
  const x0 = flip ? px - lx1 : px + lx0;
  const x1 = flip ? px - lx0 : px + lx1;
  const pix: number[] = [];
  for (let y = fr.y0; y <= fr.y1; y++) {
    const ty = py + y - fr.oy;
    for (let x = fr.x0; x <= fr.x1; x++) {
      if ((fr.buf.get(x, y) >>> 24) === 0) continue;
      const sx = flip ? px - (x - fr.ox) : px + (x - fr.ox);
      pix.push(sx, ty);
    }
  }
  DBG.push({ name, x0, y0: py + fr.y0 - fr.oy, x1, y1: py + fr.y1 - fr.oy, px, py, pix });
}
function dbgSpr(name: string, dx: number, dy: number, spr: PixelBuf, flip: boolean): void {
  if (!DBG) return;
  const pix: number[] = [];
  for (let y = 0; y < spr.h; y++)
    for (let x = 0; x < spr.w; x++) {
      if ((spr.get(x, y) >>> 24) === 0) continue;
      pix.push(flip ? dx + spr.w - 1 - x : dx + x, dy + y);
    }
  DBG.push({ name, x0: dx, y0: dy, x1: dx + spr.w - 1, y1: dy + spr.h - 1, pix });
}

// ---------------------------------------------------------------- main draw
/** Draw the mercenary. (x,y) = feet anchor in buffer coords (camera-transformed). */
export function drawHero(b: PixelBuf, x: number, y: number, p: HeroPose): void {
  DBG = p.dbg ?? null;
  const pxm = p.pxm ?? 30;
  const set = armorSetById(p.set ?? ARMOR_SETS[0].id);
  const S = ensureSet(set, pxm);
  const B_boot = S.boot;
  const M = S.m;
  const gs = ensureGun(p.gun, pxm, S.guns);
  const fl = p.flash;
  const flip = Math.cos(p.aimAng) < 0;
  const langAim = flip ? Math.PI - p.aimAng : p.aimAng; // right-facing local angle
  // low-ready idle: weapon diagonal down-forward ~45 deg, head stays forward (torso-facing)
  const lr = Math.max(0, Math.min(1, p.lowReady ?? 0));
  const LANG_LR = 0.85;
  let lang = langAim + (LANG_LR - langAim) * lr;
  const OV = p.boneOverride;
  if (OV && OV.gun !== undefined) lang = OV.gun;
  const ri = rotIdx(lang);
  const cl = Math.cos(lang), sl = Math.sin(lang);

  const ws = p.moving ? sampleWalk(p.walk) : IDLE_SAMPLE;
  const hipX = ws.hipX, bob = ws.bob;

  // posture lean: smooth ~150 ms in/out; shifts the whole upper root (torso/neck/head/arms/weapon)
  const leanTarget = p.moving ? 1 : 0;
  leanCur += Math.max(-LEAN_STEP, Math.min(LEAN_STEP, leanTarget - leanCur));
  const md = p.moveDir ?? [1, 0];
  const lox = Math.round(leanCur * 2 * md[0] * (p.pxm ? p.pxm / 30 : 1));          // screen-space lean offset
  const loy = Math.round(leanCur * 1 * md[1]);
  const loxL = flip ? -lox : lox;                        // local-space equivalent for the skeleton

  // All skeleton math runs in LOCAL (right-facing) integer space; mirroring happens only at blit.
  const MX = (lx: number) => x + (flip ? -lx : lx);
  const MY = (ly: number) => y + ly;

  shadow(b, x, y + 1, M.k);

  // ---- legs: back (darker) then front; two-bone IK hip->ankle, knee forward, chained joints
  const legPass = (back: boolean) => {
    const hipA = back ? M.hipB : M.hipF;
    const foot = back ? (p.stance?.footB ?? ws.footB) : (p.stance?.footF ?? ws.footF);
    const fk = M.footK;
    const sx = hipA[0] + hipX, sy = hipA[1] + bob;
    const hipL: [number, number] = [Math.round(sx), Math.round(sy)];
    const footL: [number, number] = [Math.round(foot[0] * fk), Math.round(foot[1] * fk)];
    const [kx, ky] = ik(sx, sy, foot[0] * fk, foot[1] * fk, M.thighLen, M.shinLen, -1);
    let thA = Math.atan2(ky - sy, kx - sx);
    let shA0 = 0;
    if (OV) { const ov = OV[back ? 'thighB' : 'thighF']; if (ov !== undefined) thA = ov; }
    const thIdx = boneIdx(thA);
    const oT = distalOff(thIdx, M.thighD, M.thighP);
    const kneeL: [number, number] = [hipL[0] + oT[0], hipL[1] + oT[1]];
    let shA = Math.atan2(footL[1] - kneeL[1], footL[0] - kneeL[0]);
    if (OV) { const ov = OV[back ? 'shinB' : 'shinF']; if (ov !== undefined) shA = ov; }
    const shIdx = boneIdx(shA);
    const thigh = back ? (fl ? S.thigh.df : S.thigh.d) : (fl ? S.thigh.nf : S.thigh.n);
    const shin = back ? (fl ? S.shin.df : S.shin.d) : (fl ? S.shin.nf : S.shin.n);
    const boot = back ? (fl ? B_boot.df : B_boot.d) : (fl ? B_boot.nf : B_boot.n);
    dbgFrame(back ? 'thighB' : 'thighF', thigh[thIdx], MX(hipL[0]), MY(hipL[1]), flip);
    blitFrame(b, thigh[thIdx], MX(hipL[0]), MY(hipL[1]), flip);
    dbgFrame(back ? 'shinB' : 'shinF', shin[shIdx], MX(kneeL[0]), MY(kneeL[1]), flip);
    blitFrame(b, shin[shIdx], MX(kneeL[0]), MY(kneeL[1]), flip);
    dbgFrame(back ? 'bootB' : 'bootF', boot[foot[2]], MX(footL[0]), MY(footL[1]), flip);
    blitFrame(b, boot[foot[2]], MX(footL[0]), MY(footL[1]), flip);  // exact foot target = sticky stance
  };
  legPass(true);
  legPass(false);

  // ---- firing arm chain (the weapon placement derives from the DRAWN wrist)
  const shF: [number, number] = [M.shF[0] + hipX + loxL, M.shF[1] + bob + loy];
  const shB: [number, number] = [M.supIk[0] + hipX + (p.moving ? ws.sway : 0) + loxL, M.supIk[1] + bob + loy];
  const deg = (lang * 180) / Math.PI;
  const upZone = deg < -55 && deg > -125;     // aim up: arm under head, weapon over shoulder
  const downZone = deg > 55 && deg < 125;    // aim down: grip stays above the thigh line
  let d = M.wristD;
  if (upZone) d = M.wristUp;
  if (downZone) d = M.wristDown;
  let wx = shF[0] + cl * d, wy = shF[1] + sl * d;
  if (upZone) { wy = Math.max(wy, Math.round(-34 * M.k)); wx += Math.round(2 * M.k); }   // wrist never rises into the head
  if (downZone) { wy = Math.min(wy, Math.round(-30 * M.k)); wx += Math.round(6 * M.k); } // barrel passes IN FRONT of the legs
  const shFL: [number, number] = [Math.round(shF[0]), Math.round(shF[1])];
  const elIK = ik(shF[0], shF[1], wx, wy, M.uparmLen, M.forearmLen, 1);
  // low-ready: elbow stays out to the aim side (visible right of the torso), not tucked inside it
  const elMan: [number, number] = [shF[0] + Math.round(9 * M.k), shF[1] + Math.round(4 * M.k)];
  const elF: [number, number] = [
    elIK[0] + (elMan[0] - elIK[0]) * lr,
    elIK[1] + (elMan[1] - elIK[1]) * lr,
  ];
  let aUpF = Math.atan2(elF[1] - shF[1], elF[0] - shF[0]);
  if (OV && OV.uparmF !== undefined) aUpF = OV.uparmF;
  const upIdxF = boneIdx(aUpF);
  const oU = distalOff(upIdxF, M.uparmD, M.uparmP);
  const elFL: [number, number] = [shFL[0] + oU[0], shFL[1] + oU[1]];
  const wristTL: [number, number] = [Math.round(wx), Math.round(wy)];
  let aFoF = Math.atan2(wristTL[1] - elFL[1], wristTL[0] - elFL[0]);
  if (OV && OV.forearmF !== undefined) aFoF = OV.forearmF;
  const foIdxF = boneIdx(aFoF);
  const oF = distalOff(foIdxF, M.forearmD, M.forearmP);
  const wristL: [number, number] = [elFL[0] + oF[0], elFL[1] + oF[1]];
  // weapon grip lands exactly under the drawn fist; handguard follows the weapon
  const gunL: [number, number] = wristL;
  const g = p.gun === 'none' ? null : GUNS[p.gun];
  let hgL: [number, number] | null = null;
  if (g && g.handguard) {
    const hx = g.handguard[0] - g.grip[0], hy = g.handguard[1] - g.grip[1];
    hgL = [Math.round(wx + cl * hx - sl * hy), Math.round(wy + sl * hx + cl * hy)];
  }

  // ---- support arm chain (target: handguard, or free bent arm for one-handed guns)
  const supTL: [number, number] = hgL ?? [Math.round(shB[0] + 7), Math.round(shB[1] + 7 + (p.moving ? ws.sway : 0))];
  const shBL: [number, number] = [Math.round(shB[0]), Math.round(shB[1])];
  const elS = ik(shB[0], shB[1], supTL[0], supTL[1], M.uparmSLen, M.forearmSLen, 1);
  let aUpS = Math.atan2(elS[1] - shB[1], elS[0] - shB[0]);
  if (OV && OV.uparmS !== undefined) aUpS = OV.uparmS;
  const upIdxS = boneIdx(aUpS);
  const oUS = distalOff(upIdxS, M.uparmSD, M.uparmSP);
  const elSL: [number, number] = [shBL[0] + oUS[0], shBL[1] + oUS[1]];
  let aFoS = Math.atan2(supTL[1] - elSL[1], supTL[0] - elSL[0]);
  if (OV && OV.forearmS !== undefined) aFoS = OV.forearmS;
  const foIdxS = boneIdx(aFoS);
  const oFS = distalOff(foIdxS, M.forearmSD, M.forearmSP);
  const supWristL: [number, number] = [elSL[0] + oFS[0], elSL[1] + oFS[1]];

  // back pack hump (behind torso; mirrors with aim, follows bob/lean)
  if (S.pack) {
    const pw = S.pack.w;
    const dx = (flip ? x - set.packOff[0] - pw : x + set.packOff[0]) + lox;
    blitSpr(b, S.pack, dx, y + set.packOff[1] + bob + loy, flip);
  }

  // FAR (right) upper arm: shoulder + upper arm BEHIND the torso (1 px ink outline at the edges)
  dbgFrame('uparmF', (fl ? S.uparm.df : S.uparm.d)[upIdxF], MX(shFL[0]), MY(shFL[1]), flip);
  blitFrame(b, S.uparm.o[upIdxF], MX(shFL[0]), MY(shFL[1]), flip);
  blitFrame(b, (fl ? S.uparm.df : S.uparm.d)[upIdxF], MX(shFL[0]), MY(shFL[1]), flip);
  if (DBG) {
    DBG.push({ name: 'anchorR', x0: MX(shFL[0]), y0: MY(shFL[1]), x1: MX(shFL[0]), y1: MY(shFL[1]), px: MX(shFL[0]), py: MY(shFL[1]) });
    DBG.push({ name: 'anchorL', x0: MX(shBL[0]), y0: MY(shBL[1]), x1: MX(shBL[0]), y1: MY(shBL[1]), px: MX(shBL[0]), py: MY(shBL[1]) });
  }

  // ---- torso, neck (head sits IN the raised collar)
  const ox = flip ? -Math.round(hipX) : Math.round(hipX);
  dbgSpr('torso', x + S.torsoAnchor[0] + ox + lox, y + S.torsoAnchor[1] + bob + loy, S.torso, flip);
  blitSpr(b, fl ? S.torsoF : S.torso, x + S.torsoAnchor[0] + ox + lox, y + S.torsoAnchor[1] + bob + loy, flip);
  if (!S.helmOff) {  // helmet covers the neck entirely
    dbgSpr('neck', x + M.neckA[0] + ox + lox, y + M.neckA[1] + bob + loy, S.neck, flip);
    blitSpr(b, fl ? S.neckF : S.neck, x + M.neckA[0] + ox + lox, y + M.neckA[1] + bob + loy, flip);
  }

  // NEAR (left) upper arm: fully visible OVER the torso
  dbgFrame('uparmS', (fl ? S.uparmS.nf : S.uparmS.n)[upIdxS], MX(shBL[0]), MY(shBL[1]), flip);
  blitFrame(b, S.uparmS.o[upIdxS], MX(shBL[0]), MY(shBL[1]), flip);
  blitFrame(b, (fl ? S.uparmS.nf : S.uparmS.n)[upIdxS], MX(shBL[0]), MY(shBL[1]), flip);

  // FAR forearm: OVER the torso, UNDER the weapon
  dbgFrame('forearmF', (fl ? S.forearm.df : S.forearm.d)[foIdxF], MX(elFL[0]), MY(elFL[1]), flip);
  blitFrame(b, (fl ? S.forearm.df : S.forearm.d)[foIdxF], MX(elFL[0]), MY(elFL[1]), flip);

  const blitGun = () => {
    if (gs.frames.length) {
      dbgFrame('gun', (fl ? gs.flash : gs.frames)[ri], MX(gunL[0]), MY(gunL[1]), flip);
      blitFrame(b, (fl ? gs.flash : gs.frames)[ri], MX(gunL[0]), MY(gunL[1]), flip);
    }
  };
  // NEAR forearm + hand: OVER the weapon; hand chained to the forearm distal (no gap ever)
  const blitForeS = () => {
    dbgFrame('forearmS', (fl ? S.forearmS.nf : S.forearmS.n)[foIdxS], MX(elSL[0]), MY(elSL[1]), flip);
    blitFrame(b, S.forearmS.o[foIdxS], MX(elSL[0]), MY(elSL[1]), flip);
    blitFrame(b, (fl ? S.forearmS.nf : S.forearmS.n)[foIdxS], MX(elSL[0]), MY(elSL[1]), flip);
  };
  const blitSupHand = () => {
    if (hgL) {
      dbgFrame('handS', (fl ? S.suphand.nf : S.suphand.n)[ri], MX(supWristL[0]), MY(supWristL[1]), flip);
      blitFrame(b, (fl ? S.suphand.nf : S.suphand.n)[ri], MX(supWristL[0]), MY(supWristL[1]), flip);
    } else {
      dbgFrame('handS', (fl ? S.fist.nf : S.fist.n)[ri], MX(supWristL[0]), MY(supWristL[1]), flip);
      blitFrame(b, (fl ? S.fist.nf : S.fist.n)[ri], MX(supWristL[0]), MY(supWristL[1]), flip);
    }
  };
  const blitFistF = () => {
    dbgFrame('handF', (fl ? S.fist.df : S.fist.d)[ri], MX(gunL[0]), MY(gunL[1]), flip);
    blitFrame(b, (fl ? S.fist.df : S.fist.d)[ri], MX(gunL[0]), MY(gunL[1]), flip);  // fist OVER the weapon at GRIP
  };
  if (upZone) { blitGun(); blitFistF(); blitForeS(); blitSupHand(); }  // weapon+arms slide behind the head when aiming up

  // ---- head
  const leanX = Math.abs(cl) > 0.35 ? 1 : 0;
  const leanY = Math.max(-1, Math.min(1, Math.round(sl * 1.2)));
  const hox = flip ? -Math.round(hipX + leanX) : Math.round(hipX + leanX);
  const hd = S.heads[lr > 0.5 ? 'profile' : headOrient(lang)];
  const hAnchor = S.helmOff ?? M.headA;
  const hBob = S.helmOff ? 0 : ws.headBob;   // helmet is rigid with the torso lean
  dbgSpr('head', x + hAnchor[0] + hox + lox, y + hAnchor[1] + bob + hBob + leanY + loy, hd.n, flip);
  blitSpr(b, fl ? hd.f : hd.n, x + hAnchor[0] + hox + lox, y + hAnchor[1] + bob + hBob + leanY + loy, flip);

  // ---- weapon over the far forearm, then near arm on top
  if (!upZone) { blitGun(); blitFistF(); blitForeS(); blitSupHand(); }

  // ---- muzzle flash at the rotated muzzle anchor
  if (p.muzzle > 0 && gs.muzzle) {
    const mx = gs.muzzle[0], my = gs.muzzle[1];
    const rx = Math.round(cl * mx - sl * my);
    const ry = Math.round(sl * mx + cl * my);
    const fxp = MX(gunL[0]) + (flip ? -rx : rx), fyp = MY(gunL[1]) + ry;
    const dirx = Math.cos(p.aimAng), diry = Math.sin(p.aimAng);
    b.discA(fxp + Math.round(dirx * 2), fyp + Math.round(diry * 2), 4, rgba(255, 190, 90, 96));
    b.disc(fxp, fyp, 2, rgba(255, 226, 160));
    b.set(fxp + Math.round(dirx * 3), fyp + Math.round(diry * 3), rgba(255, 242, 208));
    b.blend(fxp + Math.round(-diry * 2), fyp + Math.round(dirx * 2), rgba(255, 214, 140, 200));
    b.blend(fxp + Math.round(diry * 2), fyp + Math.round(-dirx * 2), rgba(255, 214, 140, 200));
  }
  DBG = null;
}
