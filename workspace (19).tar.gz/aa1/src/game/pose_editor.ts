import { PixelBuf, rgba } from '../core/buf.js';
import { drawHero, type HeroPose, type BoneName, type PartDbg } from './hero.js';
import { HEAD_SET } from './hero_art.js';
import { drawTextS } from './font.js';
import { P } from '../core/palette.js';
import type { GameCore } from './game.js';
import type { InputState } from '../engine/input.js';

/**
 * POSE MODE (v10) - a purely visual development tool. The simulation is paused while active;
 * the mode USES the skeleton math (chain joints, baked frames) via HeroPose.boneOverride and
 * never modifies it. The headless bot never presses [P], so qa determinism is untouched.
 *
 * Controls: [P] enter/exit, [Esc] exit, [Tab] cycle part, click = select, drag = rotate the bone
 * around its pivot (children follow through the same chain math as combat), Shift+drag = weapon
 * angle as a separate bone, wheel = zoom 4/6/8, [M] scale 30/36/40, [B]/[H] sets/hair, [S] silhouette,
 * [L] labels+pivots, [1] low-ready [2] aim [3] walk-key0 [0] reset, [C] copy pose JSON, [V] save PNG.
 */

export interface PoseJson {
  scale: number; set: string; hair: string;
  aim: number; lowReady: number; moving: boolean; walk: number;
  bones: Record<string, number>;   // degrees
  gun: number | null;              // degrees
  hideGun?: boolean;               // weapon hidden (arms posed separately)
}

const PARTS: string[] = [
  'head', 'neck', 'torso', 'uparmF', 'forearmF', 'handF', 'gun', 'handS', 'forearmS', 'uparmS',
  'thighF', 'shinF', 'bootF', 'thighB', 'shinB', 'bootB',
];
const BONES: BoneName[] = ['thighF', 'shinF', 'thighB', 'shinB', 'uparmF', 'forearmF', 'uparmS', 'forearmS', 'gun'];
const DEG = 180 / Math.PI;

export class PoseEditor {
  active = false;
  zoom = 4;
  pxm = 30;
  sil = false;
  labels = false;
  sel = -1;
  hideGun = false;                 // [G]: weapon off so each arm can be posed separately
  overrides: Partial<Record<BoneName, number>> = {};
  pose = { aimAng: 0.2, moving: false, walk: 0, lowReady: 1 };
  private dbg: PartDbg[] = [];
  private drag: 'bone' | 'gun' | null = null;
  private prevDown = false;
  private viewOx = 0;
  private viewOy = 0;
  private cellW = 150;
  private cellH = 130;
  private footX = 70;
  private footY = 116;

  heroPose(core: GameCore, withDbg: boolean): HeroPose {
    return {
      aimAng: this.pose.aimAng, moving: this.pose.moving, walk: this.pose.walk,
      flash: false, gun: this.hideGun ? 'none' : 'rifle', muzzle: 0,
      set: 'rookie',
      lowReady: this.pose.lowReady,
      pxm: this.pxm,
      boneOverride: Object.keys(this.overrides).length ? this.overrides : undefined,
      dbg: withDbg ? this.dbg : undefined,
    };
  }
  /** Editor pose rendered into the live scene (1x window): same overrides, scene scale 30. */
  scenePose(core: GameCore): HeroPose {
    const p = this.heroPose(core, false);
    p.pxm = 30;
    return p;
  }

  json(core: GameCore): PoseJson {
    const bones: Record<string, number> = {};
    for (const b of BONES) if (b !== 'gun' && this.overrides[b] !== undefined) bones[b] = Math.round(this.overrides[b]! * DEG * 10) / 10;
    return {
      scale: this.pxm, set: 'rookie', hair: HEAD_SET.hair,
      aim: Math.round(this.pose.aimAng * DEG * 10) / 10, lowReady: this.pose.lowReady,
      moving: this.pose.moving, walk: Math.round(this.pose.walk * 100) / 100,
      bones, gun: this.overrides.gun !== undefined ? Math.round(this.overrides.gun * DEG * 10) / 10 : null,
      hideGun: this.hideGun,
    };
  }
  applyJson(j: PoseJson) {
    this.pxm = j.scale; this.pose.aimAng = j.aim / DEG; this.pose.lowReady = j.lowReady;
    this.pose.moving = j.moving; this.pose.walk = j.walk;
    this.overrides = {};
    for (const k of Object.keys(j.bones)) this.overrides[k as BoneName] = j.bones[k] / DEG;
    if (j.gun !== null) this.overrides.gun = j.gun / DEG;
    this.hideGun = !!j.hideGun;
  }

  parts(): PartDbg[] { return this.dbg; }
  /** Pixel-precise: topmost drawn pixel wins (a part hidden under another is not clickable there). */
  hitTest(x: number, y: number): string | null {
    for (let i = this.dbg.length - 1; i >= 0; i--) {
      const d = this.dbg[i];
      if (!d.pix) continue;
      for (let q = 0; q < d.pix.length; q += 2)
        if (d.pix[q] === x && d.pix[q + 1] === y) return d.name;
    }
    return null;
  }
  /** A point where this part is the topmost clickable pixel (for tests / editor UX). */
  clickablePoint(name: string): [number, number] | null {
    const d = this.dbg.find((q) => q.name === name);
    if (!d || !d.pix) return null;
    for (let q = d.pix.length - 2; q >= 0; q -= 2) {
      const x = d.pix[q], y = d.pix[q + 1];
      let top = true;
      for (let i = this.dbg.length - 1; i >= 0; i--) {
        const e = this.dbg[i];
        if (e.name === name) break;
        if (!e.pix) continue;
        for (let r = 0; r < e.pix.length; r += 2)
          if (e.pix[r] === x && e.pix[r + 1] === y) { top = false; break; }
        if (!top) break;
      }
      if (top) return [x, y];
    }
    return null;
  }
  private partPoint(name: string): [number, number] | null {
    for (let i = this.dbg.length - 1; i >= 0; i--) if (this.dbg[i].name === name) {
      const d = this.dbg[i];
      return [(d.x0 + d.x1) / 2, (d.y0 + d.y1) / 2];
    }
    return null;
  }

  tick(inp: InputState, core: GameCore, hooks: { copy: (s: string) => void; save: (b: PixelBuf, j: PoseJson) => void }) {
    const pr = inp.pressed;
    if (pr.has('g')) this.hideGun = !this.hideGun;
    if (pr.has('tab')) {
      // cycle only parts actually present in the last render (gun hidden => no 'gun' part)
      for (let step = 1; step <= PARTS.length; step++) {
        this.sel = (this.sel + step) % PARTS.length;
        if (this.dbg.some((d) => d.name === PARTS[this.sel])) break;
      }
    }
    if (pr.has('m')) { const s = [30, 36, 40]; this.pxm = s[(s.indexOf(this.pxm) + 1) % 3]; }
    if (pr.has('b')) core.cycleSet();
    if (pr.has('h')) core.cycleHair();
    if (pr.has('s')) this.sil = !this.sil;
    if (pr.has('l')) this.labels = !this.labels;
    if (pr.has('1')) { this.pose = { aimAng: 0.2, moving: false, walk: 0, lowReady: 1 }; this.overrides = {}; }
    if (pr.has('2')) { this.pose = { aimAng: -0.15, moving: false, walk: 0, lowReady: 0 }; this.overrides = {}; }
    if (pr.has('3')) { this.pose = { aimAng: 0, moving: true, walk: 0, lowReady: 0 }; this.overrides = {}; }
    if (pr.has('0')) { this.pose = { aimAng: 0.2, moving: false, walk: 0, lowReady: 0 }; this.overrides = {}; }
    if (pr.has('c')) hooks.copy(JSON.stringify(this.json(core)));
    if (inp.wheel) { this.zoom = this.zoom === 4 ? 6 : this.zoom === 6 ? 8 : 4; }
    // mouse: select / drag-rotate
    const down = inp.mouseDown;
    if (down && !this.prevDown) {
      const [cx, cy] = this.toCell(inp.mouseX, inp.mouseY);
      const hit = this.hitTest(cx, cy);
      if (hit) {
        this.sel = Math.max(0, PARTS.indexOf(hit));
        if (hit === 'gun') this.drag = 'gun';
        else {
          const bone = this.dragBoneFor(hit);
          this.drag = bone ? 'bone' : null;
          if (bone) this.dragName = bone;
        }
      } else this.drag = null;
    }
    if (down && this.drag) {
      const [cx, cy] = this.toCell(inp.mouseX, inp.mouseY);
      const name = this.drag === 'gun' ? 'gun' : this.dragName;  // dragName already alias-resolved
      const pt = name === 'gun' ? this.partPoint('gun') : this.pivotOf(name);
      if (pt) {
        const a = Math.atan2(cy - pt[1], cx - pt[0]);
        if (name === 'gun') this.overrides.gun = a;
        else this.overrides[name as BoneName] = a;
      }
    }
    if (!down) this.drag = null;
    this.prevDown = down;
    if (pr.has('v')) hooks.save(this.render(core), this.json(core));
  }
  private dragName: BoneName = 'uparmF';
  /** Hands/boots drag their parent bone so every visible part is movable. */
  private dragBoneFor(name: string): BoneName | null {
    const alias: Record<string, BoneName> = {
      handF: 'forearmF', handS: 'forearmS', bootF: 'shinF', bootB: 'shinB',
    };
    const n = alias[name] ?? name;
    return BONES.includes(n as BoneName) ? (n as BoneName) : null;
  }
  private pivotOf(name: string): [number, number] | null {
    for (const d of this.dbg) if (d.name === name && d.px !== undefined) return [d.px, d.py!];
    // sprites (head/torso/neck): pivot = bbox center
    const p = this.partPoint(name);
    return p;
  }
  /** cell coords -> screen coords of the main view (tests / external tools). */
  toScreen(x: number, y: number): [number, number] {
    return [this.viewOx + x * this.zoom, this.viewOy + y * this.zoom];
  }
  private toCell(mx: number, my: number): [number, number] {
    // dbg pixels are integers in cell space: round the inverse transform or hits never match
    return [Math.round((mx - this.viewOx) / this.zoom), Math.round((my - this.viewOy) / this.zoom)];
  }

  render(core: GameCore): PixelBuf {
    const b = new PixelBuf(640, 360, rgba(14, 15, 18));
    // main 4x/6x/8x view
    this.dbg = [];
    const cell = new PixelBuf(this.cellW, this.cellH);
    drawHero(cell, this.footX, this.footY, this.heroPose(core, true));
    if (this.sil) {
      for (let y = 0; y < cell.h; y++)
        for (let x = 0; x < cell.w; x++) {
          const c = cell.get(x, y);
          if ((c >>> 24) === 0) continue;
          cell.set(x, y, rgba(8, 8, 10));
        }
    }
    const up = new PixelBuf(cell.w * this.zoom, cell.h * this.zoom);
    for (let y = 0; y < cell.h; y++)
      for (let x = 0; x < cell.w; x++) {
        const c = cell.get(x, y);
        for (let dy = 0; dy < this.zoom; dy++) for (let dx = 0; dx < this.zoom; dx++) up.set(x * this.zoom + dx, y * this.zoom + dy, c);
      }
    // center the torso in the main view
    const t = this.dbg.find((d) => d.name === 'torso');
    const ccx = t ? (t.x0 + t.x1) / 2 : this.footX;
    const ccy = t ? (t.y0 + t.y1) / 2 : this.footY - 30;
    this.viewOx = 300 - Math.round(ccx * this.zoom);
    this.viewOy = 170 - Math.round(ccy * this.zoom);
    b.blit(up, this.viewOx, this.viewOy);
    // selection + labels + pivots
    if (this.sel >= 0) {
      const name = PARTS[this.sel];
      for (const d of this.dbg) if (d.name === name)
        b.frame(this.viewOx + d.x0 * this.zoom, this.viewOy + d.y0 * this.zoom,
          (d.x1 - d.x0 + 1) * this.zoom, (d.y1 - d.y0 + 1) * this.zoom, rgba(255, 90, 70));
    }
    if (this.labels) {
      for (const d of this.dbg) {
        if (d.name === 'anchorR' || d.name === 'anchorL') {
          const tag = d.name === 'anchorR' ? 'SHOULDER_R FAR' : 'SHOULDER_L NEAR';
          const lx = this.viewOx + (d.px! * this.zoom) + (d.name === 'anchorR' ? 6 : -78);
          drawTextS(b, lx, this.viewOy + d.py! * this.zoom - 6, tag, P.xp);
          b.set(this.viewOx + d.px! * this.zoom, this.viewOy + d.py! * this.zoom, rgba(255, 240, 220));
          b.set(this.viewOx + d.px! * this.zoom + 1, this.viewOy + d.py! * this.zoom, rgba(255, 240, 220));
          continue;
        }
        drawTextS(b, this.viewOx + d.x0 * this.zoom, this.viewOy + d.y0 * this.zoom - 8, d.name.toUpperCase(), P.textDim);
        if (d.px !== undefined) b.set(this.viewOx + d.px * this.zoom, this.viewOy + d.py! * this.zoom, rgba(255, 240, 220));
      }
    }
    // 1x scene window (readability check in gameplay)
    const scene = core.render(this.scenePose(core));
    const px = core.cam.wx(core.px), py = core.cam.wy(core.py);
    const wx = 470, wy = 8, ww = 162, wh = 118;
    b.frame(wx - 1, wy - 1, ww + 2, wh + 2, rgba(90, 96, 104));
    b.blit(scene, wx, wy, Math.max(0, px - ww / 2), Math.max(0, py - wh + 24), ww, wh);
    drawTextS(b, wx, wy + wh + 4, 'SCENE 1X', P.textDim);
    // HUD
    const j = this.json(core);
    drawTextS(b, 8, 300, '[P]/[ESC] EXIT  [TAB] PART  CLICK=SEL  DRAG=ROT  SHIFT+DRAG=GUN  [G] GUN OFF  WHEEL=ZOOM  [M] SCALE  [B]/[H]  [S] SIL  [L] LABELS', P.textDim);
    drawTextS(b, 8, 310, '[1] LOW-READY  [2] AIM  [3] WALK K0  [0] RESET  [C] COPY JSON  [V] SAVE PNG', P.textDim);
    const selRaw = this.sel >= 0 ? PARTS[this.sel] : '-';
    const selBone = this.sel >= 0 ? (this.dragBoneFor(selRaw) ?? selRaw) : '-';
    const selName = selBone !== selRaw ? `${selRaw}->${selBone}` : selRaw;
    const ov = this.sel >= 0 ? this.overrides[selBone as BoneName] : undefined;
    drawTextS(b, 8, 322, `SEL: ${selName} ${ov !== undefined ? Math.round(ov * DEG) + ' DEG' : ''}  SCALE ${this.pxm}  SET ${j.set}  HAIR ${j.hair}  ZOOM ${this.zoom}X${this.sil ? '  SIL' : ''}${this.labels ? '  LABELS' : ''}`, P.text);
    const js = JSON.stringify(j).replace(/{/g, '(').replace(/}/g, ')').replace(/"/g, "'");
    drawTextS(b, 8, 334, `POSE JSON: ${js}`, P.textDim);
    return b;
  }
}
