import { PixelBuf, rgba, shade, mixc } from '../core/buf.js';
import { makeRng, pick, ri, type Rng } from '../core/rng.js';
import { ramp5 } from '../core/palette.js';

/**
 * Composite humanoid rig (Cortex Command-style assembly): every character is a stack of
 * generated parts (head/helmet, torso, arms, legs, gear) from a part-set. Parts come with
 * per-instance variants so two enemies of one archetype never look identical.
 *
 * Drawn parametrically each frame (cheap: a few hundred pixel ops) so walk/aim pose is live.
 * Anchor = feet center. Height ~1.7 m at 30 px/m => ~50 px, heroic pixel-art proportions.
 */

export type Dir8 = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7; // 0=E, 1=SE, 2=S, 3=SW, 4=W, 5=NW, 6=N, 7=NE
export const DIR_VEC: [number, number][] = [
  [1, 0], [0.707, 0.707], [0, 1], [-0.707, 0.707], [-1, 0], [-0.707, -0.707], [0, -1], [0.707, -0.707],
];
export function dir8FromVec(dx: number, dy: number): Dir8 {
  const a = Math.atan2(dy, dx);
  let i = Math.round(a / (Math.PI / 4));
  if (i < 0) i += 8;
  return (i % 8) as Dir8;
}

export interface RigParts {
  skin: number[];          // 5-step skin ramp
  cloth: number[];         // 5-step cloth ramp
  accent: number[];        // 5-step accent (trim, straps, glow housing)
  head: 'helmet' | 'hood' | 'bandana' | 'bare' | 'mask' | 'drone';
  bulk: 0 | 1 | 2;         // torso bulk
  legStyle: 'pants' | 'armored' | 'mech';
  glow: number;            // emissive accent color (visor/lights)
  scale: number;           // 0.9..1.15 size jitter
  scars: number;           // 0..3 wear marks
}

export function rollRigParts(r: Rng, gang: [number, number, number][], opts?: Partial<RigParts>): RigParts {
  return {
    skin: ramp5(pick(r, [[0x9c, 0x6e, 0x4a], [0x7a, 0x52, 0x36], [0xc0, 0x90, 0x68], [0x60, 0x44, 0x30]] as [number, number, number][])),
    cloth: ramp5(pick(r, gang)),
    accent: ramp5(pick(r, [[0x8a, 0x6a, 0x2a], [0x40, 0x60, 0x68], [0x70, 0x30, 0x28], [0x50, 0x58, 0x40]] as [number, number, number][])),
    head: pick(r, ['helmet', 'hood', 'bandana', 'bare', 'mask'] as const),
    bulk: ri(r, 0, 2) as 0 | 1 | 2,
    legStyle: pick(r, ['pants', 'armored', 'mech'] as const),
    glow: pick(r, [rgba(0x6a, 0xc8, 0xe8), rgba(0xe8, 0x8a, 0x3c), rgba(0xc8, 0x5a, 0x4a), rgba(0x8a, 0xe8, 0x9a)]),
    scale: 0.92 + r() * 0.2,
    scars: ri(r, 0, 3),
    ...opts,
  };
}

export interface Pose {
  dir: Dir8;          // body facing
  aim: Dir8;          // aim facing
  walk: number;       // walk cycle phase (radians); 0 = idle
  moving: boolean;
  crouch?: number;    // 0..1
  flash?: boolean;    // hit flash tint
  dead?: number;      // 0..1 death slump
}

const INK = rgba(10, 11, 13);

/** Draw weapon held by front arm. kind drives silhouette. Returns muzzle offset (px). */
export function drawGun(b: PixelBuf, x: number, y: number, aim: Dir8, kind: 'rifle' | 'pistol' | 'smg' | 'melee' | 'none',
  body: number, hi: number, glow: number, muzzleFlash: number): [number, number] {
  if (kind === 'none') return [0, 0];
  const [vx, vy] = DIR_VEC[aim];
  const len = kind === 'rifle' ? 15 : kind === 'smg' ? 11 : kind === 'pistol' ? 8 : 10;
  const mx = Math.round(x + vx * len), my = Math.round(y + vy * len * 0.62);
  // stock->muzzle as thick line
  const steps = len;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = Math.round(x + vx * len * t), py = Math.round(y + vy * len * t * 0.62);
    const thick = i < 3 ? 2 : i > steps - 4 ? 1 : 2;
    for (let dy = -(thick >> 1); dy <= (thick >> 1); dy++) b.set(px, py + dy, i > steps - 5 ? hi : body);
  }
  // mag
  b.set(Math.round(x + vx * 5), Math.round(y + vy * 5 * 0.62) + 2, body);
  b.set(Math.round(x + vx * 5), Math.round(y + vy * 5 * 0.62) + 3, shade(body, 0.8));
  if (kind === 'rifle' || kind === 'smg') b.set(Math.round(x + vx * 8), Math.round(y + vy * 8 * 0.62) - 2, glow);
  if (muzzleFlash > 0) {
    const fx = Math.round(x + vx * (len + 2)), fy = Math.round(y + vy * (len + 2) * 0.62);
    b.disc(fx, fy, muzzleFlash > 0.5 ? 3 : 2, rgba(0xff, 0xe2, 0xa0));
    b.set(fx + Math.round(vx * 3), fy + Math.round(vy * 2), rgba(0xff, 0xf2, 0xd0));
  }
  return [mx, my];
}

/** Main humanoid draw. (x,y) = feet anchor in buf coords (already camera-transformed). */
export function drawHumanoid(b: PixelBuf, x: number, y: number, parts: RigParts, pose: Pose,
  gun: 'rifle' | 'pistol' | 'smg' | 'melee' | 'none', muzzle = 0): void {
  const s = parts.scale;
  const H = Math.round(46 * s);              // total height px
  const w = Math.round((10 + parts.bulk * 3) * s);
  const crouch = pose.crouch ?? 0;
  const slump = pose.dead ?? 0;
  const bh = Math.round(H * (1 - 0.25 * slump - 0.08 * crouch));
  const swing = pose.moving ? Math.sin(pose.walk) : 0;
  const swing2 = pose.moving ? Math.sin(pose.walk + Math.PI) : 0;
  const bob = pose.moving ? (Math.sin(pose.walk * 2) > 0 ? 1 : 0) : 0;
  const C = parts.cloth, K = parts.skin, A = parts.accent;
  const flash = pose.flash ?? false;
  const col = (c: number) => (flash ? mixc(c, rgba(255, 236, 220), 0.62) : c);

  // shadow
  b.discA(x, y + 1, Math.round(7 * s), rgba(0, 0, 0, 70));

  const top = y - bh;                        // head top
  const torsoY = top + Math.round(12 * s) + bob;
  const hipY = y - Math.round(14 * s);

  // legs (2), walk swing moves feet horizontally
  const legW = Math.max(2, Math.round(3 * s));
  const lx = x - Math.round(2.5 * s), rx = x + Math.round(1.5 * s);
  const lsw = Math.round(swing * 3 * s), rsw = Math.round(swing2 * 3 * s);
  for (let yy = hipY; yy <= y; yy++) {
    const t = (yy - hipY) / Math.max(1, y - hipY);
    b.hline(lx + Math.round(lsw * t), yy, legW, col(parts.legStyle === 'mech' ? A[1] : C[1]));
    b.hline(rx + Math.round(rsw * t), yy, legW, col(parts.legStyle === 'mech' ? A[2] : C[2]));
  }
  // boots
  b.hline(lx + lsw - 1, y, legW + 1, col(INK));
  b.hline(rx + rsw - 1, y, legW + 1, col(INK));
  if (parts.legStyle === 'armored') {
    b.hline(lx, hipY + 3, legW, col(A[2]));
    b.hline(rx, hipY + 3, legW, col(A[2]));
  }

  // torso
  const tw = w, th = Math.round(16 * s);
  for (let yy = torsoY; yy < torsoY + th; yy++) {
    const t = (yy - torsoY) / th;
    const cw = Math.round(tw * (0.86 + 0.14 * Math.sin(t * Math.PI)));
    b.hline(x - (cw >> 1), yy, cw, col(C[t < 0.35 ? 3 : t < 0.75 ? 2 : 1]));
  }
  // chest strap + belt
  b.hline(x - (tw >> 1), torsoY + Math.round(4 * s), tw, col(A[1]));
  b.set(x + 1, torsoY + Math.round(4 * s), col(A[3]));
  b.hline(x - (tw >> 1), torsoY + th - 2, tw, col(INK));
  b.set(x, torsoY + th - 2, col(A[3]));
  // scars / wear patches
  for (let i = 0; i < parts.scars; i++) {
    b.set(x - 3 + i * 3, torsoY + 6 + i * 2, col(C[0]));
    b.set(x - 2 + i * 3, torsoY + 6 + i * 2, col(C[0]));
  }

  // back arm
  const bsw = Math.round(swing2 * 2 * s);
  b.vline(x - (tw >> 1) - 1, torsoY + 2 + (pose.moving ? bsw : 0), Math.round(9 * s), col(C[1]));
  b.set(x - (tw >> 1) - 1, torsoY + 2 + Math.round(9 * s) + (pose.moving ? bsw : 0), col(K[2]));

  // head
  const hw = Math.round(9 * s), hh = Math.round(10 * s);
  const hy = top + bob;
  for (let yy = hy; yy < hy + hh; yy++) {
    const t = (yy - hy) / hh;
    const cw = Math.round(hw * (t < 0.25 ? 0.8 : 1));
    b.hline(x - (cw >> 1), yy, cw, col(K[t < 0.5 ? 3 : 2]));
  }
  // face direction hint: eyes/visor shifted toward facing
  const [fx, fy] = DIR_VEC[pose.dir];
  const ex = x + Math.round(fx * 2 * s), ey = hy + Math.round(4 * s) + Math.round(fy * 1);
  switch (parts.head) {
    case 'helmet':
      b.hline(x - (hw >> 1), hy - 1, hw, col(A[2]));
      b.hline(x - (hw >> 1), hy, hw, col(A[3]));
      b.hline(ex - 2, ey, 4, col(flash ? rgba(255, 240, 230) : parts.glow));
      break;
    case 'hood':
      for (let yy = hy - 2; yy < hy + hh - 2; yy++) {
        b.set(x - (hw >> 1) - 1, yy, col(C[1]));
        b.set(x + (hw >> 1), yy, col(C[1]));
      }
      b.hline(x - (hw >> 1) - 1, hy - 2, hw + 2, col(C[2]));
      b.set(ex - 1, ey, col(INK)); b.set(ex + 1, ey, col(INK));
      break;
    case 'bandana':
      b.hline(x - (hw >> 1), hy + 2, hw, col(A[2]));
      b.set(ex - 1, ey - 1, col(INK)); b.set(ex + 1, ey - 1, col(INK));
      break;
    case 'mask':
      b.hline(x - (hw >> 1), ey, hw, col(A[1]));
      b.set(ex - 1, ey - 2, col(flash ? rgba(255, 240, 230) : parts.glow));
      b.set(ex + 1, ey - 2, col(flash ? rgba(255, 240, 230) : parts.glow));
      break;
    default: // bare
      b.hline(x - (hw >> 1), hy, hw, col(shade(K[1], 0.8)));
      b.set(ex - 1, ey, col(INK)); b.set(ex + 1, ey, col(INK));
  }

  // front arm + weapon, aimed
  const [ax, ay] = DIR_VEC[pose.aim];
  const shx = x + Math.round(ax * 3 * s), shy = torsoY + Math.round(5 * s);
  const hnd = drawGun(b, shx + Math.round(ax * 4), shy + Math.round(ay * 3 * 0.62), pose.aim, gun,
    flash ? rgba(255, 240, 230) : rgba(0x2c, 0x2f, 0x36), flash ? rgba(255, 255, 255) : rgba(0x4a, 0x4f, 0x58),
    flash ? rgba(255, 240, 230) : parts.glow, muzzle);
  b.vline(shx, shy, Math.round(6 * s), col(C[3]));
  b.set(hnd[0] ? shx + Math.round(ax * 7) : shx, shy + Math.round(ay * 4 * 0.62), col(K[3]));
  void hnd;
}

/** Flying drone rig: compact body + rotor glow, no legs. */
export function drawDrone(b: PixelBuf, x: number, y: number, parts: RigParts, t: number, flash: boolean, hurtGlow: number): void {
  const s = parts.scale * 0.8;
  const C = parts.cloth;
  const hov = Math.round(Math.sin(t * 6) * 1.5);
  const cy = y - Math.round(16 * s) + hov;
  b.discA(x, y + 1, Math.round(4 * s), rgba(0, 0, 0, 50));
  const col = (c: number) => (flash ? mixc(c, rgba(255, 236, 220), 0.62) : c);
  for (let yy = -4; yy <= 3; yy++) {
    const cw = Math.round((8 - Math.abs(yy) * 1.2) * s);
    b.hline(x - (cw >> 1), cy + yy, cw, col(C[yy < -1 ? 3 : yy < 1 ? 2 : 1]));
  }
  // eye
  b.hline(x - 1, cy - 1, 3, col(flash ? rgba(255, 255, 255) : parts.glow));
  // rotors
  const rw = Math.round((5 + Math.sin(t * 40) * 2) * s);
  b.hline(x - rw - 4, cy - 5, rw, col(rgba(160, 170, 180, 160)));
  b.hline(x + 5, cy - 5, rw, col(rgba(160, 170, 180, 160)));
  b.vline(x - 5, cy - 5, 3, col(C[1]));
  b.vline(x + 4, cy - 5, 3, col(C[1]));
  if (hurtGlow > 0) b.disc(x, cy, 2, rgba(0xff, 0x80, 0x40, 200));
}

/** Small helper: deterministic gang palettes for enemy factions-of-the-scum. */
export const GANGS: [number, number, number][][] = [
  [[0x6a, 0x3a, 0x2c], [0x4a, 0x42, 0x38], [0x58, 0x4c, 0x30]],          // rust cult
  [[0x3c, 0x44, 0x50], [0x2e, 0x36, 0x40], [0x50, 0x58, 0x60]],          // scrap gang
  [[0x54, 0x30, 0x48], [0x40, 0x28, 0x38], [0x68, 0x40, 0x58]],          // neon freaks
  [[0x40, 0x50, 0x38], [0x34, 0x42, 0x30], [0x50, 0x60, 0x44]],          // marsh marauders
];
export function rollGangRig(seed: number, gangIdx?: number): RigParts {
  const r = makeRng(seed);
  const g = gangIdx ?? ri(r, 0, GANGS.length - 1);
  return rollRigParts(r, GANGS[g]);
}
