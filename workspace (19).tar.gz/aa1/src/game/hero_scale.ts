import { rgba } from '../core/buf.js';
import {
  GUNS, HEAD_SET,
  THIGH_PIVOT, SHIN_PIVOT, BOOT_PIVOT, UPARM_PIVOT, UPARM_ELBOW, FOREARM_PIVOT, FOREARM_WRIST,
  UPARM_S_PIVOT, UPARM_S_LEN, FOREARM_S_PIVOT, FOREARM_S_LEN, FIST_PIVOT, HANDSUP_PIVOT,
  type GunArt, type GunKind, type HeadOrient, type HairId,
} from './hero_art.js';
const HEAD_SET_HAIR = (): HairId => HEAD_SET.hair;

/**
 * SCALE RE-AUTHORING (v9, P5): 36 / 40 px/m part sets are GENERATED FROM RULES, not nearest-
 * upscaled: every band, taper, ridge, groove and frame is re-placed at the target scale, and the
 * extra pixels are SPENT ON DETAIL (knee-pad H + shin groove + boot strap at 36; visor frame cols,
 * 3rd belly rib, 2px lock frame, forearm groove at 40). Same sets / layering / poses as 30 px/m.
 *
 * The generator writes char-grids through the same palette contract as hero_art.ts, so
 * assertNoInteriorHoles and the bake pipeline apply unchanged.
 */

export interface ScaleMeta {
  k: number;
  thighLen: number; shinLen: number; uparmLen: number; forearmLen: number;
  uparmSLen: number; forearmSLen: number;
  thighP: [number, number]; thighD: [number, number];
  shinP: [number, number]; shinD: [number, number];
  bootP: [number, number];
  uparmP: [number, number]; uparmD: [number, number];
  forearmP: [number, number]; forearmD: [number, number];
  uparmSP: [number, number]; uparmSD: [number, number];
  forearmSP: [number, number]; forearmSD: [number, number];
  fistP: [number, number]; supP: [number, number];
  hipF: [number, number]; hipB: [number, number];
  shF: [number, number]; supIk: [number, number];
  torsoA: [number, number]; neckA: [number, number]; headA: [number, number]; helmA: [number, number] | null;
  wristD: number; wristUp: number; wristDown: number;
  footK: number;
}
export interface ScaleArts {
  meta: ScaleMeta;
  torso: string[];
  neck: string[];
  heads: Record<HeadOrient, string[]>;
  helmet: Record<HeadOrient, string[]> | null;
  thigh: string[]; shin: string[]; boot: string[]; uparm: string[]; forearm: string[];
  uparmS: string[]; forearmS: string[];
  fist: string[]; suphand: string[];
  guns: Record<GunKind, GunArt>;
  pal?: Record<string, number>;
}

class Grid {
  g: string[][];
  constructor(readonly w: number, readonly h: number) {
    this.g = Array.from({ length: h }, () => new Array<string>(w).fill('.'));
  }
  set(x: number, y: number, c: string) { if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.g[y][x] = c; }
  span(y: number, x0: number, x1: number, c: string) { for (let x = x0; x <= x1; x++) this.set(x, y, c); }
  col(x: number, y0: number, y1: number, c: string) { for (let y = y0; y <= y1; y++) this.set(x, y, c); }
  rows(): string[] { return this.g.map((r) => r.join('')); }
}
const R = (v: number) => Math.round(v);

/** Run-length scale of a weapon row: each char run length n -> round(n*k); anchors re-mapped. */
function scaleRow(row: string, k: number): { out: string; map: (x: number) => number } {
  const runs: { c: string; n: number; x: number }[] = [];
  let x = 0;
  while (x < row.length) {
    let n = 1;
    while (x + n < row.length && row[x + n] === row[x]) n++;
    runs.push({ c: row[x], n, x });
    x += n;
  }
  let out = '';
  const bounds: [number, number, number][] = []; // srcX0, dstX0, dstLen
  for (const r of runs) {
    bounds.push([r.x, out.length, R(r.n * k)]);
    out += r.c.repeat(R(r.n * k));
  }
  const map = (sx: number) => {
    for (let i = bounds.length - 1; i >= 0; i--) {
      const [sx0, dx0, dn] = bounds[i];
      if (sx >= sx0) return dx0 + Math.min(dn - 1, R((sx - sx0) * k));
    }
    return 0;
  };
  return { out, map };
}
export function scaleGun(g: GunArt, k: number): GunArt {
  if (k === 1) return g;
  const rows: string[] = [];
  let mapX: (x: number) => number = (x) => x;
  for (const r of g.rows) {
    const s = scaleRow(r, k);
    rows.push(s.out);
    mapX = s.map;
  }
  const w = Math.max(...rows.map((r) => r.length));
  for (let i = 0; i < rows.length; i++) rows[i] = rows[i].padEnd(w, '.');
  const mx = (pt: [number, number]): [number, number] => [mapX(pt[0]), R(pt[1] * k)];
  return { rows, grip: mx(g.grip), handguard: g.handguard ? mx(g.handguard) : null, muzzle: mx(g.muzzle) };
}

// ---------------------------------------------------------------- bone generators
function genThigh(k: number): { art: string[]; len: number } {
  const L = R(10 * k) + 1;                     // rows incl. knee joint row
  const wTop = R(6 * k);
  const wBot = R(4 * k);
  const w = wTop + 2;
  const g = new Grid(w + 2, L + 1);
  const padRows = 3;
  for (let y = 0; y < L; y++) {
    const t = y / (L - 1);
    const cw = Math.max(wBot, Math.round(wTop + (wBot - wTop) * Math.min(1, t * 1.15))); // smooth taper
    const x0 = 1, x1 = x0 + cw - 1;
    g.span(y, x0 - 1 >= 0 ? x0 - 1 : 0, x0 - 1, '1');
    g.span(y, x1 + 1, x1 + 1, '1');
    const isGap = y === L - 1;
    for (let x = x0; x <= x1; x++) {
      let c = '3';
      if (x === x0) c = '2';
      if (x === x0 + 1) c = '2';
      if (x === x1) c = '7';                     // outer L column
      if (x === x1 - 1 && k >= 1.2) c = '7';      // wider L at scale
      if (x === x1) c = '6';            // rookie armor strip
      if (isGap) c = '5';
      g.set(x, y, c);
    }
  }
  return { art: g.rows(), len: L - 1 };
}
function genShin(k: number): { art: string[]; len: number } {
  const L = R(10 * k) + 2;
  const wTop = R(4 * k);
  const wBulge = wTop + 1;
  const w = wBulge + 2;
  const g = new Grid(w + 2, L + 1);
  for (let y = 0; y < L; y++) {
    const third = y < L * 0.45;
    const cw = y === 0 ? wTop : third ? wBulge : wTop;
    const x0 = 1, x1 = x0 + cw - 1;
    g.set(x0 - 1, y, '1'); g.set(x1 + 1, y, '1');
    for (let x = x0; x <= x1; x++) {
      let c = '3';
      if (x === x0) c = '2';
      const ridge = x === x1 - 1 || (k >= 1.2 && x === x1 - 2);
      if (ridge) c = '7';                          // continuous front ridge
      if (x === x1) c = '6';
      if (y === 0) c = '5';
      if (y >= L - 2) c = x === x0 ? '1' : '5';
      g.set(x, y, c);
    }
  }
  return { art: g.rows(), len: L - 2 };
}
function genBoot(k: number): string[] {
  const w = R((9) * k);
  const h = R(5 * k);
  const g = new Grid(w, h);
  const toe = Math.max(2, R(3 * k));
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let c = 'a';
      if (y === 0) c = x < 1 || x > w - 3 ? '.' : ('a');   // cuff collar
      if (y === 0 && (x === 1 || x === w - 2)) c = '1';
      if (x === 0 && y > 0 && y < h - 1) c = 'a';          // heel
      if (x === w - 1 && y > 0) c = '1';
      if (y === h - 1) c = '2';                                          // D sole
      if (y >= h - 3 && y < h - 1 && x >= w - 1 - toe) c = 'b'; // toe-cap / light
      if (y === 1 && x >= 2 && x <= 4) c = '7';                          // ridge
      if (y === 1 && x >= 2 && x <= 3) c = 'b';
      g.set(x, y, c);
    }
  }
  return g.rows();
}
function genUparm(k: number, L0?: number): { art: string[]; len: number } {
  const L = L0 ?? R(11 * k) + 3;
  const cw = R(4 * k);
  const w = cw + 2;
  const g = new Grid(w, L + 1);
  for (let y = 0; y < L; y++) {
    const x0 = 0, x1 = w - 1;
    if (y === 0) { g.span(0, 1, w - 2, '6'); g.set(0, 0, '.'); g.set(w - 1, 0, '.'); continue; }
    g.set(x0, y, '1'); g.set(x1, y, '1');
    for (let x = 1; x <= w - 2; x++) {
      let c = '3';
      if (x === 1) c = '2';
      if (x === w - 2) c = '7';
      if (y >= L - 3) c = '5';           // elbow gunmetal 2 rows + crease
      g.set(x, y, c);
    }
  }
  return { art: g.rows(), len: L - 3 };
}
function genForearm(k: number, L0?: number, wTop0?: number): { art: string[]; len: number } {
  const L = L0 ?? R(8 * k) + 1;
  const wTop = wTop0 ?? (R(4 * k));
  const wBot = R(5 * k);          // gauntlet flare
  const w = wBot + 2;
  const g = new Grid(w, L + 1);
  for (let y = 0; y < L; y++) {
    const t = y / (L - 1);
    const cw = Math.round(wTop + (wBot - wTop) * t);
    const x0 = 1, x1 = x0 + cw - 1;
    g.set(x0 - 1, y, '1'); g.set(x1 + 1, y, '1');
    for (let x = x0; x <= x1; x++) {
      let c = '6';
      if (x === x1) c = '7';                          // outer ridge
      if (y >= L - 3) c = 'a';          // cuff
      g.set(x, y, c);
    }
  }
  return { art: g.rows(), len: L - 1 };
}
function genFist(k: number): string[] {
  const w = R(8 * k), h = R(6 * k);
  const g = new Grid(w, h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let c = '.';
      const core0 = 2, core1 = 2 + R(4 * k) - 1;
      if (y === 0) c = x === 0 ? '5' : x === 1 ? '1' : x <= core1 + 1 ? (x >= core0 ? 'b' : 'a') : x === core1 + 2 ? 'a' : '.';
      if (y === 0 && x > core1 + 2) c = '.';
      if (y > 0 && y < h - 2) {
        c = x === 0 ? '5' : x === 1 ? '1' : x >= core0 && x <= core1 ? (y >= h - 3 ? '2' : x === core0 ? 'a' : 'b') : x === core1 + 1 ? '9' : x === core1 + 2 ? '1' : '.';
      }
      if (y === h - 2) c = x >= 1 && x <= core1 ? (x === 1 ? '1' : 'a') : '.';
      if (y === h - 1) c = x >= 1 && x <= core1 - 1 ? (x === 1 ? '1' : 'a') : '.';
      g.set(x, y, c);
    }
  }
  return g.rows();
}
function genSuphand(k: number): string[] {
  const w = R(7 * k), h = R(6 * k);
  const g = new Grid(w, h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      let c = '.';
      const c0 = 2, c1 = 2 + R(4 * k) - 2;
      if (y === 0) c = x >= c0 && x <= c1 ? 'b' : x === c0 - 1 || x === c1 + 1 ? '1' : '.';
      if (y === 1) c = x === 0 ? '1' : x >= 1 && x <= c1 + 1 ? (x === c1 + 1 ? '1' : x < c0 ? 'a' : 'b') : '.';
      if (y >= 2 && y <= h - 3) c = x === 0 ? '5' : x === 1 ? '1' : x >= 2 && x <= c1 ? (y === h - 3 ? '2' : 'b') : x === c1 + 1 ? '1' : '.';
      if (y === h - 2) c = x >= 1 && x <= c1 ? (x === 1 ? '1' : 'a') : '.';
      g.set(x, y, c);
    }
  return g.rows();
}

// ---------------------------------------------------------------- torso / head generators
function genTorso(k: number): { art: string[]; anchor: [number, number] } {
  const W = R((25) * k), H = R(22 * k);
  const g = new Grid(W, H);
  const cx = (W / 2) | 0;
  const bw = (f: number) => R(f * W);                       // band widths as fractions
  // pauldron span / chest / belly / hips bands (fractions of H)
  const yTrap0 = 0, yTrap1 = R(0.09 * H);
  const yPaul0 = yTrap1 + 1, yPaul1 = R(0.32 * H);
  const yChest0 = yTrap1 + 1, yChest1 = R(0.5 * H);
  const yBelly0 = yChest1 + 1, yBelly1 = R(0.68 * H);
  const yWaist = yBelly1 + 1;
  const yHip0 = yWaist + 1, yHip1 = H - 3;
  const pOut = bw(0.24);                 // pauldron outer x
  const chOut = bw(0.34);
  for (let y = 0; y < H; y++) {
    // horizontal span for this row
    let x0: number, x1: number;
    if (y <= yTrap1) { x0 = cx - pOut + 2; x1 = cx + pOut - 2; }
    else if (y <= yPaul1) { const s = (y - yPaul0) / Math.max(1, yPaul1 - yPaul0); x0 = R(cx - pOut - s * (pOut * 0.15)); x1 = W - 1 - x0; }
    else if (y <= yChest1) { x0 = cx - chOut; x1 = cx + chOut; }
    else if (y <= yBelly1) { const s = (y - yBelly0) / Math.max(1, yBelly1 - yBelly0); x0 = cx - R(chOut * (0.78 - 0.1 * s)); x1 = W - 1 - x0; }
    else if (y === yWaist) { x0 = cx - bw(0.18); x1 = cx + bw(0.18); }
    else if (y <= yHip1) { const s = (y - yHip0) / Math.max(1, yHip1 - yHip0); x0 = cx - R(bw(0.22) * (1 - 0.25 * s)); x1 = W - 1 - x0; }
    else { x0 = cx - bw(0.16); x1 = cx + bw(0.16); if (y === H - 1) { x0 = cx - bw(0.12); x1 = cx - 1; g.span(y, x0, x1, '3'); x0 = cx + 2; x1 = cx + bw(0.12); g.span(y, x0, x1, '3'); continue; } }
    for (let x = x0; x <= x1; x++) {
      let c = '3';
      const edgeL = x === x0, edgeR = x === x1;
        if (edgeL || edgeR) c = '2';
        if (y === 0 || y === 1) c = x >= cx - 3 && x <= cx + 3 ? (y === 0 ? '6' : '6') : c;
        if (y === 0 && (x === cx - 4 || x === cx + 4)) c = '5';
        if (y >= 2 && y <= 4 && x <= x0 + 3) c = y === 2 ? '8' : '6';       // ONE pauldron (support side)
        if (y >= 5 && y <= 10 * k && x >= cx - bw(0.2) && x <= cx + bw(0.2)) c = y === 5 ? '7' : '6'; // chest panel
        if (y >= 7 && y <= 9 * k && (Math.abs(x - (cx - bw(0.12))) < 1.5 || Math.abs(x - (cx + bw(0.12))) < 1.5)) c = '8'; // pouches
        if (y === 6 && x === cx + 1) c = 'c';                               // cyan indicator
        if (y === R(0.77 * H) || y === R(0.77 * H) + 1) c = 'o';            // dark leather belt
        if (y === R(0.77 * H) + 1 && x === cx) c = '9';
        if (y >= 8 && y <= 10 && x >= cx + bw(0.24) && x <= cx + bw(0.3)) c = '3'; // jumpsuit graphite side
      g.set(x, y, c);
    }
  }
  return { art: g.rows(), anchor: [-cx, -R(45 * k)] };
}
function genHead(k: number, o: HeadOrient, hair: HairId): string[] {
  const sh = hair === 'F' ? 'C' : hair === 'D' ? 'B' : hair === 'C' ? 'C2' : 'A';
  const W = R(13 * k), H = R(10 * k);
  const g = new Grid(W, H);
  const faceY0 = o === 'profile' ? R(0.3 * H) : o === 'up' ? R(0.5 * H) : R(0.6 * H);
  const front = W - R(4 * k);
  for (let y = 0; y < H; y++) {
    let x0: number, x1: number;
    if (y === 0) { x0 = R(W * 0.23); x1 = R(W * 0.69); }
    else if (y === H - 1) { x0 = R(W * (o === 'profile' ? 0.15 : 0.15)); x1 = R(W * 0.77); }
    else { x0 = R(W * 0.08); x1 = R(W * 0.85); }
    for (let x = x0; x <= x1; x++) {
      const isFace = y >= faceY0 && (o === 'profile' ? x >= front - R(1 * k) : x >= R(W * 0.25) && x <= R(W * 0.75));
      let c = isFace ? 'h' : 'k';
      if (!isFace && y <= 2) c = x <= x0 + 1 || y === 0 ? 'j' : 'k';
      if (isFace) {
        if (o === 'profile') {
          if (y === faceY0) c = x === front ? 'h' : 'g';
          if (y === faceY0 + 1) c = x === front - 1 ? '1' : 'h';       // eye line
          if (y === faceY0 + 2) c = x === front ? 'i' : x <= x0 + 2 ? 'h' : 'h'; // nose light + ear zone
          if (y === faceY0 + 2 && x >= x0 + 1 && x <= x0 + 2) c = x === x0 + 1 ? 'h' : 'g'; // ear
          if (y === H - 2) c = x === x1 ? 'g' : 'h';
          if (y === H - 1) c = x <= x0 + 2 ? 'g' : x === x1 ? 'g' : 'h';
        } else {
          if (y === faceY0 + (o === 'up' ? 1 : 2)) c = (x === R(W * 0.35) || x === R(W * 0.6)) ? '1' : 'h'; // eyes
          if (y === H - 1) c = 'g';
          if (y === faceY0 - 1) c = 'h';
        }
      } else {
        // hair variant shaping
        if (sh === 'C' && y === 0 && x % 2 === 0) c = '.';           // spike teeth
        if (sh === 'B' && y >= H - 4 && x <= x0 + 1) c = y === H - 4 ? 'b' : 'j'; // tail
        if (sh === 'C2' && y === 0 && (x < R(W * 0.3) || x > R(W * 0.7))) c = '.'; // buzz trim
        if (sh === 'A' && y <= 2 && x <= x0 + 2) c = 'j';            // swept back mass
      }
      if (c !== '.') g.set(x, y, c);
    }
  }
  return g.rows();
}
function genNeck(k: number): string[] {
  const w = R(6 * k), h = R(6 * k);
  const g = new Grid(w, h);
  for (let y = 0; y < h; y++) g.span(y, 1, w - 2, y >= h - 2 ? 'g' : 'h');
  return g.rows();
}

// ---------------------------------------------------------------- assemble a scale set
export function buildScaleArts(pxm: number): ScaleArts {
  const k = pxm / 30;
  const thigh = genThigh(k);
  const shin = genShin(k);
  const uparm = genUparm(k);
  const forearm = genForearm(k);
  const uparmS = genUparm(k, R(13 * k) + 3);
  const forearmS = genForearm(k, R(13 * k) + 2, 5);
  const torso = genTorso(k);
  const guns = {} as Record<GunKind, GunArt>;
  for (const gk of Object.keys(GUNS) as GunKind[]) guns[gk] = scaleGun(GUNS[gk], k);
  const heads = {} as Record<HeadOrient, string[]>;
  for (const o of ['up', 'profile', 'down'] as HeadOrient[]) {
    heads[o] = genHead(k, o, HEAD_SET_HAIR());
  }
  const meta: ScaleMeta = {
    k,
    thighLen: thigh.len, shinLen: shin.len, uparmLen: uparm.len, forearmLen: forearm.len,
    uparmSLen: uparmS.len, forearmSLen: forearmS.len,
    thighP: THIGH_PIVOT, thighD: [THIGH_PIVOT[0], thigh.len], shinP: SHIN_PIVOT, shinD: [SHIN_PIVOT[0], shin.len], bootP: BOOT_PIVOT,
    uparmP: UPARM_PIVOT, uparmD: [UPARM_PIVOT[0], uparm.len], forearmP: FOREARM_PIVOT, forearmD: [FOREARM_PIVOT[0], forearm.len],
    uparmSP: UPARM_S_PIVOT, uparmSD: [UPARM_S_PIVOT[0], uparmS.len],
    forearmSP: FOREARM_S_PIVOT, forearmSD: [FOREARM_S_PIVOT[0], forearmS.len],
    fistP: FIST_PIVOT, supP: HANDSUP_PIVOT,
    hipF: [R(4 * k), -R(24 * k)], hipB: [-R(5 * k), -R(25 * k)],
    shF: [R(8 * k), -R(41 * k)], supIk: [-R(8 * k), -R(41 * k)],
    torsoA: torso.anchor, neckA: [-R(3 * k), -R(48 * k)],
    headA: [-R(6 * k), -R(57 * k)], helmA: null,
    wristD: R(8 * k), wristUp: R(7 * k), wristDown: R(11 * k),
    footK: k,
  };
  return {
    meta,
    torso: torso.art,
    neck: genNeck(k),
    heads,
    helmet: null,
    thigh: thigh.art, shin: shin.art, boot: genBoot(k),
    uparm: uparm.art, forearm: forearm.art, uparmS: uparmS.art, forearmS: forearmS.art,
    fist: genFist(k), suphand: genSuphand(k),
    guns,
    pal: undefined,
  };
}
