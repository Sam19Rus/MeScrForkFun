import { rgba } from '../core/buf.js';

/**
 * HERO ART v3 - mass/proportion pass + hand re-author (mercenary, authored pixel arrays).
 *
 * v3 changes over v2:
 *  - STOCKY VETERAN proportions (Coalition-style mass from Cortex Command as proportion reference
 *    only, no design copying): height 61 -> 56 px, torso 20 -> 25 px wide with a wedge silhouette
 *    (shoulders > hips), deeper chest, raised collar (head sits IN the collar), thicker bones
 *    (thigh core 6, shin 4, upper arm 5, forearm 5), massive boots with clear heel/toe/sole,
 *    head:body = 10:56 ~ 1:5.6, head +1 px wide, visible neck 2 px.
 *  - HEAD PALETTE: light skin is the base; the tan tone stays in the part-set as a future NPC
 *    skin variant (SKIN_VARIANTS registry, slot already wired).
 *  - HANDS RE-AUTHORED as separate parts in WEAPON space: firing fist 5x6 core with thumb over the
 *    grip and readable knuckles (drawn OVER the weapon at GRIP); support hand with fingers wrapping
 *    the handguard from above (different shape). Both rotate with the weapon frame index.
 *  - Bone sprites keep the v2 joint/crease language; lengths: thigh/shin 10, upper arm 11,
 *    forearm 8 (+hand), so the support hand physically reaches the handguard anchors.
 *
 * Body parts are literal string grids: 1 char = 1 pixel, '.' = transparent, chars index HERO_PAL.
 * Weapons/hands/torso are authored through row builders (explicit x-offsets, length-safe).
 * Bones are authored pointing DOWN (+y = distal joint); weapons & hands point RIGHT (+x = aim).
 */

/** Mercenary palette (cloth/armor/leather/metal ramp + emissives; v3: light skin base). */
export const HERO_PAL: Record<string, number> = {
  '1': rgba(0x12, 0x14, 0x1a), // ink (selective outline)
  '2': rgba(0x2e, 0x32, 0x26), // cloth shadow (olive)
  '3': rgba(0x4d, 0x53, 0x40), // cloth base  (olive)
  '4': rgba(0x6a, 0x70, 0x57), // cloth light (olive)
  '5': rgba(0x1a, 0x1d, 0x21), // armor shadow / gunmetal dark
  '6': rgba(0x2b, 0x30, 0x36), // armor base / gunmetal #2b3036
  '7': rgba(0x4a, 0x52, 0x5a), // gunmetal light #4a525a
  '8': rgba(0x7e, 0x86, 0x8c), // metal light (neutral grey)
  '9': rgba(0x9a, 0xa2, 0xa8), // gun light / muzzle face: light grey, not white
  a: rgba(0x6b, 0x4a, 0x2f),   // leather brown (muted)
  b: rgba(0x8a, 0x65, 0x40),   // leather light (muted)
  m: rgba(0xb0, 0x5a, 0x20),   // belt orange (used by non-default sets only)
  n: rgba(0xcf, 0x7a, 0x2e),   // belt orange light
  o: rgba(0x4a, 0x35, 0x24),   // dark leather (rookie belt)
  p: rgba(0x64, 0x49, 0x2f),   // dark leather light
  v: rgba(0xff, 0xd2, 0x7a),   // amber visor bright (emissive)
  c: rgba(0x6a, 0xc8, 0xe8),   // visor glow
  d: rgba(0xcd, 0xf0, 0xff),   // visor bright
  e: rgba(0xe8, 0xb2, 0x3c),   // emissive amber
  f: rgba(0xc4, 0xca, 0xcd),   // specular (light grey, not bright white)
  g: rgba(0x9a, 0x78, 0x60),   // skin shadow (LIGHT base)
  h: rgba(0xc8, 0xa2, 0x84),   // skin base  (LIGHT)
  i: rgba(0xe4, 0xc4, 0xa6),   // skin light (LIGHT)
  j: rgba(0x22, 0x1c, 0x18),   // hair shadow (short crop)
  k: rgba(0x3c, 0x30, 0x26),   // hair base
  l: rgba(0x58, 0x47, 0x38),   // hair light
};

/** Skin-tone variants for the head/neck part-set: light = base merc; tan = future NPC slot. */
export const SKIN_VARIANTS: Record<'light' | 'tan', Record<string, number>> = {
  light: { g: rgba(0x9a, 0x78, 0x60), h: rgba(0xc8, 0xa2, 0x84), i: rgba(0xe4, 0xc4, 0xa6) },
  tan: { g: rgba(0x6e, 0x4c, 0x36), h: rgba(0xa8, 0x7c, 0x58), i: rgba(0xc4, 0x9a, 0x72) },
};

/** Attachment points in body space (origin = feet center, y up is negative). v3 stocky stack. */
export const ANCHORS = {
  feet: [0, 0] as [number, number],
  hip_front: [4, -24] as [number, number],
  hip_back: [-5, -25] as [number, number],
  torso: [-12, -45] as [number, number],       // top-left of the 25x22 torso
  head: [-6, -57] as [number, number],         // top-left of the 13x10 head (v5: +1 up, not sunk)
  shoulder_front: [8, -41] as [number, number], // gun-arm (R) pivot = top of the FRONT zone
  shoulder_back: [-8, -41] as [number, number], // support-arm (L) pivot = top of the BACK zone
  neck: [-3, -48] as [number, number],          // top-left of the 6x6 neck column (static part)
};

/** Row builder: explicit [x, pixels] segments over a fixed width (length-safe by construction). */
export function row(w: number, ...segs: [number, string][]): string {
  const a = new Array<string>(w).fill('.');
  for (const [x, s] of segs) {
    if (x < 0 || x + s.length > w) throw new Error(`row segment out of bounds: x=${x} len=${s.length} w=${w}`);
    for (let i = 0; i < s.length; i++) a[x + i] = s[i];
  }
  return a.join('');
}
const rep = (n: number, ch: string) => ch.repeat(n);
const trow = (...segs: [number, string][]) => row(25, ...segs);

// ---------------------------------------------------------------- torso 25x21 (front view, v3 wedge)
// Raised collar (head sits in it) -> wide delts/pauldrons -> deep chest plate with reactor cell ->
// bandolier -> belt with pouches -> coat hem. Shoulders 24 px span vs hips 10: wedge silhouette.
export const ART_TORSO: string[] = [
  trow([9, '5'], [10, '6776'], [14, '5']),                                 // y0  collar top (behind neck)
  trow([8, '5'], [9, '677776'], [15, '5']),                                // y1  collar raised (wider than neck)
  trow([4, '677'], [8, '55'], [10, '6776'], [14, '55'], [18, '776']),       // y2  traps + collar base
  trow([2, '6777'], [6, '55'], [9, '567765'], [15, '55'], [19, '7776']),    // y3  delt tops + plate top
  trow([1, '67775'], [6, '55'], [8, '5677765'], [16, '5'], [18, '57776']),  // y4  pauldron caps
  trow([1, '56775'], [7, '5666665'], [14, 'aa'], [16, '56'], [19, '5776']), // y5  bandolier starts
  trow([2, '5675'], [7, '5666665'], [13, 'aa'], [15, '66'], [19, '576']),   // y6  deep chest
  trow([2, '565'], [6, '56cc665'], [13, 'aa'], [15, '666'], [19, '56']),    // y7  reactor cell
  trow([2, '565'], [6, '56cc65'], [12, 'aa'], [14, '6666'], [19, '56']),    // y8
  trow([2, '565'], [6, '5666aa5'], [13, '6666'], [18, '56']),               // y9  vents
  trow([2, '565'], [6, '566aa66'], [13, '6666'], [18, '56']),               // y10
  trow([2, '565'], [6, '56ba666'], [14, '666'], [18, '56']),                // y11 strap highlight
  trow([3, '56'], [6, '5ab66665'], [15, '66'], [18, '56']),                 // y12 plate bottom
  trow([4, '2'], [6, 'ab3333332'], [15, '3'], [17, '2']),                   // y13 belly (cloth)
  trow([4, '22'], [7, '3333333'], [14, '22']),                              // y14
  trow([5, '22222222222'], [16, '22']),                                     // y15 waist crease
  trow([4, 'mmmm'], [8, 'nnnn'], [12, 'mmmmmmmm'], [20, 'mm']),             // y16 BELT (only orange)
  trow([4, 'mmmm'], [8, 'n'], [9, '98'], [11, 'n'], [12, 'mmmm'], [16, 'mm'], [19, 'mm']), // y17 buckle
  trow([4, 'mmm11'], [9, '99'], [11, '11mmm'], [16, 'mm'], [19, 'mm']),     // y18
  trow([4, '1111'], [8, '1881'], [12, '1111'], [16, '111']),                // y19 pouch bottoms
  trow([5, '2333'], [10, '3332']),                                          // y20 hips / coat split
];

// ---------------------------------------------------------------- neck 5x5 (static, in the collar)
// Head overlaps the top row; the raised collar hides the bottom two. Visible span 2 px.
export const ART_NECK: string[] = [
  '.hhhh.', // y0  under-jaw (overlapped by head bottom row)
  '.hhhh.', // y1  visible - constant column
  '.hhhh.', // y2  visible - constant column
  '.gghh.', // y3  hidden by collar row 0
  '.gghh.', // y4  hidden by collar row 1
  '.1111.', // y5  hidden by collar row 2
];

// ---------------------------------------------------------------- head v3/v4 13x10 - NO helmet, light skin
// Face layer (smooth continuous profile: steps <= 1 px, no brow/chin teeth) composed with a hair
// layer; hair variant switches with ONE config line: HEAD_SET.hair = 'A' | 'B' | 'C'.
export type HeadOrient = 'up' | 'profile' | 'down';
export type HairId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
export interface HeadVariant {
  id: string;                                  // 'bare' now; 'helmet'... later (armor slot)
  hairs: Record<HairId, Record<HeadOrient, string[]>>;
}

/** Face layers: skin/eye/ear/jaw only; hair area is transparent. */
const FACE_PROFILE: string[] = [
  '.............',
  '.............',
  '.............',
  '.........h...', // y3  forehead (front edge x9)
  '........gh...', // y4  brow shade inside the line
  '.......h1h...', // y5  eye line (profile)
  '....hg.hhi...', // y6  ear (h/g) + nose light at the front column
  '....hh.hhh...', // y7  cheek / ear front
  '.......hhg...', // y8  jaw line + shade (same front column)
  '......ghhg...', // y9  chin / under-jaw (overlaps neck)
];
const FACE_UP: string[] = [
  '.............',
  '.............',
  '.............',
  '.............',
  '.............',
  '....hhhh.....', // y5  brow band
  '...h1hh1h....', // y6  eye line high
  '.ghhhhhhhg...', // y7  cheeks
  '..ghhhhhg....', // y8  jaw from below
  '....ggggg....', // y9  under-jaw (overlaps neck)
];
const FACE_DOWN: string[] = [
  '.............',
  '.............',
  '.............',
  '.............',
  '.............',
  '.............',
  '....hhhh.....', // y6  forehead band
  '...h11hh.....', // y7  eye line low
  '..ghhhhhhg...', // y8  cheeks / jaw top
  '....ggggg....', // y9  jaw hidden (overlaps neck)
];

/** Hair A - undercut, longer top swept back (DEFAULT). */
const HAIR_A_PROFILE: string[] = [
  '....jjjjj....', // y0  quiff volume forward-up
  '..jjkkkkkjj..',
  '.jjkkllkkkj..',
  '.jkkkllkkk...', // y3  short temples
  '.jjkkkkkk....',
  '.jjkkkkk.....',
  'jjkk..k......', // y6  nape + sideburn, ear clear
  'jjkk..k......',
  '.jjkkkk......',
  '..jjkk.......',
];
const HAIR_A_UP: string[] = [
  '...jjjjjjj...',
  '..jjkkkkkjj..',
  '.jkkllllkkj..',
  'jjkkllllkkjj.',
  'jkkkkkkkkkkj.',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_A_DOWN: string[] = [
  '...jjjjjjj...',
  '..jjkkkkkjj..',
  '.jkkllllkkj..',
  '.jkkkkkkkkj..',
  '.jkkkkkkkkj..',
  '.jkkkkkkkkj..',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
];
const HAIR_B_PROFILE: string[] = [
  '...jjjjjj....', // y0  slick-back flat top
  '.jjkkkkkkjj..',
  '.jkjkkkkkkj..', // y2  HARD PART line
  '.jkkkkkkkk...',
  '.jjkkkkkk....',
  '.jjkkkkk.....',
  'jjkk..k......',
  'jjkk..k......',
  '.jjkkkk......',
  '..jjkk.......',
];
const HAIR_B_UP: string[] = [
  '..jjjjjjjj...',
  '.jjkkkkkkjj..',
  '.jkjkkkkkkj..', // part line
  'jjkkkkkkkkjj.',
  'jkkkkkkkkkkj.',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_B_DOWN: string[] = [
  '..jjjjjjjj...',
  '.jjkkkkkkjj..',
  '.jkjkkkkkkj..',
  '.jkkkkkkkkj..',
  '.jkkkkkkkkj..',
  '.jkkkkkkkkj..',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
];
const HAIR_C_PROFILE: string[] = [
  '....jjjjj....', // y0  buzz cap thin
  '...jjjjjjj...',
  '..jjjjjjjjj..',
  '..jjkkkkkk...', // y3  buzz edge
  '..jjkkkkk....',
  '..jjkkkk.....',
  '.jjk..k......',
  '.jjk..j......', // y7  beard sideburn
  '.jjkkjjjj....', // y8  beard along the jaw
  '..jjjjjjj....', // y9  beard chin mass
];
const HAIR_C_UP: string[] = [
  '...jjjjjj....',
  '..jjjjjjjj...',
  '.jjjjjjjjjj..',
  'jjjjjjjjjjjj.',
  'jjjjjjjjjjjj.',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_C_DOWN: string[] = [
  '...jjjjjj....',
  '..jjjjjjjj...',
  '.jjjjjjjjjj..',
  '.jjjjjjjjjj..',
  '.jjjjjjjjjj..',
  '.jjjjjjjjjj..',
  'jjjj....jjjj.',
  'jjj.....jjjj.',
  '.jj......jj..',
  '..jjjjjjjj...',
];
const HAIR_E_PROFILE: string[] = [
  '...jjjjjj....',
  '..jjkkkkjj...',
  '.jjkkllkkjj..',
  '.jkklllkkkj..', // y3  side-swept fringe mass
  '.jkkllkkkkj..', // y4  fringe tip over the brow
  '.jkkkkkkkjj..', // y5  fringe edge
  'jjkk..kj.....', // y6  fringe strand + ear
  'jjkk..k......',
  '.jjkkkk......',
  '..jjkk.......',
];
const HAIR_E_UP: string[] = [
  '..jjjjjjjj...',
  '.jjkkkkkkjj..',
  '.jkkllllkkj..',
  'jjkkllllkjjj.', // sweep to the side
  'jkkkkllkkkkj.',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_E_DOWN: string[] = [
  '...jjjjjj....',
  '..jjkkkkjj...',
  '.jjkkllkkjj..',
  '.jkkllllkkj..',
  '.jkkllllkkj..',
  '.jkkkkllkkj..', // fringe tip low
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
];

// D = short tail with a tie pixel; F = ridge with shaved temples
const HAIR_D_PROFILE : string[] = [
  '...jjjjjj....',
  '..jjkkkkjj...',
  '.jjkkllkkjj..',
  '.jkkkllkkk...',
  '.jkkkkkkk....',
  'jjkkkkkk.....',
  'jbjkk.kk.....', // y6  tie (b) + tail start
  'jjkk..k......', // y7  tail hangs
  'jjjjkkk......', // y8  tail mass
  '.jjjjkk......', // y9  tail tip
];
const HAIR_D_UP : string[] = [
  '...jjjjjj....',
  '..jjkkkkjj...',
  '.jjkklllljj..',
  'jjkkllllkkjj.',
  'jkkkkkkkkkkj.',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_D_DOWN : string[] = [
  '...jjjjjj....',
  '..jjkkkkjj...',
  '.jjkkkkkkjj..',
  '.jkkllllkkj..',
  '.jkkkkkkkkj..',
  '.jkkkkkkkkj..',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
];
const HAIR_F_PROFILE : string[] = [
  '..j.j.jj.j...', // y0  spike teeth
  '.jjkkkkkkj...',
  'jjkkllkkkkj..',
  'jkkkllkkkk...',
  'jkkjjjjk.....', // y4  shaved temple patch
  'jjkjjjj......', // y5
  'jjkk.kk......', // y6  ear clear
  'jjkk..k......',
  '.jjkkkk......',
  '..jjkk.......',
];
const HAIR_F_UP : string[] = [
  '..j.j.jj.j...',
  '.jjkkkkkkjj..',
  '.jkkllllkkj..',
  'jjkkllllkkjj.',
  'jkkjjjjjjkkj.', // y4  shaved ring
  'jjkjjjjjjkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
  '.jj......jj..',
];
const HAIR_F_DOWN : string[] = [
  '..j.j.jj.j...',
  '.jjkkkkkkjj..',
  '.jkkkkkkkkj..',
  '.jkkllllkkj..',
  '.jkkjjjjkkj..', // y4  shaved ring
  '.jkkjjjjkkj..',
  'jjkk....kkjj.',
  'jjk.....kkjj.',
  'jj........jj.',
  '.jj......jj..',
];
/** Compose hair over face (hair pixels win). Deterministic, validated by bake(). */
function composeHead(face: string[], hair: string[]): string[] {
  return face.map((fr, y) => {
    const hr = hair[y];
    let out = '';
    for (let x = 0; x < fr.length; x++) out += hr[x] !== '.' ? hr[x] : fr[x];
    return out;
  });
}

function hairSet(prof: string[], up: string[], down: string[]): Record<HeadOrient, string[]> {
  return {
    up: composeHead(FACE_UP, up),
    profile: composeHead(FACE_PROFILE, prof),
    down: composeHead(FACE_DOWN, down),
  };
}
export const HEAD_BARE: HeadVariant = {
  id: 'bare',
  hairs: {
    A: hairSet(HAIR_A_PROFILE, HAIR_A_UP, HAIR_A_DOWN),
    B: hairSet(HAIR_B_PROFILE, HAIR_B_UP, HAIR_B_DOWN),
    C: hairSet(HAIR_C_PROFILE, HAIR_C_UP, HAIR_C_DOWN),
    D: hairSet(HAIR_D_PROFILE, HAIR_D_UP, HAIR_D_DOWN),
    E: hairSet(HAIR_E_PROFILE, HAIR_E_UP, HAIR_E_DOWN),
    F: hairSet(HAIR_F_PROFILE, HAIR_F_UP, HAIR_F_DOWN),
  },
};

/** Head part-set: base variant + armor slot (helmet later) + ONE-LINE hair switch. */
export const HEAD_SET: { base: HeadVariant; armorSlot: HeadVariant | null; hair: HairId } = {
  base: HEAD_BARE,
  armorSlot: null,
  hair: 'A',
};
/** Current head art for an orientation (follows HEAD_SET.hair). */
export const headArts = (o: HeadOrient): string[] => HEAD_SET.base.hairs[HEAD_SET.hair][o];

// ---------------------------------------------------------------- leg bones (authored pointing DOWN)
// thigh 10x11: hip pivot (5,0), knee at (5,10). Core 6 px: cloth + outer armor strip, knee cap.
export const ART_THIGH: string[] = [
  '..1666661.', // y0  hip cap (armor)
  '..13333661', // y1  thigh: cloth + front armor strip
  '..12333661', // y2
  '..12333661',
  '..12333661',
  '..12333661',
  '..12333661',
  '..12333661', // y7
  '..13366771', // y8  knee cap top
  '..15666771', // y9  knee cap + crease shade
  '..15556771', // y10 knee joint row (crease)
];
export const THIGH_PIVOT: [number, number] = [5, 0];
export const THIGH_KNEE: [number, number] = [5, 10];
export const THIGH_LEN = 10;

// shin 8x12: knee pivot (4,0), ankle at (4,10) + overlap row y11 (hides boot-cuff mismatch).
export const ART_SHIN: string[] = [
  '.155551.', // y0  knee crease cap
  '.123361.', // y1  shin: cloth back + armor strip front
  '.123361.',
  '.123361.',
  '.123361.',
  '.123361.',
  '.123361.',
  '.123361.', // y7
  '.1abba1.', // y8  boot cuff (leather)
  '.1aaaa1.', // y9
  '.155551.', // y10 ankle shadow into the boot
  '.155551.', // y11 overlap margin under the cuff
];
export const SHIN_PIVOT: [number, number] = [4, 0];
export const SHIN_ANKLE: [number, number] = [4, 10];
export const SHIN_LEN = 10;

// boot 9x5: ankle pivot (3,0); heel x0, toe x7-8, sole row y4. Massive, clear read.
export const ART_BOOT: string[] = [
  '.1aa1....', // y0  ankle cuff
  '.1abbaa1.', // y1  boot body + toe cap
  '1aabbbba1', // y2  heel + light plane
  '1aaaaaaa1', // y3
  '111111111', // y4  sole
];
export const BOOT_PIVOT: [number, number] = [3, 0];

// ---------------------------------------------------------------- arm bones (authored pointing DOWN)
// upper arm 7x14: shoulder pivot (3,1), elbow at (3,12). Core 5 px, bicep highlight row.
export const ART_UPARM: string[] = [
  '.16661.', // y0  shoulder cap
  '1333331', // y1  shoulder pivot row (cloth)
  '1233361', // y2  bicep: cloth + outer strip
  '1233361',
  '1433361', // y4  bicep highlight (reads as muscle)
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361', // y9
  '1233361', // y10
  '1266671', // y11 elbow cap top
  '1566671', // y12 elbow joint row (crease)
  '.15551.', // y13 crease shade
];
export const UPARM_PIVOT: [number, number] = [3, 1];
export const UPARM_ELBOW: [number, number] = [3, 12];
export const UPARM_LEN = 11;

// forearm 7x9: elbow pivot (3,0), wrist cuff end at (3,8). Core 5 px; the HAND is a separate part.
export const ART_FOREARM: string[] = [
  '.15551.', // y0  elbow crease cap
  '1666661', // y1  gauntlet (armor)
  '1677761', // y2  light plane
  '1566651', // y3
  '1666661', // y4
  '1566651', // y5
  '15aaa51', // y6  leather cuff
  '15aaa51', // y7
  '1555551', // y8  wrist shadow (hand part covers from here)
];
export const FOREARM_PIVOT: [number, number] = [3, 0];
export const FOREARM_WRIST: [number, number] = [3, 8];
export const FOREARM_LEN = 8;

// ---------------------------------------------------------------- support-arm bones (LONG: L shoulder wraps to the handguard)
// upper arm S 7x16: pivot (3,1), elbow at (3,14) -> len 13
export const ART_UPARM_S: string[] = [
  '.16661.',
  '1333331',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1233361',
  '1566671',
  '1566671', // y13 elbow joint row (gunmetal)
  '.15551.',
  '.15551.',
];
export const UPARM_S_PIVOT: [number, number] = [3, 1];
export const UPARM_S_LEN = 13;
// forearm S 7x15: pivot (3,0), wrist at (3,13) -> len 13
export const ART_FOREARM_S: string[] = [
  '.15551.',
  '1666661',
  '1677761',
  '1566651',
  '1666661',
  '1566651',
  '1566651',
  '1566651',
  '1566651',
  '1566651',
  '15aaa51',
  '15aaa51',
  '1555551',
  '1555551', // y13 wrist row
  '.1551..',
];
export const FOREARM_S_PIVOT: [number, number] = [3, 0];
export const FOREARM_S_LEN = 13;

// ---------------------------------------------------------------- hands (authored in WEAPON space, point RIGHT)
// Firing fist: 5x6 core, thumb OVER the grip (top side), knuckle row with specular dots,
// wrist stub on the stock side (covers the forearm cuff). Pivot = grip center (4,4).
export const ART_HAND_FIST: string[] = [
  '51abbba.', // y0  thumb/finger HORIZONTAL along the receiver toward muzzle (flat top)
  '51abb91.', // y1  knuckle light edge on the muzzle side
  '51abb91.', // y2
  '5122291.', // y3  dark finger row
  '.1aaa1..', // y4  fist bottom shadow
  '.1aa1...', // y5  wrist blend
];
export const FIST_PIVOT: [number, number] = [3, 3];

// Support hand: fingers wrap the handguard FROM ABOVE (arch over the top), palm beside it,
// wrist stub on the shoulder side. Pivot = handguard center (4,3).
export const ART_HAND_SUPPORT: string[] = [
  '.1bb1..', // y0  fingertips curl UP over the near side of the handguard
  '.1bbb1.', // y1  fingers wrapping up the near side
  '51bbb1.', // y2  handguard line: palm meets the tube (pivot row)
  '.1aaa1.', // y3  palm UNDER the handguard (under-hand grip)
  '.1aa1..', // y4  palm bottom / heel of the hand
  '..11...', // y5  wrist blend DOWN (elbow down)
];
export const HANDSUP_PIVOT: [number, number] = [3, 2];

// ---------------------------------------------------------------- weapons (authored pointing RIGHT)
export type GunKind = 'rifle' | 'smg' | 'pistol' | 'launcher' | 'blade';
export interface GunArt {
  rows: string[];
  grip: [number, number];          // firing-hand fist center lands here
  handguard: [number, number] | null; // support-hand center (null = one-handed: pistol)
  muzzle: [number, number];        // bullet origin / muzzle-flash anchor
}

const RW = 33; // rifle canvas width
/** Assault rifle 33x12: stock, railed receiver, ammo counter, grip, curved mag, vented handguard, brake. */
export const GUN_RIFLE: GunArt = {
  grip: [11, 7], handguard: [19, 4], muzzle: [32, 4],
  rows: [
    row(RW, [8, '8'], [26, '9']),                                   // y0 rear/front sights
    row(RW, [8, '8'], [26, '8']),                                   // y1
    row(RW, [7, '88'], [9, rep(10, '7')], [19, rep(9, '7')], [30, '99']), // y2 full-length rail + brake top
    row(RW, [1, '1'], [2, '67776'], [7, rep(12, '6')], [19, rep(9, '6')], [28, '88'], [30, '99'], [32, '5']), // y3 stock cheek + bodies
    row(RW, [0, '1'], [1, '566665'], [7, '6666'], [11, '555'], [14, '66'], [16, 'e'], [17, '88'], [19, '66'], [21, '5'], [22, '6'], [23, '5'], [24, '6'], [25, '5'], [26, '66'], [28, '88'], [30, '99'], [32, '1']), // y4 port, counter, vents
    row(RW, [0, '1'], [1, '566665'], [7, rep(12, '5')], [19, rep(9, '5')], [28, '88'], [30, '99'], [32, '1']), // y5 bottom shadows
    row(RW, [1, '565'], [7, '555'], [10, '5aa5'], [15, '56665']),  // y6 grip top + mag top
    row(RW, [7, '555'], [10, '1aa1'], [14, '8'], [15, '56565']),    // y7 trigger
    row(RW, [10, '1a51'], [14, '1'], [15, '55665']),                // y8 guard bottom
    row(RW, [10, '151'], [15, '56665']),                            // y9
    row(RW, [16, '55665']),                                         // y10 mag curve
    row(RW, [16, '11111']),                                         // y11 baseplate
  ],
};

const SW = 25; // smg canvas width
/** SMG 25x11: folded stock rod, compact receiver, long mag, shrouded barrel. */
export const GUN_SMG: GunArt = {
  grip: [10, 7], handguard: [16, 4], muzzle: [24, 4],
  rows: [
    row(SW, [1, rep(7, '5')]),                                      // y0 stock rod
    row(SW, [1, '5'], [7, '6'], [8, '8']),                          // y1 hinge + rear sight
    row(SW, [1, '5'], [7, rep(10, '7')], [20, '8']),                // y2 rail + front sight
    row(SW, [1, '5'], [7, rep(8, '6')], [15, 'e'], [16, rep(5, '6')], [21, '88'], [23, '99']), // y3
    row(SW, [1, '5'], [7, rep(9, '6')], [16, '65656'], [21, '88'], [23, '91']),                // y4 vents
    row(SW, [1, '5'], [7, rep(14, '5')], [21, '88'], [23, '91']),   // y5 bottom shadow
    row(SW, [1, '5'], [9, '1aa1'], [13, '5665']),                   // y6 grip + mag top
    row(SW, [9, '1aa1'], [13, '5665']),                             // y7
    row(SW, [9, '151'], [13, '5665']),                              // y8 grip bottom
    row(SW, [14, '5665']),                                          // y9 mag curve
    row(SW, [14, '1111']),                                          // y10 baseplate
  ],
};

const PW = 17; // pistol canvas width
/** Pistol 17x10: serrated slide, angled grip, trigger guard, hammer. One-handed (handguard = null). */
export const GUN_PISTOL: GunArt = {
  grip: [5, 7], handguard: null, muzzle: [15, 3],
  rows: [
    row(PW, [13, '9']),                                             // y0 front sight
    row(PW, [3, '8'], [13, '8']),                                   // y1 rear sight
    row(PW, [1, '8'], [2, rep(12, '7')], [14, '99']),               // y2 hammer + slide top
    row(PW, [2, '665566556666'], [14, '91']),                       // y3 serrations + port + muzzle face
    row(PW, [2, rep(12, '5')], [14, '9']),                          // y4 slide bottom
    row(PW, [4, '1aa1'], [9, '181']),                               // y5 grip top + guard/trigger
    row(PW, [4, '1aa1'], [9, '11']),                                // y6
    row(PW, [3, '1aa1']),                                           // y7 grip angle
    row(PW, [3, '1a51']),                                           // y8
    row(PW, [3, '151']),                                            // y9 butt
  ],
};

const LW = 31; // launcher canvas width
/** Rocket launcher 31x14: scope, hazard-striped tube, exhaust, funnel muzzle with glowing warhead. */
export const GUN_LAUNCHER: GunArt = {
  grip: [10, 10], handguard: [17, 5], muzzle: [29, 5],
  rows: [
    row(LW, [15, '666']),                                           // y0 scope top
    row(LW, [6, '8'], [14, '6666c']),                               // y1 rear sight + scope/lens
    row(LW, [4, rep(19, '7')], [23, rep(6, '6')]),                  // y2 tube top + funnel rim
    row(LW, [3, rep(20, '6')], [23, '66'], [25, '111'], [28, '6']), // y3
    row(LW, [0, '155'], [3, '66666'], [8, 'e'], [9, '666'], [12, 'e'], [13, rep(10, '6')], [23, '6'], [24, '111'], [27, 'e'], [28, '6']), // y4 hazard stripes
    row(LW, [0, '155'], [3, '66666'], [8, 'e'], [9, '666'], [12, 'e'], [13, rep(10, '6')], [23, '6'], [24, '11'], [26, 'e9'], [28, '6']),  // y5 warhead glows
    row(LW, [0, '155'], [3, rep(20, '6')], [23, '6'], [24, '11'], [26, 'e9'], [28, '6']), // y6
    row(LW, [0, '155'], [3, rep(20, '6')], [23, '6'], [24, rep(4, '1')], [28, '6']),      // y7
    row(LW, [1, '55'], [3, rep(20, '5')], [23, '66'], [25, '55'], [27, '66']),            // y8 bottom shadows
    row(LW, [9, '5aa5'], [24, rep(4, '6')]),                          // y9 grip top + funnel skirt
    row(LW, [9, '1aa1']),                                           // y10
    row(LW, [9, '1a51']),                                           // y11
    row(LW, [9, '151']),                                            // y12 grip bottom
    row(LW),                                                        // y13
  ],
};

const BW = 27; // blade canvas width
/** Combat machete 27x9: wrapped grip, guard, steel body with energy edge. Two-hand: support on the pommel. */
export const GUN_BLADE: GunArt = {
  grip: [9, 4], handguard: [5, 4], muzzle: [26, 4],
  rows: [
    row(BW),                                                        // y0
    row(BW),                                                        // y1
    row(BW, [12, '89'], [14, rep(11, '8')], [25, '9']),             // y2 guard top + spine
    row(BW, [4, '88'], [6, 'aa1a1a'], [12, '99'], [14, rep(12, '9')], [26, 'f']), // y3
    row(BW, [4, '88'], [6, '1a1a1a'], [12, '99'], [14, rep(12, '9')], [26, 'f']), // y4
    row(BW, [4, '55'], [6, rep(6, '5')], [12, '89'], [14, rep(10, 'c')]),          // y5 energy edge
    row(BW, [12, '88']),                                            // y6 guard bottom
    row(BW),                                                        // y7
    row(BW),                                                        // y8
  ],
};

export const GUNS: Record<GunKind, GunArt> = {
  rifle: GUN_RIFLE, smg: GUN_SMG, pistol: GUN_PISTOL, launcher: GUN_LAUNCHER, blade: GUN_BLADE,
};



// ---------------------------------------------------------------- equipment sets (v6)
// A set restyles the rig: torso art (+own anchor when wider), back pack (optional, reserved for
// the projections stage), helmet override (hides hair + neck), bone overlays and a palette
// override. Skeleton/IK/walk/anchors are shared. All torso/helmet rows tile contiguously -
// interior holes are banned by the bench assert (assertNoInteriorHoles).
export interface ArmorSet {
  id: string;
  name: string;
  torso: string[];
  torsoAnchor?: [number, number];        // top-left when the torso is wider than the base 25
  pack: string[] | null;                 // optional back pack (reserved for projections)
  packOff: [number, number];
  helmet: Record<HeadOrient, string[]> | null;  // headOverride: hides hair AND neck
  helmOff?: [number, number];
  thigh?: string[];
  shin?: string[];
  boot?: string[];
  uparm?: string[];
  forearm?: string[];
  uparmS?: string[];
  forearmS?: string[];
  pal?: Record<string, number>;
  arts40?: {
    torso: string[]; neck: string[];
    heads: Record<HeadOrient, string[]>;
    helmet: Record<HeadOrient, string[]> | null;
    thigh: string[]; shin: string[]; boot: string[];
    uparm: string[]; forearm: string[]; uparmS: string[]; forearmS: string[];
    fist: string[]; suphand: string[];
    pal?: Record<string, number>;
    meta: {
      k: number;
      thighLen: number; shinLen: number; uparmLen: number; forearmLen: number;
      uparmSLen: number; forearmSLen: number;
      thighP: [number, number]; thighD: [number, number];
      shinP: [number, number]; shinD: [number, number];
      bootP: [number, number];
      uparmP: [number, number]; uparmD: [number, number];
      forearmP: [number, number]; forearmD: [number, number];
      uparmSP: [number, number]; uparmSD: [number, number];
      forearmSP: [number, number]; forearmSD: [number, number];
      fistP: [number, number]; supP: [number, number];
      hipF: [number, number]; hipB: [number, number];
      shF: [number, number]; supIk: [number, number];
      torsoA: [number, number]; neckA: [number, number]; headA: [number, number]; helmA: [number, number] | null;
      wristD: number; wristUp: number; wristDown: number; footK: number;
    };
  };
}

// ---- ROOKIE MERC (default): light modular kit over a work jumpsuit. Modest, not bare.
// Chest rig: graphite panel, TWO mag pouches symmetric under the collar (the aim-side one reads
// on the front edge in profile), 1px shoulder straps, cyan indicator. ONE small pauldron on the
// support side. Narrow dark-leather belt, no orange. Knee-pads darker than cloth.
// 3/4 CHEST view: FRONT zone (x16-24) carries all chest gear, MID zone (x8-15) side wrap with a
// vertical seam shadow, BACK zone (x0-7) plain cloth one value darker (recedes into the back).
// Shoulder R (firing) sits on top of the FRONT zone, shoulder L (support) on top of the BACK zone.
const ROOKIE_TORSO: string[] = [
  trow([9, '5677765']),                                                        // y0  collar (mid zone top)
  trow([8, '567777765']),                                                      // y1
  trow([1, '5885'], [5, '55'], [7, '33'], [9, '2'], [10, '5665'], [14, '33'], [16, '2'], [17, '5665'], [21, '2222']), // y2  NEAR pauldron+strap L, plain R
  trow([1, '5885'], [5, '55'], [7, '33'], [9, '2'], [10, '5665'], [14, '33'], [16, '2'], [17, '5665'], [21, '2222']), // y3
  trow([1, '5665'], [5, '55'], [7, '33'], [9, '2'], [10, '3333'], [14, '33'], [16, '2'], [17, '5665'], [21, '2222']), // y4
  trow([0, '677777776223323332255665']), // y5  FRONT: chest panel top (+1 value)
  trow([0, '655555556223323332255665']), // y6  panel + cyan below
  trow([0, '6888c8886223323332255665']), // y7  TWO pouches + cyan indicator
  trow([0, '667666766223323332255665']), // y8
  trow([0, '665666566223323332255665']), // y9
  trow([0, '655555556223323332255665']), // y10 panel bottom
  trow([4, '33333333323332255665']), // y11 mid wrap olive
  trow([4, '3333333332333225565']), // y12
  trow([6, '33323333323322565']), // y13
  trow([6, '33323333323322565']), // y14
  trow([7, '332333332332265']), // y15 waist
  trow([7, '322222222322265']), // y16 crease
  trow([3, 'oo9'], [7, 'oooooooooooo55']), // y17 BELT + buckle FRONT
  trow([3, 'ooo'], [7, 'oooooooooppo55']), // y18
  trow([7, 'oooooooooooo55']), // y19 belt bottom + front pouch
  trow([9, '233333'], [16, '3332']), // y20 hips split (mid)
  trow([10, '233'], [16, '332']), // y21 hem
];
const ROOKIE_THIGH: string[] = [
  '..1666661.',
  '..13333661',
  '..12333661',
  '..12333661',
  '..12333661',
  '..12333661',
  '..12333661',
  '..12333661',
  '..13332221', // y8  knee-pad 1-2 px darker than cloth
  '..12222221',
  '..12222221',
];


const HEAVY_UPARM: string[] = [
  '.17771.', // y0  rounded shell + H top
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1344361', // y11 gunmetal elbow 1-2 rows
  '1344361',
  '.13331.',
];
const HEAVY_THIGH: string[] = [
  '.166666771.', // y0  7-wide top, hides under the hip plate
  '.166666771.', // y1  convex outer L column
  '.166666771.',
  '..16666771.', // y3  smooth taper 7 -> 6
  '..16666771.',
  '..16666771.',
  '..15666771.', // y6  inner S shadow
  '..15666771.',
  '..18777771.', // y8  GREEN knee pad: H top edge, 1 px wider than shin
  '..16777771.',
  '..12222221.', // y10 D gap row UNDER the pad (knee pivot row)
];
const HEAVY_SHIN: string[] = [
  '.1222221.', // y0  joint shade under the D gap
  '.1667761.', // y1  5 core + continuous front L ridge
  '.16667761', // y2  calf bulge 6 (upper third)
  '.16667761',
  '.16667761',
  '..1667761', // y5  taper to 5
  '..1667761',
  '..1667761',
  '..1667761',
  '..1667761',
  '..1344361', // y10 gunmetal ankle joint
  '..1555561',
];
const HEAVY_BOOT: string[] = [
  '.1661.....', // y0  cuff collar
  '.16677661.', // y1  body + ridge
  '1667776641', // y2  heel back, gray toe-cap starts
  '1666664441', // y3  toe-cap 3 px gray
  '2222222222', // y4  D sole 1 px
];
const HEAVY_FOREARM: string[] = [
  '.15551..',
  '166761..', // y1  4 at the elbow
  '166761..',
  '1666761.', // y3  5
  '1666761.',
  '16666761', // y5  gauntlet flare 6 + outer ridge
  '16666761',
  '13444361', // y7  gunmetal cuff
  '13333331',
];

// HEAVY support-arm bones: green shell, gunmetal (3/4) elbow and cuff, same long geometry
const HEAVY_UPARM_S: string[] = [
  '.16661.',
  '1666661',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1666761',
  '1344361', // elbow gunmetal
  '.13331.',
  '.13331.',
];
const HEAVY_FOREARM_S: string[] = [
  '.15551.',
  '1666661',
  '1667761',
  '1667761',
  '1667761',
  '1667761',
  '1667761',
  '1667761',
  '1667761',
  '1667761',
  '1344341', // cuff gunmetal
  '1344341',
  '1333331',
  '1333331',
  '.13331.',
];

export const ARMOR_SETS: ArmorSet[] = [
  {
    id: 'rookie', name: 'ROOKIE MERC',
    torso: ROOKIE_TORSO, pack: null, packOff: [0, 0],
    helmet: null, thigh: ROOKIE_THIGH,
  },
];
export const armorSetById = (id: string): ArmorSet => ARMOR_SETS.find((s) => s.id === id) ?? ARMOR_SETS[0];
