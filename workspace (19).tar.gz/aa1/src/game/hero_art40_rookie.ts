/** ROOKIE @40 px/m hand-stitched parts (v16/P3): seam columns/rows hand-placed at plate
 *  boundaries (never through pouches/cyan/buckle/face features), then hand-checked.
 *  NOT a nearest-upscale: seams chosen per part, details re-placed. */
import type { HeadOrient, HairId } from './hero_art.js';

export const ROOKIE40_TORSO: string[] = [
  '.........5..756577.76.5..........',
  '.........6.5767677.77.65.........',
  '.58885555233625366653232256652222',
  '.58885555233625366653232256652222',
  '.58885555233625366653232256652222',
  '.56665555233323333633232256652222',
  '677777777276322333223633.2255665.',
  '677777777276322333223633.2255665.',
  '655555555256322333223633.2255665.',
  '68888c888286322333223633.2255665.',
  '667666767266322333223633.2255665.',
  '667666767266322333223633.2255665.',
  '665666565266322333223633.2255665.',
  '655555555256322333223633.2255665.',
  '.....3333333333333223633.2255665.',
  '.....3333333333333223633.2255665.',
  '.....3333333333333223633.225565..',
  '......3.3233323233233623.322565..',
  '......3.3233323233233623.322565..',
  '......3.3233323233233623.322565..',
  '.........233323233233523.32265...',
  '.........232222222222523.22265...',
  '...ooo.9.oooooooooooo.oo.oo55....',
  '...ooo.9.oooooooooooo.oo.oo55....',
  '...ooo.o.oooooooooooo.op.po55....',
  '.........oooooooooooo.oo.oo55....',
  '.........2..323.33333..3.332.....',
  '.........2..323.33333..3.332.....',
  '............3.2.332....3.32......'
];
export const ROOKIE40_NECK: string[] = [
  '.hhhhhh.',
  '.hhhhhh.',
  '.hhhhhh.',
  '.hhhhhh.',
  '.ggghhh.',
  '.ggghhh.',
  '.ggghhh.',
  '.111111.'
];
export const ROOKIE40_FACE_PROFILE: string[] = [
  '.................',
  '.................',
  '.................',
  '.............h...',
  '.............h...',
  '........g...gh...',
  '........1.h.1h...',
  '.....ghgh.h.hi...',
  '.....ghgh.h.hi...',
  '.....hhhh.h.hh...',
  '........h.h.hg...',
  '........hgh.hg...',
  '........hgh.hg...'
];
export const ROOKIE40_FACE_UP: string[] = [
  '.................',
  '.................',
  '.................',
  '.................',
  '.................',
  '.................',
  '.....hhh.hh......',
  '....hh1hhh1.h....',
  '....hh1hhh1.h....',
  '.ghhhhhhhhh.hg...',
  '..gghhhhghh.g....',
  '.....gggggg.g....',
  '.....gggggg.g....'
];
export const ROOKIE40_FACE_DOWN: string[] = [
  '.................',
  '.................',
  '.................',
  '.................',
  '.................',
  '.................',
  '.................',
  '.....hhh.hh......',
  '.....hhh.hh......',
  '....h111.hh......',
  '..gghhhhhhh.hg...',
  '.....gggggg.g....',
  '.....gggggg.g....'
];
export const ROOKIE40_HAIR_A_PROFILE: string[] = [
  '.....jjjjjj.j....',
  '..jjjkkkkkk.kjj..',
  '.jjjklklklk.kkj..',
  '.jkkklklklk.kk...',
  '.jkkklklklk.kk...',
  '.jjjkkkkkkk.k....',
  '.jjjkkkk.kk......',
  'jjkkk....k.......',
  'jjkkk....k.......',
  'jjkkk....k.......',
  '.jjjkkkk.k.......',
  '..jjjkkk.........',
  '..jjjkkk.........'
];
export const ROOKIE40_HAIR_A_UP: string[] = [
  '....jjjjjjj.jj...',
  '..jjjkkkkkk.kjj..',
  '.jkkklllkll.kkj..',
  'jjkkklllklljkkjj.',
  'jjkkklllklljkkjj.',
  'jkkkkkkkkkkjkkkj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_A_DOWN: string[] = [
  '....jjjjjjj.jj...',
  '..jjjkkkkkk.kjj..',
  '.jkkklllkll.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  'jjkkk...k..jkkjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_B_PROFILE: string[] = [
  '....jjjjjjj.j....',
  '.jjjkkkkkkk.kjj..',
  '.jkkjkkkkkk.kkj..',
  '.jkkkkkkkkk.kk...',
  '.jkkkkkkkkk.kk...',
  '.jjjkkkkkkk.k....',
  '.jjjkkkk.kk......',
  'jjkkk....k.......',
  'jjkkk....k.......',
  'jjkkk....k.......',
  '.jjjkkkk.k.......',
  '..jjjkkk.........',
  '..jjjkkk.........'
];
export const ROOKIE40_HAIR_B_UP: string[] = [
  '..jjjjjjjjj.jj...',
  '.jjjkkkkkkk.kjj..',
  '.jkkjkkkkkk.kkj..',
  'jjkkkkkkkkkjkkjj.',
  'jjkkkkkkkkkjkkjj.',
  'jkkkkkkkkkkjkkkj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_B_DOWN: string[] = [
  '..jjjjjjjjj.jj...',
  '.jjjkkkkkkk.kjj..',
  '.jkkjkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  'jjkkk...k..jkkjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_C_PROFILE: string[] = [
  '.....jjjjjj.j....',
  '....jjjjjjj.jj...',
  '..jjjjjjjjj.jjj..',
  '..jjjkkkkkk.kk...',
  '..jjjkkkkkk.kk...',
  '..jjjkkkkkk.k....',
  '..jjjkkk.kk......',
  '.jjjk....k.......',
  '.jjjk....k.......',
  '.jjjk....j.......',
  '.jjjkjkjjjj.j....',
  '..jjjjjjjjj.j....',
  '..jjjjjjjjj.j....'
];
export const ROOKIE40_HAIR_C_UP: string[] = [
  '....jjjjjjj.j....',
  '..jjjjjjjjj.jj...',
  '.jjjjjjjjjj.jjj..',
  'jjjjjjjjjjjjjjjj.',
  'jjjjjjjjjjjjjjjj.',
  'jjjjjjjjjjjjjjjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_C_DOWN: string[] = [
  '....jjjjjjj.j....',
  '..jjjjjjjjj.jj...',
  '.jjjjjjjjjj.jjj..',
  '.jjjjjjjjjj.jjj..',
  '.jjjjjjjjjj.jjj..',
  '.jjjjjjjjjj.jjj..',
  '.jjjjjjjjjj.jjj..',
  'jjjjj...j..jjjjj.',
  'jjjjj...j..jjjjj.',
  'jjjj....j..jjjjj.',
  '.jjj.........jj..',
  '..jjjjjjjjj.jj...',
  '..jjjjjjjjj.jj...'
];
export const ROOKIE40_HAIR_D_PROFILE: string[] = [
  '....jjjjjjj.j....',
  '..jjjkkkjkk.jj...',
  '.jjjklklklk.kjj..',
  '.jkkklklklk.kk...',
  '.jkkklklklk.kk...',
  '.jkkkkkkkkk.k....',
  'jjkkkkkk.kk......',
  'jbjjk.k..kk......',
  'jbjjk.k..kk......',
  'jjkkk....k.......',
  'jjjjjkkk.k.......',
  '.jjjjkjk.k.......',
  '.jjjjkjk.k.......'
];
export const ROOKIE40_HAIR_D_UP: string[] = [
  '....jjjjjjj.j....',
  '..jjjkkkjkk.jj...',
  '.jjjklkllll.ljj..',
  'jjkkklllklljkkjj.',
  'jjkkklllklljkkjj.',
  'jkkkkkkkkkkjkkkj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_D_DOWN: string[] = [
  '....jjjjjjj.j....',
  '..jjjkkkjkk.jj...',
  '.jjjkkkkkkk.kjj..',
  '.jkkklllkll.kkj..',
  '.jkkklllkll.kkj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkkkkkkkk.kkj..',
  'jjkkk...k..jkkjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_E_PROFILE: string[] = [
  '....jjjjjjj.j....',
  '..jjjkkkjkk.jj...',
  '.jjjklklklk.kjj..',
  '.jkkklllklk.kkj..',
  '.jkkklllklk.kkj..',
  '.jkkklllkkk.kkj..',
  '.jkkkkkkkkk.kjj..',
  'jjkkk....kj......',
  'jjkkk....kj......',
  'jjkkk....k.......',
  '.jjjkkkk.k.......',
  '..jjjkkk.........',
  '..jjjkkk.........'
];
export const ROOKIE40_HAIR_E_UP: string[] = [
  '..jjjjjjjjj.jj...',
  '.jjjkkkkkkk.kjj..',
  '.jkkklllkll.kkj..',
  'jjkkklllklljkjjj.',
  'jjkkklllklljkjjj.',
  'jkkkklklklkjkkkj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_E_DOWN: string[] = [
  '....jjjjjjj.j....',
  '..jjjkkkjkk.jj...',
  '.jjjklklklk.kjj..',
  '.jkkklllkll.kkj..',
  '.jkkklllkll.kkj..',
  '.jkkklllkll.kkj..',
  '.jkkkkkkkll.kkj..',
  'jjkkk...k..jkkjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_F_PROFILE: string[] = [
  '..jj..j..jj..j...',
  '.jjjkkkkkkk.kj...',
  'jjkkklllkkk.kkj..',
  'jkkkklllkkk.kk...',
  'jkkkklllkkk.kk...',
  'jkkkjjjj.jk......',
  'jjkkjjjj.j.......',
  'jjkkkk.k.k.......',
  'jjkkkk.k.k.......',
  'jjkkk....k.......',
  '.jjjkkkk.k.......',
  '..jjjkkk.........',
  '..jjjkkk.........'
];
export const ROOKIE40_HAIR_F_UP: string[] = [
  '..jj..j..jj..j...',
  '.jjjkkkkkkk.kjj..',
  '.jkkklllkll.kkj..',
  'jjkkklllklljkkjj.',
  'jjkkklllklljkkjj.',
  'jkkkjjjjjjjjjkkj.',
  'jjkkjjjjjjjjjkjj.',
  'jjkk....k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_HAIR_F_DOWN: string[] = [
  '..jj..j..jj..j...',
  '.jjjkkkkkkk.kjj..',
  '.jkkkkkkkkk.kkj..',
  '.jkkklllkll.kkj..',
  '.jkkklllkll.kkj..',
  '.jkkkjjjkjj.kkj..',
  '.jkkkjjjkjj.kkj..',
  'jjkkk...k..jkkjj.',
  'jjkkk...k..jkkjj.',
  'jjkk....k..jkkjj.',
  'jj.........j..jj.',
  '.jjj.........jj..',
  '.jjj.........jj..'
];
export const ROOKIE40_THIGH: string[] = [
  '..1666661661.',
  '..13333363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..12233363661',
  '..13332322221',
  '..12222222221',
  '..12222222221',
  '..12222222221'
];
export const ROOKIE40_SHIN: string[] = [
  '.155551551.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.123361361.',
  '.1abba1ba1.',
  '.1abba1ba1.',
  '.1aaaa1aa1.',
  '.155551551.',
  '.155551551.',
  '.155551551.'
];
export const ROOKIE40_BOOT: string[] = [
  '.1aaa1......',
  '.1abbbaa.a1.',
  '1aabbbbb1ba1',
  '1aabbbbb1ba1',
  '1aaaaaaa1aa1',
  '1aaaaaaa1aa1',
  '111111111111'
];
export const ROOKIE40_UPARM: string[] = [
  '.1666161.',
  '133333331',
  '123336361',
  '123336361',
  '143336361',
  '143336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '126667671',
  '156667671',
  '156667671',
  '.1555151.'
];
export const ROOKIE40_FOREARM: string[] = [
  '.1555151.',
  '166666661',
  '167776761',
  '156665651',
  '156665651',
  '166666661',
  '156665651',
  '15aaa5a51',
  '15aaa5a51',
  '15aaa5a51',
  '155555551'
];
export const ROOKIE40_UPARMS: string[] = [
  '.1666161.',
  '133333331',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '123336361',
  '156667671',
  '156667671',
  '156667671',
  '.1555151.',
  '.1555151.'
];
export const ROOKIE40_FOREARMS: string[] = [
  '.1555151.',
  '166666661',
  '167776761',
  '156665651',
  '166666661',
  '166666661',
  '156665651',
  '156665651',
  '156665651',
  '156665651',
  '156665651',
  '156665651',
  '15aaa5a51',
  '15aaa5a51',
  '15aaa5a51',
  '155555551',
  '155555551',
  '.1555.1..'
];
export const ROOKIE40_FIST: string[] = [
  '51abbbabba.',
  '51abb91b91.',
  '51abb91b91.',
  '51abb91b91.',
  '5122291291.',
  '.1aaa1.a1..',
  '.1aaa1.a1..',
  '.1aaa..1...'
];
export const ROOKIE40_SUPHAND: string[] = [
  '.1bbb.1..',
  '.1bbb1b1.',
  '51bbb1b1.',
  '51bbb1b1.',
  '.1aaa1a1.',
  '.1aaa.1..',
  '.1aaa.1..',
  '..111....'
];

const FACE40: Record<HeadOrient, string[]> = {
  profile: ROOKIE40_FACE_PROFILE, up: ROOKIE40_FACE_UP, down: ROOKIE40_FACE_DOWN,
};
const HAIR40: Record<HairId, Record<HeadOrient, string[]>> = {
  A: { profile: ROOKIE40_HAIR_A_PROFILE, up: ROOKIE40_HAIR_A_UP, down: ROOKIE40_HAIR_A_DOWN },
  B: { profile: ROOKIE40_HAIR_B_PROFILE, up: ROOKIE40_HAIR_B_UP, down: ROOKIE40_HAIR_B_DOWN },
  C: { profile: ROOKIE40_HAIR_C_PROFILE, up: ROOKIE40_HAIR_C_UP, down: ROOKIE40_HAIR_C_DOWN },
  D: { profile: ROOKIE40_HAIR_D_PROFILE, up: ROOKIE40_HAIR_D_UP, down: ROOKIE40_HAIR_D_DOWN },
  E: { profile: ROOKIE40_HAIR_E_PROFILE, up: ROOKIE40_HAIR_E_UP, down: ROOKIE40_HAIR_E_DOWN },
  F: { profile: ROOKIE40_HAIR_F_PROFILE, up: ROOKIE40_HAIR_F_UP, down: ROOKIE40_HAIR_F_DOWN },
};
function compose40(h: HairId, o: HeadOrient): string[] {
  const f = FACE40[o], hr = HAIR40[h][o];
  return f.map((fr, y) => { let s = ''; for (let x = 0; x < fr.length; x++) s += hr[y][x] !== '.' ? hr[y][x] : fr[x]; return s; });
}
export const ROOKIE40_HEADS: Record<HairId, Record<HeadOrient, string[]>> = {
  A: { profile: compose40('A', 'profile'), up: compose40('A', 'up'), down: compose40('A', 'down') },
  B: { profile: compose40('B', 'profile'), up: compose40('B', 'up'), down: compose40('B', 'down') },
  C: { profile: compose40('C', 'profile'), up: compose40('C', 'up'), down: compose40('C', 'down') },
  D: { profile: compose40('D', 'profile'), up: compose40('D', 'up'), down: compose40('D', 'down') },
  E: { profile: compose40('E', 'profile'), up: compose40('E', 'up'), down: compose40('E', 'down') },
  F: { profile: compose40('F', 'profile'), up: compose40('F', 'up'), down: compose40('F', 'down') },
};
