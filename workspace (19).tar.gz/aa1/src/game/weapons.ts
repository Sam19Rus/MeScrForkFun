import { makeRng, pick, ri, rr, wpick, chance, type Rng } from '../core/rng.js';
import { RARITY, type Rarity } from '../core/palette.js';

/**
 * Procedural gear generator - Borderlands principle: every item is assembled from part-sets
 * (body / barrel / mag / grip / element core), parts drive stats and silhouette, rarity
 * multiplies the stat budget. Nothing is a flat random number: stats derive from parts.
 */

export type Element = 'none' | 'kinetic' | 'laser' | 'fire' | 'cryo' | 'shock';
export const ELEMENT_COLOR: Record<Element, number> = {
  none: 0xb9b6aa, kinetic: 0xd8d0b8, laser: 0x48c8f0, fire: 0xe8703c, cryo: 0x9adce8, shock: 0xe8d058,
} as unknown as Record<Element, number>;

export interface WeaponParts {
  body: string; barrel: string; mag: string; grip: string; core: string; sight: string;
}
export interface Weapon {
  id: number;
  kind: 'weapon';
  name: string;
  cls: 'rifle' | 'smg' | 'pistol' | 'launcher' | 'blade';
  element: Element;
  rarity: Rarity;
  dmg: number;          // per hit
  rpm: number;          // rounds per minute
  spread: number;       // radians
  projSpeed: number;    // m/s
  magSize: number;
  reload: number;       // s
  range: number;        // m
  parts: WeaponParts;
  score: number;        // comparable power score for the confiscation rule
  seed: number;
}
export interface Armor {
  id: number;
  kind: 'armor';
  name: string;
  rarity: Rarity;
  hpBonus: number;
  speedBonus: number;   // multiplicative, e.g. 0.06
  dmgBonus: number;     // multiplicative
  resist: Element;      // element this armor resists (50% dmg reduction)
  parts: { shell: string; plate: string; trim: string };
  score: number;
  seed: number;
}
export type Item = Weapon | Armor | { id: number; kind: 'medkit'; name: string; heal: number; rarity: Rarity; score: number; seed: number };

let NEXT_ID = 1;

const BODIES = ['KV', 'ARX', 'MUL', 'SKS', 'VND', 'GRD', 'OSS', 'TAL'];
const NICKS = ['Оса', 'Гром', 'Пыль', 'Игла', 'Рой', 'Кувалда', 'Шёпот', 'Факел', 'Зенит', 'Хмарь', 'Клык', 'Стриж'];
const BARRELS = ['std', 'long', 'vent', 'split'];
const MAGS = ['drum', 'stick', 'cell', 'belt'];
const GRIPS = ['ergo', 'crude', 'mil'];
const CORES = ['kinetic', 'laser', 'fire', 'cryo', 'shock'];
const SIGHTS = ['iron', 'dot', 'scope', 'none'];

const RARITY_MULT = [1, 1.18, 1.4, 1.7, 2.05, 2.5];

export function rollRarity(r: Rng, table: Record<Rarity, number>): Rarity {
  return wpick(r, RARITY, RARITY.map((k) => table[k]));
}
export const CONTAINER_TABLE: Record<Rarity, number> = {
  common: 44, uncommon: 27, rare: 17, epic: 9, legendary: 3, special: 0,
};
export const SHUTTLE_TABLE: Record<Rarity, number> = {
  common: 0, uncommon: 0, rare: 0, epic: 55, legendary: 33, special: 12,
};

export function genWeapon(seed: number, rarity: Rarity, forcedCls?: Weapon['cls']): Weapon {
  const r = makeRng(seed);
  const mult = RARITY_MULT[RARITY.indexOf(rarity)];
  const cls = forcedCls ?? wpick(r, ['rifle', 'smg', 'pistol', 'launcher', 'blade'] as const, [34, 26, 16, 8, 16]);
  const element: Element = cls === 'blade'
    ? (pick(r, ['none', 'kinetic', 'fire', 'cryo', 'shock'] as const))
    : (pick(r, CORES) as Element);
  const parts: WeaponParts = {
    body: pick(r, BODIES) + '-' + ri(r, 1, 9),
    barrel: cls === 'blade' ? 'edge' : pick(r, BARRELS),
    mag: cls === 'blade' ? 'none' : pick(r, MAGS),
    grip: pick(r, GRIPS),
    core: element,
    sight: cls === 'blade' ? 'none' : pick(r, SIGHTS),
  };
  // part-driven stat budget
  let dmg = rr(r, 6, 9), rpm = rr(r, 320, 420), spread = rr(r, 0.05, 0.09), magSize = ri(r, 20, 30);
  let projSpeed = 22, range = 14;
  if (cls === 'rifle') { dmg *= 1.25; rpm *= 0.85; range = 16; }
  if (cls === 'smg') { dmg *= 0.62; rpm *= 1.9; spread *= 1.7; range = 11; }
  if (cls === 'pistol') { dmg *= 0.9; rpm *= 0.7; range = 12; }
  if (cls === 'launcher') { dmg *= 3.4; rpm *= 0.22; spread *= 0.6; projSpeed = 12; range = 15; magSize = ri(r, 1, 3); }
  if (cls === 'blade') { dmg *= 2.2; rpm = 240; spread = 0; projSpeed = 0; range = 1.3; magSize = 0; }
  if (parts.barrel === 'long') { dmg *= 1.15; range *= 1.25; rpm *= 0.92; }
  if (parts.barrel === 'vent') { spread *= 0.7; }
  if (parts.barrel === 'split') { dmg *= 0.8; spread *= 1.6; }
  if (parts.mag === 'drum') { magSize = Math.round(magSize * 1.8); rpm *= 1.05; }
  if (parts.mag === 'cell') { magSize = Math.round(magSize * 0.7); dmg *= 1.12; }
  if (parts.grip === 'ergo') { spread *= 0.85; }
  if (parts.grip === 'crude') { spread *= 1.3; dmg *= 1.1; }
  if (parts.sight === 'scope') { range *= 1.3; rpm *= 0.9; }
  dmg *= mult; rpm *= 1 + (mult - 1) * 0.35; spread /= 1 + (mult - 1) * 0.5; magSize = Math.round(magSize * (1 + (mult - 1) * 0.3));
  const reload = rr(r, 1.4, 2.4) / (1 + (mult - 1) * 0.2);
  const dps = cls === 'blade' ? dmg * (rpm / 60) : dmg * (rpm / 60) * 0.72; // 0.72 = assumed hit rate
  const score = Math.round(dps * 10 + range * 2 + magSize * 0.4 + RARITY.indexOf(rarity) * 25);
  const nick = pick(r, NICKS);
  const name = `${parts.body} «${nick}»`;
  return {
    id: NEXT_ID++, kind: 'weapon', name, cls, element, rarity,
    dmg: Math.round(dmg * 10) / 10, rpm: Math.round(rpm), spread, projSpeed, magSize,
    reload: Math.round(reload * 100) / 100, range, parts, score, seed,
  };
}

const SHELLS = ['каркас', 'панцирь', 'экзо-жилет', 'пластинник'];
const PLATES = ['композит', 'сталь', 'керамика', 'хитин'];
const TRIMS = ['гильдейский', 'кустарный', 'войсковой', 'трофейный'];

export function genArmor(seed: number, rarity: Rarity): Armor {
  const r = makeRng(seed);
  const mult = RARITY_MULT[RARITY.indexOf(rarity)];
  const shell = pick(r, SHELLS), plate = pick(r, PLATES), trim = pick(r, TRIMS);
  let hp = rr(r, 10, 22), spd = rr(r, 0.0, 0.05), dmgB = rr(r, 0.0, 0.06);
  if (plate === 'сталь') hp *= 1.4;
  if (plate === 'композит') spd += 0.03;
  if (plate === 'хитин') dmgB += 0.05;
  hp *= mult; spd *= mult; dmgB *= mult;
  const resist = pick(r, ['fire', 'cryo', 'shock', 'kinetic', 'laser'] as const);
  const score = Math.round(hp * 2 + spd * 300 + dmgB * 300 + RARITY.indexOf(rarity) * 25);
  return {
    id: NEXT_ID++, kind: 'armor', name: `${shell} «${plate}», ${trim}`, rarity,
    hpBonus: Math.round(hp), speedBonus: Math.round(spd * 100) / 100,
    dmgBonus: Math.round(dmgB * 100) / 100, resist,
    parts: { shell, plate, trim }, score, seed,
  };
}

export function genMedkit(seed: number): Item {
  return { id: NEXT_ID++, kind: 'medkit', name: 'медпакет гильдии', heal: 35, rarity: 'common', score: 0, seed };
}

/** Loot roll for a source. Returns 1-2 items. */
export function rollLoot(seed: number, source: 'container' | 'shuttle'): Item[] {
  const r = makeRng(seed);
  const n = source === 'shuttle' ? (chance(r, 0.55) ? 2 : 1) : (chance(r, 0.3) ? 2 : 1);
  const out: Item[] = [];
  for (let i = 0; i < n; i++) {
    const rar = rollRarity(r, source === 'shuttle' ? SHUTTLE_TABLE : CONTAINER_TABLE);
    const t = r();
    if (t < 0.52) out.push(genWeapon(seed * 31 + i * 7 + 1, rar));
    else if (t < 0.82) out.push(genArmor(seed * 37 + i * 11 + 2, rar));
    else out.push(genMedkit(seed * 41 + i + 3));
  }
  return out;
}

/** The guild confiscation rule: worse-or-equal gear is converted to credits, not picked up. */
export function compareScore(item: Item, currentScore: number): boolean {
  return item.kind === 'medkit' ? true : item.score > currentScore;
}
