/** AA1 constants. Production base: 640x360 viewport, 30 px/m world scale. */
export const VIEW_W = 640;
export const VIEW_H = 360;
export const PXM = 40;                 // pixels per meter (PRODUCTION since v15; 30/36 = bench options)
export const ART_K = PXM / 30;         // authored-at-30 art scale factor (temp until v16 hand-authoring)
/** Zoom = world-window presets; frame downscales by nearest sampling (S7 pixel-merge validated). */
export const ZOOM_LEVELS = [
  { w: 640, h: 360 },   // 1.0  - close combat view
  { w: 800, h: 450 },   // 0.8  - default slasher view
  { w: 1024, h: 576 },  // 0.625- tactical view
  { w: 1280, h: 720 },  // 0.5  - exploration tier (v15)
] as const;
export const DEFAULT_ZOOM = 0;         // index into ZOOM_LEVELS (1:1 = default, crisp)
export const MAP_W = 2560;             // px  (= 64 m at 40 px/m)
export const MAP_H = 1440;             // px  (= 36 m at 40 px/m)
export const DT = 1 / 60;              // fixed timestep
export const PLAYER_SPEED = 3.4;       // m/s
export const PLAYER_HP = 100;
export const MELEE_CD = 0.45;          // s
export const MELEE_RANGE = 1.15;       // m
export const MELEE_DMG = 34;
export const KILL_CREDITS = 7;         // base credits per kill
export const DROP_EVERY = 50;          // guild shuttle milestones: 50, 100, 150...
export const CONTAINERS = 14;          // static loot containers on map
export const CAPSULES = 4;             // companion capsules
export const RESPAWN_INVULN = 2.5;     // s after restart

/** Enemy stat blocks (archetypes). Parts/cosmetics vary per instance via part-set rng. */
export const ENEMY_DEFS = {
  psycho:  { hp: 46,  speed: 2.6, dmg: 12, atkRange: 0.95, atkCd: 1.1, radius: 0.34, credits: 6,  kind: 'melee' },
  scav:    { hp: 34,  speed: 2.2, dmg: 7,  atkRange: 8.5,  atkCd: 1.6, radius: 0.32, credits: 9,  kind: 'ranged' },
  drone:   { hp: 18,  speed: 4.1, dmg: 8,  atkRange: 0.8,  atkCd: 0.9, radius: 0.24, credits: 5,  kind: 'dash' },
  brute:   { hp: 130, speed: 1.7, dmg: 20, atkRange: 1.15, atkCd: 1.5, radius: 0.46, credits: 22, kind: 'melee' },
} as const;
export type EnemyKind = keyof typeof ENEMY_DEFS;
