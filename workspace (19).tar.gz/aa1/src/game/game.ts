import { PixelBuf, rgba } from '../core/buf.js';
import { makeRng, ri, rr, pick, chance, type Rng } from '../core/rng.js';
import { P, RARITY_COLOR, RARITY_RU, CONFISCATE_PRICE } from '../core/palette.js';
import { Camera } from '../engine/camera.js';
import type { InputState } from '../engine/input.js';
import type { Sfx } from '../engine/audio.js';
import {
  VIEW_W, VIEW_H, PXM, ART_K, MAP_W, MAP_H, PLAYER_SPEED, PLAYER_HP, MELEE_CD, MELEE_RANGE, MELEE_DMG,
  DROP_EVERY, CONTAINERS, CAPSULES, ENEMY_DEFS, type EnemyKind,
} from './config.js';
import { drawHumanoid, drawDrone, rollGangRig, rollRigParts, dir8FromVec, DIR_VEC, GANGS, type RigParts, type Dir8 } from './rig.js';
import { drawHero, resetLean, type HeroGun } from './hero.js';
import { ARMOR_SETS, HEAD_SET, type HairId } from './hero_art.js';
import { fbm as fbmLocal } from '../core/noise.js';
import { rollLoot, compareScore, type Item, type Weapon, type Armor } from './weapons.js';
import { drawText, drawTextS, textWidth } from './font.js';

/** Everything gameplay: one deterministic core, driven by InputState ticks. No DOM. */

interface Enemy {
  kind: EnemyKind; rig: RigParts; x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number; atkT: number; windup: number; stagger: number; slow: number;
  flash: number; walk: number; deadT: number; strafe: number; seed: number;
}
interface Proj {
  x: number; y: number; px: number; py: number; vx: number; vy: number;
  dmg: number; from: 'player' | 'enemy' | 'ally'; element: string; life: number; color: number;
}
interface Fx { x: number; y: number; vx: number; vy: number; life: number; max: number; color: number; size: number; type: string; ang?: number }
interface Decal { x: number; y: number; r: number; color: number }
interface LootBox { x: number; y: number; open: boolean; seed: number; kind: 'container' | 'capsule' | 'crate'; items?: Item[] }
interface GroundItem { x: number; y: number; item: Item; t: number }
interface Shuttle { t: number; tx: number; ty: number; done: boolean }
interface Toast { text: string; color: number; t: number }
interface Companion {
  kind: 'gunner' | 'drone'; rig: RigParts; x: number; y: number; hp: number; maxHp: number;
  fireT: number; downT: number; walk: number; flash: number;
}
interface Boulder { x: number; y: number; r: number; seed: number }

const BASIC: Weapon = {
  id: 0, kind: 'weapon', name: 'БАЗОВАЯ ШТУРМОВАЯ', cls: 'rifle', element: 'kinetic', rarity: 'common',
  dmg: 8, rpm: 460, spread: 0.055, projSpeed: 24, magSize: 0, reload: 0, range: 16,
  parts: { body: 'GILD-1', barrel: 'std', mag: 'belt', grip: 'mil', core: 'kinetic', sight: 'iron' },
  score: 55, seed: 1,
};

export type GameState = 'menu' | 'play' | 'dead';

export class GameCore {
  private readonly PK = PXM / 30;
  state: GameState = 'menu';
  tick = 0;
  time = 0;
  paused = false;
  runSeed = 20260930;
  ground: PixelBuf | null = null;
  cam = new Camera();
  sfx: Sfx;
  // rng streams (reset per run)
  private rSpawn!: Rng; private rLoot!: Rng; private rFx!: Rng;
  // player
  px = MAP_W / 2; py = MAP_H / 2; pvx = 0; pvy = 0;
  php = PLAYER_HP; pmaxBase = PLAYER_HP;
  aim: Dir8 = 0; dir: Dir8 = 2; walk = 0; moving = false;
  /** Continuous screen-space aim angle (shoulder -> cursor); the sprite rig + shooting follow it. */
  aimAng = 0;
  fireT = 0; reloadT = 0; meleeT = 0; meleeSwing = 0; muzzle = 0; invuln = 0; pflash = 0;
  weapon2: Weapon | null = null; mag2 = 0; slot = 1; armor: Armor | null = null;
  credits = 0; kills = 0; drops = 0; confiscated = 0;
  armorSetIdx = 0; // visual-only equipment set (hotkey [B])
  aimT = 0;        // seconds since last aim/fire input (low-ready blend)
  lowReady = 0;    // 0 = aim pose, 1 = low-ready idle pose (blend ~150 ms)
  noEnemies = false; // debug hotkey [N]: enemies off
  private prevMX = -1; private prevMY = -1;
  // world
  enemies: Enemy[] = [];
  projs: Proj[] = [];
  fx: Fx[] = [];
  decals: Decal[] = [];
  boxes: LootBox[] = [];
  items: GroundItem[] = [];
  shuttles: Shuttle[] = [];
  companion: Companion | null = null;
  boulders: Boulder[] = [];
  toasts: Toast[] = [];
  nextDrop = DROP_EVERY;
  spawnT = 0;
  hurtVignette = 0;
  menuBg: PixelBuf | null = null;
  mouseX = VIEW_W / 2; mouseY = VIEW_H / 2;
  hoverPlay = false;

  constructor(sfx: Sfx) { this.sfx = sfx; }

  setGround(g: PixelBuf) { this.ground = g; }

  // ---------------------------------------------------------------- run control
  startRun(seed: number) {
    this.runSeed = seed;
    this.rSpawn = makeRng(seed ^ 0x51ab);
    this.rLoot = makeRng(seed ^ 0x77f1);
    this.rFx = makeRng(seed ^ 0x1234);
    this.px = MAP_W / 2; this.py = MAP_H / 2 + 40; this.pvx = 0; this.pvy = 0;
    this.php = PLAYER_HP; this.pmaxBase = PLAYER_HP;
    this.weapon2 = null; this.mag2 = 0; this.slot = 1; this.armor = null;
    this.credits = 0; this.kills = 0; this.drops = 0; this.confiscated = 0;
    this.enemies = []; this.projs = []; this.fx = []; this.decals = [];
    this.boxes = []; this.items = []; this.shuttles = []; this.companion = null;
    this.toasts = []; this.nextDrop = DROP_EVERY; this.spawnT = 0; this.hurtVignette = 0;
    this.armorSetIdx = 0; HEAD_SET.hair = 'A'; resetLean();
    this.invuln = 2.5; this.fireT = 0; this.reloadT = 0; this.meleeT = 0;
    // static world scatter (deterministic)
    const rw = makeRng(seed ^ 0xbeef);
    this.boulders = [];
    for (let i = 0; i < 12; i++) {
      const x = rr(rw, 60, MAP_W - 60), y = rr(rw, 60, MAP_H - 60);
      if (Math.hypot(x - this.px, y - this.py) < 150) continue;
      this.boulders.push({ x, y, r: rr(rw, 10, 20), seed: ri(rw, 1, 1 << 20) });
    }
    for (let i = 0; i < CONTAINERS; i++) {
      const x = rr(rw, 50, MAP_W - 50), y = rr(rw, 50, MAP_H - 50);
      this.boxes.push({ x, y, open: false, seed: ri(rw, 1, 1 << 20), kind: 'container' });
    }
    for (let i = 0; i < CAPSULES; i++) {
      const x = rr(rw, 70, MAP_W - 70), y = rr(rw, 70, MAP_H - 70);
      this.boxes.push({ x, y, open: false, seed: ri(rw, 1, 1 << 20), kind: 'capsule' });
    }
    for (let i = 0; i < 4; i++) this.spawnEnemy(true);
    this.cam.x = this.px; this.cam.y = this.py;
    this.cam.follow(this.px, this.py, 1, true);
    this.state = 'play';
    this.toast('КОНТРАКТ ГИЛЬДИИ АКТИВЕН: ЗАЧИСТКА ОКРАИНЫ', P.xp);
  }

  cycleSet() {
    this.armorSetIdx = (this.armorSetIdx + 1) % ARMOR_SETS.length;
    this.toast(`СЕТ: ${ARMOR_SETS[this.armorSetIdx].name}`, P.text);
  }
  cycleHair() {
    if (ARMOR_SETS[this.armorSetIdx].helmet) return;
    const order: HairId[] = ['A', 'B', 'C', 'D', 'E', 'F'];
    const i = order.indexOf(HEAD_SET.hair);
    HEAD_SET.hair = order[(i + 1) % order.length];
    const names: Record<HairId, string> = {
      A: 'QUIFF-UNDERCUT', B: 'SLICK-BACK', C: 'BUZZ+BEARD', D: 'TAIL', E: 'SIDE-SWEPT', F: 'RIDGE',
    };
    this.toast(`ПРИЧЁСКА: ${names[HEAD_SET.hair]}`, P.text);
  }
  toast(text: string, color: number) { this.toasts.push({ text, color, t: 3.2 }); if (this.toasts.length > 5) this.toasts.shift(); }

  get pmax(): number { return this.pmaxBase + (this.armor ? this.armor.hpBonus : 0); }
  get speedMul(): number { return 1 + (this.armor ? this.armor.speedBonus : 0); }
  get dmgMul(): number { return 1 + (this.armor ? this.armor.dmgBonus : 0); }
  get activeWeapon(): Weapon { return this.slot === 2 && this.weapon2 ? this.weapon2 : BASIC; }

  // ---------------------------------------------------------------- update
  update(dt: number, inp: InputState) {
    this.tick++;
    this.time += dt;
    const mouseMoved = Math.abs(inp.mouseX - this.prevMX) > 1 || Math.abs(inp.mouseY - this.prevMY) > 1;
    this.prevMX = inp.mouseX; this.prevMY = inp.mouseY;
    this.mouseX = inp.mouseX; this.mouseY = inp.mouseY;
    if (inp.mouseDown || mouseMoved) this.aimT = 0.8; else this.aimT = Math.max(0, this.aimT - dt);
    const lrTarget = this.moving || this.aimT > 0 ? 0 : 1;
    const lrStep = dt / 0.15;
    this.lowReady += Math.max(-lrStep, Math.min(lrStep, lrTarget - this.lowReady));
    if (this.state === 'menu') {
      this.hoverPlay = inp.mouseX > 260 && inp.mouseX < 380 && inp.mouseY > 208 && inp.mouseY < 232;
      if (inp.pressed.has('play') || inp.pressed.has('enter') || (this.hoverPlay && inp.pressed.has('lmb'))) {
        this.sfx.ui(); this.startRun(this.runSeed);
      }
      inp.pressed.clear();
      return;
    }
    if (this.paused) {
      if (inp.pressed.has('pause')) { this.paused = false; this.sfx.ui(); }
      inp.pressed.clear();
      return;
    }
    if (inp.pressed.has('pause')) { this.paused = true; this.sfx.ui(); inp.pressed.clear(); return; }
    if (this.state === 'dead') {
      if (inp.pressed.has('play') || inp.pressed.has('r')) { this.sfx.ui(); this.startRun(this.runSeed + this.kills + 1); }
      inp.pressed.clear();
      return;
    }
    if (inp.pressed.has('zoomin')) this.cam.cycleZoom(1);
    if (inp.pressed.has('zoomout')) this.cam.cycleZoom(-1);

    this.updatePlayer(dt, inp);
    this.updateCompanion(dt);
    this.updateEnemies(dt);
    this.updateProjs(dt);
    this.updateFx(dt);
    this.updateShuttles(dt);
    this.updateSpawns(dt);
    for (const t of this.toasts) t.t -= dt;
    this.toasts = this.toasts.filter((t) => t.t > 0);
    this.hurtVignette = Math.max(0, this.hurtVignette - dt * 2);
    this.cam.follow(this.px, this.py, dt);
    inp.pressed.clear();
  }

  private updatePlayer(dt: number, inp: InputState) {
    let ix = 0, iy = 0;
    if (inp.keys.has('w') || inp.keys.has('arrowup')) iy -= 1;
    if (inp.keys.has('s') || inp.keys.has('arrowdown')) iy += 1;
    if (inp.keys.has('a') || inp.keys.has('arrowleft')) ix -= 1;
    if (inp.keys.has('d') || inp.keys.has('arrowright')) ix += 1;
    const l = Math.hypot(ix, iy) || 1;
    const sp = PLAYER_SPEED * PXM * this.speedMul;
    const k = 1 - Math.exp(-14 * dt);
    this.pvx += ((ix / l) * sp - this.pvx) * k;
    this.pvy += ((iy / l) * sp - this.pvy) * k;
    this.moving = ix !== 0 || iy !== 0;
    if (this.moving) { this.dir = dir8FromVec(ix, iy); this.walk += dt * 11; }
    this.px += this.pvx * dt; this.py += this.pvy * dt;
    this.collideBoulders((o) => { this.px = o.x; this.py = o.y; });
    this.px = Math.max(12, Math.min(MAP_W - 12, this.px));
    this.py = Math.max(16, Math.min(MAP_H - 6, this.py));

    // aim from mouse (view -> world)
    const z = this.cam.zoom;
    const wx = this.cam.left + (this.mouseX * z.w) / VIEW_W;
    const wy = this.cam.top + (this.mouseY * z.h) / VIEW_H;
    this.aim = dir8FromVec(wx - this.px, wy - this.py);
    // continuous angle in window space: shoulder pivot -> cursor (spec: atan2(cursor - shoulder))
    const mwx = (this.mouseX * z.w) / VIEW_W, mwy = (this.mouseY * z.h) / VIEW_H;
    this.aimAng = Math.atan2(mwy - (this.cam.wy(this.py) - 55), mwx - this.cam.wx(this.px));  // shoulder at 40 px/m

    this.fireT = Math.max(0, this.fireT - dt);
    this.meleeT = Math.max(0, this.meleeT - dt);
    this.meleeSwing = Math.max(0, this.meleeSwing - dt);
    this.muzzle = Math.max(0, this.muzzle - dt);
    this.invuln = Math.max(0, this.invuln - dt);
    this.pflash = Math.max(0, this.pflash - dt);
    if (this.reloadT > 0) {
      this.reloadT -= dt;
      if (this.reloadT <= 0 && this.weapon2) { this.mag2 = this.weapon2.magSize; }
    }
    // weapon switch
    if (inp.pressed.has('1')) { this.slot = 1; this.sfx.ui(); }
    if (inp.pressed.has('2') && this.weapon2) { this.slot = 2; this.sfx.ui(); }
    if (inp.pressed.has('tab') && this.weapon2) { this.slot = this.slot === 1 ? 2 : 1; this.sfx.ui(); }
    if (inp.pressed.has('r') && this.weapon2 && this.slot === 2 && this.reloadT <= 0 && this.mag2 < this.weapon2.magSize) {
      this.reloadT = this.weapon2.reload;
    }
    // fire
    if (inp.mouseDown && this.fireT <= 0 && this.reloadT <= 0 && this.meleeSwing <= 0) {
      const w = this.activeWeapon;
      if (this.slot === 2 && this.weapon2) {
        if (this.mag2 <= 0) { this.reloadT = this.weapon2.reload; }
        else { this.shoot(w); this.mag2--; }
      } else this.shoot(w);
    }
    // melee
    if ((inp.rmbDown || inp.pressed.has('q')) && this.meleeT <= 0) this.doMelee();
    // interact
    if (inp.pressed.has('e')) this.interact();
    // visual-only customization hotkeys (bot never presses these; qa unaffected)
    if (inp.pressed.has('b')) { this.cycleSet(); this.sfx.ui(); }
    if (inp.pressed.has('n')) {
      this.noEnemies = !this.noEnemies;
      if (this.noEnemies) this.enemies = [];
      this.toast(this.noEnemies ? 'ВРАГИ ОТКЛЮЧЕНЫ (DEBUG)' : 'ВРАГИ ВКЛЮЧЕНЫ', P.textDim);
      this.sfx.ui();
    }
    if (inp.pressed.has('h')) { this.cycleHair(); this.sfx.ui(); }
    // pickups
    this.tryPickups();
  }

  private shoot(w: Weapon) {
    this.fireT = 60 / w.rpm;
    const ax = Math.cos(this.aimAng), ay = Math.sin(this.aimAng);
    const spread = (this.rFx() - 0.5) * 2 * w.spread + (this.moving ? 0.02 : 0);
    const a = this.aimAng + spread;
    const mx = this.px + ax * 34, my = this.py - 41 + ay * 34;
    this.projs.push({
      x: mx, y: my, px: mx, py: my,
      vx: Math.cos(a) * w.projSpeed * PXM, vy: Math.sin(a) * w.projSpeed * PXM,
      dmg: w.dmg * this.dmgMul, from: 'player', element: w.element, life: w.range / w.projSpeed,
      color: w.element === 'laser' ? rgba(0x48, 0xc8, 0xf0) : w.element === 'fire' ? rgba(0xe8, 0x70, 0x3c)
        : w.element === 'cryo' ? rgba(0x9a, 0xdc, 0xe8) : w.element === 'shock' ? rgba(0xe8, 0xd0, 0x58) : rgba(0xff, 0xd8, 0x8a),
    });
    this.muzzle = 0.06;
    this.cam.shake = Math.min(6, this.cam.shake + (w.cls === 'launcher' ? 5 : 1.4));
    this.sfx.shoot();
  }

  private doMelee() {
    this.meleeT = MELEE_CD; this.meleeSwing = 0.16;
    this.sfx.melee();
    const reach = MELEE_RANGE * PXM;
    const ax = Math.cos(this.aimAng), ay = Math.sin(this.aimAng);
    this.fx.push({ x: this.px, y: this.py - 45, vx: 0, vy: 0, life: 0.16, max: 0.16, color: rgba(0xff, 0xf2, 0xd0), size: reach, type: 'slash', ang: this.aimAng });
    for (const e of this.enemies) {
      if (e.deadT > 0) continue;
      const dx = e.x - this.px, dy = e.y - this.py;
      const d = Math.hypot(dx, dy);
      if (d > reach + 8) continue;
      const dot = (dx / (d || 1)) * ax + (dy / (d || 1)) * ay;
      if (dot < 0.35) continue;
      const fin = e.stagger > 0;
      this.damageEnemy(e, MELEE_DMG * this.dmgMul * (fin ? 2.5 : 1), dx / (d || 1), dy / (d || 1), 5.5);
      e.stagger = Math.max(e.stagger, 0.7);
      if (fin) this.toast('ФИНИШ: ДОБИВАНИЕ x2.5', P.spark);
    }
  }

  private interact() {
    let best: LootBox | null = null; let bd = 1.35 * PXM;
    for (const b of this.boxes) {
      if (b.open) continue;
      const d = Math.hypot(b.x - this.px, b.y - this.py);
      if (d < bd) { bd = d; best = b; }
    }
    if (!best) return;
    best.open = true;
    const seed = best.seed;
    if (best.kind === 'capsule') {
      this.sfx.capsule();
      const r = makeRng(seed);
      const kind: 'gunner' | 'drone' = chance(r, 0.5) ? 'gunner' : 'drone';
      if (this.companion && this.companion.downT <= 0) {
        this.toast('КАПСУЛА: КОМПАНЬОН УЖЕ С ВАМИ (ОБМЕН НА КРЕДИТЫ +60)', P.credit);
        this.credits += 60;
      } else {
        this.companion = {
          kind, rig: kind === 'gunner'
            ? rollRigParts(r, GANGS[0], { head: 'helmet' })
            : rollRigParts(r, GANGS[1], { head: 'drone' }),
          x: this.px + 20, y: this.py + 10, hp: 60, maxHp: 60, fireT: 0.5, downT: 0, walk: 0, flash: 0,
        };
        this.toast(kind === 'gunner' ? 'КОМПАНЬОН: СТРЕЛОК ПРИСОЕДИНИЛСЯ' : 'КОМПАНЬОН: ДРОН ПРИСОЕДИНИЛСЯ', P.xp);
        this.sfx.companion();
      }
      return;
    }
    // container / crate loot
    const items = best.items ?? rollLoot(seed, best.kind === 'crate' ? 'shuttle' : 'container');
    best.items = undefined;
    this.sfx.ui();
    if (items.length === 0) this.toast('ПУСТО', P.textDim);
    for (const it of items) {
      this.items.push({ x: best.x + rr(this.rLoot, -10, 10), y: best.y + rr(this.rLoot, 4, 12), item: it, t: 0 });
    }
  }

  private tryPickups() {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const g = this.items[i];
      g.t += 1 / 60;
      if (Math.hypot(g.x - this.px, g.y - this.py) > 0.6 * PXM) continue;
      const it = g.item;
      if (it.kind === 'medkit') {
        if (this.php < this.pmax) {
          this.php = Math.min(this.pmax, this.php + it.heal);
          this.toast('МЕДПАКЕТ: +35 HP', P.hpHi);
          this.sfx.pickup(0);
        } else { this.credits += 5; this.toast('МЕДПАКЕТ В БАГАЖ ГИЛЬДИИ: +5 КР', P.credit); this.sfx.confiscate(); }
        this.items.splice(i, 1); continue;
      }
      const cur = it.kind === 'weapon' ? (this.weapon2 ? this.weapon2.score : BASIC.score) : (this.armor ? this.armor.score : 0);
      if (compareScore(it, cur)) {
        // better: equip; old gear goes to the guild too
        if (it.kind === 'weapon') {
          if (this.weapon2) { this.credits += CONFISCATE_PRICE[this.weapon2.rarity]; this.confiscated++; }
          this.weapon2 = it; this.mag2 = it.magSize; this.slot = 2; this.reloadT = 0;
          this.toast(`ПОДОБРАНО: ${it.name} [${RARITY_RU[it.rarity]}]`, RARITY_COLOR[it.rarity]);
        } else {
          if (this.armor) { this.credits += CONFISCATE_PRICE[this.armor.rarity]; this.confiscated++; }
          this.armor = it; this.php = Math.min(this.pmax, this.php + it.hpBonus);
          this.toast(`БРОНЯ: ${it.name} [${RARITY_RU[it.rarity]}]`, RARITY_COLOR[it.rarity]);
        }
        this.sfx.pickup(['common', 'uncommon', 'rare', 'epic', 'legendary', 'special'].indexOf(it.rarity));
      } else {
        const price = CONFISCATE_PRICE[it.rarity];
        this.credits += price; this.confiscated++;
        this.toast(`КОНФИСКАЦИЯ ГИЛЬДИИ: ${it.name} -> +${price} КР`, P.credit);
        this.sfx.confiscate();
      }
      this.items.splice(i, 1);
    }
  }

  // ---------------------------------------------------------------- enemies
  private spawnEnemy(near = false) {
    const r = this.rSpawn;
    const kinds: EnemyKind[] = ['psycho'];
    if (this.kills >= 5) kinds.push('scav');
    if (this.kills >= 12) kinds.push('drone');
    if (this.kills >= 30) kinds.push('brute');
    const kind = pick(r, kinds);
    let x: number, y: number;
    if (near) { x = rr(r, 80, MAP_W - 80); y = rr(r, 80, MAP_H - 80); }
    else {
      const a = r() * Math.PI * 2;
      const d = rr(r, 13, 17) * PXM;
      x = Math.max(30, Math.min(MAP_W - 30, this.px + Math.cos(a) * d));
      y = Math.max(40, Math.min(MAP_H - 20, this.py + Math.sin(a) * d));
    }
    const def = ENEMY_DEFS[kind];
    const seed = ri(r, 1, 1 << 24);
    const rig = kind === 'drone' ? rollRigParts(makeRng(seed), GANGS[ri(r, 0, GANGS.length - 1)], { head: 'drone' }) : rollGangRig(seed);
    this.enemies.push({
      kind, rig, x, y, vx: 0, vy: 0, hp: def.hp, maxHp: def.hp, atkT: rr(r, 0.2, 1),
      windup: 0, stagger: 0, slow: 0, flash: 0, walk: r() * 6, deadT: 0, strafe: chance(r, 0.5) ? 1 : -1, seed,
    });
  }

  private updateSpawns(dt: number) {
    const alive = this.enemies.filter((e) => e.deadT <= 0).length;
    const target = Math.min(3 + Math.floor(this.kills / 10), 20);
    this.spawnT -= dt;
    if (!this.noEnemies && alive < target && this.spawnT <= 0) {
      this.spawnT = 0.9;
      this.spawnEnemy();
      if (this.kills > 20 && chance(this.rSpawn, 0.4)) this.spawnEnemy();
    }
    this.enemies = this.enemies.filter((e) => e.deadT <= 0 || e.deadT < 0.9);
  }

  private damageEnemy(e: Enemy, dmg: number, nx: number, ny: number, knock: number, element = 'none') {
    if (e.deadT > 0) return;
    let d = dmg;
    if (element === 'fire') d *= 1.2;
    if (element === 'cryo') e.slow = Math.max(e.slow, 1.6);
    if (element === 'shock') e.stagger = Math.max(e.stagger, 0.35);
    e.hp -= d;
    e.flash = 0.09;
    e.vx += nx * knock * PXM; e.vy += ny * knock * PXM;
    for (let i = 0; i < 4; i++) {
      this.fx.push({
        x: e.x, y: e.y - 16, vx: rr(this.rFx, -60, 60) + nx * 40, vy: rr(this.rFx, -80, 20),
        life: rr(this.rFx, 0.2, 0.4), max: 0.4, color: e.kind === 'drone' ? P.spark : P.blood, size: 1, type: 'bit',
      });
    }
    this.sfx.hit();
    if (e.hp <= 0) this.killEnemy(e);
  }

  private killEnemy(e: Enemy) {
    e.deadT = 0.001;
    const def = ENEMY_DEFS[e.kind];
    const bonus = ri(this.rLoot, 0, 3);
    this.credits += def.credits + bonus;
    this.kills++;
    this.sfx.kill();
    for (let i = 0; i < 8; i++) {
      this.fx.push({
        x: e.x, y: e.y - 30, vx: rr(this.rFx, -90, 90), vy: rr(this.rFx, -110, 10),
        life: rr(this.rFx, 0.25, 0.5), max: 0.5, color: e.kind === 'drone' ? P.spark : P.blood, size: 1, type: 'bit',
      });
    }
    this.decals.push({ x: e.x, y: e.y, r: e.kind === 'brute' ? 9 : 6, color: e.kind === 'drone' ? rgba(30, 30, 34) : rgba(70, 16, 14) });
    if (this.decals.length > 420) this.decals.shift();
    if (e.kind === 'drone') this.fx.push({ x: e.x, y: e.y - 14, vx: 0, vy: 0, life: 0.3, max: 0.3, color: P.spark, size: 10, type: 'ring' });
    // guild shuttle milestones
    if (this.kills >= this.nextDrop) {
      this.nextDrop += DROP_EVERY;
      this.drops++;
      const a = this.rLoot() * Math.PI * 2;
      this.shuttles.push({ t: 0, tx: this.px + Math.cos(a) * 70, ty: this.py + Math.sin(a) * 50, done: false });
      this.toast(`ГУЛЬДИЯ: ${this.kills} УБИЙСТВ - ШАТТЛ С ГРУЗОМ НА ПОДХОДЕ`, P.xp);
      this.sfx.shuttle();
    }
  }

  private updateEnemies(dt: number) {
    const def = (e: Enemy) => ENEMY_DEFS[e.kind];
    for (const e of this.enemies) {
      if (e.deadT > 0) { e.deadT += dt; continue; }
      e.flash = Math.max(0, e.flash - dt);
      e.stagger = Math.max(0, e.stagger - dt);
      e.slow = Math.max(0, e.slow - dt);
      e.atkT = Math.max(0, e.atkT - dt);
      const d = def(e);
      const dx = this.px - e.x, dy = this.py - e.y;
      const dist = Math.hypot(dx, dy) || 1;
      const spd = d.speed * PXM * (e.slow > 0 ? 0.5 : 1);
      if (e.stagger > 0) {
        e.vx *= Math.exp(-8 * dt); e.vy *= Math.exp(-8 * dt);
      } else if (e.windup > 0) {
        e.windup -= dt;
        e.vx *= 0.8; e.vy *= 0.8;
        if (e.windup <= 0) {
          if (dist < d.atkRange * PXM * 1.35) this.hurtPlayer(d.dmg, e);
        }
      } else if (e.kind === 'scav') {
        const want = 7 * PXM;
        let mx = 0, my = 0;
        if (dist > want + 40) { mx = dx / dist; my = dy / dist; }
        else if (dist < want - 50) { mx = -dx / dist; my = -dy / dist; }
        else { mx = -dy / dist * e.strafe; my = dx / dist * e.strafe; }
        e.vx += (mx * spd - e.vx) * (1 - Math.exp(-6 * dt));
        e.vy += (my * spd - e.vy) * (1 - Math.exp(-6 * dt));
        if (e.atkT <= 0 && dist < d.atkRange * PXM) {
          e.atkT = d.atkCd;
          const a = Math.atan2(dy, dx) + (this.rFx() - 0.5) * 0.14;
          this.projs.push({
            x: e.x, y: e.y - 34, px: e.x, py: e.y - 34,
            vx: Math.cos(a) * 13 * PXM, vy: Math.sin(a) * 13 * PXM,
            dmg: d.dmg, from: 'enemy', element: 'none', life: 1.1, color: rgba(0xe8, 0x6a, 0x4c),
          });
          this.fx.push({ x: e.x + Math.cos(a) * 12, y: e.y - 29 + Math.sin(a) * 8, vx: 0, vy: 0, life: 0.07, max: 0.07, color: P.muzzle, size: 3, type: 'flash' });
        }
      } else {
        // melee chasers / dash drone
        const mx = dx / dist, my = dy / dist;
        const acc = e.kind === 'drone' ? 10 : 6;
        e.vx += (mx * spd - e.vx) * (1 - Math.exp(-acc * dt));
        e.vy += (my * spd - e.vy) * (1 - Math.exp(-acc * dt));
        if (e.atkT <= 0 && dist < d.atkRange * PXM) {
          e.atkT = d.atkCd;
          if (e.kind === 'drone') { this.hurtPlayer(d.dmg, e); e.vx = -mx * 260; e.vy = -my * 260; }
          else e.windup = 0.35;
        }
      }
      e.x += e.vx * dt; e.y += e.vy * dt;
      e.x = Math.max(14, Math.min(MAP_W - 14, e.x));
      e.y = Math.max(20, Math.min(MAP_H - 8, e.y));
      if (Math.hypot(e.vx, e.vy) > 12) e.walk += dt * (e.kind === 'drone' ? 0 : 10);
      // separation
      for (const o of this.enemies) {
        if (o === e || o.deadT > 0) continue;
        const sx = e.x - o.x, sy = e.y - o.y;
        const sd = Math.hypot(sx, sy);
        const min = (def(e).radius + ENEMY_DEFS[o.kind].radius) * PXM;
        if (sd > 0.01 && sd < min) { e.x += (sx / sd) * (min - sd) * 0.5; e.y += (sy / sd) * (min - sd) * 0.5; }
      }
      this.collideBoulders((o) => { e.x = o.x; e.y = o.y; }, e);
    }
  }

  private hurtPlayer(dmg: number, from?: Enemy) {
    if (this.invuln > 0 || this.state !== 'play') return;
    let d = dmg;
    if (from && this.armor && this.armor.resist === 'kinetic') d *= 0.7;
    this.php -= d;
    this.invuln = 0.4; this.pflash = 0.12; this.hurtVignette = 1;
    this.cam.shake = Math.min(8, this.cam.shake + 3);
    this.sfx.hurt();
    if (this.php <= 0) { this.php = 0; this.state = 'dead'; }
  }

  private collideBoulders(set: (o: { x: number; y: number }) => void, e?: Enemy) {
    const ox = e ? e.x : this.px, oy = e ? e.y : this.py;
    const rad = e ? ENEMY_DEFS[e.kind].radius * PXM : 9;
    for (const b of this.boulders) {
      const dx = ox - b.x, dy = oy - b.y;
      const d = Math.hypot(dx, dy);
      const min = b.r * 0.8 + rad;
      if (d < min && d > 0.01) {
        set({ x: b.x + (dx / d) * min, y: b.y + (dy / d) * min });
      }
    }
  }

  // ---------------------------------------------------------------- projectiles / fx
  private updateProjs(dt: number) {
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const p = this.projs[i];
      p.px = p.x; p.py = p.y;
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.life -= dt;
      let hit = p.life <= 0;
      if (!hit) {
        if (p.from === 'enemy') {
          if (Math.hypot(p.x - this.px, p.y - (this.py - 45)) < 14) { this.hurtPlayer(p.dmg); hit = true; }
        } else {
          for (const e of this.enemies) {
            if (e.deadT > 0) continue;
            const r = ENEMY_DEFS[e.kind].radius * PXM + 4;
            if (Math.hypot(p.x - e.x, p.y - (e.y - 34)) < r) {
              const d = Math.hypot(p.vx, p.vy) || 1;
              this.damageEnemy(e, p.dmg, p.vx / d, p.vy / d, p.element === 'kinetic' ? 2.2 : 1.2, p.element);
              hit = true; break;
            }
          }
        }
      }
      // boulders block shots
      if (!hit) {
        for (const b of this.boulders) {
          if (Math.hypot(p.x - b.x, p.y - b.y) < b.r * 0.8) { hit = true; break; }
        }
      }
      if (hit) {
        for (let j = 0; j < 3; j++) {
          this.fx.push({ x: p.x, y: p.y, vx: rr(this.rFx, -50, 50), vy: rr(this.rFx, -50, 50), life: 0.15, max: 0.15, color: p.color, size: 1, type: 'bit' });
        }
        this.projs.splice(i, 1);
      }
    }
  }

  private updateFx(dt: number) {
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i];
      f.life -= dt;
      f.x += f.vx * dt; f.y += f.vy * dt;
      f.vx *= Math.exp(-4 * dt); f.vy *= Math.exp(-4 * dt);
      if (f.type === 'bit' && f.color === P.blood && f.life <= 0 && this.rFx() < 0.5) {
        this.decals.push({ x: f.x, y: Math.min(MAP_H - 2, f.y + 12), r: 3, color: rgba(70, 16, 14) });
        if (this.decals.length > 420) this.decals.shift();
      }
      if (f.life <= 0) this.fx.splice(i, 1);
    }
  }

  private updateShuttles(dt: number) {
    for (let i = this.shuttles.length - 1; i >= 0; i--) {
      const s = this.shuttles[i];
      s.t += dt;
      if (!s.done && s.t >= 1.5) {
        s.done = true;
        this.boxes.push({ x: s.tx, y: s.ty, open: false, seed: ri(this.rLoot, 1, 1 << 20), kind: 'crate', items: rollLoot(ri(this.rLoot, 1, 1 << 20), 'shuttle') });
        for (let j = 0; j < 14; j++) {
          this.fx.push({ x: s.tx + rr(this.rFx, -12, 12), y: s.ty + rr(this.rFx, -4, 4), vx: rr(this.rFx, -40, 40), vy: rr(this.rFx, -60, -10), life: rr(this.rFx, 0.4, 0.8), max: 0.8, color: rgba(120, 110, 95, 160), size: 2, type: 'smoke' });
        }
        this.cam.shake = Math.min(8, this.cam.shake + 4);
      }
      if (s.t > 3.4) this.shuttles.splice(i, 1);
    }
  }

  private updateCompanion(dt: number) {
    const c = this.companion;
    if (!c) return;
    c.flash = Math.max(0, c.flash - dt);
    if (c.downT > 0) {
      c.downT -= dt;
      if (c.downT <= 0) { c.hp = c.maxHp; c.x = this.px + 20; c.y = this.py + 14; this.toast('КОМПАНЬОН СНОВА В СТРОЮ', P.xp); }
      return;
    }
    const dx = this.px - c.x, dy = this.py - c.y;
    const d = Math.hypot(dx, dy) || 1;
    const fly = c.kind === 'drone';
    if (d > 46) {
      const sp = (fly ? 4.2 : 3.7) * PXM;
      c.x += (dx / d) * sp * dt; c.y += (dy / d) * sp * dt;
      c.walk += dt * 10;
    }
    c.fireT -= dt;
    if (c.fireT <= 0) {
      let best: Enemy | null = null; let bd = 9 * PXM;
      for (const e of this.enemies) {
        if (e.deadT > 0) continue;
        const ed = Math.hypot(e.x - c.x, e.y - c.y);
        if (ed < bd) { bd = ed; best = e; }
      }
      if (best) {
        c.fireT = fly ? 1.0 : 0.8;
        const a = Math.atan2(best.y - c.y, best.x - c.x) + (this.rFx() - 0.5) * 0.1;
        this.projs.push({
          x: c.x, y: c.y - (fly ? 16 : 34), px: c.x, py: c.y - 34,
          vx: Math.cos(a) * 20 * PXM, vy: Math.sin(a) * 20 * PXM,
          dmg: fly ? 9 : 6, from: 'player', element: fly ? 'shock' : 'kinetic', life: 0.7,
          color: fly ? rgba(0xe8, 0xd0, 0x58) : rgba(0xff, 0xd8, 0x8a),
        });
      }
    }
  }

  // ---------------------------------------------------------------- render
  render(poseOverride?: import('./hero.js').HeroPose): PixelBuf {
    if (this.state === 'menu') return this.renderMenu();
    this.poseOverride = poseOverride ?? null;
    const z = this.cam.zoom;
    const view = new PixelBuf(z.w, z.h);
    if (this.ground) view.blit(this.ground, 0, 0, Math.round(this.cam.left), Math.round(this.cam.top), z.w, z.h);
    else view.fill(rgba(40, 36, 30));
    // decals
    for (const d of this.decals) {
      const x = this.cam.wx(d.x), y = this.cam.wy(d.y);
      if (x < -20 || y < -20 || x > z.w + 20 || y > z.h + 20) continue;
      view.disc(x, y, d.r, d.color);
    }
    // y-sorted drawables
    type D = { y: number; fn: () => void };
    const ds: D[] = [];
    for (const b of this.boulders) ds.push({ y: b.y, fn: () => this.drawBoulder(view, b) });
    for (const b of this.boxes) ds.push({ y: b.y, fn: () => this.drawBox(view, b) });
    for (const g of this.items) ds.push({ y: g.y, fn: () => this.drawGroundItem(view, g) });
    for (const e of this.enemies) ds.push({ y: e.y, fn: () => this.drawEnemy(view, e) });
    if (this.companion) ds.push({ y: this.companion.y, fn: () => this.drawCompanion(view, this.companion!) });
    ds.push({ y: this.py, fn: () => this.drawPlayer(view) });
    ds.sort((a, b) => a.y - b.y);
    for (const d of ds) d.fn();
    // projectiles (tracers)
    for (const p of this.projs) {
      const x = this.cam.wx(p.x), y = this.cam.wy(p.y);
      const px = this.cam.wx(p.px), py = this.cam.wy(p.py);
      view.line(px, py, x, y, p.color);
      view.set(x, y, rgba(255, 255, 255));
    }
    // fx
    for (const f of this.fx) this.drawFx(view, f);
    // shuttle silhouettes overhead
    for (const s of this.shuttles) this.drawShuttle(view, s);
    // downscale to 640x360
    const out = z.w === VIEW_W ? view : PixelBuf.downscale(view, VIEW_W, VIEW_H);
    this.drawHUD(out);
    return out;
  }

  private drawBoulder(b: PixelBuf, bo: Boulder) {
    const x = this.cam.wx(bo.x), y = this.cam.wy(bo.y);
    if (x < -40 || y < -40 || x > this.cam.zoom.w + 40 || y > this.cam.zoom.h + 40) return;
    const r = bo.r;
    b.discA(x, y + 2, Math.round(r * 0.95), rgba(0, 0, 0, 55));
    const facet = 0.75 + ((bo.seed & 31) / 31) * 0.35;
    for (let dy = -Math.round(r * 0.6); dy <= 0; dy++) {
      const t = -dy / (r * 0.6);
      const jitter = ((bo.seed >> ((dy + 40) & 3)) & 3) - 1;
      const w = Math.max(3, Math.round(r * (0.75 + 0.35 * Math.sqrt(Math.max(0, 1 - t * t))) * facet) + jitter);
      const k = 1.15 + t * 0.6;
      const g = Math.round(88 * k + ((bo.seed >> (dy & 7)) & 5));
      b.hline(x - w, y + dy, w * 2, rgba(g, g + 3, g + 7));
    }
    b.hline(x - Math.round(r * 0.4), y - Math.round(r * 0.55), Math.round(r * 0.7), rgba(188, 190, 196));
    b.hline(x - Math.round(r * 0.6), y, Math.round(r * 1.2), rgba(70, 70, 74));
    // crack detail
    b.vline(x + Math.round(r * 0.2), y - Math.round(r * 0.4), Math.round(r * 0.35), rgba(70, 72, 78));
  }

  private drawBox(b: PixelBuf, box: LootBox) {
    const x = this.cam.wx(box.x), y = this.cam.wy(box.y);
    if (x < -40 || y < -40 || x > this.cam.zoom.w + 40 || y > this.cam.zoom.h + 40) return;
    const PK = this.PK;
    if (box.kind === 'capsule') {
      b.discA(x, y + 1, Math.round(8 * PK), rgba(0, 0, 0, 70));
      const H = Math.round(22 * PK), W = Math.round(6 * PK);
      for (let yy = -H; yy <= 0; yy++) {
        const w = yy > -Math.round(4 * PK) ? W + 1 : W;
        b.hline(x - w, y + yy, w * 2, rgba(yy < -H + Math.round(4 * PK) ? 70 : 48, yy < -H + Math.round(4 * PK) ? 78 : 54, yy < -H + Math.round(4 * PK) ? 84 : 60));
      }
      b.frame(x - W, y - H, W * 2 + 1, H + 1, rgba(30, 33, 38));
      if (PK >= 1.33) { // 40: ribs + cap ring detail
        b.hline(x - W + 1, y - Math.round(H * 0.3), (W - 1) * 2, rgba(38, 42, 47));
        b.hline(x - W + 1, y - Math.round(H * 0.7), (W - 1) * 2, rgba(38, 42, 47));
        b.hline(x - W + 1, y - H, (W - 1) * 2, rgba(84, 88, 94));
      }
      if (!box.open) {
        const pulse = 0.6 + 0.4 * Math.sin(this.time * 4 + box.seed);
        const wy = -Math.round(17 * PK), wh = Math.round(9 * PK);
        b.rect(x - Math.round(3 * PK), y + wy, Math.round(7 * PK), wh, rgba(60, 176, 194, 90 + Math.round(90 * pulse)));
        b.set(x, y + wy + Math.round(4 * PK), rgba(188, 243, 245));
      } else b.rect(x - Math.round(3 * PK), y - Math.round(17 * PK), Math.round(7 * PK), Math.round(9 * PK), rgba(16, 18, 20));
      return;
    }
    const crate = box.kind === 'crate';
    const w = Math.round((crate ? 9 : 10) * PK), h = Math.round((crate ? 9 : 8) * PK);
    b.discA(x, y + 1, w + 1, rgba(0, 0, 0, 60));
    const base = crate ? [64, 68, 60] : [48, 83, 87];
    for (let yy = -h; yy <= 0; yy++) {
      const k = yy < -h + 2 ? 1.25 : yy > -3 ? 0.8 : 1;
      b.hline(x - w, y + yy, w * 2, rgba(base[0] * k | 0, base[1] * k | 0, base[2] * k | 0));
    }
    b.frame(x - w, y - h, w * 2 + 1, h + 1, rgba(24, 26, 30));
    b.hline(x - w, y - h + Math.round(3 * PK), w * 2, rgba(24, 26, 30));
    if (PK >= 1.33) { // 40: lid seam + corner brackets + vent
      b.hline(x - w + 1, y - Math.round(h * 0.5), w * 2 - 2, rgba(34, 37, 42));
      b.vline(x - w + 1, y - h + 2, 3, rgba(90, 95, 100));
      b.vline(x + w - 1, y - h + 2, 3, rgba(90, 95, 100));
      if (!crate) { b.vline(x - Math.round(w * 0.5), y - h + Math.round(4 * PK), 2, rgba(30, 33, 38)); b.vline(x + Math.round(w * 0.5), y - h + Math.round(4 * PK), 2, rgba(30, 33, 38)); }
    }
    if (!box.open) {
      if (crate) { b.rect(x - Math.round(3 * PK), y - Math.round(6 * PK), Math.round(7 * PK), Math.round(3 * PK), rgba(190, 146, 64)); b.set(x, y - Math.round(5 * PK), rgba(250, 224, 158)); }
      else { b.set(x - Math.round(2 * PK), y - Math.round(5 * PK), rgba(156, 88, 44)); b.set(x + Math.round(3 * PK), y - Math.round(4 * PK), rgba(156, 88, 44)); }
    } else {
      b.rect(x - w + 2, y - h + 2, w * 2 - 3, 3, rgba(14, 15, 17));
    }
    // interact hint
    if (!box.open && Math.hypot(box.x - this.px, box.y - this.py) < 1.35 * PXM) {
      drawTextS(b, x - 3, y - h - 12, 'E', P.xp);
    }
  }

  private drawGroundItem(b: PixelBuf, g: GroundItem) {
    const x = this.cam.wx(g.x), y = this.cam.wy(g.y);
    if (x < -20 || y < -20 || x > this.cam.zoom.w + 20 || y > this.cam.zoom.h + 20) return;
    const col = RARITY_COLOR[g.item.rarity];
    const pulse = 0.5 + 0.5 * Math.sin(this.time * 5 + g.x);
    for (let i = 0; i < 14; i++) {
      const a = Math.round(120 * (1 - i / 14) * (0.5 + pulse * 0.5));
      b.set(x, y - 4 - i, (col & 0x00ffffff) | (a << 24));
    }
    b.discA(x, y, 3, rgba(0, 0, 0, 60));
    if (g.item.kind === 'weapon') {
      b.hline(x - 4, y - 3, 9, rgba(44, 47, 54));
      b.hline(x - 4, y - 2, 6, rgba(64, 68, 76));
      b.set(x + 4, y - 3, col);
    } else if (g.item.kind === 'armor') {
      b.rect(x - 3, y - 5, 7, 5, rgba(58, 62, 70));
      b.hline(x - 3, y - 5, 7, col);
      b.set(x, y - 3, col);
    } else {
      b.rect(x - 3, y - 4, 7, 4, rgba(200, 196, 188));
      b.vline(x, y - 4, 4, rgba(196, 58, 44));
      b.hline(x - 2, y - 2, 5, rgba(196, 58, 44));
    }
  }

  private drawEnemy(b: PixelBuf, e: Enemy) {
    const x = this.cam.wx(e.x), y = this.cam.wy(e.y);
    if (x < -40 || y < -60 || x > this.cam.zoom.w + 40 || y > this.cam.zoom.h + 40) return;
    if (e.deadT > 0) {
      const t = Math.min(1, e.deadT / 0.9);
      if (e.kind !== 'drone') this.drawArtK(b, x, y, (tmp, ox, oy) => drawHumanoid(tmp, ox, oy, e.rig, { dir: 2 as Dir8, aim: 2 as Dir8, walk: 0, moving: false, dead: t, flash: false }, 'none'));
      else b.discA(x, y - 4, 5, rgba(40, 40, 44, Math.round(200 * (1 - t))));
      return;
    }
    const aimD = dir8FromVec(this.px - e.x, this.py - e.y);
    const movD = Math.hypot(e.vx, e.vy) > 12 ? dir8FromVec(e.vx, e.vy) : aimD;
    const tele = e.windup > 0;
    if (e.kind === 'drone') {
      this.drawArtK(b, x, y, (tmp, ox, oy) => drawDrone(tmp, ox, oy, e.rig, this.time + e.seed, e.flash > 0, tele ? 1 : 0));
    } else {
      drawHumanoid(b, x, y, e.rig, {
        dir: movD, aim: aimD, walk: e.walk, moving: Math.hypot(e.vx, e.vy) > 12,
        flash: e.flash > 0, crouch: tele ? 0.5 : e.stagger > 0 ? 0.3 : 0,
      }, e.kind === 'scav' ? 'pistol' : e.kind === 'brute' ? 'melee' : 'melee', 0);
      if (e.kind === 'brute') { // shoulder plate
        b.hline(x - 8, y - 34, 6, e.rig.accent[3]);
        b.hline(x - 8, y - 33, 6, e.rig.accent[2]);
      }
    }
    if (tele) b.ring(x, y - 16, 8 + Math.round((0.35 - e.windup) * 20), rgba(232, 106, 76, 160));
    if (e.stagger > 0) { b.set(x - 2, y - 44, P.spark); b.set(x + 2, y - 46, P.sparkHot); b.set(x, y - 48, P.spark); }
    if (e.slow > 0) b.ring(x, y - 14, 7, rgba(154, 220, 232, 120));
    // hp pip bar for damaged enemies
    if (e.hp < e.maxHp) {
      const w = 14;
      b.hline(x - (w >> 1), y - 56, w, rgba(20, 20, 24));
      b.hline(x - (w >> 1), y - 56, Math.max(1, Math.round((w * e.hp) / e.maxHp)), rgba(196, 58, 44));
    }
  }

  /** Temp v15: rig art is authored at 30 px/m - blit it nearest-rational-scaled by ART_K so the
   *  scene stays coherent at production 40 px/m. v16 replaces this with hand-authored 40 art. */
  private drawArtK(b: PixelBuf, x: number, y: number, fn: (tmp: PixelBuf, ox: number, oy: number) => void) {
    const k = ART_K;
    const W = 96, H = 96, AX = 48, AY = 88;
    const tmp = new PixelBuf(W, H);
    fn(tmp, AX, AY);
    const OW = Math.round(W * k), OH = Math.round(H * k);
    const ox0 = x - Math.round(AX * k), oy0 = y - Math.round(AY * k);
    for (let oy = 0; oy < OH; oy++) {
      const sy = Math.floor(oy / k);
      for (let ox = 0; ox < OW; ox++) {
        const c = tmp.get(Math.floor(ox / k), sy);
        if ((c >>> 24) === 0) continue;
        b.set(ox0 + ox, oy0 + oy, c);
      }
    }
  }

  private drawCompanion(b: PixelBuf, c: Companion) {
    const x = this.cam.wx(c.x), y = this.cam.wy(c.y);
    if (c.downT > 0) {
      b.discA(x, y - 2, 6, rgba(0, 0, 0, 70));
      b.hline(x - 6, y - 2, 13, rgba(60, 60, 66));
      drawTextS(b, x - 8, y - 14, `ПОДНЯТИЕ ${Math.ceil(c.downT)}`, P.textDim);
      return;
    }
    if (c.kind === 'drone') this.drawArtK(b, x, y, (tmp, ox, oy) => drawDrone(tmp, ox, oy, c.rig, this.time, c.flash > 0, 0));
    else this.drawArtK(b, x, y, (tmp, ox, oy) => drawHumanoid(tmp, ox, oy, c.rig, { dir: dir8FromVec(this.px - c.x, this.py - c.y), aim: this.aim, walk: c.walk, moving: Math.hypot(this.px - c.x, this.py - c.y) > 61, flash: c.flash > 0 }, 'smg', 0));
    b.hline(x - 8, y - 53, 17, rgba(20, 20, 24));
    b.hline(x - 8, y - 53, Math.round((17 * c.hp) / c.maxHp), P.xp);
  }

  poseOverride: import('./hero.js').HeroPose | null = null;
  /** QA-only: skip the player draw so assertGameEqualsBench can isolate the hero mask (v17). */
  hidePlayer = false;
  private drawPlayer(b: PixelBuf) {
    if (this.hidePlayer) return;
    const x = this.cam.wx(this.px), y = this.cam.wy(this.py);
    const cls = this.activeWeapon.cls;
    const gun: HeroGun =
      cls === 'rifle' ? 'rifle' : cls === 'smg' ? 'smg' : cls === 'launcher' ? 'launcher' : cls === 'blade' ? 'blade' : 'pistol';
    drawHero(b, x, y, this.poseOverride ?? {
      aimAng: this.aimAng, moving: this.moving, walk: this.walk,
      flash: this.pflash > 0, gun, muzzle: this.muzzle > 0 ? 1 : 0,
      moveDir: DIR_VEC[this.dir],   // visual-only posture lean direction
      set: ARMOR_SETS[this.armorSetIdx].id,
      lowReady: this.lowReady,
      pxm: PXM,
    });
    // melee slash arc
    if (this.meleeSwing > 0) {
      const t = 1 - this.meleeSwing / 0.16;
      const a0 = this.aimAng - 0.9 + t * 1.8;
      for (let i = 0; i < 10; i++) {
        const a = a0 - i * 0.09;
        const r = MELEE_RANGE * PXM - i;
        b.set(x + Math.round(Math.cos(a) * r), y - 45 + Math.round(Math.sin(a) * r * 0.7), rgba(255, 242, 208, 220 - i * 20));
      }
    }
  }

  private playerRigCache: RigParts | null = null;
  playerRig(): RigParts {
    if (!this.playerRigCache) {
      const r = makeRng(777);
      this.playerRigCache = rollRigParts(r, [[0x5a, 0x62, 0x6a], [0x46, 0x50, 0x58], [0x6e, 0x76, 0x7e]], { head: 'helmet', glow: rgba(0x6a, 0xc8, 0xe8) });
    }
    return this.playerRigCache;
  }

  private drawFx(b: PixelBuf, f: Fx) {
    const x = this.cam.wx(f.x), y = this.cam.wy(f.y);
    const t = f.life / f.max;
    if (f.type === 'bit') b.set(x, y, (f.color & 0x00ffffff) | (Math.round(255 * t) << 24));
    else if (f.type === 'smoke') b.disc(x, y, f.size, (f.color & 0x00ffffff) | (Math.round(120 * t) << 24));
    else if (f.type === 'flash') b.disc(x, y, f.size, (f.color & 0x00ffffff) | (Math.round(255 * t) << 24));
    else if (f.type === 'ring') b.ring(x, y, Math.round(f.size * (1.6 - t)), (f.color & 0x00ffffff) | (Math.round(200 * t) << 24));
    else if (f.type === 'slash' && f.ang !== undefined) {
      for (let i = 0; i < 14; i++) {
        const a = f.ang - 0.9 + (i / 14) * 1.8;
        const r = f.size - (i % 3);
        b.set(x + Math.round(Math.cos(a) * r), y + Math.round(Math.sin(a) * r * 0.7), (f.color & 0x00ffffff) | (Math.round(230 * t) << 24));
      }
    }
  }

  private drawShuttle(b: PixelBuf, s: Shuttle) {
    const t = s.t;
    const prog = Math.min(1, t / 2.6);
    const sx = -80 + prog * (this.cam.zoom.w + 160);
    const sy = 30 + Math.sin(prog * Math.PI) * -12;
    // ground shadow tracks drop point approach
    const gx = this.cam.wx(s.tx), gy = this.cam.wy(s.ty);
    const shA = t > 0.6 && t < 1.6 ? Math.round(90 * Math.sin(((t - 0.6) / 1.0) * Math.PI)) : 0;
    if (shA > 0) b.discA(gx, gy, 16, rgba(0, 0, 0, shA));
    if (t < 2.6) {
      for (let i = 0; i < 26; i++) {
        const w = i < 4 ? 6 : i > 21 ? 5 : 9;
        b.hline(Math.round(sx) - 13 + i, Math.round(sy) - (w >> 1), 1, rgba(i > 8 && i < 16 ? 90 : 52, i > 8 && i < 16 ? 96 : 56, i > 8 && i < 16 ? 104 : 62));
      }
      b.hline(Math.round(sx) - 16, Math.round(sy), 6, rgba(108, 214, 226));
      b.hline(Math.round(sx) + 12, Math.round(sy), 5, rgba(250, 224, 158, 200));
    }
    if (!s.done && t > 0.9 && t < 1.5) {
      const fy = sy + (t - 0.9) / 0.6 * (gy - sy);
      b.rect(gx - 3, Math.round(fy), 7, 6, rgba(64, 68, 60));
      b.hline(gx - 5, Math.round(fy) - 2, 11, rgba(190, 146, 64, 200));
    }
  }

  // ---------------------------------------------------------------- HUD
  private drawHUD(b: PixelBuf) {
    const W = VIEW_W;
    // top-left: hp
    b.rect(6, 6, 132, 16, rgba(12, 13, 16, 200));
    b.frame(6, 6, 132, 16, P.panelEdge);
    const hpw = Math.round((126 * Math.max(0, this.php)) / this.pmax);
    b.rect(9, 9, 126, 10, rgba(40, 20, 18));
    b.rect(9, 9, hpw, 10, P.hp);
    b.hline(9, 9, hpw, P.hpHi);
    drawText(b, 12, 11, `${Math.ceil(this.php)}/${this.pmax}`, P.text);
    if (this.armor) {
      b.rect(6, 24, 132, 8, rgba(12, 13, 16, 180));
      drawText(b, 9, 25, `БРОНЯ +${this.armor.hpBonus} HP`, RARITY_COLOR[this.armor.rarity]);
    }
    // top-right: credits / kills / drop progress
    const rw = 150;
    b.rect(W - rw - 6, 6, rw, 26, rgba(12, 13, 16, 200));
    b.frame(W - rw - 6, 6, rw, 26, P.panelEdge);
    drawText(b, W - rw - 2, 9, `КРЕДИТЫ: ${this.credits}`, P.credit);
    drawText(b, W - rw - 2, 17, `УБИЙСТВ: ${this.kills}`, P.text);
    const prog = Math.min(1, (this.kills % DROP_EVERY) / DROP_EVERY);
    b.rect(W - rw - 2, 26, 100, 3, rgba(40, 44, 50));
    b.rect(W - rw - 2, 26, Math.round(100 * prog), 3, P.xp);
    drawText(b, W - rw + 102, 24, `ШАТТЛ`, P.textDim);
    // bottom-left: weapon slots
    b.rect(6, VIEW_H - 26, 210, 20, rgba(12, 13, 16, 200));
    b.frame(6, VIEW_H - 26, 210, 20, P.panelEdge);
    drawText(b, 10, VIEW_H - 22, '1', this.slot === 1 ? P.spark : P.textDim);
    drawText(b, 18, VIEW_H - 22, 'БАЗ. АВТОМАТ', this.slot === 1 ? P.text : P.textDim);
    if (this.weapon2) {
      drawText(b, 96, VIEW_H - 22, '2', this.slot === 2 ? P.spark : P.textDim);
      const nm = this.weapon2.name.slice(0, 12);
      drawText(b, 104, VIEW_H - 22, nm, RARITY_COLOR[this.weapon2.rarity]);
      drawText(b, 176, VIEW_H - 22, this.reloadT > 0 ? 'ПЗР' : `${this.mag2}`, this.reloadT > 0 ? P.credit : P.ammo);
    }
    // bottom-right hints
    const hint = '[E] ВЗЯТЬ  [ПКМ/Q] УДАР  [R] ПЗР  [1/2] ОРЖ  [-/] ЗУМ  [ESC] ПАУЗА';
    b.rect(VIEW_W - textWidth(hint) - 10, VIEW_H - 12, textWidth(hint) + 8, 9, rgba(12, 13, 16, 150));
    drawText(b, VIEW_W - textWidth(hint) - 6, VIEW_H - 11, hint, P.textDim);
    // companion
    if (this.companion) {
      const c = this.companion;
      const st = c.downT > 0 ? `ПОДНЯТИЕ ${Math.ceil(c.downT)}` : `${c.kind === 'gunner' ? 'СТРЕЛОК' : 'ДРОН'} ${Math.ceil(c.hp)}/${c.maxHp}`;
      drawTextS(b, VIEW_W - textWidth(st) - 8, VIEW_H - 24, st, P.xp);
    }
    // toasts
    let ty = 40;
    for (const t of this.toasts) {
      const a = Math.min(1, t.t / 0.6);
      const col = (t.color & 0x00ffffff) | (Math.round(255 * a) << 24);
      const w = textWidth(t.text) + 8;
      b.rect((VIEW_W - w) / 2, ty, w, 9, rgba(12, 13, 16, Math.round(180 * a)));
      drawText(b, (VIEW_W - w) / 2 + 4, ty + 1, t.text, col);
      ty += 11;
    }
    // crosshair
    const mx = this.mouseX | 0, my = this.mouseY | 0;
    const cc = this.reloadT > 0 ? P.credit : this.meleeSwing > 0 ? P.spark : rgba(230, 235, 240);
    b.hline(mx - 5, my, 3, cc); b.hline(mx + 3, my, 3, cc);
    b.vline(mx, my - 5, 3, cc); b.vline(mx, my + 3, 3, cc);
    b.set(mx, my, cc);
    // hurt vignette
    if (this.hurtVignette > 0) {
      const a = Math.round(120 * this.hurtVignette);
      for (let i = 0; i < 10; i++) {
        const al = Math.round(a * (1 - i / 10));
        const col = rgba(140, 20, 16, al);
        b.frame(i, i, VIEW_W - i * 2, VIEW_H - i * 2, col);
      }
    }
    if (this.paused) {
      b.rect(0, 0, VIEW_W, VIEW_H, rgba(6, 7, 9, 190));
      drawTextS(b, VIEW_W / 2 - 40, 150, 'ПАУЗА', P.text, 3);
      drawTextS(b, VIEW_W / 2 - 70, 190, '[ESC] ПРОДОЛЖИТЬ', P.textDim);
    }
    if (this.state === 'dead') {
      b.rect(0, 0, VIEW_W, VIEW_H, rgba(20, 6, 6, 200));
      drawTextS(b, VIEW_W / 2 - 150, 110, 'КОНТРАКТ ПРЕРВАН', P.hp, 3);
      drawTextS(b, VIEW_W / 2 - 110, 150, `УБИЙСТВ: ${this.kills}   КРЕДИТЫ: ${this.credits}`, P.text);
      drawTextS(b, VIEW_W / 2 - 110, 165, `ГРУЗОВ ШАТТЛА: ${this.drops}   КОНФИСКАЦИЙ: ${this.confiscated}`, P.textDim);
      drawTextS(b, VIEW_W / 2 - 80, 200, '[R] НОВЫЙ КОНТРАКТ', P.xp);
    }
  }

  // ---------------------------------------------------------------- menu
  private renderMenu(): PixelBuf {
    const b = new PixelBuf(VIEW_W, VIEW_H);
    if (!this.menuBg) this.menuBg = this.makeSpace();
    b.blit(this.menuBg, 0, 0);
    // twinkle
    const r = makeRng(4242);
    for (let i = 0; i < 70; i++) {
      const x = ri(r, 0, VIEW_W - 1), y = ri(r, 0, VIEW_H - 1);
      const ph = r() * 6.28;
      const tw = 0.5 + 0.5 * Math.sin(this.time * 2 + ph);
      if (tw > 0.75) b.set(x, y, rgba(220, 230, 240, Math.round(180 * tw)));
    }
    drawTextS(b, 130, 84, 'PALE MERIDIAN', rgba(216, 212, 200), 4);
    drawTextS(b, 196, 122, 'ОКРАИННЫЙ КОНТРАКТ AA1', rgba(108, 214, 226), 1);
    // play button
    const hov = this.hoverPlay;
    b.rect(260, 208, 120, 24, hov ? rgba(48, 83, 87) : rgba(27, 30, 35));
    b.frame(260, 208, 120, 24, hov ? rgba(108, 214, 226) : P.panelEdge);
    drawTextS(b, 292, 216, 'ИГРАТЬ', hov ? rgba(188, 243, 245) : P.text, 1);
    drawTextS(b, 244, 240, '[ENTER] ИЛИ КЛИК', P.textDim);
    const lines = [
      'WASD - ДВИЖЕНИЕ   МЫШЬ - ПРИЦЕЛ   ЛКМ - ОГОНЬ',
      'ПКМ/Q - УДАР С БЛИЗКОЙ   R - ПЕРЕЗАРЯДКА   E - ВЗЯТЬ',
      'ЛУТ ТОЛЬКО ИЗ КОНТЕЙНЕРОВ, КАПСУЛ И ГРУЗОВ ШАТТЛА',
      'ХУДШИЙ ТРОФЕЙ ГИЛЬДИЯ КОНФИСКУЕТ В КРЕДИТЫ',
    ];
    lines.forEach((l, i) => drawTextS(b, VIEW_W / 2 - textWidth(l) / 2, 274 + i * 10, l, i > 1 ? rgba(138, 136, 128) : rgba(180, 178, 168)));
    drawText(b, 8, VIEW_H - 9, 'SEED 20260930  640X360  30 PX/M', rgba(90, 90, 88));
    return b;
  }

  private makeSpace(): PixelBuf {
    const b = new PixelBuf(VIEW_W, VIEW_H);
    const r = makeRng(999);
    // deep space base with vertical gradient
    for (let y = 0; y < VIEW_H; y++) {
      const t = y / VIEW_H;
      b.hline(0, y, VIEW_W, rgba(Math.round(6 + t * 6), Math.round(7 + t * 5), Math.round(12 + t * 8)));
    }
    // nebula: two lobes
    for (let y = 0; y < VIEW_H; y += 1) {
      for (let x = 0; x < VIEW_W; x += 1) {
        const n = fbmLocal(x / 90, y / 70, 4, 11);
        const n2 = fbmLocal(x / 40 + 9, y / 34 + 3, 3, 29);
        if (n > 0.52) {
          const a = Math.min(120, (n - 0.52) * 320);
          b.blend(x, y, rgba(46, 96, 118, Math.round(a)));
        }
        if (n2 > 0.6) {
          const a = Math.min(90, (n2 - 0.6) * 260);
          b.blend(x, y, rgba(96, 54, 108, Math.round(a)));
        }
      }
    }
    // stars, 3 depths
    for (let i = 0; i < 240; i++) {
      const x = ri(r, 0, VIEW_W - 1), y = ri(r, 0, VIEW_H - 1);
      const d = ri(r, 0, 2);
      const c = d === 0 ? rgba(120, 128, 140) : d === 1 ? rgba(180, 190, 200) : rgba(240, 244, 250);
      b.set(x, y, c);
      if (d === 2) { b.set(x + 1, y, rgba(120, 128, 140)); b.set(x, y + 1, rgba(120, 128, 140)); }
    }
    // planet limb bottom-right
    const cx = VIEW_W + 90, cy = VIEW_H + 150, pr = 240;
    for (let y = 0; y < VIEW_H; y++) {
      for (let x = VIEW_W - 320; x < VIEW_W; x++) {
        const d = Math.hypot(x - cx, y - cy);
        if (d < pr) {
          const t = 1 - d / pr;
          const band = Math.sin(y * 0.09 + Math.sin(x * 0.02) * 2) * 0.5 + 0.5;
          const g = Math.round(46 + t * 60 + band * 22);
          b.set(x, y, rgba(Math.round(g * 0.78), g, Math.round(g * 1.18)));
          if (d > pr - 3) b.set(x, y, rgba(120, 190, 210));
        } else if (d < pr + 2) {
          b.set(x, y, rgba(150, 210, 228, 220));
        }
      }
    }
    return b;
  }
}
