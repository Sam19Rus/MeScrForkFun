import { GameCore } from '../game/game.js';
import { WebSfx } from '../engine/audio.js';
import { emptyInput, type InputState } from '../engine/input.js';
import { VIEW_W, VIEW_H, DT } from '../game/config.js';
import { PixelBuf, rgba } from '../core/buf.js';
import { PoseEditor } from '../game/pose_editor.js';
import { encodePNG } from '../engine/png.js';
import { P } from '../core/palette.js';

/** Browser shell: canvas + input + fixed-step loop + WebAudio. All game logic lives in GameCore. */
const canvas = document.getElementById('cv') as HTMLCanvasElement;
const ctx = canvas.getContext('2d')!;
canvas.width = VIEW_W;
canvas.height = VIEW_H;

function fit() {
  const s = Math.max(1, Math.min(Math.floor(window.innerWidth / VIEW_W), Math.floor(window.innerHeight / VIEW_H)));
  canvas.style.width = `${VIEW_W * s}px`;
  canvas.style.height = `${VIEW_H * s}px`;
}
fit();
window.addEventListener('resize', fit);

const sfx = new WebSfx();
const core = new GameCore(sfx);
const inp: InputState = emptyInput();
const editor = new PoseEditor();
let poseSaveN = 0;
function downloadPose(buf: PixelBuf, name: string) {
  const bytes = encodePNG(buf);
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const blob = new Blob([u8.buffer as ArrayBuffer], { type: 'image/png' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ---- ground texture (baked by the python content bridge)
async function loadGround(): Promise<PixelBuf> {
  const res = await fetch('assets/ground.png');
  const blob = await res.blob();
  const bmp = await createImageBitmap(blob);
  const c = document.createElement('canvas');
  c.width = bmp.width; c.height = bmp.height;
  const g = c.getContext('2d')!;
  g.drawImage(bmp, 0, 0);
  const d = g.getImageData(0, 0, bmp.width, bmp.height);
  const buf = new PixelBuf(bmp.width, bmp.height);
  buf.px.set(new Uint32Array(d.data.buffer));
  // browser gives straight alpha over transparent; ground is opaque, force a=255
  for (let i = 0; i < buf.px.length; i++) buf.px[i] = (buf.px[i] | 0xff000000) >>> 0;
  return buf;
}

// ---- input
const KEYMAP: Record<string, string> = {
  KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd',
  ArrowUp: 'w', ArrowLeft: 'a', ArrowDown: 's', ArrowRight: 'd',
  KeyR: 'r', KeyE: 'e', KeyQ: 'q', Digit1: '1', Digit2: '2',
  KeyB: 'b', KeyH: 'h', KeyN: 'n', KeyP: 'p', KeyG: 'g', KeyM: 'm', KeyC: 'c', KeyV: 'v', KeyL: 'l',
  Digit0: '0', ShiftLeft: 'shift', ShiftRight: 'shift',
  Tab: 'tab', Enter: 'enter', Escape: 'pause',
  Minus: 'zoomout', Equal: 'zoomin', NumpadSubtract: 'zoomout', NumpadAdd: 'zoomin',
  BracketLeft: 'zoomout', BracketRight: 'zoomin',
};
window.addEventListener('keydown', (ev) => {
  const k = KEYMAP[ev.code];
  if (!k) return;
  ev.preventDefault();
  if (!ev.repeat) inp.pressed.add(k);
  inp.keys.add(k);
  if (k === 'shift') inp.shiftDown = true;
});
window.addEventListener('keyup', (ev) => {
  const k = KEYMAP[ev.code];
  if (!k) return;
  inp.keys.delete(k);
  if (k === 'shift') inp.shiftDown = false;
});
window.addEventListener('blur', () => { inp.keys.clear(); inp.mouseDown = false; inp.rmbDown = false; });
canvas.addEventListener('wheel', (ev) => { ev.preventDefault(); inp.wheel = Math.sign(ev.deltaY) || 1; }, { passive: false });
canvas.addEventListener('contextmenu', (ev) => ev.preventDefault());
canvas.addEventListener('mousemove', (ev) => {
  const r = canvas.getBoundingClientRect();
  inp.mouseX = Math.max(0, Math.min(VIEW_W - 1, ((ev.clientX - r.left) / r.width) * VIEW_W));
  inp.mouseY = Math.max(0, Math.min(VIEW_H - 1, ((ev.clientY - r.top) / r.height) * VIEW_H));
});
canvas.addEventListener('mousedown', (ev) => {
  if (ev.button === 0) { inp.mouseDown = true; inp.pressed.add('lmb'); }
  if (ev.button === 2) { inp.rmbDown = true; inp.pressed.add('rmb'); }
});
window.addEventListener('mouseup', (ev) => {
  if (ev.button === 0) inp.mouseDown = false;
  if (ev.button === 2) inp.rmbDown = false;
});

// ---- loop
const img = ctx.createImageData(VIEW_W, VIEW_H);
let last = performance.now();
let acc = 0;
function frame(now: number) {
  acc += Math.min(0.1, (now - last) / 1000);
  last = now;
  let buf: PixelBuf;
  if (inp.pressed.has('p') && core.state === 'play') {
    editor.active = !editor.active;
    if (editor.active) core.toast('POSE MODE', P.text);
    inp.pressed.clear();
    acc = 0;
  }
  if (editor.active) {
    if (inp.pressed.has('pause')) {
      editor.active = false; inp.pressed.clear();
      buf = core.render();
    } else {
      editor.tick(inp, core, {
        copy: (s) => { void navigator.clipboard?.writeText(s); },
        save: (b2) => downloadPose(b2, `pose_${poseSaveN++}.png`),
      });
      buf = editor.render(core);
      inp.pressed.clear();
    }
    inp.wheel = 0;
    acc = 0;                                   // simulation frozen while in pose mode
  } else {
    while (acc >= DT) { core.update(DT, inp); acc -= DT; }
    buf = core.render();
    inp.wheel = 0;
  }
  img.data.set(new Uint8ClampedArray(buf.px.buffer));
  ctx.putImageData(img, 0, 0);
  requestAnimationFrame(frame);
}

loadGround()
  .then((g) => {
    core.setGround(g);
    requestAnimationFrame((t) => { last = t; frame(t); });
  })
  .catch((e) => {
    // run without baked ground (flat fill) if asset missing
    console.error('ground load failed, running with flat ground:', e);
    core.setGround(new PixelBuf(1, 1, rgba(60, 51, 42)));
    requestAnimationFrame((t) => { last = t; frame(t); });
  });
