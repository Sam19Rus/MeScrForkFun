import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { GameCore } from '../game/game.js';
import { NullSfx } from '../engine/audio.js';
import { decodePNG, encodePNG } from '../engine/png.js';
import { emptyInput, type InputState } from '../engine/input.js';
import { DT, VIEW_W, VIEW_H, PXM, ENEMY_DEFS } from '../game/config.js';
import { makeRng, rr } from '../core/rng.js';
import { genWeapon } from '../game/weapons.js';

/**
 * Headless QA driver: boots the same GameCore the browser uses, drives it with a scripted
 * "test player" policy (move / aim nearest / shoot / loot), dumps deterministic frames.
 * This is the BUILD -> INSPECT -> VALIDATE loop without a browser.
 */
export interface ShotSpec { tick: number; name: string }
export interface Intervention { tick: number; kind: 'goto_box' | 'kills_49' | 'zoom_out' | 'goto_capsule' | 'drop_common' | 'drop_legendary' }

export function runHeadless(opts: {
  outDir: string; shots: ShotSpec[]; ticks: number; seed?: number; interventions?: Intervention[];
}): Record<string, number | string> {
  const here = dirname(fileURLToPath(import.meta.url));
  const root = join(here, '..', '..');
  const core = new GameCore(new NullSfx());
  if (opts.seed !== undefined) core.runSeed = opts.seed;
  core.setGround(decodePNG(readFileSync(join(root, 'public', 'assets', 'ground.png'))));
  const iv = new Map((opts.interventions ?? []).map((i) => [i.tick, i.kind]));
  const inp: InputState = emptyInput();
  const bot = makeRng(555);
  let mode: 'idle' | 'strafe' = 'strafe';
  let modeT = 0;
  const stats = { shots: 0, kills: 0, credits: 0, pickups: 0 };
  const shotsTaken: string[] = [];
  const shotMap = new Map(opts.shots.map((s) => [s.tick, s.name]));

  mkdirSync(opts.outDir, { recursive: true });
  for (let t = 0; t < opts.ticks; t++) {
    // ---- bot policy
    inp.keys.clear();
    inp.pressed.clear();
    inp.mouseDown = false; inp.rmbDown = false;
    if (core.state === 'menu') {
      if (t === 20) inp.pressed.add('enter');
    } else if (core.state === 'play' && !core.paused) {
      modeT -= DT;
      if (modeT <= 0) { modeT = rr(bot, 0.6, 1.6); mode = bot() < 0.5 ? 'strafe' : 'idle'; }
      // keep some distance from nearest enemy: kite
      let ne: { x: number; y: number; deadT: number } | null = null;
      let nd = 1e9;
      for (const e of core.enemies) {
        if (e.deadT > 0) continue;
        const d = Math.hypot(e.x - core.px, e.y - core.py);
        if (d < nd) { nd = d; ne = e; }
      }
      if (ne && mode === 'strafe') {
        const dx = core.px - ne.x, dy = core.py - ne.y;
        const d = Math.hypot(dx, dy) || 1;
        let mx = 0, my = 0;
        if (d < 5 * PXM) { mx = dx / d; my = dy / d; }           // back off
        else if (d > 9 * PXM) { mx = -dx / d; my = -dy / d; }    // close in
        else { mx = -dy / d; my = dx / d; }                      // strafe
        if (mx < -0.3) inp.keys.add('a'); if (mx > 0.3) inp.keys.add('d');
        if (my < -0.3) inp.keys.add('w'); if (my > 0.3) inp.keys.add('s');
      }
      // aim nearest enemy through mouse (view space)
      if (ne) {
        const z = core.cam.zoom;
        inp.mouseX = Math.max(0, Math.min(VIEW_W - 1, ((ne.x - core.cam.left) / z.w) * VIEW_W));
        inp.mouseY = Math.max(0, Math.min(VIEW_H - 1, ((ne.y - 19 - core.cam.top) / z.h) * VIEW_H));
        if (nd < 13 * PXM) inp.mouseDown = true;
        if (nd < 1.05 * PXM && core.meleeT <= 0) inp.rmbDown = true;
      }
      // open nearest closed box when close
      for (const b of core.boxes) {
        if (!b.open && Math.hypot(b.x - core.px, b.y - core.py) < 1.2 * PXM) { inp.pressed.add('e'); break; }
      }
    }
    const kind = iv.get(t);
    if (kind === 'goto_box') {
      const box = core.boxes.find((b) => !b.open && b.kind === 'container');
      if (box) { core.px = box.x; core.py = box.y + 26; }
    } else if (kind === 'kills_49') {
      core.kills = 49;
    } else if (kind === 'zoom_out') {
      core.cam.cycleZoom(1);
    } else if (kind === 'goto_capsule') {
      const cap = core.boxes.find((b) => !b.open && b.kind === 'capsule');
      if (cap) { core.px = cap.x; core.py = cap.y + 26; }
    } else if (kind === 'drop_common' || kind === 'drop_legendary') {
      const w = genWeapon(4242, kind === 'drop_common' ? 'common' : 'legendary');
      w.score = kind === 'drop_common' ? 1 : 9999;   // force confiscate / pickup path for QA
      core.items.push({ x: core.px + 8, y: core.py + 4, item: w, t: 0 });
    }
    const prevKills = core.kills, prevConf = core.confiscated, prevW = core.weapon2;
    core.update(DT, inp);
    if (core.kills > prevKills) stats.kills = core.kills;
    if (core.confiscated > prevConf) stats.pickups += core.confiscated - prevConf;
    if (core.weapon2 !== prevW) stats.pickups++;
    stats.credits = core.credits;
    // ---- frame dump
    const name = shotMap.get(t);
    if (name) {
      const frame = core.render();
      writeFileSync(join(opts.outDir, `${name}.png`), encodePNG(frame));
      shotsTaken.push(name);
    }
  }
  return {
    ticks: opts.ticks, kills: core.kills, credits: core.credits, drops: core.drops,
    confiscated: core.confiscated, state: core.state, shots: shotsTaken.join(','),
    enemies: core.enemies.length, items: core.items.length,
    companion: core.companion && core.companion.downT <= 0 ? 1 : 0,
    weapon2: core.weapon2 ? `${core.weapon2.rarity}:${core.weapon2.score}` : 'none',
    armor: core.armor ? core.armor.rarity : 'none',
  };
}
