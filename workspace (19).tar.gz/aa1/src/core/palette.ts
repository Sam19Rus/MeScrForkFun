import { rgba } from './buf.js';

/**
 * AA1 palette. Ground/biome hues come from the production pipeline bake (tools/bake_aa1_ground.py);
 * here live UI, rarity, blood/spark, and character-skin ramps used by the runtime painters.
 * Rarity colors: common grey -> uncommon green -> rare blue -> epic violet -> legendary amber -> special teal.
 */
export const P = {
  ink:        rgba(0x0a, 0x0b, 0x0d),
  ink2:       rgba(0x14, 0x16, 0x1a),
  panel:      rgba(0x1b, 0x1e, 0x23),
  panelHi:    rgba(0x2a, 0x2e, 0x35),
  panelEdge:  rgba(0x3c, 0x41, 0x4a),
  text:       rgba(0xd8, 0xd4, 0xc8),
  textDim:    rgba(0x8a, 0x88, 0x80),
  hp:         rgba(0xc4, 0x3a, 0x2c),
  hpHi:       rgba(0xe2, 0x6a, 0x4c),
  credit:     rgba(0xe8, 0xc8, 0x6a),
  ammo:       rgba(0xb8, 0xc4, 0xcc),
  xp:         rgba(0x6a, 0xc8, 0xe8),
  blood:      rgba(0x8e, 0x1c, 0x18),
  bloodDark:  rgba(0x5c, 0x14, 0x10),
  spark:      rgba(0xff, 0xd8, 0x8a),
  sparkHot:   rgba(0xff, 0xf2, 0xd0),
  smoke:      rgba(0x55, 0x55, 0x55, 120),
  shadow:     rgba(0, 0, 0, 96),
  muzzle:     rgba(0xff, 0xe2, 0xa0),
  laserCore:  rgba(0xb8, 0xf0, 0xff),
  laserGlow:  rgba(0x48, 0xc8, 0xf0),
};

export const RARITY = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'special'] as const;
export type Rarity = (typeof RARITY)[number];
export const RARITY_COLOR: Record<Rarity, number> = {
  common:    rgba(0xb9, 0xb6, 0xaa),
  uncommon:  rgba(0x6f, 0xc4, 0x5e),
  rare:      rgba(0x5a, 0x9a, 0xe8),
  epic:      rgba(0xb4, 0x6a, 0xe0),
  legendary: rgba(0xe8, 0xa2, 0x3c),
  special:   rgba(0x3c, 0xd8, 0xc8),
};
export const RARITY_RU: Record<Rarity, string> = {
  common: 'ОБЫЧНОЕ', uncommon: 'НЕОБЫЧНОЕ', rare: 'РЕДКОЕ',
  epic: 'ЭПИЧЕСКОЕ', legendary: 'ЛЕГЕНДАРНОЕ', special: 'ОСОБОЕ',
};
/** Confiscation value per rarity (credits) - guild buys out worse gear. */
export const CONFISCATE_PRICE: Record<Rarity, number> = {
  common: 12, uncommon: 30, rare: 80, epic: 220, legendary: 600, special: 1500,
};

/** Skin / gang tint ramps for composite rigs (5-step: dark, mid, base, light, hi). */
export const SKIN_RAMPS: number[][] = [
  [0x4a, 0x2e, 0x1e], [0x7a, 0x52, 0x36], [0x9c, 0x6e, 0x4a], [0xb8, 0x8c, 0x62], [0xd0, 0xa8, 0x7e],
].map(([r, g, b]) => [rgba(r * 0.5 | 0, g * 0.5 | 0, b * 0.5 | 0), rgba(r * 0.75 | 0, g * 0.75 | 0, b * 0.75 | 0), rgba(r, g, b), rgba((r + 255) / 2 | 0, (g + 255) / 2 | 0, (b + 255) / 2 | 0), rgba(235, 215, 195)]);

/** Cloth/metal ramps per enemy gang + player (base rgb, ramp auto-derived). */
export function ramp5(base: [number, number, number]): number[] {
  const [r, g, b] = base;
  const f = (k: number) => rgba(Math.min(255, r * k) | 0, Math.min(255, g * k) | 0, Math.min(255, b * k) | 0);
  return [f(0.4), f(0.62), f(0.85), f(1.0), f(1.22)];
}
