import { hash2 } from './rng.js';

/** Cheap deterministic value noise (integer lattice + smoothstep), used for menu nebula and effects. */
export function vnoise(x: number, y: number, seed = 1): number {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const sx = xf * xf * (3 - 2 * xf), sy = yf * yf * (3 - 2 * yf);
  const n00 = (hash2(xi + seed * 977, yi) & 1023) / 1023;
  const n10 = (hash2(xi + 1 + seed * 977, yi) & 1023) / 1023;
  const n01 = (hash2(xi + seed * 977, yi + 1) & 1023) / 1023;
  const n11 = (hash2(xi + 1 + seed * 977, yi + 1) & 1023) / 1023;
  const a = n00 + (n10 - n00) * sx;
  const b = n01 + (n11 - n01) * sx;
  return a + (b - a) * sy;
}
export function fbm(x: number, y: number, oct = 4, seed = 1): number {
  let v = 0, amp = 0.5, f = 1, norm = 0;
  for (let i = 0; i < oct; i++) { v += vnoise(x * f, y * f, seed + i * 131) * amp; norm += amp; amp *= 0.5; f *= 2; }
  return v / norm;
}
