/** Deterministic RNG (mulberry32) + string/coord hashing. Every system takes its own stream. */
export type Rng = () => number;

export function makeRng(seed: number): Rng {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hash1(n: number): number {
  let h = (n | 0) ^ 0x9e3779b9;
  h = Math.imul(h ^ (h >>> 16), 0x21f0aaad);
  h = Math.imul(h ^ (h >>> 15), 0x735a2d97);
  return (h ^ (h >>> 15)) >>> 0;
}
export function hash2(x: number, y: number): number { return hash1(x * 374761393 + y * 668265263); }
export function hash3(x: number, y: number, z: number): number { return hash1(x * 374761393 + y * 668265263 + z * 2147483647); }

export function rr(r: Rng, a: number, b: number): number { return a + (b - a) * r(); }
export function ri(r: Rng, a: number, bInclusive: number): number { return a + Math.floor(r() * (bInclusive - a + 1)); }
export function pick<T>(r: Rng, arr: readonly T[]): T { return arr[Math.floor(r() * arr.length)]; }
export function chance(r: Rng, p: number): boolean { return r() < p; }
/** Weighted pick: weights need not sum to 1. */
export function wpick<T>(r: Rng, items: readonly T[], weights: readonly number[]): T {
  let total = 0; for (const w of weights) total += w;
  let t = r() * total;
  for (let i = 0; i < items.length; i++) { t -= weights[i]; if (t <= 0) return items[i]; }
  return items[items.length - 1];
}
