/** Software pixel buffer: Uint32 RGBA (little-endian 0xAABBGGRR). No canvas, no DOM. */
export type RGBA = number;

export function rgba(r: number, g: number, b: number, a = 255): RGBA {
  return ((r & 255) | ((g & 255) << 8) | ((b & 255) << 16) | ((a & 255) << 24)) >>> 0;
}
export const rOf = (c: RGBA) => c & 255;
export const gOf = (c: RGBA) => (c >>> 8) & 255;
export const bOf = (c: RGBA) => (c >>> 16) & 255;
export const aOf = (c: RGBA) => (c >>> 24) & 255;
export function shade(c: RGBA, f: number): RGBA {
  const r = Math.min(255, Math.round(((c) & 255) * f));
  const g = Math.min(255, Math.round(((c >>> 8) & 255) * f));
  const b = Math.min(255, Math.round(((c >>> 16) & 255) * f));
  return rgba(r, g, b, (c >>> 24) & 255);
}
export function mixc(a: RGBA, b: RGBA, t: number): RGBA {
  const u = 1 - t;
  return rgba(
    Math.round((a & 255) * u + (b & 255) * t),
    Math.round(((a >>> 8) & 255) * u + ((b >>> 8) & 255) * t),
    Math.round(((a >>> 16) & 255) * u + ((b >>> 16) & 255) * t),
    255,
  );
}

export class PixelBuf {
  readonly w: number; readonly h: number; readonly px: Uint32Array;
  constructor(w: number, h: number, fill: RGBA = 0) {
    this.w = w; this.h = h; this.px = new Uint32Array(w * h);
    if (fill) this.px.fill(fill);
  }
  inB(x: number, y: number): boolean { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  get(x: number, y: number): RGBA { return this.px[y * this.w + x]; }
  set(x: number, y: number, c: RGBA): void { if (this.inB(x | 0, y | 0)) this.px[(y | 0) * this.w + (x | 0)] = c; }
  /** Alpha-over composite (straight alpha, integer math, deterministic). */
  blend(x: number, y: number, c: RGBA): void {
    x = x | 0; y = y | 0; if (!this.inB(x, y)) return;
    const a = (c >>> 24) & 255; if (a === 0) return;
    const i = y * this.w + x;
    if (a === 255) { this.px[i] = c; return; }
    const d = this.px[i];
    const r = ((c & 255) * a + (d & 255) * (255 - a)) / 255 | 0;
    const g = (((c >>> 8) & 255) * a + ((d >>> 8) & 255) * (255 - a)) / 255 | 0;
    const b = (((c >>> 16) & 255) * a + ((d >>> 16) & 255) * (255 - a)) / 255 | 0;
    this.px[i] = rgba(r, g, b, 255);
  }
  fill(c: RGBA): void { this.px.fill(c); }
  rect(x: number, y: number, w: number, h: number, c: RGBA): void {
    let x0 = Math.max(0, x | 0), y0 = Math.max(0, y | 0);
    let x1 = Math.min(this.w, (x | 0) + w), y1 = Math.min(this.h, (y | 0) + h);
    for (let yy = y0; yy < y1; yy++) this.px.fill(c, yy * this.w + x0, yy * this.w + x1);
  }
  /** 1px frame rect. */
  frame(x: number, y: number, w: number, h: number, c: RGBA): void {
    this.hline(x, y, w, c); this.hline(x, y + h - 1, w, c);
    this.vline(x, y, h, c); this.vline(x + w - 1, y, h, c);
  }
  hline(x: number, y: number, w: number, c: RGBA): void {
    y = y | 0; if (y < 0 || y >= this.h) return;
    const x0 = Math.max(0, x | 0), x1 = Math.min(this.w, (x | 0) + w);
    for (let i = x0; i < x1; i++) this.px[y * this.w + i] = c;
  }
  vline(x: number, y: number, h: number, c: RGBA): void {
    x = x | 0; if (x < 0 || x >= this.w) return;
    const y0 = Math.max(0, y | 0), y1 = Math.min(this.h, (y | 0) + h);
    for (let yy = y0; yy < y1; yy++) this.px[yy * this.w + x] = c;
  }
  /** Bresenham line. */
  line(x0: number, y0: number, x1: number, y1: number, c: RGBA): void {
    let sx = x0 | 0, sy = y0 | 0; const ex = x1 | 0, ey = y1 | 0;
    const dx = Math.abs(ex - sx), dy = -Math.abs(ey - sy);
    const stepx = sx < ex ? 1 : -1, stepy = sy < ey ? 1 : -1;
    let err = dx + dy;
    for (;;) {
      this.set(sx, sy, c);
      if (sx === ex && sy === ey) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; sx += stepx; }
      if (e2 <= dx) { err += dx; sy += stepy; }
    }
  }
  /** Filled circle (pixel-exact, symmetric). */
  disc(cx: number, cy: number, r: number, c: RGBA): void {
    const r2 = r * r;
    for (let dy = -r; dy <= r; dy++) {
      const dx = Math.floor(Math.sqrt(Math.max(0, r2 - dy * dy)));
      this.hline(cx - dx, cy + dy, dx * 2 + 1, c);
    }
  }
  /** Alpha-blended disc (shadows, AO, glows). */
  discA(cx: number, cy: number, r: number, c: RGBA): void {
    const r2 = r * r;
    for (let dy = -r; dy <= r; dy++) {
      const dx = Math.floor(Math.sqrt(Math.max(0, r2 - dy * dy)));
      for (let x = cx - dx; x <= cx + dx; x++) this.blend(x, cy + dy, c);
    }
  }
  ring(cx: number, cy: number, r: number, c: RGBA): void {
    const steps = Math.max(8, (r * 6) | 0);
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      this.set(Math.round(cx + Math.cos(a) * r), Math.round(cy + Math.sin(a) * r), c);
    }
  }
  /** Opaque blit at integer pos (src clipped). */
  blit(src: PixelBuf, dx: number, dy: number, sx = 0, sy = 0, sw = -1, sh = -1): void {
    const w = sw < 0 ? src.w : sw, h = sh < 0 ? src.h : sh;
    for (let y = 0; y < h; y++) {
      const ty = dy + y; if (ty < 0 || ty >= this.h) continue;
      for (let x = 0; x < w; x++) {
        const tx = dx + x; if (tx < 0 || tx >= this.w) continue;
        const c = src.get(sx + x, sy + y);
        if ((c >>> 24) === 0) continue;
        this.px[ty * this.w + tx] = c;
      }
    }
  }
  /** Alpha blit. */
  blitA(src: PixelBuf, dx: number, dy: number): void {
    for (let y = 0; y < src.h; y++)
      for (let x = 0; x < src.w; x++) {
        const c = src.get(x, y); if ((c >>> 24) === 0) continue;
        this.blend(dx + x, dy + y, c);
      }
  }
  /** Tinted blit: multiply rgb by k (for flash/shadow variants). */
  blitTint(src: PixelBuf, dx: number, dy: number, k: number): void {
    for (let y = 0; y < src.h; y++)
      for (let x = 0; x < src.w; x++) {
        const c = src.get(x, y); if ((c >>> 24) === 0) continue;
        this.blend(dx + x, dy + y, shade(c, k));
      }
  }
  /** Nearest downscale by factor f>1 into a 640x360-style target. */
  static downscale(src: PixelBuf, tw: number, th: number): PixelBuf {
    const out = new PixelBuf(tw, th);
    for (let y = 0; y < th; y++) {
      const sy = ((y * src.h / th) | 0) * src.w;
      for (let x = 0; x < tw; x++) out.px[y * tw + x] = src.px[sy + (x * src.w / tw | 0)];
    }
    return out;
  }
}
