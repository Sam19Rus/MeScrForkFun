const fs = require('fs');
const path = require('path');
(async () => {
  const { createExtractorFromData } = require('node-unrar-js');
  const data = fs.readFileSync(path.join(__dirname, '..', 'downloads', 'aa1.rar'));
  const ab = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  const extractor = await createExtractorFromData({ data: ab });
  const ex = extractor.extract({});
  const files = [...ex.files];
  let count = 0, totalBytes = 0;
  const outRoot = path.join(__dirname, '..');
  for (const f of files) {
    const h = f.fileHeader;
    if (!f.extraction) continue;
    const out = path.join(outRoot, h.name);
    if (out.indexOf('..') !== -1) continue;
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, Buffer.from(f.extraction));
    count++; totalBytes += f.extraction.length;
  }
  console.log('EXTRACTED FILES:', count, 'BYTES:', totalBytes);
})().catch(e => { console.error('ERR', e); process.exit(1); });
