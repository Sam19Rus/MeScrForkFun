import urllib.request, urllib.parse, re, sys, html as H

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9'}


def get(url, data=None):
    req = urllib.request.Request(url, headers=UA, data=data)
    return urllib.request.urlopen(req, timeout=40).read().decode('utf-8', 'ignore')


def ddg(q, n=30):
    body = urllib.parse.urlencode({'q': q, 'kl': 'us-en'}).encode()
    htm = get('https://html.duckduckgo.com/html/', data=body)
    res = []
    for m in re.finditer(r'<a rel="nofollow" class="result__a" href="([^"]+)">(.*?)</a>', htm, re.S):
        url, title = m.group(1), re.sub('<[^>]+>', '', m.group(2))
        if 'uddg=' in url:
            url = urllib.parse.unquote(re.search(r'uddg=([^&]+)', url).group(1))
        res.append((H.unescape(title).strip(), url))
        if len(res) >= n:
            break
    snips = [re.sub('<[^>]+>', '', s) for s in re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', htm, re.S)]
    return res, snips


if __name__ == '__main__':
    q = sys.argv[1]
    res, snips = ddg(q)
    for (t, u), s in zip(res, snips + [''] * len(res)):
        print(f'- {t}\n  {u}\n  {H.unescape(s).strip()[:250]}\n')
