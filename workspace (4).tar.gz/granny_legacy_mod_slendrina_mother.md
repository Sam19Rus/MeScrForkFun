# Мод «Мать Слендерины можно воскресить, и она станет врагом» — найдено ✅

Дата исследования: 30.09.2026

## Что это за мод

**Granny Remake 2026** (раньше назывался *Granny 1 2026 Remake* / *Granny 1.8 Remake*)
Автор: **Candy** (GameJolt: `@Candy522` и старый аккаунт `@Candy_Yu_522`, она же канал LGC / LGC_yyz / LGC_HorrorGame)

⚠️ **Важно:** это **не мод-надстройка на Granny Legacy**, а **отдельная самостоятельная фан-игра**
(ремейк первой Granny). Ставится отдельно, Steam и купленная Granny не нужны. Именно в ней есть
та самая механика воскрешения Матери Слендерины, которую ты видел(а) на англоязычном YouTube.

## Скачать (бесплатно)

| Что | Версия | Размер | Ссылка |
|---|---|---|---|
| **Granny Remake 2026 — PC (актуальная страница автора)** | **1.7.7** | 567 МБ | https://gamejolt.com/games/grannyremake2026/1071536 |
| Granny Remake 2026 — Mobile | 1.8.53 | — | та же страница |
| Granny 1 2026 Remake (старая страница, 215k просмотров) | 1.7.0 | 565 МБ | https://gamejolt.com/games/G12026Remake/1039954 |
| Страница автора @Candy522 | — | — | https://gamejolt.com/@Candy522/games |
| Старый аккаунт автора @Candy_Yu_522 (все её игры) | — | — | https://gamejolt.com/@Candy_Yu_522/games |
| Сообщество «Granny 2026 Remake» (636 участников) | — | — | https://gamejolt.com/c/G12026Remake-yk5pan |
| Discord автора | — | — | https://discord.gg/GxJEahbbVy |
| Старая версия Granny 1.8 Remake (v1.0.3) | 1.0.3 | 993 МБ | https://gamejolt.com/games/G1RemakeLGC_HorrorGame/1045899 |
| То же самое зеркалом от BlueLightningSpecter | 0.2.0 | 105 МБ | https://gamejolt.com/games/lchorrrorgame/1059157 |
| Ещё её мод: Granny 1.9 Unofficial (Test Version) | 0.1.0 | 1 ГБ | https://gamejolt.com/games/G1Unnoficial/1059675 |

На странице `grannyremake2026/1071536` кнопка **Download (567 MB)** — это PC-сборка.
В changelog версии 1.7.0 прямо написано: **«Improved SlendrinaMom (On testing)»**.

## Как работает Мать Слендерины в этом моде

Цитата из описания мода (перевод):

- В **Extra Options** включается **«Add Slendrina's Mother»**.
- **«Как только ты подберёшь книгу (book) — она воскресает и начинает ходить за тобой»**.
- Если её убить, тело нужно **поднять и отрубить ей голову на гильотине** — оттуда выпадает **ключ**.
- В версии **1.7** она научилась **выламывать двери** — прятаться за закрытой дверью больше не спасает.
- Есть отдельная опция **«Add Slendrina»** (дочь) — она «безумно умная» и атакует,
  как только кто-то из «родителей» тебя заметит.
- Дополнительно: **Play As** (можно играть за Spider Mom, Bat Granny, Dynamite Granny,
  Cane/Shotgun Grandpa), новый враг **Evil Rat**, режимы/челленджи (Super Speed, Random Gravity,
  Teleport Enemies, Crouchable Grandparents, Impossible), Visitor (неуязвимая Гренни из Remake),
  мини-карта, фонарь/лампа, цветовые фильтры.

## Видео (по ним видно, что это именно тот мод)

- «Resurrecting Slendrina Mother in Granny Update!! New Ending with Slendrina Mother» — 1 034 650 просмотров
  https://www.youtube.com/watch?v=Jwga33DzVnU  (в описании: «This game is made by my friend @Candy_Yu_522»)
- «Granny Unofficial (v1.8): Slendrina's Mom can ressurected? Extreme Mode Full Game Play» (канал самой Candy)
  https://www.youtube.com/watch?v=SSgt_yGhbJc
- «Resurrected Slendrina Mom On Granny 1???» (Candy / LGC_yyz)
  https://www.youtube.com/watch?v=foqMeWelznE
- «Resurrecting Slendrina Mom In Granny V1.8 Remake Extreme Nightmare Mode But Enemies Is Invisible»
  https://www.youtube.com/watch?v=2xRqrTg5EkA
- «Granny 1.8 Remake with Stun Gun, Slendrina Mom as enemy and more…»
  https://www.youtube.com/watch?v=YU7iNLVVZVQ
- «Granny (PC) V1.8 Remake With Slendrina's Mother — Four Enemies On The House» — 380 017 просмотров
  https://www.youtube.com/watch?v=MioEdwDj4W8
- «Granny Remake 2026 New update 1.7 — Now Slendrina's Mom can break doors»
  https://www.youtube.com/watch?v=qlL_LIjregE
- «Granny Slendrina's Mom Can Break Doors | Granny Remake Update»
  https://www.youtube.com/watch?v=OUyxOXR_N1I
- Обзор со списком всех фич (в т.ч. пункт 7 — про Мать Слендерины и гильотину):
  https://www.youtube.com/watch?v=BxmbBOOTfnI
- «Granny Remake 2026 Mobile Using All New Weapons Against Slendrina's Mom!»
  https://www.youtube.com/watch?v=lUY9qRWpZ9k

---

# Если всё-таки нужен именно Granny Legacy (OmGi)

В самой Legacy Мать Слендерины есть только в паучьей форме — **Spider Mom** сидит в паучьем подвале
(Spider Mom = мутировавшая Мать Слендерины, добавлена в Granny v1.8):
https://granny.fandom.com/wiki/Spider_Mom

Опции «Мать Слендерины в человеческом облике + воскрешение» в официальной Legacy **нет** —
это пока только запрос фанатов в комментариях на GameJolt (предлагали: книга исчезает,
вместо неё рычаг открывает книжный шкаф, мама выходит охотиться, оглушается арбалетом/дробовиком,
число ударов зависит от сложности). В патчах v1.9.0/v1.9.1 этого не добавили.
Официальная страница Legacy: https://gamejolt.com/games/grannylegacy/1011593 (PC v1.9.1, 639 МБ)

Что можно сделать в Legacy:

1. **Мод «Spider Mom Inside House» для Legacy** (автор BlueLightningSpecter) — Mama-паук выходит
   из подвала и охотится по дому + фонарик.
   - Видео со ссылками: https://www.youtube.com/watch?v=7ImcikTF4WQ
   - Геймплей: https://www.youtube.com/watch?v=wjrYG5Iq9Xg
   - Ссылка из описания (это APK, мобильный порт; на 30.09.2026 отдаёт 404 — свежую ссылку
     брать в описании/комментариях видео):
     `https://www.mediafire.com/file/43js6kwk0cqizta/Granny__Legacy_Spider_Mom_Inside_House_+_Flashlight_signed.apk/file`
   - Все моды автора: https://gamejolt.com/@BlueLightningSpecter/games
2. **Мод-меню для Legacy (ПК)** — заспавнить/клонировать любого врага, включая Spider Mom:
   - Bluelands_Modz's Granny Legacy Mod Menu (PC 1.8.8, 613/620 МБ; Spawn NPCs, Clone Enemies,
     Resize Enemies, ESP): https://gamejolt.com/games/bluelands_grannylegacy/1077481
     Видео: https://www.youtube.com/watch?v=29fQegSDQ0w
   - Granny Legacy Mod Menu by RahilPlayz1: https://gamejolt.com/games/grannylegacymodmenu/1025436
   - GRANNY LEGACY MOD MENU by GenoMux: https://gamejolt.com/games/granny-legacy-mod-menu/1048772
   - Granny Legacy EXE Mod by Little_L: https://gamejolt.com/games/Granny-Legacy-EXE-Mod/1074747
   - Хаб Legacy-модов и атмосфер (SummerYT, страница помечена «mature» — нажать «Proceed to Game»):
     https://gamejolt.com/games/grannylegacy/1028393
3. Ещё один будущий кандидат: **gabzin1** — «UPDATE! Slendrina's Mom is ALIVE on Granny's House!»
   https://www.youtube.com/watch?v=xDYVFqSU92I — в описании **«Link: Private for now!»**,
   мод ещё не выпущен (автор чинит баги). Игры автора: https://gamejolt.com/@gabzin011/games

## Русскоязычные площадки, где стоит спросить/поискать

- Telegram «Groyhell» — моды и игры по Granny (2,9K подписчиков, 293 файла): https://t.me/grannylegacygast
  предложка: `@Granny_mods_groyhell_bot`, `@Granny_mods_predlozhka_bot`
- Второй ТГ-канал по Legacy: https://t.me/s/GrannyLegacyYT
- Гайд «Как установить любой мод по Гренни» (Steam, RU): https://steamcommunity.com/sharedfiles/filedetails/?l=russian&id=3596204601
- Гайд «Как скачать Granny Legacy» (Steam, RU): https://steamcommunity.com/sharedfiles/filedetails/?id=3669972068
- Оффлайн-сборки Legacy + changelog'и: https://github.com/takivn0/GrannyLegacyOffline/releases

## Безопасность

В этой нише куча перезаливов «модов» с троянами (MediaFire / Google Drive / Telegram).
Качай только со страницы автора на GameJolt (`@Candy522` / `@Candy_Yu_522`), сверяй ник автора
в описании видео, не запускай .exe из чужих архивов и прогоняй файл через VirusTotal.
