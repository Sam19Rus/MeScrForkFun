import urllib.request, urllib.parse, json, re, sys, time

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9'}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=40).read().decode('utf-8', 'ignore')


def yt_search(query, n=25):
    url = 'https://www.youtube.com/results?search_query=' + urllib.parse.quote(query)
    html = get(url)
    m = re.search(r'var ytInitialData = (\{.*?\});</script>', html, re.S)
    if not m:
        m = re.search(r'ytInitialData"?\s*[:=]\s*(\{.*?\});', html, re.S)
    if not m:
        print('NO DATA', len(html))
        return []
    data = json.loads(m.group(1))
    vids = []

    def walk(o):
        if isinstance(o, dict):
            if 'videoRenderer' in o:
                v = o['videoRenderer']
                vid = v.get('videoId')
                title = ''.join(r.get('text', '') for r in v.get('title', {}).get('runs', []))
                ch = ''.join(r.get('text', '') for r in v.get('ownerText', {}).get('runs', []))
                pub = v.get('publishedTimeText', {}).get('simpleText', '')
                views = v.get('viewCountText', {}).get('simpleText', '')
                length = v.get('lengthText', {}).get('simpleText', '')
                desc = ''.join(r.get('text', '') for r in v.get('detailedMetadataSnippets', [{}])[0].get('snippetText', {}).get('runs', [])) if v.get('detailedMetadataSnippets') else ''
                vids.append((vid, title, ch, pub, views, length, desc))
            for k in o.values():
                walk(k)
        elif isinstance(o, list):
            for k in o:
                walk(k)
    walk(data)
    out = []
    seen = set()
    for v in vids:
        if v[0] in seen:
            continue
        seen.add(v[0])
        out.append(v)
        if len(out) >= n:
            break
    return out


if __name__ == '__main__':
    q = sys.argv[1]
    for vid, title, ch, pub, views, length, desc in yt_search(q):
        print(f'* {title}\n  https://www.youtube.com/watch?v={vid}\n  [{ch}] {pub} | {views} | {length}\n  {desc[:220]}\n')
