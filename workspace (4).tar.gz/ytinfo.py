import urllib.request, urllib.parse, json, re, sys, gzip, io

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9', 'Accept-Encoding': 'gzip'}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    r = urllib.request.urlopen(req, timeout=40)
    data = r.read()
    if r.headers.get('Content-Encoding') == 'gzip':
        data = gzip.GzipFile(fileobj=io.BytesIO(data)).read()
    return data.decode('utf-8', 'ignore')


def info(vid):
    html = get('https://www.youtube.com/watch?v=' + vid + '&hl=en&bpctr=9999999999&has_verified=1')
    m = re.search(r'ytInitialPlayerResponse\s*=\s*(\{.*?\});(?:var |</script>)', html, re.S)
    if not m:
        m = re.search(r'ytInitialPlayerResponse"?\s*=\s*(\{.*?\})\s*;', html, re.S)
    if not m:
        print(vid, ': no player response, len', len(html))
        return
    try:
        d = json.loads(m.group(1))
    except Exception as e:
        print(vid, 'json err', e)
        return
    vd = d.get('videoDetails', {})
    print('=' * 72)
    print('TITLE:', vd.get('title'))
    print('CHANNEL:', vd.get('author'), '| views:', vd.get('viewCount'))
    print('URL: https://www.youtube.com/watch?v=' + vid)
    print('DESC:')
    print((vd.get('shortDescription') or '')[:2000])


if __name__ == '__main__':
    for v in sys.argv[1:]:
        try:
            info(v)
        except Exception as e:
            print(v, 'ERR', e)
