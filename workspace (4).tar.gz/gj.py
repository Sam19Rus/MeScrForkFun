import urllib.request, urllib.parse, json, re, sys

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9'}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=40).read().decode('utf-8', 'ignore')


def gj_search(q):
    url = 'https://gamejolt.com/site/search/games?q=' + urllib.parse.quote(q)
    html = get(url)
    m = re.search(r'"searchPayload":(\{.*?\})\s*,\s*"', html, re.S)
    out = []
    # generic scrape of game cards
    for mm in re.finditer(r'\{"id":(\d+),"type":"Game"[^}]*?\}', html):
        out.append(mm.group(0)[:400])
    return html, out


if __name__ == '__main__':
    q = sys.argv[1] if len(sys.argv) > 1 else 'granny legacy'
    html, out = gj_search(q)
    with open('gj_out.html', 'w') as f:
        f.write(html)
    print('LEN', len(html))
    print('CARDS', len(out))
    for o in out[:20]:
        print(o[:300])
        print('---')
