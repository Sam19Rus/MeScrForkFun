import urllib.request, urllib.parse, json, re, sys

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9'}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=40).read().decode('utf-8', 'ignore')


def desc(vid):
    html = get('https://www.youtube.com/watch?v=' + vid + '&hl=en')
    m = re.search(r'"shortDescription":"((?:[^"\\]|\\.)*)"', html)
    t = re.search(r'<meta name="title" content="([^"]+)"', html)
    d = ''
    if m:
        d = m.group(1).encode().decode('unicode_escape')
    print('=' * 70)
    print('TITLE:', t.group(1) if t else '?')
    print('URL: https://www.youtube.com/watch?v=' + vid)
    print(d[:2500])


if __name__ == '__main__':
    for v in sys.argv[1:]:
        try:
            desc(v)
        except Exception as e:
            print(v, 'ERR', e)
