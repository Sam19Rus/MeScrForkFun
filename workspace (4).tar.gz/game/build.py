#!/usr/bin/env python3
"""Сборка single-file HTML: three.js + код игры инлайнятся в шаблон."""
import io, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, 'src')
THREE = os.path.join(ROOT, '..', 'vendor_three.min.js')
OUT = os.path.join(ROOT, '..', 'quiet-house.html')

ORDER = ['a_core.js', 'b_audio.js', 'c_world.js', 'd_player.js', 'e_game.js']

EXPORT = """
/* отладочный доступ из консоли */
window.QH = {
  Game: Game, Player: Player, Enemy: Enemy, World: World, Sound: Sound, UI: UI,
  Input: Input, Jar: Jar, Noise: Noise, CFG: CFG, ROOMS: ROOMS, DOORS: DOORS,
  ITEM_DEFS: ITEM_DEFS, FX: FX, FZ: FZ, txOf: txOf, tzOf: tzOf, roomNameAt: roomNameAt,
  blockedAt: blockedAt, lineOfSight: lineOfSight, findPath: findPath,
  findPathForce: findPathForce, canStep: canStep, edgeOpen: edgeOpen,
  doorBetween: doorBetween, rebuildLOS: rebuildLOS, spawnItems: spawnItems,
  Enemy2: null
};
window.QH.losSize = function () { return [losW, losH]; };
"""


def read(p):
    with io.open(p, 'r', encoding='utf-8') as f:
        return f.read()


def main():
    tpl = read(os.path.join(SRC, 'template.html'))
    three = read(THREE)
    parts = []
    for n in ORDER:
        parts.append('/* ==== %s ==== */\n%s' % (n, read(os.path.join(SRC, n))))
    game = "'use strict';\n" + '\n\n'.join(parts) + '\n' + EXPORT

    for blob, name in ((three, 'three'), (game, 'game')):
        if '</script' in blob.lower():
            sys.exit('FATAL: %s содержит </script>' % name)

    assert '/*__THREE__*/' in tpl and '/*__GAME__*/' in tpl, 'плейсхолдеры не найдены'
    html = tpl.replace('/*__THREE__*/', three, 1).replace('/*__GAME__*/', game, 1)
    with io.open(OUT, 'w', encoding='utf-8') as f:
        f.write(html)
    print('OK ->', OUT)
    print('   three.js : %8d bytes' % len(three))
    print('   game code: %8d bytes' % len(game))
    print('   total    : %8d bytes (%.2f MB)' % (len(html), len(html.encode('utf-8')) / 1048576.0))


if __name__ == '__main__':
    main()
