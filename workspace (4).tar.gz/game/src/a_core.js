/* ============================================================
   ТИХИЙ ДОМ — ядро: конфиг, утилиты, процедурные текстуры
   ============================================================ */

const CFG = {
  CELL: 1.9,          // размер клетки сетки (метры)
  WALL_H: 3.05,       // высота стен
  WALL_T: 0.16,       // толщина стен
  GW: 16, GH: 13,     // размер сетки дома в клетках

  EYE: 1.62,          // высота глаз стоя
  CROUCH_EYE: 0.92,   // высота глаз в присяде
  P_RAD: 0.30,        // радиус коллизии игрока

  WALK: 2.05, SPRINT: 4.15, CROUCH: 1.05,
  STAMINA: 100, STAM_DRAIN: 21, STAM_REGEN: 13,

  DAYS: 5,

  // враг
  E_PATROL: 1.30, E_INVEST: 1.95, E_CHASE: 3.55, E_SEARCH: 1.55,
  E_RAD: 0.34,
  E_FOV: 115 * Math.PI / 180,
  E_SIGHT_DARK: 6.5,
  E_SIGHT_LIT: 13.0,
  E_SIGHT_TORCH: 21.0,   // с включённым фонарём тебя видно дальше
  E_HEAR_MULT: 1.0,
  E_CATCH: 1.05,

  TORCH_DRAIN: 1.55,     // % заряда в секунду
};

const TAU = Math.PI * 2;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const dampf = (a, b, l, dt) => lerp(a, b, 1 - Math.exp(-l * dt));
const dist2 = (ax, az, bx, bz) => { const dx = ax - bx, dz = az - bz; return dx * dx + dz * dz; };
const dist = (ax, az, bx, bz) => Math.sqrt(dist2(ax, az, bx, bz));
const smoothstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
const pick = (rng, arr) => arr[(rng() * arr.length) | 0];
const randRange = (rng, a, b) => a + rng() * (b - a);

/* детерминированный ГСЧ */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

/* координаты клетки -> мировые */
const wx = tx => (tx + 0.5) * CFG.CELL;
const wz = ty => (ty + 0.5) * CFG.CELL;
const txOf = x => Math.floor(x / CFG.CELL);
const tzOf = z => Math.floor(z / CFG.CELL);

/* ============================================================
   ПРОЦЕДУРНЫЕ ТЕКСТУРЫ (canvas, без внешних файлов)
   ============================================================ */
const TexLib = (() => {
  const cache = {};

  function canvas(size) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    return c;
  }

  function hash(x, y, s) {
    let h = x * 374761393 + y * 668265263 + s * 1442695040;
    h = (h ^ (h >>> 13)) * 1274126177;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
  }

  /* дешёвый «облачный» шум */
  function fbm(ctx, size, seed, octaves, alpha, tint) {
    for (let o = 0; o < octaves; o++) {
      const cells = 2 << o;
      const s = size / cells;
      const g = [];
      for (let y = 0; y <= cells; y++) { g[y] = []; for (let x = 0; x <= cells; x++) g[y][x] = hash(x, y, seed + o * 131); }
      for (let py = 0; py < size; py += 2) {
        for (let px = 0; px < size; px += 2) {
          const gx = px / s, gy = py / s;
          const x0 = gx | 0, y0 = gy | 0;
          const fx = gx - x0, fy = gy - y0;
          const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
          const a = g[y0][x0], b = g[y0][x0 + 1] !== undefined ? g[y0][x0 + 1] : g[y0][x0];
          const c = g[y0 + 1] ? g[y0 + 1][x0] : a;
          const d = g[y0 + 1] && g[y0 + 1][x0 + 1] !== undefined ? g[y0 + 1][x0 + 1] : c;
          const v = lerp(lerp(a, b, sx), lerp(c, d, sx), sy);
          ctx.fillStyle = `rgba(${tint[0]},${tint[1]},${tint[2]},${(v * alpha).toFixed(3)})`;
          ctx.fillRect(px, py, 2, 2);
        }
      }
    }
  }

  function stain(ctx, size, rng, n, col, maxR) {
    for (let i = 0; i < n; i++) {
      const x = rng() * size, y = rng() * size, r = rng() * maxR + 4;
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, col.replace('A', (0.10 + rng() * 0.20).toFixed(3)));
      g.addColorStop(1, col.replace('A', '0'));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    }
  }

  function finish(c, rx, ry, aniso) {
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(rx, ry);
    t.encoding = THREE.sRGBEncoding;
    t.anisotropy = aniso || 4;
    return t;
  }

  /* --- доски --- */
  function wood(key, base, dark, rx, ry, vertical) {
    if (cache[key]) return cache[key].clone();
    const S = 256, c = canvas(S), g = c.getContext('2d');
    const rng = mulberry32(7 + key.length * 13);
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    const planks = 5, pw = S / planks;
    for (let i = 0; i < planks; i++) {
      const v = 0.82 + rng() * 0.36;
      g.fillStyle = shade(base, v); g.fillRect(i * pw, 0, pw - 1.5, S);
      // волокна
      for (let k = 0; k < 42; k++) {
        g.strokeStyle = `rgba(0,0,0,${(0.03 + rng() * 0.10).toFixed(3)})`;
        g.lineWidth = 0.6 + rng() * 1.3;
        const x = i * pw + rng() * pw;
        g.beginPath(); g.moveTo(x, 0);
        g.bezierCurveTo(x + rng() * 6 - 3, S * 0.33, x + rng() * 6 - 3, S * 0.66, x + rng() * 4 - 2, S);
        g.stroke();
      }
      g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(i * pw + pw - 1.5, 0, 1.5, S);
    }
    // поперечные стыки
    for (let i = 0; i < planks; i++) {
      const y = rng() * S;
      g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(i * pw, y, pw - 1.5, 1.4);
    }
    fbm(g, S, 21, 3, 0.30, [0, 0, 0]);
    fbm(g, S, 91, 2, 0.13, [255, 240, 210]);
    stain(g, S, rng, 7, 'rgba(20,10,4,A)', 46);
    const t = finish(c, rx, ry);
    t.needsUpdate = true;
    cache[key] = t;
    return t.clone();
  }

  /* --- обои с узором --- */
  function wallpaper(key, base, pat, rx, ry) {
    if (cache[key]) return cache[key].clone();
    const S = 256, c = canvas(S), g = c.getContext('2d');
    const rng = mulberry32(31 + key.length * 7);
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    // вертикальные полосы
    for (let x = 0; x < S; x += 32) {
      g.fillStyle = `rgba(255,255,255,0.035)`; g.fillRect(x, 0, 14, S);
    }
    // дамасский мотив
    g.strokeStyle = pat; g.fillStyle = pat; g.lineWidth = 1.6;
    for (let y = 16; y < S; y += 48) {
      for (let x = 16; x < S; x += 48) {
        const ox = ((y / 48) % 2) * 24;
        g.save(); g.translate(x + ox, y); g.globalAlpha = 0.55;
        g.beginPath();
        g.moveTo(0, -13); g.bezierCurveTo(11, -6, 11, 8, 0, 15);
        g.bezierCurveTo(-11, 8, -11, -6, 0, -13);
        g.stroke();
        g.beginPath(); g.arc(0, 0, 2.6, 0, TAU); g.fill();
        g.restore();
      }
    }
    g.globalAlpha = 1;
    fbm(g, S, 55, 3, 0.34, [0, 0, 0]);
    stain(g, S, rng, 12, 'rgba(46,26,10,A)', 54);
    stain(g, S, rng, 5, 'rgba(90,10,6,A)', 30);
    // отходящие обои
    for (let i = 0; i < 3; i++) {
      const x = rng() * S, y = rng() * S * 0.6;
      g.fillStyle = 'rgba(0,0,0,0.30)';
      g.beginPath(); g.moveTo(x, y); g.lineTo(x + 10 + rng() * 16, y + 24 + rng() * 40); g.lineTo(x - 6, y + 30 + rng() * 30); g.closePath(); g.fill();
    }
    const t = finish(c, rx, ry); cache[key] = t; return t.clone();
  }

  /* --- плитка --- */
  function tile(key, base, grout, rx, ry, n) {
    if (cache[key]) return cache[key].clone();
    const S = 256, c = canvas(S), g = c.getContext('2d');
    const rng = mulberry32(97 + n);
    const k = n || 8, ts = S / k;
    g.fillStyle = grout; g.fillRect(0, 0, S, S);
    for (let y = 0; y < k; y++) for (let x = 0; x < k; x++) {
      g.fillStyle = shade(base, 0.86 + rng() * 0.3);
      g.fillRect(x * ts + 1.4, y * ts + 1.4, ts - 2.8, ts - 2.8);
      if (rng() < 0.14) { // трещина
        g.strokeStyle = 'rgba(0,0,0,0.5)'; g.lineWidth = 0.9;
        g.beginPath(); g.moveTo(x * ts + rng() * ts, y * ts); g.lineTo(x * ts + rng() * ts, y * ts + ts); g.stroke();
      }
    }
    fbm(g, S, 13, 2, 0.20, [0, 0, 0]);
    stain(g, S, rng, 6, 'rgba(60,20,14,A)', 40);
    const t = finish(c, rx, ry); cache[key] = t; return t.clone();
  }

  /* --- штукатурка / бетон --- */
  function plaster(key, base, rx, ry, seed) {
    if (cache[key]) return cache[key].clone();
    const S = 256, c = canvas(S), g = c.getContext('2d');
    const rng = mulberry32(seed || 5);
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    fbm(g, S, seed || 5, 4, 0.42, [0, 0, 0]);
    fbm(g, S, (seed || 5) + 400, 3, 0.16, [255, 252, 240]);
    for (let i = 0; i < 26; i++) {
      g.strokeStyle = `rgba(0,0,0,${(0.05 + rng() * 0.18).toFixed(3)})`;
      g.lineWidth = 0.5 + rng() * 1.2;
      const x = rng() * S, y = rng() * S;
      g.beginPath(); g.moveTo(x, y);
      let cx = x, cy = y;
      for (let s = 0; s < 5; s++) { cx += rng() * 34 - 17; cy += rng() * 34 - 17; g.lineTo(cx, cy); }
      g.stroke();
    }
    stain(g, S, rng, 10, 'rgba(30,18,8,A)', 52);
    const t = finish(c, rx, ry); cache[key] = t; return t.clone();
  }

  /* --- металл / ржавчина --- */
  function metal(key, base, rx, ry) {
    if (cache[key]) return cache[key].clone();
    const S = 128, c = canvas(S), g = c.getContext('2d');
    const rng = mulberry32(222);
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 240; i++) {
      g.strokeStyle = `rgba(255,255,255,${(rng() * 0.06).toFixed(3)})`;
      const y = rng() * S; g.beginPath(); g.moveTo(0, y); g.lineTo(S, y + rng() * 4 - 2); g.stroke();
    }
    fbm(g, S, 77, 3, 0.30, [0, 0, 0]);
    stain(g, S, rng, 8, 'rgba(120,52,16,A)', 26);
    const t = finish(c, rx, ry); cache[key] = t; return t.clone();
  }

  /* --- ткань --- */
  function fabric(key, base, rx, ry) {
    if (cache[key]) return cache[key].clone();
    const S = 128, c = canvas(S), g = c.getContext('2d');
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    for (let y = 0; y < S; y += 2) for (let x = 0; x < S; x += 2) {
      g.fillStyle = `rgba(${((x + y) % 4 === 0) ? '255,255,255' : '0,0,0'},0.05)`;
      g.fillRect(x, y, 2, 2);
    }
    fbm(g, S, 404, 3, 0.26, [0, 0, 0]);
    const t = finish(c, rx, ry); cache[key] = t; return t.clone();
  }

  function shade(hex, mul) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = clamp(Math.round(r * mul), 0, 255); g = clamp(Math.round(g * mul), 0, 255); b = clamp(Math.round(b * mul), 0, 255);
    return `rgb(${r},${g},${b})`;
  }

  return { wood, wallpaper, tile, plaster, metal, fabric, shade };
})();

/* быстрый материал */
function mat(map, opt) {
  return new THREE.MeshStandardMaterial(Object.assign({
    map: map, roughness: 0.94, metalness: 0.02, color: 0xffffff
  }, opt || {}));
}
function matPlain(color, rough, metal) {
  return new THREE.MeshStandardMaterial({ color: color, roughness: rough === undefined ? 0.9 : rough, metalness: metal || 0 });
}

/* ============================================================
   СЛИЯНИЕ ГЕОМЕТРИЙ (чтобы дом был 2-3 draw call)
   ============================================================ */
function mergeGeos(list) {
  let vCount = 0, iCount = 0;
  for (const it of list) {
    vCount += it.geo.attributes.position.count;
    iCount += it.geo.index ? it.geo.index.count : it.geo.attributes.position.count;
  }
  const pos = new Float32Array(vCount * 3);
  const nor = new Float32Array(vCount * 3);
  const uv = new Float32Array(vCount * 2);
  const idx = new Uint32Array(iCount);
  const m = new THREE.Matrix4(), nm = new THREE.Matrix3(), v = new THREE.Vector3();
  let vo = 0, io = 0;
  for (const it of list) {
    const g = it.geo, p = g.attributes.position, n = g.attributes.normal, u = g.attributes.uv;
    m.copy(it.matrix); nm.getNormalMatrix(m);
    const cnt = p.count;
    for (let i = 0; i < cnt; i++) {
      v.fromBufferAttribute(p, i).applyMatrix4(m);
      pos[(vo + i) * 3] = v.x; pos[(vo + i) * 3 + 1] = v.y; pos[(vo + i) * 3 + 2] = v.z;
      if (n) { v.fromBufferAttribute(n, i).applyMatrix3(nm).normalize(); }
      nor[(vo + i) * 3] = v.x; nor[(vo + i) * 3 + 1] = v.y; nor[(vo + i) * 3 + 2] = v.z;
      if (u) { uv[(vo + i) * 2] = u.getX(i); uv[(vo + i) * 2 + 1] = u.getY(i); }
    }
    if (g.index) {
      for (let i = 0; i < g.index.count; i++) idx[io + i] = g.index.getX(i) + vo;
      io += g.index.count;
    } else {
      for (let i = 0; i < cnt; i++) idx[io + i] = vo + i;
      io += cnt;
    }
    vo += cnt;
    it.geo.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  out.setIndex(new THREE.BufferAttribute(idx, 1));
  out.computeBoundingSphere();
  return out;
}

function box(w, h, d, matrix) {
  return { geo: new THREE.BoxGeometry(w, h, d), matrix: matrix };
}
function mat4(x, y, z, ry) {
  const m = new THREE.Matrix4();
  if (ry) m.makeRotationY(ry);
  m.setPosition(x, y, z);
  return m;
}
