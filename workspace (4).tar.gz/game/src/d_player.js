/* ============================================================
   ИГРОК
   ============================================================ */
const Noise = { list: [] };
function emitNoise(x, z, radius, kind) {
  Noise.list.push({ x, z, r: radius, kind: kind || 'noise', t: 0 });
  if (Noise.list.length > 24) Noise.list.shift();
}

const Player = {
  pos: new THREE.Vector3(),
  vel: new THREE.Vector3(),
  yaw: 0, pitch: 0,
  eye: CFG.EYE,
  crouch: false, sprint: false,
  stamina: CFG.STAMINA,
  torch: true, battery: 100,
  hidden: null,
  hideCd: 0,
  alive: true,
  bob: 0, bobAmt: 0,
  stepPhase: 0,
  inv: {},
  jars: 2,
  breath: 0,
  moving: false,
  lookSens: 1.0,
  hands: null,
  fovBase: 74,
  fov: 74,
  shake: 0,
  hurtFlash: 0,
  noiseLevel: 0,     // 0..1 для индикатора
  lastRoom: '',
  peekTimer: 0,

  reset(sx, sy) {
    this.pos.set(FX(sx), 0, FZ(sy));
    this.vel.set(0, 0, 0);
    this.yaw = 0; this.pitch = 0;
    this.eye = CFG.EYE;
    this.crouch = false; this.stamina = CFG.STAMINA;
    this.battery = Math.max(this.battery, 0);
    this.hidden = null; this.alive = true;
    this.bob = 0; this.shake = 0; this.hurtFlash = 0;
    this.pos.x += 0.0; this.pos.z += 0.0;
  },

  speedNow() {
    if (this.hidden) return 0;
    if (this.crouch) return CFG.CROUCH;
    return this.sprint && this.stamina > 1 ? CFG.SPRINT : CFG.WALK;
  },

  update(dt, input, cam) {
    if (!this.alive) return;

    /* --- прятки --- */
    if (this.hidden) {
      const h = this.hidden;
      this.pos.x = dampf(this.pos.x, h.x, 9, dt);
      this.pos.z = dampf(this.pos.z, h.z, 9, dt);
      this.eye = dampf(this.eye, h.eye.y, 8, dt);
      this.stamina = Math.min(CFG.STAMINA, this.stamina + CFG.STAM_REGEN * 1.7 * dt);
      this.breath = Math.min(1, this.breath + dt * 0.4);
      this.moving = false;
      this.noiseLevel = dampf(this.noiseLevel, 0, 6, dt);
      // выглядываем только в сторону щели
      const rel = ((this.yaw - h.faceYaw + Math.PI * 3) % TAU) - Math.PI;
      this.yaw = h.faceYaw + clamp(rel, -0.8, 0.8);
      this.pitch = clamp(this.pitch, -0.42, 0.4);
      cam.position.set(this.pos.x, this.eye, this.pos.z);
      cam.rotation.order = 'YXZ';
      cam.rotation.set(this.pitch + Math.sin(performance.now() * 0.0016) * 0.006, this.yaw, 0);
      if (this.hideCd > 0) this.hideCd -= dt;
      if ((input.pressed('KeyE') || input.pressed('KeyH')) && this.hideCd <= 0) this.unhide();
      // дыхание выдаёт, если она рядом
      if (this.breath > 0.85 && Math.random() < dt * 1.2) {
        emitNoise(this.pos.x, this.pos.z, 2.4, 'breath');
        this.breath = 0.45;
      }
      return;
    }
    if (this.hideCd > 0) this.hideCd -= dt;

    /* --- присед --- */
    const wantCrouch = input.down('ControlLeft') || input.down('KeyC');
    this.crouch = wantCrouch;
    const targetEye = wantCrouch ? CFG.CROUCH_EYE : CFG.EYE;
    this.eye = dampf(this.eye, targetEye, 11, dt);

    /* --- движение --- */
    let fx = 0, fz = 0;
    if (input.down('KeyW') || input.down('ArrowUp')) fz += 1;
    if (input.down('KeyS') || input.down('ArrowDown')) fz -= 1;
    if (input.down('KeyA')) fx -= 1;
    if (input.down('KeyD')) fx += 1;
    if (input.down('ArrowLeft') && !input.mouseLook) fx -= 1;
    if (input.down('ArrowRight') && !input.mouseLook) fx += 1;

    const tl = input.touchMove;
    if (tl) { fx += tl.x; fz += -tl.y; }

    const len = Math.hypot(fx, fz);
    this.moving = len > 0.05;
    if (len > 1) { fx /= len; fz /= len; }

    this.sprint = (input.down('ShiftLeft') || input.down('ShiftRight')) && fz > 0.2 && !this.crouch;
    let sp = this.speedNow();
    if (this.sprint) {
      this.stamina = Math.max(0, this.stamina - CFG.STAM_DRAIN * dt);
      if (this.stamina <= 0) this.sprint = false;
    } else {
      this.stamina = Math.min(CFG.STAMINA, this.stamina + CFG.STAM_REGEN * dt);
    }

    const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
    const vx = (fx * cy - fz * sy) * sp;
    const vz = (-fx * sy - fz * cy) * sp;
    this.pos.x += vx * dt;
    this.pos.z += vz * dt;
    resolveCircle(this.pos, CFG.P_RAD);
    this.pos.x = clamp(this.pos.x, 0.4, CFG.GW * CFG.CELL - 0.4);
    this.pos.z = clamp(this.pos.z, 0.4, CFG.GH * CFG.CELL - 0.4);

    /* --- шаг, шум, покачивание --- */
    if (this.moving) {
      this.stepPhase += dt * sp * 1.55;
      this.bobAmt = dampf(this.bobAmt, this.crouch ? 0.35 : (this.sprint ? 1.5 : 1.0), 8, dt);
      if (this.stepPhase > Math.PI) {
        this.stepPhase -= Math.PI;
        const loud = this.crouch ? 0.16 : (this.sprint ? 1.0 : 0.48);
        Sound.step(loud, 0, false);
        const tx = txOf(this.pos.x), ty = tzOf(this.pos.z);
        const creaky = CREAKY.has(tx + ':' + ty);
        let rad = this.crouch ? 1.4 : (this.sprint ? 12.5 : 5.4);
        if (creaky && !this.crouch) { rad *= 1.75; Sound.creak(false); }
        emitNoise(this.pos.x, this.pos.z, rad, 'step');
      }
    } else {
      this.bobAmt = dampf(this.bobAmt, 0, 8, dt);
      this.stepPhase = 0;
    }
    this.bob = Math.sin(this.stepPhase * 2) * 0.055 * this.bobAmt;
    this.breath = dampf(this.breath, 0, 2, dt);

    const nl = this.crouch ? (this.moving ? 0.18 : 0.02) : (this.sprint ? 1.0 : (this.moving ? 0.45 : 0.05));
    this.noiseLevel = dampf(this.noiseLevel, nl, 7, dt);

    /* --- фонарь --- */
    if (input.pressed('KeyF')) {
      if (this.battery > 0) { this.torch = !this.torch; Sound.ui('click'); }
      else Sound.deny();
    }
    if (this.torch) {
      this.battery = Math.max(0, this.battery - CFG.TORCH_DRAIN * dt);
      if (this.battery <= 0) this.torch = false;
    }

    /* --- камера --- */
    const shakeX = (Math.random() - 0.5) * this.shake;
    const shakeY = (Math.random() - 0.5) * this.shake;
    cam.position.set(this.pos.x + shakeX, this.eye + this.bob + shakeY, this.pos.z);
    const breathe = Math.sin(performance.now() * 0.0011) * 0.006 + this.breath * Math.sin(performance.now() * 0.006) * 0.02;
    cam.rotation.order = 'YXZ';
    cam.rotation.y = this.yaw;
    cam.rotation.x = clamp(this.pitch + breathe, -1.45, 1.45);
    cam.rotation.z = Math.sin(this.stepPhase) * 0.012 * this.bobAmt;
    this.fov = dampf(this.fov, this.sprint && this.moving ? this.fovBase + 7 : this.fovBase, 5, dt);
    if (Math.abs(cam.fov - this.fov) > 0.01) { cam.fov = this.fov; cam.updateProjectionMatrix(); }
    this.shake = Math.max(0, this.shake - dt * 0.6);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 1.6);

    /* --- бросок банки --- */
    if (input.pressed('KeyG')) this.throwJar(cam);
  },

  hide(spot) {
    this.hidden = spot;
    this.hideCd = 0.55;
    this.torch = false;
    this.breath = 0.2;
    this.moving = false;
    Sound.door(false, 0);
    emitNoise(this.pos.x, this.pos.z, spot.noise, 'hide');
  },
  unhide() {
    const h = this.hidden;
    this.hidden = null;
    this.hideCd = 0.75;               // защита от мгновенного повторного залезания
    // выходим наружу, а не остаёмся внутри коллайдера мебели
    const out = h.out || { x: 0, z: 1 };
    this.pos.x = h.x + out.x * 0.72;
    this.pos.z = h.z + out.z * 0.72;
    resolveCircle(this.pos, CFG.P_RAD);
    this.eye = CFG.CROUCH_EYE;
    Sound.door(true, 0);
    emitNoise(this.pos.x, this.pos.z, 3.2, 'hide');
  },

  throwJar(cam) {
    if (this.jars <= 0) { Sound.deny(); return; }
    this.jars--;
    Sound.ui('click');
    const dir = new THREE.Vector3();
    cam.getWorldDirection(dir);
    Jar.spawn(cam.position.clone(), dir);
    emitNoise(this.pos.x, this.pos.z, 3.0, 'throw');
  },

  give(kind) {
    this.inv[kind] = (this.inv[kind] || 0) + 1;
    if (kind === 'jar') this.jars++;
    if (kind === 'battery') this.battery = Math.min(100, this.battery + 55);
  },
  has(kind) { return (this.inv[kind] || 0) > 0; },
};

/* ---------------- летающие банки ---------------- */
const Jar = {
  list: [],
  spawn(pos, dir) {
    const g = new THREE.Mesh(
      new THREE.CylinderGeometry(0.055, 0.05, 0.13, 8),
      new THREE.MeshStandardMaterial({ color: 0x7a9a86, roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 })
    );
    g.position.copy(pos).add(new THREE.Vector3(0, -0.12, 0));
    g.castShadow = true;
    World.scene.add(g);
    this.list.push({
      mesh: g,
      v: dir.clone().multiplyScalar(7.2).add(new THREE.Vector3(0, 2.1, 0)),
      p: g.position.clone(), life: 3.2, landed: false
    });
  },
  update(dt) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const j = this.list[i];
      j.life -= dt;
      if (!j.landed) {
        j.v.y -= 9.6 * dt;
        const np = j.p.clone().addScaledVector(j.v, dt);
        if (np.y < 0.07) {
          j.landed = true;
          np.y = 0.07;
          Sound.thump(clamp((j.p.x - Player.pos.x) / 12, -1, 1));
          Sound.creak(true);
          emitNoise(j.p.x, j.p.z, 15.5, 'jar');
          j.mesh.rotation.z = Math.PI / 2;
        } else {
          const test = { x: np.x, z: np.z };
          if (blockedAt(test.x, test.z, 0.07)) {
            j.landed = true;
            Sound.thump(0);
            emitNoise(j.p.x, j.p.z, 12, 'jar');
          }
        }
        j.p.copy(np);
      }
      j.mesh.position.copy(j.p);
      if (!j.landed) j.mesh.rotation.x += dt * 7;
      if (j.life <= 0) { World.scene.remove(j.mesh); this.list.splice(i, 1); }
    }
  }
};

/* ============================================================
   ВРАГ — «БАБУШКА»
   ============================================================ */
function buildEnemyModel() {
  const g = new THREE.Group();
  const dress = new THREE.MeshStandardMaterial({ color: 0x2b2620, roughness: 1.0 });
  const dress2 = new THREE.MeshStandardMaterial({ color: 0x3a2f2a, roughness: 1.0 });
  const skin = new THREE.MeshStandardMaterial({ color: 0x9d9285, roughness: 0.86 });
  const hair = new THREE.MeshStandardMaterial({ color: 0xb9b3a6, roughness: 1 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x0b0908, roughness: 1 });

  const body = new THREE.Group(); g.add(body);

  const robe = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.5, 1.22, 12, 1, true), dress);
  robe.position.y = 0.62; robe.castShadow = true; body.add(robe);
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.3, 0.5, 10), dress2);
  torso.position.y = 1.16; torso.castShadow = true; body.add(torso);
  const shawl = new THREE.Mesh(new THREE.SphereGeometry(0.33, 12, 8, 0, TAU, 0, Math.PI * 0.55), dress2);
  shawl.position.y = 1.3; shawl.scale.y = 0.75; shawl.castShadow = true; body.add(shawl);

  const headG = new THREE.Group(); headG.position.y = 1.5; body.add(headG);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.185, 14, 12), skin);
  head.scale.set(0.92, 1.08, 0.98); head.castShadow = true; headG.add(head);
  const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 8), skin);
  jaw.position.set(0, -0.09, 0.03); jaw.scale.set(1, 0.75, 1); headG.add(jaw);
  const bun = new THREE.Mesh(new THREE.SphereGeometry(0.105, 10, 8), hair);
  bun.position.set(0, 0.13, -0.13); headG.add(bun);
  const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.185, 12, 8, 0, TAU, 0, Math.PI * 0.42), hair);
  hairTop.position.y = 0.03; headG.add(hairTop);

  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xe8e4d8 });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 6), eyeMat);
  eyeL.position.set(-0.065, 0.015, 0.163); headG.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.065; headG.add(eyeR);
  const socketMat = new THREE.MeshStandardMaterial({ color: 0x1b1512, roughness: 1 });
  for (const s of [-1, 1]) {
    const so = new THREE.Mesh(new THREE.SphereGeometry(0.048, 8, 6), socketMat);
    so.position.set(s * 0.065, 0.018, 0.148); so.scale.z = 0.5; headG.add(so);
  }
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.085, 0.03, 0.03), dark);
  mouth.position.set(0, -0.085, 0.16); headG.add(mouth);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.075, 6), skin);
  nose.position.set(0, -0.02, 0.185); nose.rotation.x = Math.PI / 2; headG.add(nose);

  const eyeLight = new THREE.PointLight(0xd8d2c0, 0.0, 3.2, 2);
  eyeLight.position.set(0, 1.52, 0.15); g.add(eyeLight);

  /* руки */
  function arm(side) {
    const a = new THREE.Group();
    a.position.set(side * 0.28, 1.3, 0);
    const up = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.055, 0.44, 8), dress2);
    up.position.y = -0.22; up.castShadow = true; a.add(up);
    const fore = new THREE.Group(); fore.position.y = -0.44; a.add(fore);
    const f = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.042, 0.42, 8), skin);
    f.position.y = -0.21; f.castShadow = true; fore.add(f);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.062, 8, 6), skin);
    hand.position.y = -0.44; fore.add(hand);
    return { g: a, fore };
  }
  const armL = arm(-1), armR = arm(1);
  body.add(armL.g); body.add(armR.g);

  /* оружие — молоток */
  const wp = new THREE.Group();
  const haft = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.03, 0.52, 7),
    new THREE.MeshStandardMaterial({ color: 0x4a3520, roughness: 0.95 }));
  haft.position.y = -0.2; wp.add(haft);
  const headM = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.12, 0.24),
    new THREE.MeshStandardMaterial({ color: 0x5a4a3c, roughness: 0.5, metalness: 0.7 }));
  headM.position.y = -0.46; wp.add(headM);
  const bloodM = new THREE.Mesh(new THREE.BoxGeometry(0.135, 0.06, 0.245),
    new THREE.MeshStandardMaterial({ color: 0x3d0d0d, roughness: 0.6 }));
  bloodM.position.y = -0.5; wp.add(bloodM);
  wp.position.y = -0.46; armR.fore.add(wp);

  g.traverse(o => { if (o.isMesh) { o.castShadow = true; } });
  return { root: g, body, headG, armL, armR, eyeMat, eyeLight, mouth, robe };
}

const Enemy = {
  pos: new THREE.Vector3(),
  yaw: 0,
  model: null,
  state: 'patrol',      // patrol | investigate | chase | search | stunned
  speed: CFG.E_PATROL,
  path: null, pathIdx: 0, repath: 0,
  target: null,         // {x,z}
  lastKnown: null,
  searchTimer: 0,
  walkPhase: 0,
  stun: 0,
  seenTimer: 0,
  lostTimer: 0,
  aggro: 0,             // 0..1
  doorWait: 0,
  mutter: 0,
  alertPulse: 0,
  active: true,
  patrolIdx: 0,
  patrol: [],
  homeRoom: 4,

  init(scene) {
    this.model = buildEnemyModel();
    scene.add(this.model.root);
    this.patrol = [
      [2, 1], [3, 6], [2, 11], [6, 12], [6, 6], [6, 1], [11, 1], [14, 2],
      [10, 6], [12, 7], [10, 10], [14, 10], [11, 12], [7, 9], [9, 3],
    ];
    this.pos.set(FX(11), 0, FZ(2));
    this.model.root.position.copy(this.pos);
    this.state = 'patrol';
    this.stun = 0; this.aggro = 0;
  },

  reset() {
    this.pos.set(FX(this.patrol[0][0]), 0, FZ(this.patrol[0][1]));
    this.state = 'patrol'; this.aggro = 0; this.stun = 0;
    this.path = null; this.target = null; this.lastKnown = null;
    this.searchTimer = 0; this.seenTimer = 0; this.lostTimer = 0;
    this.model.root.position.copy(this.pos);
  },

  tile() { return [txOf(this.pos.x), tzOf(this.pos.z)]; },

  hears() {
    for (let i = Noise.list.length - 1; i >= 0; i--) {
      const n = Noise.list[i];
      const d = dist(this.pos.x, this.pos.z, n.x, n.z);
      if (d < n.r * CFG.E_HEAR_MULT) {
        if (n.kind === 'breath') {
          if (this.state === 'chase' || this.state === 'search') { this.lastKnown = { x: n.x, z: n.z }; this.searchTimer = 5; }
          continue;
        }
        Noise.list.splice(i, 1);
        this.target = { x: n.x, z: n.z };
        this.lastKnown = { x: n.x, z: n.z };
        if (this.state === 'patrol') { this.state = 'investigate'; this.path = null; }
        else if (this.state === 'search') { this.searchTimer = Math.max(this.searchTimer, 5.5); }
        this.alertPulse = 1;
        return true;
      }
    }
    return false;
  },

  seesPlayer(camPos, torchOn) {
    if (Player.hidden) return false;
    if (!Player.alive) return false;
    const dx = camPos.x - this.pos.x, dz = camPos.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    const maxD = torchOn ? CFG.E_SIGHT_TORCH : (Player.crouch ? CFG.E_SIGHT_DARK * 0.72 : CFG.E_SIGHT_LIT);
    if (d > maxD) return false;
    // угол зрения
    const toP = Math.atan2(dx, dz);
    let diff = Math.abs(((toP - this.yaw + Math.PI * 3) % TAU) - Math.PI);
    const fov = this.state === 'chase' ? Math.PI * 0.95 : CFG.E_FOV / 2;
    if (diff > fov && d > 1.6) return false;
    // темнота снижает дальность: считаем «освещённость» игрока
    let vis = 1;
    if (!torchOn) vis = d < 3.2 ? 1 : 0.55;
    if (Player.crouch) vis *= 0.7;
    if (d > maxD * vis) return false;
    if (!lineOfSight(this.pos.x, this.pos.z, camPos.x, camPos.z)) return false;
    return true;
  },

  update(dt, camPos, torchOn) {
    if (!this.active) return;
    const M = this.model;

    if (this.stun > 0) {
      this.stun -= dt;
      M.root.position.copy(this.pos);
      M.body.rotation.z = Math.sin(performance.now() * 0.01) * 0.05;
      M.body.position.y = -0.12;
      if (this.stun <= 0) { M.body.position.y = 0; M.body.rotation.z = 0; this.state = 'search'; this.searchTimer = 4; }
      return;
    }

    /* --- восприятие --- */
    const sees = this.seesPlayer(camPos, torchOn);
    if (sees) {
      this.seenTimer += dt;
      this.lastKnown = { x: Player.pos.x, z: Player.pos.z };
      this.aggro = Math.min(1, this.aggro + dt * (torchOn ? 2.4 : 1.5));
      if (this.seenTimer > 0.18 || this.state === 'chase') {
        if (this.state !== 'chase') { this.alertPulse = 1; Sound.growl(0); }
        this.state = 'chase';
        this.target = { x: Player.pos.x, z: Player.pos.z };
        this.path = null;
      }
    } else {
      this.seenTimer = Math.max(0, this.seenTimer - dt * 1.6);
      this.aggro = Math.max(0, this.aggro - dt * 0.24);
      if (this.state === 'chase') {
        this.lostTimer += dt;
        if (this.lostTimer > 2.6) { this.state = 'search'; this.searchTimer = 8; this.lostTimer = 0; }
      }
    }
    if (this.state !== 'chase') this.lostTimer = 0;

    this.hears();

    /* --- цель --- */
    if (this.state === 'patrol') {
      if (!this.target || (Math.abs(this.pos.x - FX(this.target[0])) < 0.5 && Math.abs(this.pos.z - FZ(this.target[1])) < 0.5)) {
        this.patrolIdx = (this.patrolIdx + 1) % this.patrol.length;
        this.target = this.patrol[this.patrolIdx];
        this.path = null;
      }
    }

    const goal = this.state === 'patrol'
      ? { x: FX(this.target[0]), z: FZ(this.target[1]) }
      : this.target;

    /* --- путь (она умеет открывать двери, поэтому путь «сквозь» них) --- */
    this.repath -= dt;
    const et = this.tile();
    if (goal && (this.repath <= 0 || !this.path)) {
      const gtx = clamp(txOf(goal.x), 0, CFG.GW - 1), gty = clamp(tzOf(goal.z), 0, CFG.GH - 1);
      const p = findPathForce(et[0], et[1], gtx, gty);
      this.path = (p && p.length) ? p : null;
      this.pathIdx = 0;
      this.repath = this.state === 'chase' ? 0.3 : 0.8;
    }

    /* --- движение --- */
    let tx = null, tz = null;
    if (this.path && this.pathIdx < this.path.length) {
      const node = this.path[this.pathIdx];
      tx = FX(node[0]); tz = FZ(node[1]);
      const dr = doorBetween(et[0], et[1], node[0], node[1]);
      if (dr && !doorPassable(dr)) {
        tx = dr.cx; tz = dr.cz;                      // сначала подойти к двери
        if (dist(this.pos.x, this.pos.z, dr.cx, dr.cz) < 1.25) {
          if (!dr.open) {
            dr.open = true; dr.target = DOOR_OPEN_A;
            Sound.door(true, clamp((dr.cx - Player.pos.x) / 12, -1, 1));
            emitNoise(dr.cx, dr.cz, 9.0, 'door');
          }
          this.doorWait = 0.42;
        }
      }
      if (dist(this.pos.x, this.pos.z, FX(node[0]), FZ(node[1])) < 0.36) this.pathIdx++;
    } else if (goal && this.state !== 'patrol') {
      tx = goal.x; tz = goal.z;
    }

    if (this.doorWait > 0) { this.doorWait -= dt; tx = tz = null; }

    const baseSpeed =
      this.state === 'chase' ? CFG.E_CHASE :
      this.state === 'investigate' ? CFG.E_INVEST :
      this.state === 'search' ? CFG.E_SEARCH : CFG.E_PATROL;
    this.speed = dampf(this.speed, baseSpeed, 4, dt);

    if (tx !== null) {
      const dx = tx - this.pos.x, dz = tz - this.pos.z;
      const d = Math.hypot(dx, dz) || 1;
      const nx = this.pos.x + dx / d * this.speed * dt;
      const nz = this.pos.z + dz / d * this.speed * dt;
      const test = new THREE.Vector3(nx, 0, nz);
      resolveCircle(test, CFG.E_RAD);
      const moved = dist(this.pos.x, this.pos.z, test.x, test.z);
      this.pos.x = test.x; this.pos.z = test.z;
      if (moved < this.speed * dt * 0.35 && this.state !== 'chase') { this.path = null; this.repath = 0.2; }
      this.yaw = dampf(this.yaw, Math.atan2(dx, dz), this.state === 'chase' ? 12 : 6, dt);
      this.walkPhase += dt * this.speed * 2.3;
      // её шаги
      if (Math.sin(this.walkPhase) > 0.985 && !this._stepLock) {
        this._stepLock = true;
        const dToP = dist(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
        const vol = clamp(1 - dToP / 18, 0.05, 1);
        Sound.step(vol, clamp((this.pos.x - Player.pos.x) / 10, -1, 1), true);
        emitNoise(this.pos.x, this.pos.z, this.state === 'chase' ? 6.5 : 3.4, 'enemyStep');
      } else if (Math.sin(this.walkPhase) < 0.5) this._stepLock = false;
    } else {
      this.walkPhase = dampf(this.walkPhase, Math.round(this.walkPhase / Math.PI) * Math.PI, 4, dt);
    }

    /* --- поиск --- */
    if (this.state === 'search') {
      this.searchTimer -= dt;
      if (!this.target || dist(this.pos.x, this.pos.z, this.target.x, this.target.z) < 0.9) {
        if (this.lastKnown) {
          this.target = {
            x: clamp(this.lastKnown.x + (Math.random() - 0.5) * 5.5, 0.8, CFG.GW * CFG.CELL - 0.8),
            z: clamp(this.lastKnown.z + (Math.random() - 0.5) * 5.5, 0.8, CFG.GH * CFG.CELL - 0.8)
          };
        }
        this.path = null;
      }
      if (this.searchTimer <= 0) { this.state = 'patrol'; this.target = null; this.path = null; this._sawHide = false; }
    }
    if (this.state === 'investigate') {
      if (this.target && dist(this.pos.x, this.pos.z, this.target.x, this.target.z) < 0.85) {
        this.state = 'search'; this.searchTimer = 5.5;
      }
    }

    /* --- бормотание --- */
    this.mutter -= dt;
    const dToP = dist(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
    if (this.mutter <= 0 && dToP < 11) {
      Sound.breath(clamp((this.pos.x - Player.pos.x) / 9, -1, 1), dToP < 5);
      if (this.state === 'chase' && Math.random() < 0.35)
        Sound.growl(clamp((this.pos.x - Player.pos.x) / 9, -1, 1));
      this.mutter = this.state === 'chase' ? 1.4 + Math.random() * 1.6 : 2.6 + Math.random() * 4;
    }

    /* --- анимация модели --- */
    const r = M.root;
    r.position.set(this.pos.x, 0, this.pos.z);
    r.rotation.y = this.yaw;
    const sw = Math.sin(this.walkPhase), cw = Math.cos(this.walkPhase * 2);
    const spd = clamp(this.speed / CFG.E_CHASE, 0.25, 1);
    M.body.position.y = Math.abs(cw) * 0.035 * spd;
    M.body.rotation.x = lerp(0.06, 0.26, spd) + sw * 0.02;
    M.body.rotation.z = sw * 0.045 * spd;
    M.armL.g.rotation.x = sw * 0.55 * spd;
    M.armR.g.rotation.x = -sw * 0.35 * spd - (this.state === 'chase' ? 1.15 : 0.15);
    M.armR.fore.rotation.x = this.state === 'chase' ? -0.55 + sw * 0.5 : -0.25;
    M.armL.fore.rotation.x = -0.2 - sw * 0.2;
    // голова: смотрит на игрока при погоне
    if (this.state === 'chase' || this.state === 'search') {
      const dx = Player.pos.x - this.pos.x, dz = Player.pos.z - this.pos.z;
      const want = ((Math.atan2(dx, dz) - this.yaw + Math.PI * 3) % TAU) - Math.PI;
      M.headG.rotation.y = dampf(M.headG.rotation.y, clamp(want, -1.0, 1.0), 8, dt);
    } else {
      M.headG.rotation.y = dampf(M.headG.rotation.y, sw * 0.14, 4, dt);
    }
    M.headG.rotation.z = Math.sin(this.walkPhase * 0.5) * 0.05 + (this.state === 'chase' ? 0.20 : 0.04);
    M.headG.rotation.x = this.state === 'chase' ? 0.16 : 0.06;

    const chaseF = this.state === 'chase' ? 1 : 0;
    const eyeCol = chaseF ? 0xff2a1a : 0xd8d2c0;
    M.eyeMat.color.setHex(eyeCol);
    M.eyeLight.color.setHex(eyeCol);
    const near = clamp(1 - dToP / 13, 0, 1);
    M.eyeLight.intensity = dampf(M.eyeLight.intensity, (0.16 + chaseF * 1.5) * (0.35 + near), 6, dt);
    M.mouth.scale.y = dampf(M.mouth.scale.y, chaseF ? 3.0 : 1.0, 6, dt);
    M.mouth.position.y = -0.085 - (chaseF ? 0.03 : 0);

    this.alertPulse = Math.max(0, this.alertPulse - dt * 1.8);
    return dToP;
  },

  threatLevel(camPos) {
    const d = dist(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
    let t = clamp(1 - d / 16, 0, 1);
    if (this.state === 'chase') t = Math.max(t, 0.75);
    if (this.state === 'search') t = Math.max(t, 0.45);
    if (Player.hidden) t *= 0.55;
    return t;
  },

  canCatch() {
    if (this.stun > 0) return false;
    if (Player.hidden) {
      // если видела, как прятались — подойдёт и достанет
      const d = dist(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
      return this._sawHide && d < 1.45;
    }
    const d = dist(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
    return d < CFG.E_CATCH && lineOfSight(this.pos.x, this.pos.z, Player.pos.x, Player.pos.z);
  },
};
