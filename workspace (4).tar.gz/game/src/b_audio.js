/* ============================================================
   ЗВУК: полностью процедурный (WebAudio), без внешних файлов
   ============================================================ */
const Sound = (() => {
  let ctx = null, master = null, wet = null, dry = null, conv = null;
  let noiseBuf = null, ready = false;
  let droneA = null, droneB = null, droneG = null, windG = null, windSrc = null;
  let heartTimer = 0, heartGain = 0;
  let threat = 0, whisperG = null, whisperSrc = null;
  let tickTimer = 0, creakTimer = 6, thumpTimer = 11;
  let muted = false, volume = 0.85;

  function makeIR(seconds, decay) {
    const rate = ctx.sampleRate, len = Math.floor(rate * seconds);
    const buf = ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      for (let i = 0; i < len; i++) {
        const t = i / len;
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay);
      }
    }
    return buf;
  }

  function init() {
    if (ready) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
    } catch (e) { return; }
    master = ctx.createGain(); master.gain.value = muted ? 0 : volume;
    master.connect(ctx.destination);

    conv = ctx.createConvolver(); conv.buffer = makeIR(2.9, 2.6);
    wet = ctx.createGain(); wet.gain.value = 0.42;
    dry = ctx.createGain(); dry.gain.value = 1.0;
    dry.connect(master);
    wet.connect(conv); conv.connect(master);

    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const nd = noiseBuf.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

    startDrone();
    ready = true;
  }

  function bus(node, w) {
    node.connect(dry);
    const g = ctx.createGain(); g.gain.value = w === undefined ? 0.5 : w;
    node.connect(g); g.connect(wet);
  }

  function startDrone() {
    droneG = ctx.createGain(); droneG.gain.value = 0.0;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 190; f.Q.value = 2.5;
    droneA = ctx.createOscillator(); droneA.type = 'sawtooth'; droneA.frequency.value = 41;
    droneB = ctx.createOscillator(); droneB.type = 'sine'; droneB.frequency.value = 54.7;
    const ga = ctx.createGain(); ga.gain.value = 0.5;
    const gb = ctx.createGain(); gb.gain.value = 0.65;
    droneA.connect(ga); droneB.connect(gb);
    ga.connect(f); gb.connect(f); f.connect(droneG); droneG.connect(master);
    droneA.start(); droneB.start();

    // ветер / комнатный шум
    windSrc = ctx.createBufferSource(); windSrc.buffer = noiseBuf; windSrc.loop = true;
    const wf = ctx.createBiquadFilter(); wf.type = 'bandpass'; wf.frequency.value = 340; wf.Q.value = 0.6;
    windG = ctx.createGain(); windG.gain.value = 0.028;
    windSrc.connect(wf); wf.connect(windG); windG.connect(master);
    windSrc.start();

    // шёпот
    whisperSrc = ctx.createBufferSource(); whisperSrc.buffer = noiseBuf; whisperSrc.loop = true;
    const wp = ctx.createBiquadFilter(); wp.type = 'bandpass'; wp.frequency.value = 1450; wp.Q.value = 7;
    whisperG = ctx.createGain(); whisperG.gain.value = 0.0;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 3.1;
    const lg = ctx.createGain(); lg.gain.value = 0.55;
    lfo.connect(lg); lg.connect(whisperG.gain); lfo.start();
    whisperSrc.connect(wp); wp.connect(whisperG); whisperG.connect(master);
    whisperSrc.start();
  }

  /* --- базовые голоса --- */
  function noise(o) {
    if (!ready) return;
    const t = ctx.currentTime;
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    s.playbackRate.value = o.rate || 1;
    if (o.loop) s.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = o.type || 'bandpass'; f.frequency.value = o.freq || 800; f.Q.value = o.q === undefined ? 1 : o.q;
    const g = ctx.createGain();
    const atk = o.atk === undefined ? 0.004 : o.atk;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(o.gain, t + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, t + (o.dur || 0.2));
    let node = s; s.connect(f); f.connect(g);
    if (o.pan !== undefined && o.pan !== 0) {
      const p = ctx.createStereoPanner(); p.pan.value = clamp(o.pan, -1, 1);
      g.connect(p); bus(p, o.wet);
    } else bus(g, o.wet);
    if (o.sweep) f.frequency.exponentialRampToValueAtTime(Math.max(40, o.sweep), t + (o.dur || 0.2));
    s.start(t, o.off || Math.random() * 1.5);
    s.stop(t + (o.dur || 0.2) + 0.06);
    return g;
  }

  function tone(o) {
    if (!ready) return;
    const t = ctx.currentTime;
    const s = ctx.createOscillator(); s.type = o.type || 'sine';
    s.frequency.setValueAtTime(o.freq, t);
    if (o.to) s.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t + (o.dur || 0.3));
    if (o.detune) s.detune.value = o.detune;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(o.gain, t + (o.atk || 0.008));
    g.gain.exponentialRampToValueAtTime(0.0001, t + (o.dur || 0.3));
    s.connect(g);
    if (o.pan) { const p = ctx.createStereoPanner(); p.pan.value = clamp(o.pan, -1, 1); g.connect(p); bus(p, o.wet); }
    else bus(g, o.wet);
    s.start(t); s.stop(t + (o.dur || 0.3) + 0.05);
  }

  /* --- игровые события --- */
  function step(loud, pan, enemy) {
    if (!ready) return;
    const base = enemy ? 96 : 132;
    noise({
      type: 'lowpass', freq: base + Math.random() * 60, q: 1.1,
      gain: (enemy ? 0.30 : 0.24) * loud, dur: enemy ? 0.14 : 0.10,
      pan: pan, wet: 0.7, rate: 0.8 + Math.random() * 0.4
    });
    if (!enemy && loud > 0.5) {
      tone({ freq: 52 + Math.random() * 10, type: 'sine', gain: 0.10 * loud, dur: 0.11, pan: pan, wet: 0.5 });
    }
  }

  function creak(big) {
    if (!ready) return;
    const d = big ? 0.85 : 0.42;
    noise({
      type: 'bandpass', freq: big ? 420 : 640, q: 14, gain: big ? 0.16 : 0.10, dur: d,
      sweep: big ? 190 : 380, wet: 1.1, rate: 0.35, atk: 0.06
    });
    tone({ freq: big ? 173 : 240, to: big ? 96 : 150, type: 'triangle', gain: 0.035, dur: d, wet: 0.9 });
  }

  function door(open, pan) {
    if (!ready) return;
    noise({ type: 'bandpass', freq: 520, q: 9, gain: 0.13, dur: 0.62, sweep: 240, rate: 0.3, pan: pan, wet: 1.2, atk: 0.05 });
    setTimeout(() => {
      noise({ type: 'highpass', freq: 1800, gain: 0.10, dur: 0.06, pan: pan, wet: 0.6 });
      tone({ freq: 88, type: 'square', gain: 0.07, dur: 0.07, pan: pan, wet: 0.4 });
    }, open ? 560 : 40);
  }

  function pickup() {
    tone({ freq: 660, type: 'triangle', gain: 0.10, dur: 0.16, wet: 0.7 });
    setTimeout(() => tone({ freq: 990, type: 'triangle', gain: 0.075, dur: 0.22, wet: 0.9 }), 90);
  }

  function deny() {
    tone({ freq: 150, type: 'square', gain: 0.075, dur: 0.16, wet: 0.4 });
    setTimeout(() => tone({ freq: 112, type: 'square', gain: 0.07, dur: 0.22, wet: 0.4 }), 110);
  }

  function unlock() {
    noise({ type: 'highpass', freq: 2400, gain: 0.14, dur: 0.09, wet: 0.5 });
    tone({ freq: 300, to: 180, type: 'square', gain: 0.09, dur: 0.13, wet: 0.6 });
    setTimeout(() => { tone({ freq: 420, to: 260, type: 'square', gain: 0.08, dur: 0.14, wet: 0.6 }); }, 150);
    setTimeout(() => { tone({ freq: 190, type: 'triangle', gain: 0.10, dur: 0.5, wet: 1.2 }); }, 330);
  }

  function thump(pan) {
    tone({ freq: 62, to: 33, type: 'sine', gain: 0.30, dur: 0.34, pan: pan, wet: 0.8 });
    noise({ type: 'lowpass', freq: 240, gain: 0.14, dur: 0.20, pan: pan, wet: 0.6 });
  }

  function bang(pan) {
    for (let i = 0; i < 2; i++) setTimeout(() => {
      tone({ freq: 74, to: 40, type: 'square', gain: 0.34, dur: 0.20, pan: pan, wet: 1.0 });
      noise({ type: 'lowpass', freq: 700, gain: 0.22, dur: 0.24, pan: pan, wet: 0.9 });
    }, i * 190);
  }

  function breath(pan, near) {
    if (!ready) return;
    noise({
      type: 'bandpass', freq: 480, q: 2.2, gain: near ? 0.11 : 0.05, dur: 0.55,
      sweep: 260, pan: pan, wet: 0.9, atk: 0.22, rate: 0.5
    });
  }

  function growl(pan) {
    if (!ready) return;
    tone({ freq: 78, to: 55, type: 'sawtooth', gain: 0.13, dur: 1.1, pan: pan, wet: 1.3, atk: 0.14 });
    tone({ freq: 117, to: 84, type: 'sawtooth', gain: 0.075, dur: 1.0, pan: pan, wet: 1.3, atk: 0.2, detune: 22 });
    noise({ type: 'lowpass', freq: 620, gain: 0.07, dur: 1.0, pan: pan, wet: 1.0, atk: 0.2 });
  }

  function sting() {
    if (!ready) return;
    const t = ctx.currentTime;
    noise({ type: 'highpass', freq: 900, gain: 0.55, dur: 1.5, wet: 1.6, atk: 0.002 });
    noise({ type: 'lowpass', freq: 300, gain: 0.5, dur: 1.7, wet: 1.4, atk: 0.002 });
    [155, 164, 233, 311, 466].forEach((f, i) => {
      tone({ freq: f, to: f * 0.72, type: 'sawtooth', gain: 0.20, dur: 1.5, wet: 1.5, atk: 0.004, detune: i * 9 });
    });
    tone({ freq: 1400, to: 210, type: 'square', gain: 0.16, dur: 0.9, wet: 1.2 });
  }

  function thunder() {
    if (!ready) return;
    noise({ type: 'lowpass', freq: 300, gain: 0.42, dur: 2.6, sweep: 60, wet: 1.8, atk: 0.05 });
    setTimeout(() => noise({ type: 'lowpass', freq: 180, gain: 0.26, dur: 2.2, sweep: 45, wet: 1.8, atk: 0.3 }), 260);
  }

  function heartbeat(strong) {
    if (!ready) return;
    const g = strong ? 0.34 : 0.22;
    tone({ freq: 54, to: 30, type: 'sine', gain: g, dur: 0.17, wet: 0.55 });
    setTimeout(() => tone({ freq: 47, to: 27, type: 'sine', gain: g * 0.72, dur: 0.20, wet: 0.55 }), strong ? 165 : 200);
  }

  function win() {
    [392, 523, 659, 784].forEach((f, i) => setTimeout(() =>
      tone({ freq: f, type: 'triangle', gain: 0.13, dur: 1.4, wet: 1.6, atk: 0.02 }), i * 210));
  }

  function ui(kind) {
    if (!ready) return;
    if (kind === 'hover') tone({ freq: 880, type: 'sine', gain: 0.035, dur: 0.06, wet: 0.3 });
    else if (kind === 'click') { tone({ freq: 420, to: 300, type: 'square', gain: 0.07, dur: 0.09, wet: 0.4 }); }
    else if (kind === 'back') { tone({ freq: 260, to: 180, type: 'square', gain: 0.06, dur: 0.11, wet: 0.4 }); }
  }

  function tv(on) {
    if (!ready) return;
    if (on && !Sound._tv) {
      const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
      const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 700;
      const g = ctx.createGain(); g.gain.value = 0.05;
      s.connect(f); f.connect(g); bus(g, 0.9); s.start();
      Sound._tv = { s, g };
    } else if (!on && Sound._tv) {
      try { Sound._tv.s.stop(); } catch (e) { }
      Sound._tv = null;
    }
  }

  function tvLevel(v) { if (Sound._tv) Sound._tv.g.gain.value = clamp(v, 0, 0.4); }

  /* --- непрерывное обновление --- */
  function update(dt, thr, canAmb) {
    if (!ready) return;
    threat = dampf(threat, thr, 3.2, dt);
    if (droneG) droneG.gain.value = canAmb ? 0.055 + threat * 0.16 : 0;
    if (droneA) {
      droneA.frequency.value = 41 + threat * 7;
      droneB.frequency.value = 54.7 + threat * 12.5;
    }
    if (windG) windG.gain.value = canAmb ? 0.024 + threat * 0.012 : 0;
    if (whisperG) whisperG.gain.value = canAmb ? Math.max(0, (threat - 0.45)) * 0.075 : 0;

    // сердцебиение
    heartTimer -= dt;
    if (heartTimer <= 0 && threat > 0.22 && canAmb) {
      heartbeat(threat > 0.7);
      heartTimer = lerp(1.15, 0.34, clamp((threat - 0.22) / 0.78, 0, 1));
    } else if (heartTimer <= 0) heartTimer = 0.4;

    if (!canAmb) return;
    // случайные звуки дома
    creakTimer -= dt;
    if (creakTimer <= 0) { creak(Math.random() < 0.3); creakTimer = 7 + Math.random() * 16; }
    thumpTimer -= dt;
    if (thumpTimer <= 0) { thump((Math.random() * 2 - 1) * 0.8); thumpTimer = 14 + Math.random() * 26; }
    tickTimer -= dt;
    if (tickTimer <= 0) {
      tone({ freq: 2100, type: 'square', gain: 0.018, dur: 0.02, wet: 0.6 });
      tickTimer = 1.0;
    }
  }

  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }
  function setMuted(m) { muted = m; if (master) master.gain.value = m ? 0 : volume; }
  function setVolume(v) { volume = v; if (master && !muted) master.gain.value = v; }

  return {
    init, resume, update, step, creak, door, pickup, deny, unlock, thump, bang,
    breath, growl, sting, thunder, heartbeat, win, ui, tv, tvLevel,
    setMuted, setVolume, get ok() { return ready; }
  };
})();
