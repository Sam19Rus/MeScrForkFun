/* ============================================================
   ДОМ: планировка, геометрия, мебель, окна, двери, коллизии
   ============================================================ */

const ROOMS = [
  { id: 0, name: 'Кухня',      x0: 0,  y0: 0, x1: 5,  y1: 3,  floor: 'tileK', wall: 'wallK' },
  { id: 1, name: 'Гостиная',   x0: 0,  y0: 4, x1: 5,  y1: 8,  floor: 'wood',  wall: 'wallR' },
  { id: 2, name: 'Прихожая',   x0: 0,  y0: 9, x1: 5,  y1: 12, floor: 'wood',  wall: 'wallH' },
  { id: 3, name: 'Коридор',    x0: 6,  y0: 0, x1: 7,  y1: 12, floor: 'wood',  wall: 'wallH' },
  { id: 4, name: 'Мастерская', x0: 8,  y0: 0, x1: 15, y1: 3,  floor: 'stone', wall: 'wallB' },
  { id: 5, name: 'Кабинет',    x0: 8,  y0: 4, x1: 12, y1: 8,  floor: 'wood',  wall: 'wallS' },
  { id: 6, name: 'Кладовая',   x0: 13, y0: 4, x1: 15, y1: 7,  floor: 'stone', wall: 'wallB' },
  { id: 7, name: 'Спальня',    x0: 8,  y0: 9, x1: 12, y1: 12, floor: 'wood',  wall: 'wallR' },
  { id: 8, name: 'Ванная',     x0: 13, y0: 8, x1: 15, y1: 12, floor: 'tileB', wall: 'wallB' },
];

/* двери: V — вертикальное ребро (между tx-1 и tx), H — горизонтальное (между ty-1 и ty) */
const DOORS = [
  { k: 'V:6:2',   a: 0, b: 3, name: 'дверь на кухню' },
  { k: 'V:6:6',   a: 1, b: 3, name: 'дверь в гостиную' },
  { k: 'V:6:11',  a: 2, b: 3, name: 'дверь в прихожую' },
  { k: 'V:8:2',   a: 4, b: 3, name: 'дверь в мастерскую' },
  { k: 'V:8:6',   a: 5, b: 3, name: 'дверь в кабинет' },
  { k: 'V:8:11',  a: 7, b: 3, name: 'дверь в спальню' },
  { k: 'H:3:4',   a: 0, b: 1, name: 'дверь между кухней и гостиной' },
  { k: 'H:3:9',   a: 1, b: 2, name: 'дверь между гостиной и прихожей' },
  { k: 'H:10:4',  a: 4, b: 5, name: 'дверь в кабинет' },
  { k: 'H:14:4',  a: 4, b: 6, name: 'дверь в кладовую' },
  { k: 'V:13:6',  a: 5, b: 6, name: 'дверь в кладовую' },
  { k: 'H:10:9',  a: 5, b: 7, name: 'дверь в спальню' },
  { k: 'H:14:8',  a: 6, b: 8, name: 'дверь в ванную' },
  { k: 'V:13:10', a: 7, b: 8, name: 'дверь в ванную' },
];
const EXIT_KEY = 'H:2:13';

/* окна на наружных стенах */
const WINDOWS = [
  'V:0:1', 'V:0:2', 'V:0:5', 'V:0:7', 'V:0:10',
  'V:16:1', 'V:16:2', 'V:16:5', 'V:16:10', 'V:16:11',
  'H:1:0', 'H:3:0', 'H:6:0', 'H:7:0', 'H:10:0', 'H:14:0',
  'H:4:13', 'H:10:13', 'H:11:13', 'H:14:13',
];

/* скрипучие доски — отдельный шум */
const CREAKY = new Set(['3:6', '6:4', '7:9', '6:12', '10:5', '12:7', '9:11', '14:6', '2:10', '5:2']);

const World = {
  scene: null,
  colliders: [],
  doors: [],
  doorMap: {},
  hideSpots: [],
  interactables: [],
  items: [],
  windowPanes: [],
  lights: [],
  roomOf: [],
  exitDoor: null,
  bounds: { minX: 0, maxX: 0, minZ: 0, maxZ: 0 },
};

function roomAt(tx, ty) {
  for (const r of ROOMS) if (tx >= r.x0 && tx <= r.x1 && ty >= r.y0 && ty <= r.y1) return r;
  return null;
}
function roomNameAt(tx, ty) { const r = roomAt(tx, ty); return r ? r.name : 'снаружи'; }

/* ---------------- текстуры дома ---------------- */
function houseTextures() {
  const T = {};
  T.wood = TexLib.wood('fl_wood', '#4a3626', '#2a1c12', 1, 1);
  T.stone = TexLib.plaster('fl_stone', '#3b3733', 1, 1, 17);
  T.tileK = TexLib.tile('fl_tilek', '#5d6258', '#2c2f2a', 1, 1, 6);
  T.tileB = TexLib.tile('fl_tileb', '#79857f', '#39423d', 1, 1, 8);
  T.wallR = TexLib.wallpaper('w_r', '#5a3b34', '#7d5b4a', 1, 1);
  T.wallH = TexLib.wallpaper('w_h', '#4a4237', '#6a5d49', 1, 1);
  T.wallS = TexLib.wallpaper('w_s', '#3d4636', '#5c6a4d', 1, 1);
  T.wallK = TexLib.tile('w_k', '#6b6a5e', '#33322b', 1, 1, 5);
  T.wallB = TexLib.plaster('w_b', '#4b453d', 1, 1, 61);
  T.ceil = TexLib.plaster('w_ceil', '#37332e', 1, 1, 88);
  T.woodD = TexLib.wood('p_woodd', '#33241a', '#1b1109', 1, 1);
  T.woodL = TexLib.wood('p_woodl', '#6b4c30', '#3d2a19', 1, 1);
  T.metal = TexLib.metal('p_metal', '#6a6d70', 1, 1);
  T.rust = TexLib.metal('p_rust', '#5c3a24', 1, 1);
  T.fabR = TexLib.fabric('p_fabr', '#4a1f22', 1, 1);
  T.fabG = TexLib.fabric('p_fabg', '#2b3a2c', 1, 1);
  T.pale = TexLib.plaster('p_pale', '#8d8377', 1, 1, 3);
  T.paper = TexLib.plaster('p_paper', '#8a7f63', 1, 1, 44);
  T.blood = TexLib.plaster('p_blood', '#4a1010', 1, 1, 99);
  return T;
}

function scaleUV(geo, k) {
  const uv = geo.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * k, uv.getY(i) * k);
  uv.needsUpdate = true;
  return geo;
}

/* ---------------- конструктор пропсов ---------------- */
const PB = {};   // materialKey -> [{geo, matrix}]
const PMATS = ['woodD', 'woodL', 'metal', 'rust', 'fabR', 'fabG', 'pale', 'paper', 'blood', 'glassD', 'glowD'];
function initPB() { for (const k of PMATS) PB[k] = []; }

function addB(k, w, h, d, x, y, z, ry) {
  const g = scaleUV(new THREE.BoxGeometry(w, h, d), Math.max(0.6, Math.max(w, h, d) * 0.62));
  PB[k].push({ geo: g, matrix: mat4(x, y, z, ry) });
}
function addCyl(k, rt, rb, h, seg, x, y, z, rx, rz) {
  const g = scaleUV(new THREE.CylinderGeometry(rt, rb, h, seg || 8), Math.max(0.5, h * 0.5));
  const m = new THREE.Matrix4();
  const e = new THREE.Euler(rx || 0, 0, rz || 0);
  m.makeRotationFromEuler(e); m.setPosition(x, y, z);
  PB[k].push({ geo: g, matrix: m });
}
function addSphere(k, r, x, y, z, ws, hs) {
  const g = new THREE.SphereGeometry(r, ws || 10, hs || 8);
  PB[k].push({ geo: g, matrix: mat4(x, y, z) });
}

/* мир->тайл и обратно (допускаются дробные тайлы) */
const FX = tx => (tx + 0.5) * CFG.CELL;
const FZ = ty => (ty + 0.5) * CFG.CELL;

function addCol(x, z, w, d, ry) {
  // AABB с учётом поворота на 90°
  let ww = w, dd = d;
  if (ry && Math.abs(Math.abs(ry) - Math.PI / 2) < 0.01) { ww = d; dd = w; }
  World.colliders.push({ minX: x - ww / 2, maxX: x + ww / 2, minZ: z - dd / 2, maxZ: z + dd / 2 });
}

/* ============================================================
   МЕБЕЛЬ
   ============================================================ */
const Props = {
  /* стол */
  table(x, y, w, d, h) {
    const X = FX(x), Z = FZ(y), hh = h || 0.76;
    addB('woodD', w, 0.07, d, X, hh, Z);
    const t = 0.09;
    for (const sx of [-1, 1]) for (const sz of [-1, 1])
      addB('woodD', t, hh, t, X + sx * (w / 2 - t), hh / 2, Z + sz * (d / 2 - t));
    addCol(X, Z, w * 0.92, d * 0.92);
  },
  chair(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.44, 0.06, 0.44, X, 0.45, Z, ry);
    addB('woodD', 0.44, 0.55, 0.06, X - Math.sin(ry || 0) * 0.19, 0.75, Z - Math.cos(ry || 0) * 0.19, ry);
    for (const sx of [-1, 1]) for (const sz of [-1, 1])
      addB('woodD', 0.05, 0.45, 0.05, X + sx * 0.18, 0.22, Z + sz * 0.18);
    addCol(X, Z, 0.44, 0.44, ry);
  },
  /* кухонная стойка */
  counter(x, y, w, d) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', w, 0.86, d, X, 0.43, Z);
    addB('pale', w + 0.06, 0.06, d + 0.06, X, 0.89, Z);
    addB('metal', 0.42, 0.02, 0.34, X, 0.925, Z); // мойка
    addCol(X, Z, w, d);
  },
  stove(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('metal', 0.85, 0.9, 0.72, X, 0.45, Z);
    addB('rust', 0.8, 0.05, 0.66, X, 0.92, Z);
    for (const sx of [-1, 1]) for (const sz of [-1, 1])
      addCyl('rust', 0.09, 0.09, 0.03, 10, X + sx * 0.2, 0.96, Z + sz * 0.16);
    addB('rust', 0.6, 0.34, 0.05, X, 0.32, Z + 0.36);
    addCol(X, Z, 0.85, 0.72);
  },
  fridge(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('pale', 0.82, 1.85, 0.74, X, 0.93, Z);
    addB('rust', 0.78, 0.03, 0.7, X, 1.22, Z + 0.03);
    addB('metal', 0.05, 0.42, 0.06, X + 0.34, 1.5, Z + 0.4);
    addB('blood', 0.3, 0.42, 0.02, X + 0.1, 0.62, Z + 0.38);
    addCol(X, Z, 0.82, 0.74);
  },
  /* диван */
  sofa(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 2.0, d = 0.85;
    const c = Math.cos(ry || 0), s = Math.sin(ry || 0);
    const L = (lx, lz) => [X + lx * c + lz * s, Z - lx * s + lz * c];
    let p;
    p = L(0, 0); addB('fabR', w, 0.34, d, p[0], 0.30, p[1], ry);
    p = L(0, -d / 2 + 0.12); addB('fabR', w, 0.62, 0.24, p[0], 0.60, p[1], ry);
    for (const sx of [-1, 1]) { p = L(sx * (w / 2 - 0.11), 0); addB('fabR', 0.22, 0.52, d, p[0], 0.44, p[1], ry); }
    p = L(0, 0.06); addB('fabR', w - 0.4, 0.14, d - 0.3, p[0], 0.51, p[1], ry);
    addCol(X, Z, w, d, ry);
  },
  armchair(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('fabG', 0.86, 0.32, 0.82, X, 0.30, Z, ry);
    addB('fabG', 0.86, 0.6, 0.2, X - Math.sin(ry || 0) * 0.31, 0.6, Z - Math.cos(ry || 0) * 0.31, ry);
    for (const sx of [-1, 1])
      addB('fabG', 0.18, 0.42, 0.78, X + Math.cos(ry || 0) * sx * 0.34, 0.44, Z - Math.sin(ry || 0) * sx * 0.34, ry);
    addCol(X, Z, 0.86, 0.82, ry);
  },
  /* шкаф-купе / книжный */
  bookshelf(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 1.35, d = 0.36, h = 2.15;
    addB('woodD', w, h, d, X, h / 2, Z, ry);
    const c = Math.cos(ry || 0), s = Math.sin(ry || 0);
    for (let i = 0; i < 4; i++) {
      const lz = d / 2 - 0.03, ly = 0.35 + i * 0.47;
      for (let b = 0; b < 5; b++) {
        const lx = -w / 2 + 0.14 + b * (w - 0.28) / 4.4 + (Math.random() - 0.5) * 0.03;
        const bh = 0.26 + Math.random() * 0.12;
        addB(Math.random() < 0.5 ? 'paper' : 'blood', 0.07 + Math.random() * 0.05, bh, 0.24,
          X + lx * c + lz * s, ly + bh / 2 - 0.14, Z - lx * s + lz * c, ry);
      }
    }
    addCol(X, Z, w, d, ry);
  },
  wardrobe(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 1.3, d = 0.7, h = 2.25;
    addB('woodD', w, h, d, X, h / 2, Z, ry);
    addB('woodL', w * 0.44, h - 0.25, 0.035, X - Math.cos(ry || 0) * w * 0.24, h / 2, Z + Math.sin(ry || 0) * w * 0.24, ry);
    addB('woodL', w * 0.44, h - 0.25, 0.035, X + Math.cos(ry || 0) * w * 0.24, h / 2, Z - Math.sin(ry || 0) * w * 0.24, ry);
    addB('metal', 0.035, 0.2, 0.035, X - Math.cos(ry || 0) * w * 0.03, 1.15, Z + Math.sin(ry || 0) * w * 0.03 + 0.03, ry);
    addCol(X, Z, w, d, ry);
    World.hideSpots.push({
      type: 'wardrobe', x: X, z: Z, ry: ry || 0, label: 'шкаф',
      eye: new THREE.Vector3(X, 1.42, Z), noise: 6.5
    });
  },
  /* кровать + тайник под ней */
  bed(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 1.5, d = 2.1;
    addB('woodD', w, 0.22, d, X, 0.34, Z, ry);
    for (const sx of [-1, 1]) for (const sz of [-1, 1])
      addB('woodD', 0.1, 0.34, 0.1, X + sx * (w / 2 - 0.1), 0.17, Z + sz * (d / 2 - 0.1), ry);
    addB('woodD', w + 0.08, 0.95, 0.1, X - Math.sin(ry || 0) * (d / 2), 0.85, Z - Math.cos(ry || 0) * (d / 2), ry);
    addB('paper', w - 0.1, 0.2, d - 0.16, X, 0.53, Z, ry);
    addB('fabR', w - 0.06, 0.12, d * 0.62, X + Math.sin(ry || 0) * d * 0.14, 0.62, Z + Math.cos(ry || 0) * d * 0.14, ry);
    addB('pale', 0.5, 0.14, 0.34, X - Math.sin(ry || 0) * (d / 2 - 0.32), 0.66, Z - Math.cos(ry || 0) * (d / 2 - 0.32), ry);
    addCol(X, Z, w, d, ry);
    World.hideSpots.push({
      type: 'bed', x: X, z: Z, ry: ry || 0, label: 'под кровать',
      eye: new THREE.Vector3(X, 0.30, Z), noise: 4.0
    });
  },
  nightstand(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.5, 0.56, 0.44, X, 0.28, Z);
    addB('woodL', 0.42, 0.2, 0.03, X, 0.36, Z + 0.22);
    addB('metal', 0.05, 0.03, 0.03, X, 0.36, Z + 0.245);
    addCol(X, Z, 0.5, 0.44);
  },
  /* верстак */
  workbench(x, y, w) {
    const X = FX(x), Z = FZ(y);
    addB('woodL', w, 0.12, 0.78, X, 0.88, Z);
    for (const sx of [-1, 1]) addB('woodD', 0.12, 0.88, 0.7, X + sx * (w / 2 - 0.12), 0.44, Z);
    addB('woodD', w - 0.3, 0.4, 0.6, X, 0.42, Z);
    addB('rust', w, 0.05, 0.06, X, 1.5, Z - 0.33);
    // инструменты на стене
    for (let i = 0; i < 5; i++)
      addB('metal', 0.06, 0.3 + Math.random() * 0.2, 0.05, X - w / 2 + 0.4 + i * (w - 0.8) / 4, 1.35 + Math.random() * 0.15, Z - 0.34);
    addCol(X, Z, w, 0.78);
  },
  barrel(x, y) {
    const X = FX(x), Z = FZ(y);
    addCyl('woodL', 0.33, 0.3, 0.92, 12, X, 0.46, Z);
    addCyl('rust', 0.345, 0.345, 0.06, 12, X, 0.26, Z);
    addCyl('rust', 0.345, 0.345, 0.06, 12, X, 0.68, Z);
    addCol(X, Z, 0.66, 0.66);
  },
  crate(x, y, s) {
    const X = FX(x), Z = FZ(y), k = s || 0.62;
    addB('woodL', k, k, k, X, k / 2, Z, Math.random() * 0.5);
    addB('woodD', k * 1.02, 0.06, 0.06, X, k * 0.72, Z, Math.random() * 0.5);
    addCol(X, Z, k, k);
  },
  furnace(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('rust', 1.15, 1.5, 0.95, X, 0.75, Z);
    addB('metal', 0.5, 0.44, 0.06, X, 0.55, Z + 0.48);
    addB('glowD', 0.4, 0.3, 0.03, X, 0.55, Z + 0.5);
    addCyl('rust', 0.17, 0.19, 1.3, 10, X + 0.3, 2.1, Z - 0.2);
    addCol(X, Z, 1.15, 0.95);
  },
  desk(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 1.7, d = 0.82;
    addB('woodL', w, 0.08, d, X, 0.78, Z, ry);
    for (const sx of [-1, 1])
      addB('woodD', 0.1, 0.78, d - 0.06, X + sx * (w / 2 - 0.1) * Math.cos(ry || 0), 0.39, Z - sx * (w / 2 - 0.1) * Math.sin(ry || 0), ry);
    addB('woodD', w - 0.3, 0.34, 0.06, X, 0.55, Z + 0.34 * Math.cos(ry || 0), ry);
    addB('paper', 0.3, 0.01, 0.4, X + 0.2, 0.83, Z, ry);
    addCol(X, Z, w, d, ry);
  },
  safe(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('metal', 0.72, 0.78, 0.6, X, 0.39, Z);
    addB('rust', 0.5, 0.56, 0.04, X, 0.42, Z + 0.31);
    addCyl('metal', 0.11, 0.11, 0.06, 12, X, 0.42, Z + 0.35);
    addCol(X, Z, 0.72, 0.6);
  },
  bathtub(x, y, ry) {
    const X = FX(x), Z = FZ(y), w = 1.7, d = 0.82;
    addB('pale', w, 0.6, d, X, 0.3, Z, ry);
    addB('blood', w - 0.18, 0.1, d - 0.2, X, 0.5, Z, ry);
    addB('metal', 0.06, 0.34, 0.06, X - Math.cos(ry || 0) * (w / 2 - 0.1), 0.72, Z + Math.sin(ry || 0) * (w / 2 - 0.1), ry);
    addCol(X, Z, w, d, ry);
  },
  sink(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('pale', 0.58, 0.14, 0.46, X, 0.82, Z);
    addB('pale', 0.14, 0.82, 0.14, X, 0.41, Z - 0.14);
    addB('metal', 0.04, 0.24, 0.04, X, 1.0, Z - 0.1);
    addB('blood', 0.2, 0.02, 0.16, X, 0.885, Z + 0.04);
    addCol(X, Z, 0.58, 0.46);
  },
  toilet(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('pale', 0.4, 0.42, 0.52, X, 0.21, Z);
    addB('pale', 0.42, 0.5, 0.2, X, 0.5, Z - 0.2);
    addCol(X, Z, 0.42, 0.52);
  },
  shelf(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 1.3, 1.9, 0.42, X, 0.95, Z, ry);
    for (let i = 0; i < 4; i++)
      addB('woodL', 1.2, 0.04, 0.38, X, 0.35 + i * 0.46, Z + 0.02, ry);
    for (let i = 0; i < 7; i++)
      addCyl(i % 2 ? 'blood' : 'pale', 0.07, 0.07, 0.2, 8,
        X - 0.5 + i * 0.17, 0.55 + (i % 3) * 0.46, Z + 0.03);
    addCol(X, Z, 1.3, 0.42, ry);
  },
  hangingMeat(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('rust', 0.05, 0.6, 0.05, X, CFG.WALL_H - 0.32, Z);
    addCyl('blood', 0.17, 0.11, 0.62, 8, X, CFG.WALL_H - 0.92, Z);
    addSphere('blood', 0.13, X, CFG.WALL_H - 1.26, Z, 8, 6);
  },
  clockCase(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.56, 2.2, 0.34, X, 1.1, Z, ry);
    addB('woodL', 0.44, 0.44, 0.04, X, 1.72, Z + 0.18 * Math.cos(ry || 0), ry);
    addCyl('pale', 0.17, 0.17, 0.03, 14, X, 1.72, Z + 0.2 * Math.cos(ry || 0), Math.PI / 2);
    addB('metal', 0.16, 0.16, 0.02, X, 0.85, Z + 0.18 * Math.cos(ry || 0), ry);
    addCol(X, Z, 0.56, 0.34, ry);
  },
  tv(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.9, 0.44, 0.5, X, 0.22, Z, ry);
    addB('woodD', 0.78, 0.62, 0.44, X, 0.75, Z, ry);
    addB('glowD', 0.62, 0.44, 0.03, X + Math.sin(ry || 0) * 0.22, 0.76, Z + Math.cos(ry || 0) * 0.22, ry);
    addCol(X, Z, 0.9, 0.5, ry);
    return new THREE.Vector3(X + Math.sin(ry || 0) * 0.24, 0.76, Z + Math.cos(ry || 0) * 0.24);
  },
  fireplace(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('stone'.replace('stone', 'pale'), 1.5, 1.5, 0.32, X, 0.75, Z, ry);
    addB('glowD', 0.8, 0.7, 0.06, X, 0.42, Z + 0.15 * Math.cos(ry || 0), ry);
    addB('woodD', 1.7, 0.1, 0.42, X, 1.53, Z, ry);
    addCol(X, Z, 1.5, 0.32, ry);
  },
  crate2(x, y) { Props.crate(x, y, 0.5); },
  coatRack(x, y) {
    const X = FX(x), Z = FZ(y);
    addCyl('woodD', 0.05, 0.07, 1.85, 8, X, 0.93, Z);
    addCyl('woodD', 0.28, 0.3, 0.06, 10, X, 0.03, Z);
    for (let i = 0; i < 4; i++) {
      const a = i * TAU / 4;
      addCyl('woodD', 0.025, 0.025, 0.28, 6, X + Math.cos(a) * 0.12, 1.74, Z + Math.sin(a) * 0.12, 0, Math.cos(a) * 0.7);
    }
    addB('fabG', 0.44, 0.9, 0.2, X + 0.14, 1.28, Z);
    addCol(X, Z, 0.3, 0.3);
  },
  mirror(x, y, ry, wallSide) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.68, 1.0, 0.07, X, 1.5, Z, ry);
    addB('glassD', 0.56, 0.86, 0.03, X + Math.sin(ry || 0) * 0.03, 1.5, Z + Math.cos(ry || 0) * 0.03, ry);
  },
  doll(x, y, scale) {
    const X = FX(x), Z = FZ(y), s = scale || 1;
    addB('pale', 0.1 * s, 0.16 * s, 0.08 * s, X, 0.08 * s, Z);
    addSphere('pale', 0.06 * s, X, 0.2 * s, Z, 8, 6);
    addB('blood', 0.02 * s, 0.02 * s, 0.02 * s, X - 0.022 * s, 0.21 * s, Z + 0.055 * s);
    addB('blood', 0.02 * s, 0.02 * s, 0.02 * s, X + 0.022 * s, 0.21 * s, Z + 0.055 * s);
  },
  cradle(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.9, 0.5, 0.55, X, 0.4, Z, ry);
    addB('paper', 0.8, 0.08, 0.45, X, 0.62, Z, ry);
    addB('woodD', 0.06, 0.5, 0.55, X - 0.42 * Math.cos(ry || 0), 0.85, Z + 0.42 * Math.sin(ry || 0), ry);
    Props.doll(X, Z, 1);
    addCol(X, Z, 0.9, 0.55, ry);
  },
  chest(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.95, 0.52, 0.55, X, 0.26, Z, ry);
    addB('rust', 0.98, 0.08, 0.58, X, 0.5, Z, ry);
    addB('metal', 0.14, 0.16, 0.04, X, 0.36, Z + 0.28 * Math.cos(ry || 0), ry);
    addCol(X, Z, 0.95, 0.55, ry);
  },
  cage(x, y) {
    const X = FX(x), Z = FZ(y);
    for (let i = 0; i < 8; i++) {
      const a = i * TAU / 8;
      addCyl('rust', 0.028, 0.028, 1.5, 5, X + Math.cos(a) * 0.5, 0.75, Z + Math.sin(a) * 0.5);
    }
    addCyl('rust', 0.52, 0.52, 0.05, 12, X, 1.5, Z);
    addCyl('rust', 0.52, 0.52, 0.05, 12, X, 0.04, Z);
    addSphere('pale', 0.14, X, 0.2, Z, 9, 7);
    addCol(X, Z, 1.0, 1.0);
  },
  rug(x, y, w, d) {
    addB('fabR', w, 0.02, d, FX(x), 0.012, FZ(y));
  },
  console_(x, y, ry) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 1.0, 0.06, 0.34, X, 0.74, Z, ry);
    for (const sx of [-1, 1])
      addB('woodD', 0.07, 0.74, 0.3, X + sx * 0.44 * Math.cos(ry || 0), 0.37, Z - sx * 0.44 * Math.sin(ry || 0), ry);
    addCol(X, Z, 1.0, 0.34, ry);
  },
  buckets(x, y) {
    const X = FX(x), Z = FZ(y);
    addCyl('rust', 0.17, 0.14, 0.3, 10, X, 0.15, Z);
    addCyl('metal', 0.15, 0.12, 0.26, 10, X + 0.3, 0.13, Z + 0.14);
    addCol(X, Z, 0.34, 0.34);
  },
  /* картина на стене */
  painting(x, y, ry, w, h) {
    const X = FX(x), Z = FZ(y), yy = 1.72;
    addB('woodD', w || 0.62, h || 0.8, 0.06, X, yy, Z, ry);
    addB('blood', (w || 0.62) - 0.12, (h || 0.8) - 0.12, 0.02, X + Math.sin(ry || 0) * 0.03, yy, Z + Math.cos(ry || 0) * 0.03, ry);
  },
  /* лестница-люк на чердак */
  atticHatch(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.95, 0.08, 0.95, X, CFG.WALL_H - 0.06, Z);
    addB('rust', 0.9, 0.03, 0.06, X, CFG.WALL_H - 0.11, Z);
    addB('metal', 0.05, 0.22, 0.05, X + 0.3, CFG.WALL_H - 0.2, Z);
  },
  /* свечи */
  candles(x, y) {
    const X = FX(x), Z = FZ(y);
    for (let i = 0; i < 3; i++) {
      const ox = (i - 1) * 0.14;
      addCyl('pale', 0.035, 0.04, 0.2 + i * 0.05, 7, X + ox, 0.94 + (0.2 + i * 0.05) / 2 - 0.1, Z);
    }
    return new THREE.Vector3(X, 1.18, Z);
  },
  gramophone(x, y) {
    const X = FX(x), Z = FZ(y);
    addB('woodD', 0.44, 0.24, 0.44, X, 0.12, Z);
    addCyl('rust', 0.05, 0.09, 0.3, 8, X, 0.36, Z);
    addCyl('rust', 0.26, 0.05, 0.3, 12, X + 0.12, 0.6, Z, 0.5);
    addCol(X, Z, 0.44, 0.44);
  },
};

/* ============================================================
   ПОСТРОЙКА ДОМА
   ============================================================ */
function buildHouse(scene, T) {
  World.scene = scene;
  initPB();
  const C = CFG.CELL, H = CFG.WALL_H, Tt = CFG.WALL_T;
  const GW = CFG.GW, GH = CFG.GH;

  const doorSet = {};
  for (const d of DOORS) doorSet[d.k] = d;
  doorSet[EXIT_KEY] = { k: EXIT_KEY, exit: true, name: 'входная дверь' };
  const winSet = {}; for (const w of WINDOWS) winSet[w] = true;

  const wallGeo = [], floorGeos = {}, ceilGeo = [];
  const skirtGeo = [];
  const glassGeo = [], frameGeo = [];

  function pushWall(geo) { wallGeo.push(geo); }

  /* ---- пол по комнатам ---- */
  for (const r of ROOMS) {
    const w = (r.x1 - r.x0 + 1) * C, d = (r.y1 - r.y0 + 1) * C;
    const cx = (r.x0 + r.x1 + 1) / 2 * C, cz = (r.y0 + r.y1 + 1) / 2 * C;
    const g = new THREE.PlaneGeometry(w, d);
    g.rotateX(-Math.PI / 2);
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / 2.2, uv.getY(i) * d / 2.2);
    const m = new THREE.Matrix4(); m.setPosition(cx, 0, cz);
    if (!floorGeos[r.floor]) floorGeos[r.floor] = [];
    floorGeos[r.floor].push({ geo: g, matrix: m });

    const gc = new THREE.PlaneGeometry(w, d);
    gc.rotateX(Math.PI / 2);
    const uvc = gc.attributes.uv;
    for (let i = 0; i < uvc.count; i++) uvc.setXY(i, uvc.getX(i) * w / 3, uvc.getY(i) * d / 3);
    const mc = new THREE.Matrix4(); mc.setPosition(cx, H, cz);
    ceilGeo.push({ geo: gc, matrix: mc });
  }

  /* ---- стены ---- */
  function openingPieces(cx, cz, len, horiz, openW, openB, openT) {
    const out = [];
    const sideLen = (len - openW) / 2;
    const add = (w, h, d, x, y, z) => { if (h > 0.012 && w > 0.012 && d > 0.012) out.push({ w, h, d, x, y, z }); };
    if (horiz) {
      add(len, openB, Tt, cx, openB / 2, cz);
      add(len, H - openT, Tt, cx, (H + openT) / 2, cz);
      for (const s of [-1, 1])
        add(sideLen, openT - openB, Tt, cx + s * (openW + sideLen) / 2, (openB + openT) / 2, cz);
    } else {
      add(Tt, openB, len, cx, openB / 2, cz);
      add(Tt, H - openT, len, cx, (H + openT) / 2, cz);
      for (const s of [-1, 1])
        add(Tt, openT - openB, sideLen, cx, (openB + openT) / 2, cz + s * (openW + sideLen) / 2);
    }
    return out;
  }

  function solidWall(cx, cz, horiz, len) {
    pushWall(box(horiz ? len : Tt, H, horiz ? Tt : len, mat4(cx, H / 2, cz)));
    // плинтус
    const sh = 0.13;
    skirtGeo.push(box(horiz ? len : Tt + 0.05, sh, horiz ? Tt + 0.05 : len, mat4(cx, sh / 2, cz)));
    World.colliders.push(horiz
      ? { minX: cx - len / 2, maxX: cx + len / 2, minZ: cz - Tt / 2, maxZ: cz + Tt / 2 }
      : { minX: cx - Tt / 2, maxX: cx + Tt / 2, minZ: cz - len / 2, maxZ: cz + len / 2 });
  }

  const DOOR_H = 2.12, DOOR_W = C * 0.80;
  const WIN_W = 1.05, WIN_B = 0.95, WIN_T = 2.15;

  // вертикальные рёбра
  for (let tx = 0; tx <= GW; tx++) for (let ty = 0; ty < GH; ty++) {
    const L = tx > 0 ? roomAt(tx - 1, ty) : null;
    const R = tx < GW ? roomAt(tx, ty) : null;
    const perim = !L || !R;
    if (!perim && L.id === R.id) continue;
    const key = 'V:' + tx + ':' + ty;
    const cx = tx * C, cz = (ty + 0.5) * C;
    if (doorSet[key]) {
      const p = openingPieces(cx, cz, C, false, DOOR_W, 0, DOOR_H);
      for (const q of p) pushWall(box(q.w, q.h, q.d, mat4(q.x, q.y, q.z)));
      const sh = 0.13;
      skirtGeo.push(box(Tt + 0.05, sh, (C - DOOR_W) / 2, mat4(cx, sh / 2, cz - (DOOR_W + (C - DOOR_W) / 2) / 2)));
      skirtGeo.push(box(Tt + 0.05, sh, (C - DOOR_W) / 2, mat4(cx, sh / 2, cz + (DOOR_W + (C - DOOR_W) / 2) / 2)));
      World.colliders.push({ minX: cx - Tt / 2, maxX: cx + Tt / 2, minZ: cz - C / 2, maxZ: cz - DOOR_W / 2 });
      World.colliders.push({ minX: cx - Tt / 2, maxX: cx + Tt / 2, minZ: cz + DOOR_W / 2, maxZ: cz + C / 2 });
      makeDoor(doorSet[key], cx, cz, false, DOOR_W, DOOR_H);
    } else if (winSet[key]) {
      const p = openingPieces(cx, cz, C, false, WIN_W, WIN_B, WIN_T);
      for (const q of p) pushWall(box(q.w, q.h, q.d, mat4(q.x, q.y, q.z)));
      const g = new THREE.PlaneGeometry(WIN_W, WIN_T - WIN_B);
      g.rotateY(Math.PI / 2);
      glassGeo.push({ geo: g, matrix: mat4(cx, (WIN_B + WIN_T) / 2, cz) });
      frameGeo.push(box(0.08, WIN_T - WIN_B + 0.1, 0.1, mat4(cx, (WIN_B + WIN_T) / 2, cz - WIN_W / 2)));
      frameGeo.push(box(0.08, WIN_T - WIN_B + 0.1, 0.1, mat4(cx, (WIN_B + WIN_T) / 2, cz + WIN_W / 2)));
      frameGeo.push(box(0.08, 0.09, WIN_W + 0.16, mat4(cx, WIN_B - 0.04, cz)));
      frameGeo.push(box(0.08, 0.09, WIN_W + 0.16, mat4(cx, WIN_T + 0.04, cz)));
      frameGeo.push(box(0.06, WIN_T - WIN_B, 0.05, mat4(cx, (WIN_B + WIN_T) / 2, cz)));
      frameGeo.push(box(0.06, 0.05, WIN_W, mat4(cx, (WIN_B + WIN_T) / 2, cz)));
      World.colliders.push({ minX: cx - Tt / 2, maxX: cx + Tt / 2, minZ: cz - C / 2, maxZ: cz + C / 2 });
      World.windowPanes.push({ x: cx, z: cz });
    } else {
      solidWall(cx, cz, false, C);
    }
  }
  // горизонтальные рёбра
  for (let ty = 0; ty <= GH; ty++) for (let tx = 0; tx < GW; tx++) {
    const U = ty > 0 ? roomAt(tx, ty - 1) : null;
    const D = ty < GH ? roomAt(tx, ty) : null;
    const perim = !U || !D;
    if (!perim && U.id === D.id) continue;
    const key = 'H:' + tx + ':' + ty;
    const cx = (tx + 0.5) * C, cz = ty * C;
    if (doorSet[key]) {
      const p = openingPieces(cx, cz, C, true, DOOR_W, 0, DOOR_H);
      for (const q of p) pushWall(box(q.w, q.h, q.d, mat4(q.x, q.y, q.z)));
      const sh = 0.13;
      skirtGeo.push(box((C - DOOR_W) / 2, sh, Tt + 0.05, mat4(cx - (DOOR_W + (C - DOOR_W) / 2) / 2, sh / 2, cz)));
      skirtGeo.push(box((C - DOOR_W) / 2, sh, Tt + 0.05, mat4(cx + (DOOR_W + (C - DOOR_W) / 2) / 2, sh / 2, cz)));
      World.colliders.push({ minX: cx - C / 2, maxX: cx - DOOR_W / 2, minZ: cz - Tt / 2, maxZ: cz + Tt / 2 });
      World.colliders.push({ minX: cx + DOOR_W / 2, maxX: cx + C / 2, minZ: cz - Tt / 2, maxZ: cz + Tt / 2 });
      makeDoor(doorSet[key], cx, cz, true, DOOR_W, DOOR_H);
    } else if (winSet[key]) {
      const p = openingPieces(cx, cz, C, true, WIN_W, WIN_B, WIN_T);
      for (const q of p) pushWall(box(q.w, q.h, q.d, mat4(q.x, q.y, q.z)));
      const g = new THREE.PlaneGeometry(WIN_W, WIN_T - WIN_B);
      glassGeo.push({ geo: g, matrix: mat4(cx, (WIN_B + WIN_T) / 2, cz) });
      frameGeo.push(box(0.1, WIN_T - WIN_B + 0.1, 0.08, mat4(cx - WIN_W / 2, (WIN_B + WIN_T) / 2, cz)));
      frameGeo.push(box(0.1, WIN_T - WIN_B + 0.1, 0.08, mat4(cx + WIN_W / 2, (WIN_B + WIN_T) / 2, cz)));
      frameGeo.push(box(WIN_W + 0.16, 0.09, 0.11, mat4(cx, WIN_B - 0.04, cz)));
      frameGeo.push(box(WIN_W + 0.16, 0.09, 0.11, mat4(cx, WIN_T + 0.04, cz)));
      frameGeo.push(box(0.05, WIN_T - WIN_B, 0.06, mat4(cx, (WIN_B + WIN_T) / 2, cz)));
      frameGeo.push(box(WIN_W, 0.05, 0.06, mat4(cx, (WIN_B + WIN_T) / 2, cz)));
      World.colliders.push({ minX: cx - C / 2, maxX: cx + C / 2, minZ: cz - Tt / 2, maxZ: cz + Tt / 2 });
      World.windowPanes.push({ x: cx, z: cz });
    } else {
      solidWall(cx, cz, true, C);
    }
  }

  /* ---- меши ---- */
  const wallMat = mat(T.wallH, { roughness: 0.97 });
  wallMat.map.repeat.set(1.6, 1);
  const wallMesh = new THREE.Mesh(mergeGeos(wallGeo), wallMat);
  wallMesh.receiveShadow = true; wallMesh.castShadow = true;
  scene.add(wallMesh);

  const skirtMesh = new THREE.Mesh(mergeGeos(skirtGeo), mat(T.woodD, { roughness: 0.9 }));
  skirtMesh.receiveShadow = true; scene.add(skirtMesh);

  for (const key in floorGeos) {
    const fm = mat(T[key], { roughness: 0.93 });
    fm.map.repeat.set(1, 1);
    const m = new THREE.Mesh(mergeGeos(floorGeos[key]), fm);
    m.receiveShadow = true; scene.add(m);
  }
  const cm = mat(T.ceil, { roughness: 1 });
  cm.map.repeat.set(3, 3);
  const ceilMesh = new THREE.Mesh(mergeGeos(ceilGeo), cm);
  ceilMesh.receiveShadow = true; scene.add(ceilMesh);

  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x1b2a44, emissive: 0x223a63, emissiveIntensity: 0.55,
    roughness: 0.25, metalness: 0.0, transparent: true, opacity: 0.92, side: THREE.DoubleSide
  });
  const glassMesh = new THREE.Mesh(mergeGeos(glassGeo), glassMat);
  scene.add(glassMesh);
  World.glassMat = glassMat;
  const frameMesh = new THREE.Mesh(mergeGeos(frameGeo), mat(T.woodD, { roughness: 0.85 }));
  scene.add(frameMesh);

  /* ---- мебель ---- */
  furnish();

  /* ---- сборка пропсов ---- */
  const propMats = {
    woodD: mat(T.woodD, { roughness: 0.9 }), woodL: mat(T.woodL, { roughness: 0.88 }),
    metal: mat(T.metal, { roughness: 0.45, metalness: 0.72 }),
    rust: mat(T.rust, { roughness: 0.85, metalness: 0.45 }),
    fabR: mat(T.fabR, { roughness: 1 }), fabG: mat(T.fabG, { roughness: 1 }),
    pale: mat(T.pale, { roughness: 0.8 }), paper: mat(T.paper, { roughness: 1 }),
    blood: mat(T.blood, { roughness: 0.72 }),
    glassD: new THREE.MeshStandardMaterial({ color: 0x2a3038, roughness: 0.15, metalness: 0.6 }),
    glowD: new THREE.MeshStandardMaterial({ color: 0x0a0a0a, emissive: 0x2a2a2a, roughness: 1 }),
  };
  for (const k in PB) {
    if (!PB[k].length) continue;
    const m = new THREE.Mesh(mergeGeos(PB[k]), propMats[k]);
    m.castShadow = true; m.receiveShadow = true;
    scene.add(m);
  }

  World.bounds = { minX: -1, maxX: CFG.GW * C + 1, minZ: -1, maxZ: CFG.GH * C + 1 };
  finalizeHideSpots();
  rebuildLOS();
  return { wallMesh, propMats };
}

/* ---------------- двери ---------------- */
const DOOR_OPEN_A = 1.45;

function makeDoor(def, cx, cz, horiz, w, h) {
  const panelW = w - 0.06, panelH = h - 0.05, th = 0.055;
  const pivot = new THREE.Group();
  const hx = horiz ? cx - w / 2 : cx;
  const hz = horiz ? cz : cz - w / 2;
  pivot.position.set(hx, 0, hz);
  const baseRot = horiz ? 0 : -Math.PI / 2;

  const inner = new THREE.Group();
  inner.position.set(panelW / 2, 0, 0);   // полотно от петли в сторону +X
  const doorMat = mat(def.exit ? World.tex.woodL : World.tex.woodD, { roughness: 0.88 });
  const panel = new THREE.Mesh(new THREE.BoxGeometry(panelW, panelH, th), doorMat);
  panel.position.y = panelH / 2 + 0.025;
  panel.castShadow = true; panel.receiveShadow = true;
  inner.add(panel);
  for (const sy of [0.6, 1.4]) {
    const p2 = new THREE.Mesh(new THREE.BoxGeometry(panelW * 0.6, 0.46, 0.018), matPlain(0x150d06, 0.95));
    p2.position.set(0, sy, th / 2 + 0.011); inner.add(p2);
    const p3 = p2.clone(); p3.position.z = -th / 2 - 0.011; inner.add(p3);
  }
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8),
    new THREE.MeshStandardMaterial({ color: 0x8a7a4a, roughness: 0.32, metalness: 0.92 }));
  knob.position.set(panelW / 2 - 0.13, 1.02, th / 2 + 0.05);
  inner.add(knob);
  if (def.exit) {
    // три запора входной двери
    const barMat = new THREE.MeshStandardMaterial({ color: 0x4c3c2c, roughness: 0.55, metalness: 0.62 });
    for (const yy of [0.5, 1.05, 1.62]) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(panelW * 1.04, 0.075, 0.085), barMat);
      bar.position.set(0, yy, th / 2 + 0.05); inner.add(bar);
    }
  }
  pivot.add(inner);
  pivot.rotation.y = baseRot;
  World.scene.add(pivot);

  const d = {
    def, pivot, inner, horiz, cx, cz, w, h, baseRot, dir: 1,
    open: def.exit ? false : (Math.random() < 0.34),
    angle: 0, target: 0, locked: !!def.exit, col: null,
  };
  d.target = d.open ? DOOR_OPEN_A : 0;
  d.angle = d.target;
  applyDoorRot(d);
  World.doors.push(d);
  World.doorMap[def.k] = d;
  if (def.exit) World.exitDoor = d;
  d.col = { minX: 0, maxX: 0, minZ: 0, maxZ: 0, door: d };
  World.colliders.push(d.col);
  updateDoorCollider(d);
  return d;
}

function applyDoorRot(d) { d.pivot.rotation.y = d.baseRot + d.angle * d.dir; }

function updateDoorCollider(d) {
  const c = d.col;
  if (doorPassable(d)) { c.dead = true; c.minX = c.maxX = c.minZ = c.maxZ = 0; return; }
  c.dead = false;
  const t = 0.11;
  if (d.horiz) {
    c.minX = d.cx - d.w / 2; c.maxX = d.cx + d.w / 2;
    c.minZ = d.cz - t; c.maxZ = d.cz + t;
  } else {
    c.minX = d.cx - t; c.maxX = d.cx + t;
    c.minZ = d.cz - d.w / 2; c.maxZ = d.cz + d.w / 2;
  }
}

function doorPassable(d) { return Math.abs(Math.sin(d.angle)) > 0.72; }

/* ---------------- навигация ---------------- */
function edgeKey(tx, ty, nx, ny) {
  const dx = nx - tx, dy = ny - ty;
  return dx !== 0 ? ('V:' + (dx > 0 ? tx + 1 : tx) + ':' + ty)
                  : ('H:' + tx + ':' + (dy > 0 ? ty + 1 : ty));
}
function sameRoom(tx, ty, nx, ny) {
  const a = roomAt(tx, ty), b = roomAt(nx, ny);
  return !!(a && b && a.id === b.id);
}
/* с учётом закрытых дверей */
function canStep(tx, ty, nx, ny) {
  if (nx < 0 || ny < 0 || nx >= CFG.GW || ny >= CFG.GH) return false;
  if (tx < 0 || ty < 0 || tx >= CFG.GW || ty >= CFG.GH) return false;
  if (sameRoom(tx, ty, nx, ny)) return true;
  const d = World.doorMap[edgeKey(tx, ty, nx, ny)];
  return d ? doorPassable(d) : false;
}
/* двери считаются проходимыми (враг их открывает) */
function edgeOpen(tx, ty, nx, ny) {
  if (nx < 0 || ny < 0 || nx >= CFG.GW || ny >= CFG.GH) return false;
  if (tx < 0 || ty < 0 || tx >= CFG.GW || ty >= CFG.GH) return false;
  if (sameRoom(tx, ty, nx, ny)) return true;
  return !!World.doorMap[edgeKey(tx, ty, nx, ny)];
}

/* ============================================================
   РАССТАНОВКА МЕБЕЛИ
   ============================================================ */
function furnish() {
  const P = Props;
  // Кухня (0..5, 0..3)
  P.counter(1.6, 0.05, 3.0, 0.72);
  P.stove(3.6, 0.05);
  P.fridge(5.1, 0.1);
  P.table(2.2, 2.0, 1.5, 0.95);
  P.chair(1.4, 1.5, 0.4); P.chair(3.0, 1.5, -0.4);
  P.chair(1.5, 2.6, 2.7); P.chair(3.0, 2.6, 3.5);
  P.shelf(0.05, 3.0, Math.PI / 2);
  P.hangingMeat(4.6, 3.2);
  P.buckets(5.0, 2.2);
  P.painting(2.6, 0.12, 0, 0.5, 0.4);

  // Гостиная (0..5, 4..8)
  P.rug(2.4, 6.2, 3.0, 2.4);
  P.sofa(0.45, 6.2, Math.PI / 2);
  P.tv(4.4, 6.2, -Math.PI / 2);
  P.armchair(2.2, 4.6, 2.6);
  P.fireplace(2.4, 4.05, 0);
  P.bookshelf(5.15, 4.6, -Math.PI / 2);
  P.clockCase(5.2, 8.1, -Math.PI / 2);
  P.console_(0.2, 8.1, Math.PI / 2);
  P.doll(1.1, 5.2); P.doll(3.6, 7.4, 1.2);
  P.painting(0.12, 5.0, Math.PI / 2, 0.7, 0.9);
  P.painting(0.12, 7.2, Math.PI / 2, 0.55, 0.7);

  // Прихожая (0..5, 9..12)
  P.coatRack(0.3, 9.4);
  P.console_(1.0, 12.5, 0);
  P.mirror(3.6, 9.1, 0);
  P.chest(4.8, 12.2, -0.3);
  P.rug(2.0, 12.3, 1.7, 1.0);
  P.painting(5.0, 10.5, -Math.PI / 2, 0.6, 0.8);
  P.doll(0.6, 11.6, 0.9);

  // Коридор (6..7, 0..12)
  P.console_(6.1, 3.2, Math.PI / 2);
  P.console_(7.0, 8.2, -Math.PI / 2);
  P.atticHatch(6.5, 5.5);
  P.painting(6.05, 1.4, Math.PI / 2, 0.45, 0.6);
  P.painting(7.05, 6.6, -Math.PI / 2, 0.45, 0.6);
  P.painting(6.05, 10.4, Math.PI / 2, 0.4, 0.55);
  P.buckets(7.1, 12.2);

  // Мастерская (8..15, 0..3)
  P.workbench(10.5, 0.15, 3.4);
  P.furnace(15.1, 0.2);
  P.barrel(14.2, 2.2); P.barrel(15.0, 2.9);
  P.crate(8.3, 0.4); P.crate(8.9, 1.1, 0.5); P.crate(9.2, 3.0);
  P.cage(12.6, 2.2);
  P.shelf(8.1, 2.6, Math.PI / 2);
  P.table(13.4, 1.1, 1.2, 0.7, 0.72);

  // Кабинет (8..12, 4..8)
  P.desk(10.0, 5.2, 0);
  P.chair(10.0, 6.0, Math.PI);
  P.bookshelf(12.4, 5.0, -Math.PI / 2);
  P.bookshelf(12.4, 6.6, -Math.PI / 2);
  P.safe(8.3, 8.2);
  P.gramophone(11.2, 7.6);
  P.rug(10.0, 6.4, 2.4, 2.0);
  P.armchair(8.6, 5.2, 1.2);
  World.candlePos = P.candles(9.4, 5.2);
  P.painting(8.1, 6.2, Math.PI / 2, 0.6, 0.8);

  // Кладовая (13..15, 4..7)
  P.shelf(13.6, 4.15, 0);
  P.shelf(15.2, 5.4, -Math.PI / 2);
  P.hangingMeat(14.4, 4.4); P.hangingMeat(15.0, 5.0);
  P.crate(13.3, 7.0); P.crate(14.0, 7.2, 0.5);
  P.barrel(15.1, 7.0);
  P.doll(13.6, 6.2, 1.1);

  // Спальня (8..12, 9..12)
  P.bed(9.0, 11.2, Math.PI / 2);
  P.wardrobe(12.2, 9.3, -Math.PI / 2);
  P.nightstand(8.2, 9.9);
  P.cradle(11.0, 12.2, 0.2);
  P.chest(8.4, 12.4, 0);
  P.mirror(10.0, 9.1, 0);
  P.rug(10.4, 10.8, 2.0, 1.6);
  P.painting(11.4, 9.1, 0, 0.55, 0.7);
  World.lampPos = new THREE.Vector3(FX(8.2), 1.05, FZ(9.9));

  // Ванная (13..15, 8..12)
  P.bathtub(14.2, 12.1, 0);
  P.sink(13.2, 8.4);
  P.toilet(15.2, 8.4);
  P.mirror(14.2, 8.1, 0);
  P.buckets(15.2, 11.0);
  P.shelf(13.1, 10.4, Math.PI / 2);
}

/* ============================================================
   ПРЕДМЕТЫ
   ============================================================ */
const ITEM_DEFS = {
  crowbar: { name: 'Гвоздодёр', color: 0x9a5a2a, need: 'доска' },
  cutters: { name: 'Кусачки', color: 0x8a8f96, need: 'цепь' },
  key:     { name: 'Латунный ключ', color: 0xc9a227, need: 'замок' },
  battery: { name: 'Батарейка', color: 0x3f7a4a },
  book:    { name: 'Красная книга', color: 0x8a1414 },
  coin:    { name: 'Старая монета', color: 0xb9a44a },
  photo:   { name: 'Выцветшее фото', color: 0xa89a7a },
};

function makeItemMesh(kind) {
  const g = new THREE.Group();
  const c = ITEM_DEFS[kind].color;
  const m = new THREE.MeshStandardMaterial({
    color: c, roughness: 0.4, metalness: 0.55,
    emissive: c, emissiveIntensity: 0.28
  });
  if (kind === 'key') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.016, 6, 12), m);
    g.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.028, 0.24), m);
    shaft.position.z = 0.14; g.add(shaft);
    const t1 = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.026, 0.03), m);
    t1.position.set(0, -0.03, 0.24); g.add(t1);
  } else if (kind === 'crowbar') {
    const s = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.5, 7), m);
    s.rotation.z = Math.PI / 2; g.add(s);
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.05, 0.05), m);
    h.position.x = 0.26; h.rotation.z = 0.5; g.add(h);
  } else if (kind === 'cutters') {
    for (const s of [-1, 1]) {
      const a = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.026, 0.34, 6), m);
      a.position.set(s * 0.05, 0, 0.06); a.rotation.z = s * 0.28; g.add(a);
    }
    const j = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 0.05), m); j.position.z = -0.1; g.add(j);
  } else if (kind === 'battery') {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.17, 10), m);
    b.rotation.z = Math.PI / 2; g.add(b);
  } else if (kind === 'book') {
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.07, 0.3), m); g.add(b);
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.05, 0.28),
      new THREE.MeshStandardMaterial({ color: 0xcfc3a0, roughness: 1 }));
    p.position.y = 0.005; g.add(p);
  } else if (kind === 'coin') {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.012, 14), m);
    b.rotation.x = Math.PI / 2; g.add(b);
  } else {
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.006, 0.26), m); g.add(b);
  }
  const halo = new THREE.PointLight(c, 0.55, 2.2, 2);
  halo.position.y = 0.1;
  g.add(halo);
  g.userData.halo = halo;
  return g;
}

function spawnItems(scene, rng, hideSpots) {
  for (const it of World.items) scene.remove(it.mesh);
  World.items = [];
  World.interactables = [];

  const roomTiles = {};
  for (const r of ROOMS) {
    roomTiles[r.id] = [];
    for (let x = r.x0; x <= r.x1; x++) for (let y = r.y0; y <= r.y1; y++) roomTiles[r.id].push([x, y]);
  }

  function freeSpot(roomIds, avoid) {
    for (let tries = 0; tries < 260; tries++) {
      const rid = roomIds[(rng() * roomIds.length) | 0];
      const t = roomTiles[rid][(rng() * roomTiles[rid].length) | 0];
      const px = FX(t[0]) + (rng() - 0.5) * CFG.CELL * 0.75;
      const pz = FZ(t[1]) + (rng() - 0.5) * CFG.CELL * 0.75;
      if (avoid.some(a => dist2(a.x, a.z, px, pz) < 2.2)) continue;
      if (blockedAt(px, pz, 0.28)) continue;
      return { x: px, z: pz, room: ROOMS.find(r => r.id === rid).name };
    }
    return null;
  }

  function place(kind, roomIds) {
    const sp = freeSpot(roomIds, World.items);
    if (!sp) return;
    const mesh = makeItemMesh(kind);
    mesh.position.set(sp.x, 0.32, sp.z);
    mesh.rotation.y = rng() * TAU;
    scene.add(mesh);
    const item = {
      kind, mesh, x: sp.x, z: sp.z, y: 0.32, taken: false,
      name: ITEM_DEFS[kind].name, room: sp.room, base: 0.32,
    };
    World.items.push(item);
    World.interactables.push({
      type: 'item', item, x: sp.x, y: 0.4, z: sp.z, r: 1.5,
      label: 'Взять: ' + ITEM_DEFS[kind].name,
    });
  }

  const ALL = [0, 1, 2, 3, 4, 5, 6, 7, 8];
  place('crowbar', [4, 6, 3, 8]);
  place('cutters', [4, 6, 0, 5]);
  place('key', [5, 7, 1, 6]);
  place('battery', ALL);
  place('battery', ALL);
  place('book', [5, 1, 7]);
  place('coin', ALL); place('coin', ALL); place('photo', ALL);

  // тайники тоже интерактивны
  for (const h of World.hideSpots) {
    World.interactables.push({
      type: 'hide', spot: h, x: h.x, y: 1.0, z: h.z, r: 1.45,
      label: 'Спрятаться: ' + h.label,
    });
  }
  // входная дверь
  World.interactables.push({
    type: 'exit', door: World.exitDoor,
    x: FX(2), y: 1.1, z: 13 * CFG.CELL - 0.1, r: 2.1,
    label: 'Входная дверь',
  });
}

/* ---------------- коллизии ---------------- */
function blockedAt(x, z, r) {
  for (const c of World.colliders) {
    if (c.dead) continue;
    if (c.door && doorPassable(c.door)) continue;
    const nx = clamp(x, c.minX, c.maxX), nz = clamp(z, c.minZ, c.maxZ);
    if (dist2(x, z, nx, nz) < r * r) return true;
  }
  return false;
}

function resolveCircle(pos, r) {
  for (let iter = 0; iter < 2; iter++) {
    for (const c of World.colliders) {
      if (c.dead) continue;
      if (c.door && doorPassable(c.door)) continue;
      const nx = clamp(pos.x, c.minX, c.maxX), nz = clamp(pos.z, c.minZ, c.maxZ);
      const dx = pos.x - nx, dz = pos.z - nz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        const d = Math.sqrt(d2) || 0.0001;
        if (d2 < 1e-8) { pos.x += r; continue; }
        pos.x = nx + dx / d * r;
        pos.z = nz + dz / d * r;
      }
    }
  }
  return pos;
}

/* проверка прямой видимости */
function lineOfSight(ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az;
  const len = Math.sqrt(dx * dx + dz * dz);
  if (len < 0.05) return true;
  const steps = Math.max(1, Math.ceil(len / (LOS_CELL * 0.45)));
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    if (losBlocked(ax + dx * t, az + dz * t)) return false;
  }
  return true;
}

/* BFS-путь по тайлам */
function findPath(sx, sy, gx, gy) {
  if (sx === gx && sy === gy) return [];
  const GW = CFG.GW, GH = CFG.GH;
  const prev = new Int32Array(GW * GH).fill(-1);
  const seen = new Uint8Array(GW * GH);
  const q = [sy * GW + sx];
  seen[sy * GW + sx] = 1;
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  let head = 0, found = -1;
  while (head < q.length) {
    const cur = q[head++];
    const cx = cur % GW, cy = (cur / GW) | 0;
    if (cx === gx && cy === gy) { found = cur; break; }
    for (const d of dirs) {
      const nx = cx + d[0], ny = cy + d[1];
      if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
      const ni = ny * GW + nx;
      if (seen[ni]) continue;
      if (!canStep(cx, cy, nx, ny)) continue;
      seen[ni] = 1; prev[ni] = cur; q.push(ni);
    }
  }
  if (found < 0) return null;
  const path = [];
  let c = found;
  while (c !== -1 && c !== sy * GW + sx) { path.push([c % GW, (c / GW) | 0]); c = prev[c]; }
  path.reverse();
  return path;
}

/* путь игнорируя закрытые двери (для врага — она их открывает) */
function findPathForce(sx, sy, gx, gy) {
  const GW = CFG.GW, GH = CFG.GH;
  const prev = new Int32Array(GW * GH).fill(-1);
  const seen = new Uint8Array(GW * GH);
  const q = [sy * GW + sx]; seen[sy * GW + sx] = 1;
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  let head = 0, found = -1;
  while (head < q.length) {
    const cur = q[head++];
    const cx = cur % GW, cy = (cur / GW) | 0;
    if (cx === gx && cy === gy) { found = cur; break; }
    for (const d of dirs) {
      const nx = cx + d[0], ny = cy + d[1];
      if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
      const ni = ny * GW + nx;
      if (seen[ni]) continue;
      if (!edgeOpen(cx, cy, nx, ny)) continue;
      seen[ni] = 1; prev[ni] = cur; q.push(ni);
    }
  }
  if (found < 0) return null;
  const path = [];
  let c = found;
  while (c !== -1 && c !== sy * GW + sx) { path.push([c % GW, (c / GW) | 0]); c = prev[c]; }
  path.reverse();
  return path;
}

/* ближайшая дверь на пути (чтобы открыть) */
function doorBetween(tx, ty, nx, ny) {
  if (tx === nx && ty === ny) return null;
  return World.doorMap[edgeKey(tx, ty, nx, ny)] || null;
}

/* ============================================================
   СЕТКА ПРЯМОЙ ВИДИМОСТИ (быстрая проверка LOS)
   ============================================================ */
const LOS_CELL = 0.26;
let losGrid = null, losW = 0, losH = 0;

function rebuildLOS() {
  const W = CFG.GW * CFG.CELL, H = CFG.GH * CFG.CELL;
  losW = Math.ceil(W / LOS_CELL) + 2;
  losH = Math.ceil(H / LOS_CELL) + 2;
  if (!losGrid || losGrid.length !== losW * losH) losGrid = new Uint8Array(losW * losH);
  else losGrid.fill(0);
  for (const c of World.colliders) {
    if (c.dead) continue;
    if (c.door && doorPassable(c.door)) continue;
    const x0 = Math.max(0, Math.floor(c.minX / LOS_CELL));
    const x1 = Math.min(losW - 1, Math.ceil(c.maxX / LOS_CELL));
    const z0 = Math.max(0, Math.floor(c.minZ / LOS_CELL));
    const z1 = Math.min(losH - 1, Math.ceil(c.maxZ / LOS_CELL));
    for (let z = z0; z <= z1; z++)
      for (let x = x0; x <= x1; x++) losGrid[z * losW + x] = 1;
  }
}
function losBlocked(x, z) {
  const gx = Math.floor(x / LOS_CELL), gz = Math.floor(z / LOS_CELL);
  if (gx < 0 || gz < 0 || gx >= losW || gz >= losH) return true;
  return losGrid[gz * losW + gx] === 1;
}


/* Направление, куда игрок выходит из укрытия, и куда при этом смотреть */
function finalizeHideSpots() {
  for (const h of World.hideSpots) {
    const r = roomAt(txOf(h.x), tzOf(h.z));
    let dir = { x: 0, z: 1 };
    if (r) {
      const cx = (r.x0 + r.x1 + 1) / 2 * CFG.CELL;
      const cz = (r.y0 + r.y1 + 1) / 2 * CFG.CELL;
      let dx = cx - h.x, dz = cz - h.z;
      const l = Math.hypot(dx, dz) || 1;
      dir = { x: dx / l, z: dz / l };
    }
    // подбираем свободную точку выхода
    const base = Math.atan2(dir.x, dir.z);
    let chosen = dir;
    for (const off of [0, 0.7, -0.7, 1.4, -1.4, 2.2, -2.2, 3.0]) {
      const a = base + off;
      const cand = { x: Math.sin(a), z: Math.cos(a) };
      const px = h.x + cand.x * 0.75, pz = h.z + cand.z * 0.75;
      if (!blockedAt(px, pz, CFG.P_RAD + 0.06)) { chosen = cand; break; }
    }
    h.out = chosen;
    h.faceYaw = Math.atan2(-chosen.x, -chosen.z);
  }
}
