/* ============================================================
   ВВОД
   ============================================================ */
const Input = {
  keys: {}, pressedSet: {}, mouseLook: false,
  dx: 0, dy: 0, locked: false, dragging: false,
  touchMove: null, touchLook: null,
  el: null,

  down(code) { return !!this.keys[code]; },

  init(canvas) {
    this.el = canvas;
    window.addEventListener('keydown', e => {
      if (!this.keys[e.code]) this.pressedSet[e.code] = true;
      this.keys[e.code] = true;
      if (['Space', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) e.preventDefault();
      if (e.code === 'Escape') Game.onEscape();
      if (e.code === 'KeyM') Game.toggleMute();
    });
    window.addEventListener('keyup', e => { this.keys[e.code] = false; });
    window.addEventListener('blur', () => { this.keys = {}; });

    document.addEventListener('mousemove', e => {
      if (this.locked) { this.dx += e.movementX || 0; this.dy += e.movementY || 0; this.mouseLook = true; }
      else if (this.dragging) { this.dx += e.movementX || 0; this.dy += e.movementY || 0; this.mouseLook = true; }
    });

    canvas.addEventListener('mousedown', e => {
      if (Game.state !== 'play') return;
      this.dragging = true;
      Game.requestLock();
    });
    window.addEventListener('mouseup', () => { this.dragging = false; });

    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === canvas;
      if (!this.locked && Game.state === 'play' && !Game.touchMode) Game.pause('lock');
    });
    document.addEventListener('pointerlockerror', () => { this.locked = false; });

    /* --- тач --- */
    const touches = {};
    canvas.addEventListener('touchstart', e => {
      if (Game.state !== 'play') return;
      Game.touchMode = true;
      for (const t of e.changedTouches) {
        const half = t.clientX < window.innerWidth * 0.45;
        touches[t.identifier] = { x: t.clientX, y: t.clientY, ox: t.clientX, oy: t.clientY, half };
      }
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('touchmove', e => {
      for (const t of e.changedTouches) {
        const rec = touches[t.identifier]; if (!rec) continue;
        const dx = t.clientX - rec.x, dy = t.clientY - rec.y;
        rec.x = t.clientX; rec.y = t.clientY;
        if (rec.half) {
          const bx = t.clientX - rec.ox, by = t.clientY - rec.oy;
          const m = Math.min(1, Math.hypot(bx, by) / 60);
          const a = Math.atan2(bx, -by);
          this.touchMove = m > 0.12 ? { x: Math.sin(a) * m, y: Math.cos(a) * m } : { x: 0, y: 0 };
        } else { this.dx += dx * 1.6; this.dy += dy * 1.6; }
      }
      e.preventDefault();
    }, { passive: false });
    const end = e => {
      for (const t of e.changedTouches) {
        const rec = touches[t.identifier];
        if (rec && rec.half) this.touchMove = null;
        delete touches[t.identifier];
      }
    };
    canvas.addEventListener('touchend', end);
    canvas.addEventListener('touchcancel', end);
  },

  pressed(code) { return !!this.pressedSet[code]; },
  endFrame() { this.pressedSet = {}; this.dx = 0; this.dy = 0; },
};

/* ============================================================
   ИГРА
   ============================================================ */
const Game = {
  state: 'menu',      // menu | play | pause | caught | dead | win
  renderer: null, scene: null, camera: null,
  torch: null, dust: null, grain: null, gctx: null,
  clock: null, time: 0,
  day: 1, score: 0,
  locks: { board: false, chain: false, lock: false },
  lockStep: 0, working: 0, workKind: null,
  touchMode: false,
  quality: 'high',
  flash: 0, lightningT: 12,
  jumpT: -1,
  hint: '', hintT: 0,
  subtitle: '', subT: 0,
  settings: { sens: 1.0, invert: false, shadows: true, volume: 0.85 },
  tvPos: null, candleLight: null, bulbLight: null, furnaceLight: null, lampLight: null,
  ambient: null,
  interactNow: null,
  started: false,
  qualityLevel: 2,
  caughtCount: 0,
  secret: false,

  /* ---------- инициализация ---------- */
  boot() {
    try {
      const qs = new URLSearchParams(location.search);
      if (qs.get('q') === 'low') { this.qualityLevel = 0; this.settings.shadows = false; }
      if (qs.get('res')) this._resScale = parseFloat(qs.get('res'));
    } catch (e) { }
    const canvas = document.getElementById('gl');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(this.qualityLevel === 0 ? 0.7 : Math.min(window.devicePixelRatio || 1, 1.6));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.02;
    this.renderer.shadowMap.enabled = this.settings.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0x000000, 1);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x000000);
    this.scene.fog = new THREE.FogExp2(0x05060a, 0.088);

    this.camera = new THREE.PerspectiveCamera(74, window.innerWidth / window.innerHeight, 0.05, 90);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    Input.init(canvas);

    const g = document.getElementById('grain');
    g.width = 220; g.height = 140;
    this.grain = g; this.gctx = g.getContext('2d');

    window.addEventListener('resize', () => this.resize());
    this.resize();

    this.clock = new THREE.Clock();
    this.buildWorld();
    this.bindUI();
    this.loop();
  },

  buildWorld() {
    const T = houseTextures();
    World.tex = T;

    // свет
    this.ambient = new THREE.HemisphereLight(0x2a3550, 0x07060a, 0.16);
    this.scene.add(this.ambient);

    this.torch = new THREE.SpotLight(0xffe3b4, 2.6, 19, 0.46, 0.62, 1.55);
    this.torch.castShadow = this.settings.shadows;
    this.torch.shadow.mapSize.width = 1024;
    this.torch.shadow.mapSize.height = 1024;
    this.torch.shadow.camera.near = 0.12;
    this.torch.shadow.camera.far = 20;
    this.torch.shadow.bias = -0.0022;
    this.torch.shadow.focus = 1;
    this.camera.add(this.torch);
    this.torch.position.set(0.16, -0.12, 0.05);
    this.torchTarget = new THREE.Object3D();
    this.torchTarget.position.set(0.16, -0.12, -6);
    this.camera.add(this.torchTarget);
    this.torch.target = this.torchTarget;

    buildHouse(this.scene, T);

    // свеча в кабинете
    if (World.candlePos) {
      this.candleLight = new THREE.PointLight(0xff9b45, 1.5, 6.5, 2);
      this.candleLight.position.copy(World.candlePos);
      this.scene.add(this.candleLight);
      const fl = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5),
        new THREE.MeshBasicMaterial({ color: 0xffc06a }));
      fl.position.copy(World.candlePos);
      this.scene.add(fl);
      this.candleFlame = fl;
    }
    // лампа в спальне
    if (World.lampPos) {
      this.lampLight = new THREE.PointLight(0xffb070, 0.55, 5.2, 2);
      this.lampLight.position.copy(World.lampPos);
      this.scene.add(this.lampLight);
      const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.16, 0.16, 10, 1, true),
        new THREE.MeshStandardMaterial({ color: 0x6a4a2a, emissive: 0x552a10, roughness: 1, side: THREE.DoubleSide }));
      shade.position.copy(World.lampPos).add(new THREE.Vector3(0, 0.24, 0));
      this.scene.add(shade);
    }
    // печь в мастерской
    this.furnaceLight = new THREE.PointLight(0xff5a18, 1.15, 5.0, 2);
    this.furnaceLight.position.set(FX(15.1), 0.6, FZ(0.6));
    this.scene.add(this.furnaceLight);
    // лампочка на кухне
    this.bulbLight = new THREE.PointLight(0xffd9a0, 0.42, 6.0, 2);
    this.bulbLight.position.set(FX(2.5), 2.62, FZ(1.6));
    this.scene.add(this.bulbLight);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0xffd9a0 }));
    bulb.position.copy(this.bulbLight.position);
    this.scene.add(bulb);
    const wire = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.4, 5),
      new THREE.MeshStandardMaterial({ color: 0x2a2a2a, roughness: 1 }));
    wire.position.set(FX(2.5), 2.84, FZ(1.6));
    this.scene.add(wire);

    // телевизор
    this.tvPos = new THREE.Vector3(FX(4.4) - 0.24, 0.76, FZ(6.2));
    this.tvLight = new THREE.PointLight(0x8fa8c8, 0.0, 3.4, 2);
    this.tvLight.position.copy(this.tvPos);
    this.scene.add(this.tvLight);

    this.makeDust();
    this.makeViewModel();

    spawnItems(this.scene, mulberry32((Math.random() * 1e9) | 0), World.hideSpots);
    Enemy.init(this.scene);
  },

  makeDust() {
    const N = 620;
    const pos = new Float32Array(N * 3);
    const spd = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 16;
      pos[i * 3 + 1] = Math.random() * CFG.WALL_H;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 16;
      spd[i] = 0.05 + Math.random() * 0.18;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const m = new THREE.PointsMaterial({
      color: 0xbfae92, size: 0.022, transparent: true, opacity: 0.42,
      blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true
    });
    this.dust = new THREE.Points(g, m);
    this.dust.frustumCulled = false;
    this.scene.add(this.dust);
    this.dustSpd = spd;
  },

  makeViewModel() {
    const g = new THREE.Group();
    const skin = new THREE.MeshStandardMaterial({ color: 0x8d7360, roughness: 0.9 });
    const met = new THREE.MeshStandardMaterial({ color: 0x3a3d40, roughness: 0.4, metalness: 0.7 });
    const hand = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.17), skin);
    hand.position.set(0, 0, 0.02); g.add(hand);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.042, 0.24, 10), met);
    body.rotation.x = Math.PI / 2; body.position.set(0, 0.028, -0.11); g.add(body);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.05, 0.05, 10), met);
    head.rotation.x = Math.PI / 2; head.position.set(0, 0.028, -0.24); g.add(head);
    this.torchLens = new THREE.Mesh(new THREE.CircleGeometry(0.045, 12),
      new THREE.MeshBasicMaterial({ color: 0xfff0cf }));
    this.torchLens.position.set(0, 0.028, -0.267); g.add(this.torchLens);
    g.position.set(0.20, -0.19, -0.30);
    g.rotation.set(0.05, -0.10, 0.05);
    g.traverse(o => { if (o.isMesh) o.frustumCulled = false; });
    this.camera.add(g);
    this.viewModel = g;
  },

  /* ---------- новый забег ---------- */
  newGame() {
    this.day = 1; this.score = 0; this.caughtCount = 0;
    this.locks = { board: false, chain: false, lock: false };
    this.lockStep = 0; this.working = 0; this.secret = false;
    UI.setLocks(0); UI._last.inv = null;
    Player.inv = {}; Player.jars = 2; Player.battery = 100; Player.torch = true;
    this.respawn(true);
    const rng = mulberry32((Math.random() * 1e9) | 0);
    spawnItems(this.scene, rng, World.hideSpots);
    for (const d of World.doors) {
      if (d.def.exit) continue;
      d.open = Math.random() < 0.34;
      d.target = d.open ? Math.PI / 2 * 0.92 : 0; d.angle = d.target;
      d.pivot.rotation.y = d.angle * (d.horiz ? 1 : -1);
      updateDoorCollider(d);
    }
    Enemy.reset();
    this.state = 'play';
    this.setHint('Найди гвоздодёр, кусачки и ключ. Входная дверь — в прихожей.', 7);
    this.setSub('Тихий дом. День 1 из 5.', 4);
    Sound.init(); Sound.resume();
    UI.hideAll(); UI.hud(true);
    this.updateHUD();
    Game.requestLock();
  },

  respawn(first) {
    Player.reset(9.2, 10.4);
    Player.pos.set(FX(9.2), 0, FZ(10.4));
    Player.yaw = Math.PI * 0.5;
    Player.pitch = 0;
    Player.alive = true; Player.hidden = null;
    Player.stamina = CFG.STAMINA;
    Enemy.pos.set(FX(11), 0, FZ(1));
    Enemy.reset();
    this.camera.position.set(Player.pos.x, Player.eye, Player.pos.z);
    Noise.list.length = 0;
    Jar.list.forEach(j => this.scene.remove(j.mesh));
    Jar.list.length = 0;
  },

  /* ---------- UI ---------- */
  bindUI() {
    const $ = id => document.getElementById(id);
    UI.$ = $;
    const ACT = {
      play: () => this.newGame(),
      resume: () => this.resume(),
      restart: () => this.newGame(),
      menu: () => {
        this.state = 'menu'; UI.show('menu'); UI.hud(false);
        if (document.exitPointerLock) document.exitPointerLock();
      },
      again: () => this.newGame(),
      help: () => { this._ret = (this.state === 'pause') ? 'pause' : 'menu'; UI.show('help'); },
      settings: () => { this._ret = (this.state === 'pause') ? 'pause' : 'menu'; UI.show('settings'); },
      closeHelp: () => UI.show(this._ret || 'menu'),
      closeSettings: () => UI.show(this._ret || 'menu'),
    };
    document.querySelectorAll('[data-act]').forEach(el => {
      const fn = ACT[el.getAttribute('data-act')];
      if (!fn) return;
      el.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        Sound.init(); Sound.resume(); Sound.ui('click'); fn();
      });
      el.addEventListener('mouseenter', () => { Sound.init(); Sound.ui('hover'); });
    });

    const sens = $('setSens'); if (sens) sens.addEventListener('input', () => { this.settings.sens = parseFloat(sens.value); $('sensVal').textContent = sens.value; });
    const vol = $('setVol'); if (vol) vol.addEventListener('input', () => { this.settings.volume = parseFloat(vol.value) / 100; Sound.setVolume(this.settings.volume); $('volVal').textContent = vol.value + '%'; });
    const sh = $('setShadows'); if (sh) sh.addEventListener('change', () => {
      this.settings.shadows = sh.checked;
      this.renderer.shadowMap.enabled = sh.checked;
      this.torch.castShadow = sh.checked;
      this.qualityLevel = sh.checked ? 2 : 1;
      this.scene.traverse(o => { if (o.isMesh && o.material) o.material.needsUpdate = true; });
    });
    const inv = $('setInvert'); if (inv) inv.addEventListener('change', () => this.settings.invert = inv.checked);

    UI.show('menu');
  },

  requestLock() {
    if (this.touchMode) return;
    const c = this.renderer.domElement;
    try { const p = c.requestPointerLock(); if (p && p.catch) p.catch(() => { }); } catch (e) { }
  },

  pause(why) {
    if (this.state !== 'play') return;
    this.state = 'pause';
    UI.show('pause');
    Sound.ui('back');
  },
  resume() {
    if (this.state !== 'pause') return;
    this.state = 'play';
    UI.hideAll(); UI.hud(true);
    this.requestLock();
  },
  onEscape() {
    if (this.state === 'play') this.pause('esc');
    else if (this.state === 'pause') this.resume();
  },
  toggleMute() {
    const m = !UI.muted; UI.muted = m; Sound.setMuted(m);
    const el = document.getElementById('muteInd');
    if (el) el.style.opacity = m ? 1 : 0;
  },

  setHint(t, s) { this.hint = t; this.hintT = s || 3.5; },
  setSub(t, s) { this.subtitle = t; this.subT = s || 3; },

  /* ---------- взаимодействие ---------- */
  findInteract() {
    const cam = this.camera;
    const fwd = new THREE.Vector3(); cam.getWorldDirection(fwd);
    let best = null, bestScore = -1;
    for (const it of World.interactables) {
      if (it.type === 'hide' && Player.hidden) continue;
      const dx = it.x - Player.pos.x, dz = it.z - Player.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > it.r) continue;
      const dy = (it.y || 1) - (Player.eye);
      const dd = Math.hypot(dx, dy, dz) || 1;
      const dot = (dx / dd) * fwd.x + (dy / dd) * fwd.y + (dz / dd) * fwd.z;
      const s = dot * 2 - d / it.r;
      if (dot < 0.15 && d > 1.0) continue;
      if (s > bestScore) { bestScore = s; best = it; }
    }
    return best;
  },

  doInteract() {
    const it = this.interactNow;
    if (!it) return;
    if (it.type === 'item') {
      const kind = it.item.kind;
      it.item.taken = true;
      this.scene.remove(it.item.mesh);
      const i = World.items.indexOf(it.item); if (i >= 0) World.items.splice(i, 1);
      const j = World.interactables.indexOf(it); if (j >= 0) World.interactables.splice(j, 1);
      Player.give(kind);
      Sound.pickup();
      if (kind === 'battery') this.setHint('Батарейка: фонарь заряжен до ' + Math.round(Player.battery) + '%', 3);
      else if (kind === 'book') { this.secret = true; this.setHint('Красная книга. Что-то в ней шевелится…', 5); Sound.growl(0); }
      else if (kind === 'jar') { this.setHint('Банка. Нажми G — бросить и отвлечь её.', 4); }
      else this.setHint('Взято: ' + ITEM_DEFS[kind].name, 3);
      this.score += kind === 'coin' ? 25 : (kind === 'photo' ? 15 : 0);
      emitNoise(Player.pos.x, Player.pos.z, 2.2, 'pickup');
      this.updateHUD();
    } else if (it.type === 'hide') {
      if (Player.hideCd > 0) return;
      if (Enemy.state === 'chase' && dist(Enemy.pos.x, Enemy.pos.z, Player.pos.x, Player.pos.z) < 9) {
        Enemy._sawHide = true;
        this.setHint('Она видела, куда ты залез!', 3);
      } else Enemy._sawHide = false;
      Player.hide(it.spot);
      this.setSub('Ты спрятался: ' + it.spot.label, 2.5);
    } else if (it.type === 'exit') {
      this.tryExit();
    } else if (it.type === 'door') {
      const d = it.door;
      if (d.locked) { Sound.deny(); this.setHint('Заперто', 2); return; }
      d.open = !d.open;
      d.target = d.open ? Math.PI / 2 * 0.92 : 0;
      Sound.door(d.open, 0);
      emitNoise(d.cx, d.cz, d.open ? 7.5 : 5.0, 'door');
    }
  },

  tryExit() {
    const L = this.locks;
    if (this.working > 0) return;
    if (!L.board && Player.has('crowbar')) { this.working = 1.5; this.workKind = 'board'; this.setSub('Выдираешь доску…', 2); return; }
    if (!L.board && !Player.has('crowbar')) { this.setHint('Дверь забита доской. Нужен гвоздодёр.', 4); Sound.deny(); return; }
    if (!L.chain && Player.has('cutters')) { this.working = 1.3; this.workKind = 'chain'; this.setSub('Перекусываешь цепь…', 2); return; }
    if (!L.chain) { this.setHint('Дверь на цепи. Нужны кусачки.', 4); Sound.deny(); return; }
    if (!L.lock && Player.has('key')) { this.working = 1.1; this.workKind = 'lock'; this.setSub('Поворачиваешь ключ…', 2); return; }
    if (!L.lock) { this.setHint('Нужен латунный ключ.', 4); Sound.deny(); return; }
    this.winGame();
  },

  finishWork() {
    const k = this.workKind;
    this.locks[k] = true;
    this.workKind = null;
    Sound.unlock();
    emitNoise(Player.pos.x, Player.pos.z, 18, 'unlock');
    this.score += 100;
    if (k === 'board') this.setSub('Доска сорвана. Осталась цепь и замок.', 4);
    if (k === 'chain') this.setSub('Цепь перекушена. Остался замок.', 4);
    if (k === 'lock') this.setSub('Замок открыт. Нажми E ещё раз — и беги.', 5);
    const done = (this.locks.board ? 1 : 0) + (this.locks.chain ? 1 : 0) + (this.locks.lock ? 1 : 0);
    UI.setLocks(done);
    this.updateHUD();
  },

  /* ---------- поимка ---------- */
  caught() {
    if (this.state !== 'play') return;
    this.state = 'caught';
    this.caughtCount++;
    Sound.sting();
    this.jumpT = 0;
    document.exitPointerLock && document.exitPointerLock();
    UI.jumpscare(true);
    setTimeout(() => {
      UI.jumpscare(false);
      if (this.day >= CFG.DAYS) { this.gameOver(); }
      else {
        this.day++;
        UI.death(this.day);
        this.state = 'dead';
      }
    }, 1650);
  },

  gameOver() {
    this.state = 'dead';
    UI.gameOver(this.score);
  },

  winGame() {
    this.state = 'win';
    Sound.win();
    const d = World.exitDoor;
    d.open = true; d.locked = false; d.target = Math.PI / 2 * 0.95;
    Sound.door(true, 0);
    this.score += 500 + (CFG.DAYS - this.day + 1) * 150 + Math.round(Player.battery) * 2;
    document.exitPointerLock && document.exitPointerLock();
    setTimeout(() => UI.win(this.score, this.secret, this.day), 1500);
  },

  /* ---------- главный цикл ---------- */
  resize() {
    if (!this.renderer) return;
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    const g = this.grain;
    if (g) { g.style.width = window.innerWidth + 'px'; g.style.height = window.innerHeight + 'px'; }
  },

  loop() {
    requestAnimationFrame(() => this.loop());
    let dt = this.clock ? this.clock.getDelta() : 0.016;
    dt = Math.min(dt, 0.05);
    this.time += dt;

    if (this.state === 'play') this.tick(dt);
    else if (this.state === 'caught') this.tickCaught(dt);
    else {
      // лёгкое «дыхание» сцены в меню
      if (this.state === 'menu') {
        const t = this.time * 0.085;
        this.camera.position.set(
          FX(2.4) + Math.sin(t * 0.7) * 1.5,
          1.42 + Math.sin(t * 1.3) * 0.09,
          FZ(6.1) + Math.cos(t * 0.55) * 1.7);
        this.camera.rotation.order = 'YXZ';
        this.camera.rotation.set(0.03 + Math.sin(t) * 0.02, t * 0.55 + 2.1, Math.sin(t * 0.4) * 0.02);
        this.animateWorld(dt, false);
        this.torch.intensity = 0;
        if (this.viewModel) this.viewModel.visible = false;
      }
      this.renderer.render(this.scene, this.camera);
      this.drawGrain(dt);
      Input.endFrame();
      return;
    }
    this.renderer.render(this.scene, this.camera);
    this.drawGrain(dt);
    Input.endFrame();
  },

  tickCaught(dt) {
    this.jumpT += dt;
    UI.drawJump(this.jumpT, this.camera, Enemy);
    this.animateWorld(dt, false);
    Sound.update(dt, 1, false);
  },

  tick(dt) {
    /* --- обзор --- */
    const sens = 0.0022 * this.settings.sens * (Player.crouch ? 0.85 : 1);
    Player.yaw -= Input.dx * sens;
    Player.pitch -= Input.dy * sens * (this.settings.invert ? -1 : 1);
    Player.pitch = clamp(Player.pitch, -1.45, 1.45);

    /* --- работа с дверью --- */
    if (this.working > 0) {
      this.working -= dt;
      if (Math.random() < dt * 9) { Sound.creak(false); emitNoise(Player.pos.x, Player.pos.z, 9, 'work'); }
      if (this.working <= 0) this.finishWork();
    }

    this.autoTune(dt);
    Player.update(dt, Input, this.camera);

    /* --- двери --- */
    for (const d of World.doors) {
      if (Math.abs(d.angle - d.target) > 0.001) {
        const before = doorPassable(d);
        d.angle = dampf(d.angle, d.target, 7, dt);
        applyDoorRot(d);
        updateDoorCollider(d);
        if (before !== doorPassable(d)) rebuildLOS();
      }
    }

    /* --- взаимодействие --- */
    if (!Player.hidden) {
      this.interactNow = this.findInteract();
      if (this.interactNow) {
        let label = this.interactNow.label;
        if (this.interactNow.type === 'exit') label = this.exitLabel();
        if (Input.pressed('KeyE') || Input.pressed('Space')) this.doInteract();
        UI.prompt(label);
      } else UI.prompt(null);
    } else UI.prompt(null);
    if (Player.hidden && Input.pressed('KeyE')) { }

    /* --- предметы парят --- */
    for (const it of World.items) {
      it.mesh.rotation.y += dt * 0.7;
      it.mesh.position.y = it.base + Math.sin(this.time * 1.8 + it.x) * 0.035;
      if (it.mesh.userData.halo) it.mesh.userData.halo.intensity = 0.4 + Math.sin(this.time * 2.6 + it.z) * 0.22;
    }

    /* --- банки --- */
    Jar.update(dt);

    /* --- шум затухает --- */
    for (let i = Noise.list.length - 1; i >= 0; i--) {
      Noise.list[i].t += dt;
      if (Noise.list[i].t > 1.6) Noise.list.splice(i, 1);
    }

    /* --- враг --- */
    const dToP = Enemy.update(dt, Player.pos, Player.torch && Player.battery > 0);
    this.animateWorld(dt, true);

    /* --- поимка --- */
    if (Player.alive && Enemy.canCatch()) { Player.alive = false; this.caught(); return; }

    /* --- звук --- */
    Sound.update(dt, Player.hidden ? Enemy.threatLevel() * 0.8 : Enemy.threatLevel(), true);

    /* --- комната --- */
    const rn = roomNameAt(txOf(Player.pos.x), tzOf(Player.pos.z));
    if (rn !== Player.lastRoom) {
      Player.lastRoom = rn;
      this.setSub(rn, 2.2);
    }

    this.updateHUD(dToP);

    /* --- подсказки/субтитры --- */
    if (this.hintT > 0) { this.hintT -= dt; if (this.hintT <= 0) this.hint = ''; }
    if (this.subT > 0) { this.subT -= dt; if (this.subT <= 0) this.subtitle = ''; }
    UI.hint(this.hint); UI.sub(this.subtitle);

    /* --- вспышки молний --- */
    this.lightningT -= dt;
    if (this.lightningT <= 0) {
      this.lightningT = 18 + Math.random() * 40;
      this.flash = 1;
      setTimeout(() => Sound.thunder(), 400 + Math.random() * 1600);
    }
    if (this.flash > 0) this.flash = Math.max(0, this.flash - dt * 2.6);

    /* --- урон/тревога в постобработке --- */
    UI.threat(Player.hidden ? 0.35 : clamp(Enemy.threatLevel(), 0, 1), this.flash);
  },

  exitLabel() {
    const L = this.locks;
    const done = (L.board ? 1 : 0) + (L.chain ? 1 : 0) + (L.lock ? 1 : 0);
    if (done === 3) return 'Открыть дверь и бежать';
    if (!L.board) return Player.has('crowbar') ? 'Входная дверь: выдрать доску гвоздодёром' : 'Входная дверь забита доской (нужен гвоздодёр)';
    if (!L.chain) return Player.has('cutters') ? 'Входная дверь: перекусить цепь' : 'Дверь на цепи (нужны кусачки)';
    return Player.has('key') ? 'Входная дверь: открыть замок' : 'Дверь заперта (нужен латунный ключ)';
  },

  animateWorld(dt, gameplay) {
    // пыль
    if (this.dust) {
      const p = this.dust.geometry.attributes.position;
      const cx = this.camera.position.x, cz = this.camera.position.z;
      for (let i = 0; i < p.count; i++) {
        let y = p.getY(i) - this.dustSpd[i] * dt * 0.5;
        if (y < 0.05) y = CFG.WALL_H - 0.05;
        p.setY(i, y);
        let x = p.getX(i) + Math.sin(this.time * 0.3 + i) * dt * 0.06;
        let z = p.getZ(i) + Math.cos(this.time * 0.24 + i * 0.7) * dt * 0.06;
        if (x < cx - 8) x += 16; if (x > cx + 8) x -= 16;
        if (z < cz - 8) z += 16; if (z > cz + 8) z -= 16;
        p.setX(i, x); p.setZ(i, z);
      }
      p.needsUpdate = true;
      this.dust.material.opacity = (Player.torch && Player.battery > 0) ? 0.40 : 0.14;
    }
    // фонарь
    const on = Player.torch && Player.battery > 0 && !Player.hidden;
    let inten = on ? 2.75 : 0;
    if (on && Player.battery < 22) inten *= (Math.random() < 0.14 ? 0.25 : 1) * (0.72 + Math.random() * 0.4);
    else if (on) inten *= 0.97 + Math.random() * 0.06;
    this.torch.intensity = dampf(this.torch.intensity, inten, 22, dt);
    if (this.torchLens) this.torchLens.material.color.setScalar(on ? 1 : 0.06);
    if (this.viewModel) {
      const t = this.time;
      this.viewModel.position.set(
        0.20 + Math.sin(Player.stepPhase) * 0.012 * Player.bobAmt,
        -0.19 + Math.cos(Player.stepPhase * 2) * 0.012 * Player.bobAmt - (Player.crouch ? 0.02 : 0),
        -0.30 + (this.working > 0 ? Math.sin(t * 22) * 0.03 : 0)
      );
      this.viewModel.rotation.z = 0.05 + Math.sin(Player.stepPhase) * 0.03 * Player.bobAmt + (this.working > 0 ? Math.sin(t * 18) * 0.12 : 0);
      this.viewModel.visible = !Player.hidden;
    }
    // свеча
    if (this.candleLight) {
      const f = 1.35 + Math.sin(this.time * 11) * 0.16 + Math.sin(this.time * 23.7) * 0.12 + (Math.random() - 0.5) * 0.18;
      this.candleLight.intensity = f;
      if (this.candleFlame) this.candleFlame.scale.setScalar(0.8 + f * 0.16);
    }
    // печь
    if (this.furnaceLight) this.furnaceLight.intensity = 1.0 + Math.sin(this.time * 3.1) * 0.18 + (Math.random() - 0.5) * 0.16;
    // лампа в спальне
    if (this.lampLight) this.lampLight.intensity = 0.5 + Math.sin(this.time * 0.9) * 0.05 + (Math.random() < 0.006 ? -0.35 : 0);
    // кухонная лампочка
    if (this.bulbLight) {
      const glitch = Math.random() < 0.004 ? 0.05 : 1;
      this.bulbLight.intensity = (0.4 + Math.sin(this.time * 7.3) * 0.03) * glitch;
    }
    // молния через окна
    if (World.glassMat) {
      World.glassMat.emissiveIntensity = 0.5 + this.flash * 5.5;
      this.ambient.intensity = 0.16 + this.flash * 1.5;
    }
    // телевизор
    if (this.tvLight) {
      const on = this.secret;
      this.tvLight.intensity = on ? 0.35 + Math.random() * 0.5 : 0;
      if (on && Math.random() < dt * 2) Sound.tvLevel(0.02 + Math.random() * 0.03);
    }
  },

  drawGrain(dt) {
    const c = this.gctx; if (!c) return;
    this._gt = (this._gt || 0) + dt;
    if (this._gt < 0.045) return;          // ~22 Гц достаточно для «плёнки»
    this._gt = 0;
    const w = this.grain.width, h = this.grain.height;
    if (!this._gimg || this._gimg.width !== w) this._gimg = c.createImageData(w, h);
    const d = this._gimg.data;
    const amt = 24 + (this.state === 'play' ? Enemy.threatLevel() * 32 : 10);
    for (let i = 0; i < d.length; i += 4) {
      const v = (Math.random() * amt) | 0;
      d[i] = d[i + 1] = d[i + 2] = v;
      d[i + 3] = 44;
    }
    c.putImageData(this._gimg, 0, 0);
  },

  /* авто-качество: меряем средний кадр и понижаем стоимость, если тяжело */
  autoTune(dt) {
    this._ft = this._ft === undefined ? dt : this._ft * 0.94 + dt * 0.06;
    this._ftT = (this._ftT || 0) + dt;
    if (this._ftT < 2.5) return;
    this._ftT = 0;
    const fps = 1 / Math.max(this._ft, 0.0001);
    this._fps = Math.round(fps);
    if (fps < 42 && this.qualityLevel > 0) {
      this.qualityLevel--;
      if (this.qualityLevel === 1) {
        this.renderer.shadowMap.enabled = false;
        this.torch.castShadow = false;
        this.setHint('Качество снижено (тени выключены) для плавности', 3);
      } else if (this.qualityLevel === 0) {
        this.renderer.setPixelRatio(0.7);
        const sc = document.getElementById('scan'); if (sc) sc.style.display = 'none';
        this.setHint('Качество снижено до минимума', 3);
      }
      this.scene.traverse(o => { if (o.isMesh && o.material) o.material.needsUpdate = true; });
    }
  },

  updateHUD(dToP) {
    UI.hud2({
      day: this.day, days: CFG.DAYS,
      stamina: Player.stamina / CFG.STAMINA,
      battery: Player.battery / 100,
      torch: Player.torch && Player.battery > 0,
      noise: Player.noiseLevel,
      inv: Player.inv, jars: Player.jars,
      score: this.score,
      hidden: !!Player.hidden,
      state: Enemy.state,
      threat: dToP === undefined ? 0 : clamp(1 - dToP / 16, 0, 1),
      crouch: Player.crouch,
      sprint: Player.sprint && Player.moving,
      working: this.working > 0,
      room: Player.lastRoom,
    });
  },
};

/* ============================================================
   UI (DOM)
   ============================================================ */
const UI = {
  $: null, muted: false, _last: {},
  screens: ['menu', 'pause', 'help', 'settings', 'dead', 'win', 'over'],

  hideAll() { for (const s of this.screens) { const e = document.getElementById(s); if (e) e.classList.remove('on'); } },
  show(name) { this.hideAll(); const e = document.getElementById(name); if (e) e.classList.add('on'); },
  hud(on) { const e = document.getElementById('hud'); if (e) e.style.display = on ? 'block' : 'none'; },

  prompt(txt) {
    const p = document.getElementById('prompt');
    if (!p) return;
    if (!txt) { p.style.opacity = 0; return; }
    p.style.opacity = 1;
    if (p.textContent !== txt) p.textContent = txt;
  },
  hint(t) { const e = document.getElementById('hint'); if (e) { e.textContent = t || ''; e.style.opacity = t ? 1 : 0; } },
  sub(t) { const e = document.getElementById('sub'); if (e) { e.textContent = t || ''; e.style.opacity = t ? 1 : 0; } },

  threat(v, flash) {
    const e = document.getElementById('threatVig');
    if (e) e.style.opacity = (v * 0.75).toFixed(3);
    const f = document.getElementById('flashVig');
    if (f) f.style.opacity = (flash * 0.5).toFixed(3);
    const d = document.getElementById('dmgVig');
    if (d) d.style.opacity = Player.hurtFlash.toFixed(2);
  },

  setLocks(n) {
    const e = document.getElementById('locks');
    if (!e) return;
    const kids = e.children;
    for (let i = 0; i < kids.length; i++) kids[i].classList.toggle('done', i < n);
  },

  hud2(s) {
    const set = (id, v) => { const e = document.getElementById(id); if (e && e.textContent !== v) e.textContent = v; };
    const bar = (id, v) => { const e = document.getElementById(id); if (e) e.style.width = (clamp(v, 0, 1) * 100).toFixed(1) + '%'; };
    const cls = (id, on) => { const e = document.getElementById(id); if (e) e.classList.toggle('on', !!on); };
    set('hDay', 'День ' + s.day + '/' + s.days);
    set('hScore', s.score);
    set('hRoom', s.room || '');
    bar('bStam', s.stamina);
    bar('bBatt', s.battery);
    bar('bNoise', s.noise);
    bar('bThreat', s.threat);
    cls('stTorch', s.torch);
    cls('stCrouch', s.crouch);
    cls('stRun', s.sprint);
    cls('stHidden', s.hidden);
    const sl = document.getElementById('slats');
    if (sl) sl.style.opacity = s.hidden ? 1 : 0;
    cls('stChase', s.state === 'chase');
    cls('noiseWrap', s.noise > 0.08);
    set('hJars', '×' + s.jars);

    // инвентарь
    const inv = document.getElementById('inv');
    if (inv) {
      const keys = Object.keys(s.inv).filter(k => k !== 'jar' && k !== 'battery');
      const sig = keys.join(',') + '|' + s.jars;
      if (this._last.inv !== sig) {
        this._last.inv = sig;
        inv.innerHTML = '';
        for (const k of keys) {
          const d = document.createElement('div');
          d.className = 'slot';
          d.innerHTML = '<span class="dot" style="background:#' + ITEM_DEFS[k].color.toString(16).padStart(6, '0') + '"></span>' + ITEM_DEFS[k].name;
          inv.appendChild(d);
        }
        if (s.jars > 0) {
          const d = document.createElement('div');
          d.className = 'slot';
          d.innerHTML = '<span class="dot" style="background:#7a9a86"></span>Банка <b>G</b> ×' + s.jars;
          inv.appendChild(d);
        }
      }
    }
  },

  jumpscare(on) {
    const e = document.getElementById('jump');
    if (e) e.style.display = on ? 'block' : 'none';
  },

  drawJump(t, cam, enemy) {
    const c = document.getElementById('jump');
    if (!c) return;
    const ctx = c.getContext('2d');
    if (c.width !== window.innerWidth) { c.width = window.innerWidth; c.height = window.innerHeight; }
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);
    const k = clamp(t / 0.55, 0, 1);
    const sc = lerp(0.25, 1.35, k * k * (3 - 2 * k));
    const sh = (1 - k) * 46 + Math.random() * 12;
    ctx.save();
    ctx.translate(W / 2 + (Math.random() - 0.5) * sh, H / 2 + (Math.random() - 0.5) * sh);
    ctx.scale(sc, sc);
    const s = Math.min(W, H) * 0.42;
    // волосы
    ctx.fillStyle = '#b9b3a6';
    ctx.beginPath(); ctx.ellipse(0, -s * 0.22, s * 0.62, s * 0.52, 0, 0, TAU); ctx.fill();
    // лицо
    ctx.fillStyle = '#a2968a';
    ctx.beginPath(); ctx.ellipse(0, 0, s * 0.46, s * 0.62, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(40,26,20,0.35)';
    for (let i = 0; i < 26; i++) {
      const a = Math.random() * TAU, r = Math.random();
      ctx.beginPath();
      ctx.ellipse(Math.cos(a) * s * 0.4 * r, Math.sin(a) * s * 0.55 * r, s * 0.05 * Math.random(), s * 0.02, a, 0, TAU);
      ctx.fill();
    }
    // глазницы
    for (const sx of [-1, 1]) {
      ctx.fillStyle = '#0b0806';
      ctx.beginPath(); ctx.ellipse(sx * s * 0.18, -s * 0.1, s * 0.135, s * 0.115, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#ff2a1a';
      ctx.beginPath(); ctx.arc(sx * s * 0.18 + (Math.random() - 0.5) * 4, -s * 0.1, s * 0.045, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(sx * s * 0.18, -s * 0.115, s * 0.014, 0, TAU); ctx.fill();
    }
    // нос
    ctx.fillStyle = '#8d8175';
    ctx.beginPath(); ctx.moveTo(0, -s * 0.02); ctx.lineTo(-s * 0.05, s * 0.12); ctx.lineTo(s * 0.05, s * 0.12); ctx.fill();
    // рот
    ctx.fillStyle = '#120a08';
    ctx.beginPath(); ctx.ellipse(0, s * 0.3, s * 0.19 * (0.7 + Math.random() * 0.4), s * 0.26 * k, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#c9c0b0';
    for (let i = -3; i <= 3; i++) {
      ctx.fillRect(i * s * 0.05 - s * 0.015, s * 0.3 - s * 0.24 * k, s * 0.03, s * 0.07);
    }
    ctx.restore();
    // красная вспышка
    ctx.fillStyle = 'rgba(120,10,6,' + (0.32 * (1 - k) + Math.random() * 0.1).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
  },

  death(day) {
    this.show('dead');
    const e = document.getElementById('deadDay');
    if (e) e.textContent = 'Осталось дней: ' + (CFG.DAYS - day + 1);
    const t = document.getElementById('deadText');
    if (t) t.textContent = pickTxt();
  },

  gameOver(score) {
    this.show('over');
    const e = document.getElementById('overScore');
    if (e) e.textContent = 'Очки: ' + score;
  },

  win(score, secret, day) {
    this.show('win');
    const e = document.getElementById('winScore');
    if (e) e.textContent = score;
    const t = document.getElementById('winText');
    if (t) t.textContent = secret
      ? 'Ты выбрался — но Красная книга осталась у тебя в руках. Где-то сзади хлопнула дверь, которой там не было.'
      : 'Ты выбрался из Тихого дома на ' + day + '-й день. Она всё ещё стоит у окна и смотрит тебе вслед.';
  },
};

const DEATH_TEXTS = [
  'Ты просыпаешься в спальне. Она перетащила тебя сюда. Снова.',
  'Она не злая. Она просто не хочет, чтобы ты ушёл.',
  'Последнее, что ты услышал — скрип половиц и её дыхание.',
  'Дом стал тише. Ты — громче.',
  'Она поправила тебе одеяло. Как всегда.',
];
function pickTxt() { return DEATH_TEXTS[(Math.random() * DEATH_TEXTS.length) | 0]; }

/* ---------- старт ---------- */
window.addEventListener('error', e => {
  const el = document.getElementById('fatal');
  if (el) { el.style.display = 'block'; el.textContent = 'Ошибка: ' + (e.message || e.error); }
});

function startApp() {
  try { Game.boot(); }
  catch (e) {
    const el = document.getElementById('fatal');
    if (el) { el.style.display = 'block'; el.textContent = 'Ошибка запуска: ' + e.message; }
    console.error(e);
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startApp);
else startApp();
