const puppeteer = require('puppeteer');
const path = require('path');

const FILE = 'file://' + path.resolve(__dirname, '..', 'quiet-house.html') + '?q=low';
const wait = ms => new Promise(r => setTimeout(r, ms));

function log(k, v) { console.log(k + ': ' + (typeof v === 'string' ? v : JSON.stringify(v))); }

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu-sandbox',
      '--enable-unsafe-swiftshader', '--use-gl=swiftshader',
      '--autoplay-policy=no-user-gesture-required'],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 900, height: 560 });

  const errs = [], warns = [];
  page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); else if (m.type() === 'warning') warns.push(m.text()); });
  page.on('pageerror', e => errs.push('PAGEERROR: ' + (e && e.message)));

  await page.goto(FILE, { waitUntil: 'load', timeout: 60000 });
  await wait(3000);

  log('BOOT', await page.evaluate(() => ({
    three: THREE.REVISION, state: Game.state, renderer: !!Game.renderer,
    doors: World.doors.length, colliders: World.colliders.length,
    items: World.items.length, hides: World.hideSpots.length,
    interacts: World.interactables.length, los: QH.losSize(),
    fatal: document.getElementById('fatal').textContent || '',
  })));
  await page.screenshot({ path: 'shot_menu.png' });

  // --- навигация/коллизии ---
  log('NAV', await page.evaluate(() => {
    // закроем все двери и проверим, что «силовой» путь всё равно находится
    World.doors.forEach(d => { if (!d.def.exit) { d.open = false; d.target = 0; d.angle = 0; } });
    rebuildLOS();
    const forced = findPathForce(9, 10, 14, 1);
    const polite = findPath(9, 10, 14, 1);
    return {
      forcedLen: forced ? forced.length : null,
      politeLen: polite ? polite.length : null,     // ожидаем null — все двери закрыты
      wallBlocked: blockedAt(4.75, 7.6, 0.3),      // стена кухня/гостиная
      floorFree: !blockedAt(FX(2), FZ(2), 0.3),    // центр кухни
      losThroughWall: lineOfSight(FX(2), FZ(2), FX(2), FZ(6)),
      losInRoom: lineOfSight(FX(2), FZ(1), FX(4), FZ(2)),
    };
  }));

  // --- старт ---
  await page.evaluate(() => document.querySelector('[data-act="play"]').click());
  await wait(2500);
  log('START', await page.evaluate(() => ({
    state: Game.state, day: Game.day, room: Player.lastRoom,
    player: [+Player.pos.x.toFixed(2), +Player.pos.z.toFixed(2)],
    enemy: [+Enemy.pos.x.toFixed(2), +Enemy.pos.z.toFixed(2), Enemy.state],
    fatal: document.getElementById('fatal').textContent || '',
  })));
  await page.screenshot({ path: 'shot_play1.png' });

  // --- ходьба ---
  const p0 = await page.evaluate(() => [+Player.pos.x, +Player.pos.z]);
  await page.keyboard.down('KeyW'); await wait(2500); await page.keyboard.up('KeyW');
  const p1 = await page.evaluate(() => [+Player.pos.x, +Player.pos.z, Player.lastRoom, Player.noiseLevel.toFixed(2)]);
  log('WALK', { from: p0.map(v => +v.toFixed(2)), to: [ +p1[0].toFixed(2), +p1[1].toFixed(2) ],
    moved: +Math.hypot(p1[0] - p0[0], p1[1] - p0[1]).toFixed(2), room: p1[2], noise: p1[3] });

  // --- присед / бег / фонарь ---
  await page.keyboard.down('ControlLeft'); await wait(1200);
  log('CROUCH', await page.evaluate(() => ({ crouch: Player.crouch, eye: +Player.eye.toFixed(2), noise: +Player.noiseLevel.toFixed(2) })));
  await page.keyboard.up('ControlLeft');
  await page.keyboard.down('ShiftLeft'); await page.keyboard.down('KeyW'); await wait(1400);
  log('SPRINT', await page.evaluate(() => ({ stam: Math.round(Player.stamina), noise: +Player.noiseLevel.toFixed(2) })));
  await page.keyboard.up('KeyW'); await page.keyboard.up('ShiftLeft');
  const torchBefore = await page.evaluate(() => Player.torch);
  await page.keyboard.press('KeyF'); await wait(600);
  log('TORCH', { before: torchBefore, after: await page.evaluate(() => Player.torch) });
  await page.keyboard.press('KeyF');

  // --- обзор мышью (fallback без pointer lock) ---
  const yaw0 = await page.evaluate(() => Player.yaw);
  await page.mouse.move(450, 280);
  await page.mouse.down();
  for (let i = 0; i < 10; i++) { await page.mouse.move(450 + i * 18, 280); await wait(40); }
  await page.mouse.up();
  log('LOOK', { yaw0: +yaw0.toFixed(2), yaw1: await page.evaluate(() => +Player.yaw.toFixed(2)) });
  await page.screenshot({ path: 'shot_play2.png' });

  // --- подбираем предмет, поднеся игрока к нему ---
  log('PICKUP', await page.evaluate(() => {
    const it = World.items[0];
    Player.pos.set(it.x, 0, it.z + 0.5); Player.hidden = null;
    return { kind: it.kind, name: it.name, room: it.room, itemsBefore: World.items.length };
  }));
  await wait(1200);
  await page.keyboard.press('KeyE'); await wait(900);
  log('PICKUP2', await page.evaluate(() => ({
    inv: Object.keys(Player.inv), itemsLeft: World.items.length,
    prompt: document.getElementById('prompt').textContent,
  })));

  // --- прячемся в шкаф ---
  log('HIDE', await page.evaluate(() => {
    const h = World.hideSpots.find(s => s.type === 'wardrobe');
    Player.pos.set(h.x + 0.5, 0, h.z + 0.6);
    return { spot: h.label };
  }));
  await wait(1000);
  await page.keyboard.press('KeyE'); await wait(1600);
  log('HIDDEN', await page.evaluate(() => ({ hidden: !!Player.hidden, eye: +Player.eye.toFixed(2) })));
  await page.screenshot({ path: 'shot_hide.png' });
  await page.keyboard.press('KeyE'); await wait(1200);
  log('UNHIDDEN', await page.evaluate(() => ({ hidden: !!Player.hidden })));

  // --- бросок банки ---
  log('JAR', await page.evaluate(() => {
    const b = Player.jars; Player.throwJar(Game.camera);
    return { before: b, after: Player.jars, flying: Jar.list.length };
  }));
  await wait(2500);
  log('JAR_LANDED', await page.evaluate(() => ({ noises: Noise.list.length, jars: Jar.list.length })));

  // --- ИИ: шум привлекает её ---
  await page.evaluate(() => {
    Enemy.state = 'patrol'; Enemy.path = null; Enemy.target = null;
    emitNoise(Player.pos.x, Player.pos.z, 40, 'jar');
  });
  await wait(4000);
  log('AI_HEAR', await page.evaluate(() => ({ state: Enemy.state, target: Enemy.target && [+Enemy.target.x.toFixed(1), +Enemy.target.z.toFixed(1)] })));

  // --- поимка ---
  await page.evaluate(() => {
    Player.hidden = null;
    Enemy.pos.set(Player.pos.x + 0.45, 0, Player.pos.z + 0.2);
    Enemy.state = 'chase'; Enemy.stun = 0;
  });
  await wait(4000);
  log('CATCH', await page.evaluate(() => ({
    state: Game.state, day: Game.day,
    jumpVisible: document.getElementById('jump').style.display,
  })));
  await page.screenshot({ path: 'shot_catch.png' });
  await wait(6000);
  log('AFTER_CATCH', await page.evaluate(() => ({
    state: Game.state, day: Game.day,
    screens: [...document.querySelectorAll('.screen.on')].map(e => e.id),
    text: (document.getElementById('deadText') || {}).textContent,
  })));
  await page.screenshot({ path: 'shot_death.png' });

  // --- победа ---
  await page.evaluate(() => {
    Game.state = 'play'; UI.hideAll(); UI.hud(true);
    Player.inv.crowbar = 1; Player.inv.cutters = 1; Player.inv.key = 1;
    Game.locks = { board: true, chain: true, lock: true };
    Game.winGame();
  });
  await wait(7000);
  log('WIN', await page.evaluate(() => ({
    state: Game.state, screens: [...document.querySelectorAll('.screen.on')].map(e => e.id),
    score: document.getElementById('winScore').textContent,
    text: document.getElementById('winText').textContent.slice(0, 70),
  })));
  await page.screenshot({ path: 'shot_win.png' });

  // --- экран помощи + меню ---
  await page.evaluate(() => { Game.state = 'menu'; UI.show('help'); });
  await wait(1200);
  await page.screenshot({ path: 'shot_help.png' });
  await page.evaluate(() => UI.show('settings'));
  await wait(800);
  await page.screenshot({ path: 'shot_settings.png' });

  // --- производительность ---
  const perf = await page.evaluate(() => new Promise(res => {
    let n = 0; const t0 = performance.now();
    (function f() { n++; (performance.now() - t0 < 4000) ? requestAnimationFrame(f) : res(+(n / ((performance.now() - t0) / 1000)).toFixed(1)); })();
  }));
  log('FPS_software_rendering', perf);

  const uniq = [...new Set(errs)];
  console.log('\n=== ERRORS (' + errs.length + ', unique ' + uniq.length + ') ===');
  uniq.slice(0, 15).forEach(e => console.log(' * ' + e.slice(0, 300)));
  const uw = [...new Set(warns)];
  console.log('=== WARNINGS (' + warns.length + ', unique ' + uw.length + ') ===');
  uw.slice(0, 8).forEach(e => console.log(' - ' + e.slice(0, 200)));

  await browser.close();
})().catch(e => { console.error('TEST CRASH:', e.message); process.exit(1); });
