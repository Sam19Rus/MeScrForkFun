namespace DiskCleaner.Presentation.Application;

/// <summary>
/// <see cref="IProgress{T}"/> that invokes its handler synchronously on the reporting
/// thread.
/// </summary>
/// <remarks>
/// <see cref="Progress{T}"/> captures <c>SynchronizationContext.Current</c>, which is
/// correct inside a running WPF app but makes the view models untestable and silently
/// no-ops on a thread without a context. Marshalling is therefore explicit: the scan
/// pipeline reports synchronously and the view model hops to the UI thread through
/// <see cref="IUiDispatcher"/>.
/// </remarks>
public sealed class CallbackProgress<T>(Action<T> handler) : IProgress<T>
{
    private readonly Action<T> _handler = handler ?? throw new ArgumentNullException(nameof(handler));

    public void Report(T value) => _handler(value);
}
