namespace DiskCleaner.Presentation.Application;

/// <summary>The sections of the shell, in the order they appear in the navigation rail.</summary>
public enum Section
{
    Overview = 0,
    Scan,
    Results,
    LargeFiles,
    AppLeftovers,
    AppMover,
    Cleanup,
    History,
    Settings,
}

/// <summary>Section switching. Implemented by the WPF shell; consumed by view models.</summary>
public interface INavigationService
{
    Section Current { get; }

    event EventHandler<Section>? Navigated;

    void Navigate(Section section);
}

/// <summary>Marshals work back onto the UI thread without the view models knowing about WPF.</summary>
public interface IUiDispatcher
{
    bool CheckAccess();

    void Post(Action action);

    Task InvokeAsync(Func<Task> action);
}

/// <summary>Shell interactions that need a real window manager (Explorer, dialogs).</summary>
public interface IShellService
{
    /// <summary>Opens the folder itself.</summary>
    bool OpenFolder(string path);

    /// <summary>Opens the containing folder with the file selected.</summary>
    bool OpenFileLocation(string path);

    /// <summary>Opens a file with its default handler.</summary>
    bool OpenFile(string path);

    bool OpenRecycleBin();
}

/// <summary>Modal interactions. Kept minimal on purpose — no dialog sprawl.</summary>
public interface IDialogService
{
    Task<bool> ConfirmAsync(string title, string message, string confirmLabel = "Continue", string cancelLabel = "Cancel");

    Task<string?> PickFolderAsync(string? initialDirectory = null);

    void ShowInfo(string title, string message);

    void ShowWarning(string title, string message);
}

/// <summary>Applies theme/language. Implemented by the shell because it owns the resource dictionaries.</summary>
public interface IAppearanceService
{
    void Apply(Core.Models.AppTheme theme, string language);
}
