using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.ViewModels;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace DiskCleaner.Presentation;

/// <summary>
/// Registration of the presentation layer. Platform services (dispatcher, dialogs,
/// shell, appearance, elevation) are supplied by the host.
/// </summary>
public static class PresentationServiceCollectionExtensions
{
    public static IServiceCollection AddDiskCleanerPresentation(this IServiceCollection services)
    {
        services.TryAddSingleton<IValueFormatter, ValueFormatter>();

        // Russian is the primary language; English is the fallback table.
        services.TryAddSingleton<IStringLocalizer>(_ => new StringLocalizer(StringTable.Default));
        services.TryAddSingleton<INavigationService, Services.NavigationService>();

        // Sections are registered individually so they can be resolved in rail order.
        services.AddSingleton<OverviewViewModel>();
        services.AddSingleton<ScanViewModel>();
        services.AddSingleton<ResultsViewModel>();
        services.AddSingleton<LargeFilesViewModel>();
        services.AddSingleton<AppLeftoversViewModel>();
        services.AddSingleton<AppMoverViewModel>();
        services.AddSingleton<CleanupViewModel>();
        services.AddSingleton<HistoryViewModel>();
        services.AddSingleton<SettingsViewModel>();

        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<OverviewViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<ScanViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<ResultsViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<LargeFilesViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<AppLeftoversViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<AppMoverViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<CleanupViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<HistoryViewModel>());
        services.AddSingleton<SectionViewModel>(sp => sp.GetRequiredService<SettingsViewModel>());

        services.AddSingleton<MainViewModel>();

        return services;
    }
}
