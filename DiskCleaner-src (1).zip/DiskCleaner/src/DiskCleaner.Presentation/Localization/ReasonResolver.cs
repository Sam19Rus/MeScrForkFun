namespace DiskCleaner.Presentation.Localization;

/// <summary>
/// Resolves the stable, non-localised reason keys produced by Core into UI text.
/// </summary>
/// <remarks>
/// Keys arrive from several subsystems and live in several namespaces of the string
/// table (<c>S.Cleanup.Reason.*</c> for deletion outcomes, <c>S.Reason.*</c> for
/// analyzer findings, <c>S.Reject.*</c> for plan/policy refusals, <c>S.AppMover.Reason.*</c>
/// for move refusals, <c>S.App.Expl.*</c> for catalog explanations). Every consumer
/// used to re-implement the lookup with subtle differences; this is the one place.
/// <para/>
/// A key that has no translation anywhere degrades to the caller's English fallback
/// (the analyzer's own text) and only then to the raw key — the UI never shows nothing
/// and never crashes on an unknown code.
/// </remarks>
public static class ReasonResolver
{
    private static readonly string[] Prefixes =
    [
        "S.Cleanup.Reason.",
        "S.Reason.",
        "S.Reject.",
        "S.AppMover.Reason.",
    ];

    /// <summary>Translates a reason key; returns <paramref name="fallback"/> (or the key) when unknown.</summary>
    public static string Resolve(IStringLocalizer localizer, string? key, string? fallback = null)
    {
        if (string.IsNullOrEmpty(key))
        {
            return fallback ?? string.Empty;
        }

        foreach (var prefix in Prefixes)
        {
            var candidate = prefix + key;
            if (localizer.CurrentTable.ContainsKey(candidate))
            {
                return localizer.Get(candidate);
            }
        }

        if (!string.IsNullOrEmpty(fallback))
        {
            return fallback;
        }

        return key;
    }

    /// <summary>
    /// Resolves an application explanation: the per-app key first, then the family
    /// default, then the English text from the catalog.
    /// </summary>
    public static string ResolveAppExplanation(
        IStringLocalizer localizer,
        string? explanationKey,
        string? family,
        string? englishFallback)
    {
        if (!string.IsNullOrEmpty(explanationKey))
        {
            var perApp = "S.App.Expl." + explanationKey;
            if (localizer.CurrentTable.ContainsKey(perApp))
            {
                return localizer.Get(perApp);
            }
        }

        if (!string.IsNullOrEmpty(family))
        {
            var perFamily = "S.App.Expl.family." + family;
            if (localizer.CurrentTable.ContainsKey(perFamily))
            {
                return localizer.Get(perFamily);
            }
        }

        return englishFallback ?? string.Empty;
    }
}
