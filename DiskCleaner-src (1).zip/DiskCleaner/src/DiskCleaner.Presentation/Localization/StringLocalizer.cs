using System.Globalization;

namespace DiskCleaner.Presentation.Localization;

/// <summary>
/// Resolves UI strings by key and notifies subscribers when the language changes.
/// </summary>
/// <remarks>
/// Lives in <c>Presentation</c> (not in the WPF project) so view models are localised
/// and testable without a running application. The shell copies the active table into
/// a resource dictionary, which is how XAML gets the same strings.
/// </remarks>
public interface IStringLocalizer
{
    /// <summary>Normalised language tag currently in use (<c>ru</c>, <c>en</c>).</summary>
    string Language { get; }

    /// <summary>The active table. Used by the shell to republish XAML resources.</summary>
    IReadOnlyDictionary<string, string> CurrentTable { get; }

    /// <summary>Returns the translated string, falling back to English and then to the key.</summary>
    string Get(string key);

    /// <summary>Formats a template; all arguments are expected to be pre-formatted strings.</summary>
    string Format(string key, params object?[] args);

    void SetLanguage(string? language);

    event EventHandler? LanguageChanged;
}

/// <summary>Dictionary-backed <see cref="IStringLocalizer"/>.</summary>
public sealed class StringLocalizer : IStringLocalizer
{
    private readonly object _gate = new();
    private IReadOnlyDictionary<string, string> _table;

    public StringLocalizer(string? initialLanguage = null)
    {
        Language = StringTable.Normalise(initialLanguage);
        _table = StringTable.For(Language);
    }

    public string Language { get; private set; }

    public IReadOnlyDictionary<string, string> CurrentTable
    {
        get { lock (_gate) { return _table; } }
    }

    public event EventHandler? LanguageChanged;

    public string Get(string key)
    {
        if (string.IsNullOrEmpty(key))
        {
            return string.Empty;
        }

        lock (_gate)
        {
            if (_table.TryGetValue(key, out var value))
            {
                return value;
            }
        }

        // Missing translation: fall back to English, then show the key itself so the
        // gap is visible during development instead of rendering as an empty control.
        return StringTable.En.TryGetValue(key, out var english) ? english : key;
    }

    public string Format(string key, params object?[] args)
    {
        var template = Get(key);

        if (args is null || args.Length == 0)
        {
            return template;
        }

        try
        {
            return string.Format(CultureInfo.InvariantCulture, template, args);
        }
        catch (FormatException)
        {
            // A malformed template must not take the application down.
            return template;
        }
    }

    public void SetLanguage(string? language)
    {
        var normalised = StringTable.Normalise(language);

        lock (_gate)
        {
            if (string.Equals(Language, normalised, StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            Language = normalised;
            _table = StringTable.For(normalised);
        }

        LanguageChanged?.Invoke(this, EventArgs.Empty);
    }
}
