using System.Globalization;
using DiskCleaner.Core.Infrastructure.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.Formatting;

/// <summary>
/// Single place where numbers become text.
/// </summary>
/// <remarks>
/// Every user-visible number goes through this service, so switching the UI
/// language later is a matter of swapping the culture and the unit labels —
/// not of hunting formatting code out of dozens of view models.
/// </remarks>
public interface IValueFormatter
{
    string Bytes(long value);
    string BytesPrecise(long value);
    string BytesCompact(long value);
    string Count(long value);
    string Rate(double bytesPerSecond);
    string Duration(TimeSpan value);
    string Date(DateTime? utc);
    string DateTime(DateTime? utc);
    string Percent(double? ratio);
}

public sealed class ValueFormatter(CultureInfo? culture = null, IStringLocalizer? localizer = null) : IValueFormatter
{
    private readonly CultureInfo _culture = culture ?? CultureInfo.CurrentCulture;
    private readonly IStringLocalizer? _localizer = localizer;

    public string Bytes(long value) => BytesFormatter.Format(value, _culture);

    public string BytesPrecise(long value) => BytesFormatter.FormatPrecise(value, _culture);

    public string BytesCompact(long value) => BytesFormatter.FormatCompact(value, _culture);

    public string Count(long value) => BytesFormatter.FormatCount(value, _culture);

    public string Rate(double bytesPerSecond) => BytesFormatter.FormatRate(bytesPerSecond, _culture);

    public string Duration(TimeSpan value)
    {
        if (value < TimeSpan.Zero)
        {
            value = TimeSpan.Zero;
        }

        // With a localizer, durations read the way the UI language speaks
        // («2 мин 05 с»); without one, the invariant form is kept for tests.
        if (_localizer is { } localizer)
        {
            if (value.TotalHours >= 1)
            {
                return localizer.Format("S.Fmt.Duration.Hours", (int)value.TotalHours, value.Minutes, value.Seconds);
            }

            if (value.TotalMinutes >= 1)
            {
                return localizer.Format("S.Fmt.Duration.Minutes", value.Minutes, value.Seconds);
            }

            return value.TotalSeconds >= 1
                ? localizer.Format("S.Fmt.Duration.Seconds", value.TotalSeconds.ToString("0.0", _culture))
                : localizer.Format("S.Fmt.Duration.Millis", value.TotalMilliseconds.ToString("0", _culture));
        }

        if (value.TotalHours >= 1)
        {
            return $"{(int)value.TotalHours}h {value.Minutes:00}m {value.Seconds:00}s";
        }

        if (value.TotalMinutes >= 1)
        {
            return $"{value.Minutes}m {value.Seconds:00}s";
        }

        return value.TotalSeconds >= 1
            ? $"{value.TotalSeconds:0.0}s"
            : $"{value.TotalMilliseconds:0} ms";
    }

    public string Date(DateTime? utc) =>
        utc is { } value ? value.ToLocalTime().ToString("d", _culture) : "—";

    public string DateTime(DateTime? utc) =>
        utc is { } value ? value.ToLocalTime().ToString("g", _culture) : "—";

    public string Percent(double? ratio) =>
        ratio is { } value ? (value * 100d).ToString("N1", _culture) + "%" : "—";
}
