using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>
/// One row of the report: a candidate the user can inspect, exclude, or add to the plan.
/// </summary>
public sealed partial class ScanItemViewModel : ObservableObject
{
    private readonly ICleanupPlanner _planner;
    private readonly IReportExclusions _exclusions;
    private readonly IStringLocalizer _localizer;
    private readonly IValueFormatter _formatter;
    private readonly IShellService _shell;

    [ObservableProperty]
    private bool isInPlan;

    [ObservableProperty]
    private bool isExcluded;

    public ScanItemViewModel(
        ScanItem item,
        ICleanupPlanner planner,
        IReportExclusions exclusions,
        IStringLocalizer localizer,
        IValueFormatter formatter,
        IShellService shell)
    {
        Item = item;
        _planner = planner;
        _exclusions = exclusions;
        _localizer = localizer;
        _formatter = formatter;
        _shell = shell;

        Path = item.Path;
        Name = item.Name;
        ShortPath = PathUtils.ShortenForDisplay(item.Path, 72);
        SizeText = formatter.Bytes(item.Size);
        Bytes = item.Size;
        FileCountText = formatter.Count(item.FileCount);
        ModifiedText = formatter.Date(item.ModifiedAtUtc);
        CategoryText = localizer.Get(CategoryKey(item.Category));
        ConfidenceText = localizer.Get(item.Confidence switch
        {
            CleanupConfidence.Safe => "S.Results.Confidence.Safe",
            CleanupConfidence.Likely => "S.Results.Confidence.Likely",
            _ => "S.Results.Confidence.NeedsReview",
        });
        RiskText = localizer.Get(item.RiskLevel switch
        {
            RiskLevel.None or RiskLevel.Low => "S.Results.Risk.Low",
            RiskLevel.Medium => "S.Results.Risk.Medium",
            RiskLevel.High => "S.Results.Risk.High",
            _ => "S.Results.Risk.Critical",
        });
        OwnerText = item.OwnerApplication ?? string.Empty;
        HasOwner = !string.IsNullOrEmpty(item.OwnerApplication);
        IsDeletable = item.IsDeletable && !item.IsProtected;
        IsProtected = item.IsProtected;
        RequiresElevation = item.RequiresElevation;
        ReasonKey = item.Reason ?? string.Empty;

        // Localised explanation when the reason key has a translation, otherwise the
        // English text the analyzer produced. Never a raw key and never blank.
        var translated = item.Reason is { Length: > 0 } key ? localizer.Get("S.Reason." + key) : string.Empty;
        Explanation = string.IsNullOrEmpty(translated) || translated == "S.Reason." + item.Reason
            ? item.Explanation ?? string.Empty
            : translated;

        IsInPlan = planner.Contains(item.Path);
        IsExcluded = exclusions.IsExcluded(item.Path);
    }

    public ScanItem Item { get; }

    public string Path { get; }

    public string Name { get; }

    public string ShortPath { get; }

    public string SizeText { get; }

    public long Bytes { get; }

    public string FileCountText { get; }

    public string ModifiedText { get; }

    public string CategoryText { get; }

    public string ConfidenceText { get; }

    public string RiskText { get; }

    public string OwnerText { get; }

    public bool HasOwner { get; }

    public bool IsDeletable { get; }

    public bool IsProtected { get; }

    public bool RequiresElevation { get; }

    public string ReasonKey { get; }

    public string Explanation { get; }

    public CleanupConfidence Confidence => Item.Confidence;

    public ScanCategory Category => Item.Category;

    public string PlanToggleText => IsInPlan
        ? _localizer.Get("S.Results.RemoveFromPlan")
        : _localizer.Get("S.Results.AddToPlan");

    public string ExcludeToggleText => IsExcluded
        ? _localizer.Get("S.Results.Restore")
        : _localizer.Get("S.Results.Exclude");

    /// <summary>Set by the owning view model when an add is refused, so the UI can say why.</summary>
    public string? RejectionText { get; set; }

    [RelayCommand]
    private void TogglePlan()
    {
        if (IsInPlan)
        {
            _planner.Remove(Path);
        }
        else if (_planner.TryAdd(Item, out var rejection))
        {
            RejectionText = null;
        }
        else
        {
            // A refusal must be visible: the user clicked "add" and nothing happened.
            // The planner returns stable keys; the table turns them into language.
            RejectionText = _localizer.Format(
                "S.Results.Rejected",
                ReasonResolver.Resolve(_localizer, rejection, rejection));
        }

        // Reflect the outcome at once; the plan-changed event only re-syncs the summary.
        IsInPlan = _planner.Contains(Path);
    }

    [RelayCommand]
    private void ToggleExcluded()
    {
        if (IsExcluded)
        {
            _exclusions.Include(Path);
        }
        else
        {
            _exclusions.Exclude(Path);
            _planner.Remove(Path);      // an excluded row must not stay in the plan
        }

        IsExcluded = _exclusions.IsExcluded(Path);
        IsInPlan = _planner.Contains(Path);
    }

    [RelayCommand]
    private void OpenFolder() => _shell.OpenFileLocation(Path);

    partial void OnIsInPlanChanged(bool value) => OnPropertyChanged(nameof(PlanToggleText));

    partial void OnIsExcludedChanged(bool value) => OnPropertyChanged(nameof(ExcludeToggleText));

    public static string CategoryKey(ScanCategory category) => category switch
    {
        ScanCategory.TemporaryFiles => "S.Results.Category.TemporaryFiles",
        ScanCategory.BrowserCache => "S.Results.Category.BrowserCache",
        ScanCategory.ApplicationCache => "S.Results.Category.ApplicationCache",
        ScanCategory.Logs => "S.Results.Category.Logs",
        ScanCategory.CrashDumps => "S.Results.Category.CrashDumps",
        ScanCategory.RecycleBin => "S.Results.Category.RecycleBin",
        ScanCategory.Thumbnails => "S.Results.Category.Thumbnails",
        ScanCategory.WindowsUpdateCache => "S.Results.Category.WindowsUpdateCache",
        ScanCategory.AppLeftovers => "S.Results.Category.AppLeftovers",
        ScanCategory.LargeFiles => "S.Results.Category.LargeFiles",
        ScanCategory.DeveloperData => "S.Results.Category.DeveloperData",
        ScanCategory.InstallerPackages => "S.Results.Category.InstallerPackages",
        ScanCategory.SystemData => "S.Results.Category.SystemData",
        ScanCategory.UserData => "S.Results.Category.UserData",
        _ => "S.Results.Category.Other",
    };
}
