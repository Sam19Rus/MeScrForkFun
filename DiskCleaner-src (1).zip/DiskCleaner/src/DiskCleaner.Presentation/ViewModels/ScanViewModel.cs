using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One entry of the scan-mode picker.</summary>
public sealed record ScanModeOption(ScanMode Mode, string Title, string Description);

/// <summary>
/// Scan page: choose a scope, run it, watch honest progress, cancel at any time.
/// </summary>
public sealed partial class ScanViewModel : SectionViewModel, IDisposable
{
    private readonly IScanService _scanService;
    private readonly IDriveService _driveService;
    private readonly IDialogService _dialogs;
    private readonly IValueFormatter _formatter;
    private readonly INavigationService _navigation;
    private readonly IUiDispatcher _dispatcher;
    private readonly IShellService _shell;
    private readonly ApplicationPaths _paths;
    private readonly IPrivilegeService _privileges;
    private readonly ILogger _logger;

    private CancellationTokenSource? _cancellation;
    private bool _disposed;

    public ScanViewModel(
        IScanService scanService,
        IDriveService driveService,
        ISettingsService settings,
        IDialogService dialogs,
        IValueFormatter formatter,
        INavigationService navigation,
        IUiDispatcher dispatcher,
        IShellService shell,
        ApplicationPaths paths,
        IPrivilegeService privileges,
        IStringLocalizer localizer,
        ILogger<ScanViewModel>? logger = null)
        : base(Section.Scan, "S.Nav.Scan", "\uE721", localizer)
    {
        _scanService = scanService;
        _driveService = driveService;
        _dialogs = dialogs;
        _formatter = formatter;
        _navigation = navigation;
        _dispatcher = dispatcher;
        _shell = shell;
        _paths = paths;
        _privileges = privileges;
        _logger = logger ?? NullLogger<ScanViewModel>.Instance;

        // Settings are read by ScanService when the run starts; the page only needs the
        // service to exist so the dependency is explicit.
        _ = settings;

        Issues.CollectionChanged += (_, _) => OnPropertyChanged(nameof(HasIssues));

        PhaseText = Localizer.Get("S.Scan.Phase.Idle");
        ReloadDrives();
    }

    /// <summary>Bound to the red banner; non-null only after a failed run.</summary>
    public string? FailureText { get; private set; }

    public bool HasFailure => FailureText is { Length: > 0 };

    public bool HasIssues => Issues.Count > 0;

    /// <summary>Mode picker content, re-resolved on every access so a language switch is reflected.</summary>
    public IReadOnlyList<ScanModeOption> Modes =>
    [
        new(ScanMode.Quick, Localizer.Get("S.ScanMode.Quick"), Localizer.Get("S.ScanMode.Quick.Body")),
        new(ScanMode.Deep, Localizer.Get("S.ScanMode.Deep"), Localizer.Get("S.ScanMode.Deep.Body")),
        new(ScanMode.Custom, Localizer.Get("S.ScanMode.Custom"), Localizer.Get("S.ScanMode.Custom.Body")),
    ];

    public ObservableCollection<DriveCardViewModel> Drives { get; } = [];

    public ObservableCollection<string> CustomFolders { get; } = [];

    public ObservableCollection<ScanIssueViewModel> Issues { get; } = [];

    public ObservableCollection<CategorySummaryViewModel> Categories { get; } = [];

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(StartScanCommand))]
    [NotifyCanExecuteChangedFor(nameof(CancelScanCommand))]
    private bool isRunning;

    [ObservableProperty]
    private ScanMode selectedMode = ScanMode.Quick;

    [ObservableProperty]
    private bool isCustomMode;

    [ObservableProperty]
    private string newFolderPath = string.Empty;

    // --- progress ------------------------------------------------------------

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(StatusLabel))]
    private string phaseText;

    /// <summary>"Статус: Сканирование" — phase rendered inside its localised label.</summary>
    public string StatusLabel => Localizer.Format("S.Scan.StatusFormat", PhaseText);

    [ObservableProperty]
    private string currentRootText = "—";

    [ObservableProperty]
    private string currentDirectoryText = "—";

    [ObservableProperty]
    private string filesText = "0";

    [ObservableProperty]
    private string directoriesText = "0";

    [ObservableProperty]
    private string scannedBytesText = "—";

    [ObservableProperty]
    private double progressValue;

    [ObservableProperty]
    private bool isIndeterminate = true;

    [ObservableProperty]
    private string progressText = string.Empty;

    [ObservableProperty]
    private string elapsedText = "0 ms";

    [ObservableProperty]
    private string rateText = "—";

    [ObservableProperty]
    private string resultSummaryText = string.Empty;

    [ObservableProperty]
    private bool hasResult;

    [ObservableProperty]
    private string skippedSummaryText = string.Empty;

    [ObservableProperty]
    private string potentialCleanupText = "—";

    [ObservableProperty]
    private string safeText = "—";

    [ObservableProperty]
    private string likelyText = "—";

    [ObservableProperty]
    private string needsReviewText = "—";

    [ObservableProperty]
    private bool hasCleanupCandidates;

    public override bool IsBusy => IsRunning;

    partial void OnSelectedModeChanged(ScanMode value) => IsCustomMode = value == ScanMode.Custom;

    protected override void OnLanguageChangedCore()
    {
        PhaseText = Localizer.Get(PhaseKey(LastPhase));
        OnPropertyChanged(nameof(HasIssues));
        ReloadDrives();
    }

    private ScanPhase LastPhase { get; set; } = ScanPhase.Idle;

    public override Task OnNavigatedToAsync()
    {
        if (Drives.Count == 0)
        {
            ReloadDrives();
        }

        return Task.CompletedTask;
    }

    [RelayCommand]
    private void ReloadDrives()
    {
        var previous = Drives.ToDictionary(d => d.RootPath, d => d.IsSelectedForScan);

        Drives.Clear();
        foreach (var snapshot in _driveService.GetDrives().Where(s => s.IsReady))
        {
            var card = new DriveCardViewModel(snapshot, _formatter, Localizer)
            {
                IsSelectedForScan = previous.TryGetValue(snapshot.RootPath, out var selected)
                    ? selected
                    : snapshot.IsScannableByDefault,
            };

            Drives.Add(card);
        }

        StatusText = Localizer.Format("S.Scan.Status.VolumesAvailable", _formatter.Count(Drives.Count));
    }

    [RelayCommand]
    private async Task AddFolderAsync()
    {
        var picked = await _dialogs.PickFolderAsync(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
        if (!string.IsNullOrWhiteSpace(picked) && !CustomFolders.Contains(picked, StringComparer.OrdinalIgnoreCase))
        {
            CustomFolders.Add(picked);
        }
    }

    [RelayCommand]
    private void AddPathFromTextBox()
    {
        var path = NewFolderPath?.Trim() ?? string.Empty;
        if (path.Length == 0)
        {
            return;
        }

        // A relative path would silently scan somewhere else than the user meant.
        if (!PathUtils.IsPathRooted(path))
        {
            StatusText = Localizer.Get("S.Scan.Warn.NeedAbsolutePath");
            return;
        }

        if (!CustomFolders.Contains(path, PathUtils.Comparer))
        {
            CustomFolders.Add(path);
        }

        NewFolderPath = string.Empty;
    }

    [RelayCommand]
    private void RemoveFolder(string? path)
    {
        if (path is not null)
        {
            CustomFolders.Remove(path);
        }
    }

    private bool CanStartScan() => !IsRunning;

    private bool CanCancelScan() => IsRunning;

    [RelayCommand(CanExecute = nameof(CanStartScan))]
    private async Task StartScanAsync()
    {
        var roots = new List<string>();

        if (SelectedMode == ScanMode.Custom)
        {
            roots.AddRange(Drives.Where(d => d.IsSelectedForScan).Select(d => d.RootPath));
            roots.AddRange(CustomFolders);

            if (roots.Count == 0)
            {
                StatusText = Localizer.Get("S.Scan.Status.NeedSelection");
                _dialogs.ShowWarning(
                    Localizer.Get("S.Scan.Warn.NothingSelectedTitle"),
                    Localizer.Get("S.Scan.Warn.NothingSelected"));
                return;
            }
        }

        _cancellation?.Dispose();
        _cancellation = new CancellationTokenSource();

        Issues.Clear();
        HasResult = false;
        FailureText = null;
        ResultSummaryText = string.Empty;
        IsRunning = true;
        IsIndeterminate = true;
        ProgressValue = 0;
        ProgressText = string.Empty;
        StatusText = Localizer.Get("S.Scan.Status.Preparing");
        SetPhase(ScanPhase.Preparing);

        // Marshalling is explicit: the scanner reports from worker threads and the
        // dispatcher hops back to the UI thread. No reliance on SynchronizationContext.
        var progress = new CallbackProgress<ScanProgress>(snapshot => _dispatcher.Post(() => OnProgress(snapshot)));

        try
        {
            var result = await _scanService.RunAsync(SelectedMode, roots, progress, _cancellation.Token);
            ApplyResult(result);
        }
        catch (OperationCanceledException)
        {
            StatusText = Localizer.Get("S.Scan.Status.Cancelled");
            SetPhase(ScanPhase.Cancelled);
            ProgressText = string.Empty;
        }
        catch (Exception ex)
        {
            // A failure must never be silent: full detail to the log, a short safe
            // reason to the screen (type + message, never a stack trace).
            _logger.LogError(ex, "Scan failed while running {Mode} over {Roots}", SelectedMode, string.Join(", ", roots));

            StatusText = Localizer.Get("S.Scan.Status.Failed");
            FailureText = Localizer.Format("S.Scan.FailureBody", ex.GetType().Name, OneLine(ex.Message));
            SetPhase(ScanPhase.Faulted);
            IsIndeterminate = false;
            ProgressText = string.Empty;
        }
        finally
        {
            IsRunning = false;
        }
    }

    [RelayCommand(CanExecute = nameof(CanCancelScan))]
    private void CancelScan()
    {
        StatusText = Localizer.Get("S.Scan.Status.Cancelling");
        _cancellation?.Cancel();
    }

    [RelayCommand]
    private void OpenResults() => _navigation.Navigate(Section.Results);

    [RelayCommand]
    private void OpenLogFolder()
    {
        if (!_shell.OpenFolder(_paths.LogsDirectory))
        {
            _shell.OpenFolder(_paths.RootDirectory);
        }
    }

    [RelayCommand]
    private void DismissFailure() => FailureText = null;

    /// <summary>Exception messages can contain newlines; the banner needs one line.</summary>
    private static string OneLine(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return "—";
        }

        var collapsed = text.Replace("\r", " ").Replace("\n", " ").Trim();
        return collapsed.Length > 300 ? collapsed[..300] + "…" : collapsed;
    }

    private void SetPhase(ScanPhase phase)
    {
        LastPhase = phase;
        PhaseText = Localizer.Get(PhaseKey(phase));
    }

    private void OnProgress(ScanProgress progress)
    {
        SetPhase(progress.Phase);

        CurrentRootText = progress.CurrentRoot ?? "—";
        CurrentDirectoryText = progress.CurrentDirectory ?? "—";
        FilesText = _formatter.Count(progress.FilesScanned);
        DirectoriesText = _formatter.Count(progress.DirectoriesScanned);
        ScannedBytesText = _formatter.Bytes(progress.BytesScanned);
        ElapsedText = _formatter.Duration(progress.Elapsed);
        RateText = _formatter.Rate(progress.EntriesPerSecond);

        IsIndeterminate = progress.IsIndeterminate;
        if (progress.PercentComplete is { } percent)
        {
            ProgressValue = percent;
            ProgressText = _formatter.Percent(percent);
        }
        else
        {
            ProgressValue = 0;
            ProgressText = Localizer.Format("S.Scan.EntriesCount", _formatter.Count(progress.FilesScanned + progress.DirectoriesScanned));
        }

        StatusText = progress.CurrentDirectory is { Length: > 0 } dir
            ? Localizer.Format("S.Scan.Status.Scanning", PathUtils.ShortenForDisplay(dir, 60))
            : Localizer.Get("S.Scan.Status.ScanningGeneric");
    }

    private void ApplyResult(ScanResult result)
    {
        HasResult = true;

        PotentialCleanupText = _formatter.Bytes(result.PotentialCleanupBytes);
        SafeText = _formatter.Bytes(result.SafeBytes);
        LikelyText = _formatter.Bytes(result.LikelyBytes);
        NeedsReviewText = _formatter.Bytes(result.NeedsReviewBytes);
        HasCleanupCandidates = result.PotentialCleanupBytes > 0;

        Categories.Clear();
        foreach (var group in result.BytesByCategory.OrderByDescending(kv => kv.Value).Take(8))
        {
            var count = result.CountByCategory.TryGetValue(group.Key, out var value) ? value : 0;
            Categories.Add(new CategorySummaryViewModel(group.Key, group.Value, count, _formatter, Localizer));
        }

        var stats = result.Statistics;
        ResultSummaryText = result.WasCancelled
            ? Localizer.Format(
                "S.Scan.ResultSummaryCancelled",
                _formatter.Duration(result.Duration),
                _formatter.Count(stats.FilesScanned),
                _formatter.Count(stats.DirectoriesScanned))
            : Localizer.Format(
                "S.Scan.ResultSummary",
                _formatter.Count(stats.FilesScanned),
                _formatter.Count(stats.DirectoriesScanned),
                _formatter.Bytes(stats.BytesScanned),
                _formatter.Duration(result.Duration));

        SkippedSummaryText = stats.IssuesCount == 0
            ? Localizer.Get("S.Scan.NothingSkipped")
            : Localizer.Format(
                "S.Scan.SkippedSummary",
                _formatter.Count(stats.IssuesCount),
                _formatter.Count(stats.InaccessibleDirectories),
                _formatter.Count(stats.ReparsePointsSkipped));

        foreach (var issue in result.Issues.Take(500))
        {
            Issues.Add(ScanIssueViewModel.From(issue, Localizer, _formatter, _privileges.IsElevated));
        }

        StatusText = ResultSummaryText;
        SetPhase(result.WasCancelled ? ScanPhase.Cancelled : ScanPhase.Completed);
        IsIndeterminate = false;
        ProgressValue = 1;
        ProgressText = result.WasCancelled ? Localizer.Get("S.Scan.Phase.Cancelled") : Localizer.Get("S.Scan.Done");
    }

    private static string PhaseKey(ScanPhase phase) => phase switch
    {
        ScanPhase.Preparing => "S.Scan.Phase.Preparing",
        ScanPhase.Enumerating => "S.Scan.Phase.Scanning",
        ScanPhase.Analyzing => "S.Scan.Phase.Analyzing",
        ScanPhase.Classifying => "S.Scan.Phase.Classifying",
        ScanPhase.Completed => "S.Scan.Phase.Completed",
        ScanPhase.Cancelled => "S.Scan.Phase.Cancelled",
        ScanPhase.Faulted => "S.Scan.Phase.Stopped",
        _ => "S.Scan.Phase.Idle",
    };

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _cancellation?.Cancel();
        _cancellation?.Dispose();
    }
}
