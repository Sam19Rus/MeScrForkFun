using CommunityToolkit.Mvvm.ComponentModel;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One volume as shown on the dashboard and in the scan scope picker.</summary>
public sealed partial class DriveCardViewModel : ObservableObject
{
    public DriveCardViewModel(DriveSnapshot snapshot, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Snapshot = snapshot;
        Formatter = formatter;
        RootPath = snapshot.RootPath;
        DriveTypeText = snapshot.DriveType;
        IsReady = snapshot.IsReady;
        IsScannable = snapshot.IsScannableByDefault;

        var label = snapshot.Label;
        DisplayName = string.IsNullOrWhiteSpace(label)
            ? snapshot.RootPath
            : $"{label} ({snapshot.RootPath})";

        TotalText = snapshot.IsReady ? formatter.Bytes(snapshot.TotalBytes) : localizer.Get("S.Overview.NotReady");
        UsedText = snapshot.IsReady ? formatter.Bytes(snapshot.UsedBytes) : "—";
        FreeText = snapshot.IsReady ? formatter.Bytes(snapshot.FreeBytes) : "—";
        FreeSuffixText = snapshot.IsReady ? localizer.Format("S.Overview.FreeSuffix", FreeText) : string.Empty;
        NotReadyChipText = localizer.Get("S.Overview.NotReadyChip");
        UsedRatio = snapshot.UsedRatio ?? 0d;
        UsedPercentText = formatter.Percent(snapshot.UsedRatio);
        SummaryText = snapshot.IsReady
            ? localizer.Format("S.Overview.VolumeSummary", UsedText, TotalText, FreeText)
            : localizer.Get("S.Overview.VolumeNotReady");
    }

    [ObservableProperty]
    private bool isSelectedForScan;

    public DriveSnapshot Snapshot { get; }

    public IValueFormatter Formatter { get; }

    public string RootPath { get; }

    public string DisplayName { get; }

    public string DriveTypeText { get; }

    public bool IsReady { get; }

    public bool IsScannable { get; }

    public string TotalText { get; }

    public string UsedText { get; }

    public string FreeText { get; }

    public string FreeSuffixText { get; }

    public string NotReadyChipText { get; }

    public string UsedPercentText { get; }

    public string SummaryText { get; }

    /// <summary>0..1 for the usage bar.</summary>
    public double UsedRatio { get; }

    /// <summary>Warning colour above this ratio; critical above <see cref="CriticalRatio"/>.</summary>
    public const double WarningRatio = 0.80d;

    public const double CriticalRatio = 0.93d;

    public bool IsWarning => UsedRatio >= WarningRatio && UsedRatio < CriticalRatio;

    public bool IsCritical => UsedRatio >= CriticalRatio;

    public override string ToString() => $"{DisplayName} — {SummaryText}";
}
