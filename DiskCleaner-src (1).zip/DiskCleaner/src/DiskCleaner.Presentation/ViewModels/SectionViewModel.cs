using CommunityToolkit.Mvvm.ComponentModel;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>
/// Base class for the eight shell sections.
/// </summary>
/// <remarks>
/// Titles and any generated text are resolved through <see cref="IStringLocalizer"/>,
/// so switching the language repaints the rail and the section without a restart.
/// <see cref="ImplementationPhase"/> is honest scaffolding: sections that are not
/// implemented yet say so instead of pretending to work. It disappears as each phase
/// lands.
/// </remarks>
public abstract partial class SectionViewModel : ObservableObject
{
    [ObservableProperty]
    private bool isActive;

    [ObservableProperty]
    private string statusText = string.Empty;

    protected SectionViewModel(Section section, string titleKey, string glyph, IStringLocalizer localizer)
    {
        Section = section;
        TitleKey = titleKey ?? throw new ArgumentNullException(nameof(titleKey));
        Glyph = glyph;
        Localizer = localizer ?? throw new ArgumentNullException(nameof(localizer));

        // Sections live as long as the application, so this subscription is never released.
        Localizer.LanguageChanged += HandleLanguageChanged;
    }

    public Section Section { get; }

    /// <summary>Resource key of the section title.</summary>
    public string TitleKey { get; }

    /// <summary>Localised section title.</summary>
    public string Title => Localizer.Get(TitleKey);

    /// <summary>Segoe MDL2 Assets code point, e.g. <c>&#xE80F;</c> for "Home".</summary>
    public string Glyph { get; }

    protected IStringLocalizer Localizer { get; }

    /// <summary><c>null</c> once the section is fully implemented.</summary>
    public virtual int? ImplementationPhase => null;

    /// <summary>What this section will show. Non-null only while the section is pending.</summary>
    public virtual string? PlannedContent => null;

    /// <summary>Header of the pending notice, e.g. «Очистка» ещё не подключён.</summary>
    public string PendingTitleText => Localizer.Format("S.Pending.Title", Title);

    /// <summary>"Planned for phase N" line of the pending notice.</summary>
    public string PendingPlannedLabel => Localizer.Format("S.Pending.Planned", ImplementationPhase);

    /// <summary>Localized column/section labels used by the placeholder view.</summary>
    public string PendingWhatWillBeHereLabel => Localizer.Get("S.Pending.WhatWillBeHere");

    public string PendingNoFakeDataText => Localizer.Get("S.Pending.NoFakeData");

    /// <summary><c>true</c> when the section is doing real work (blocks closing without asking).</summary>
    public virtual bool IsBusy => false;

    public bool IsImplemented => ImplementationPhase is null;

    /// <summary>Called when the section becomes visible. Refreshes live data.</summary>
    public virtual Task OnNavigatedToAsync() => Task.CompletedTask;

    /// <summary>Called when the user navigates away. Stops timers, not work.</summary>
    public virtual Task OnNavigatedFromAsync() => Task.CompletedTask;

    private void HandleLanguageChanged(object? sender, EventArgs e)
    {
        OnPropertyChanged(nameof(Title));
        OnPropertyChanged(nameof(PlannedContent));
        OnPropertyChanged(nameof(PendingTitleText));
        OnPropertyChanged(nameof(PendingPlannedLabel));
        OnPropertyChanged(nameof(PendingWhatWillBeHereLabel));
        OnPropertyChanged(nameof(PendingNoFakeDataText));
        OnLanguageChangedCore();
    }

    /// <summary>Derived sections refresh their own generated text here.</summary>
    protected virtual void OnLanguageChangedCore()
    {
    }
}
