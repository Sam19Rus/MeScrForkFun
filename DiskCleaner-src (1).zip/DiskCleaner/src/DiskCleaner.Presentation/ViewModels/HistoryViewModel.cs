using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One executed cleanup, as shown in the History list.</summary>
public sealed class HistoryRunViewModel
{
    public HistoryRunViewModel(CleanupRunRecord record, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Record = record;
        WhenText = formatter.DateTime(record.StartedAtUtc);
        DurationText = formatter.Duration(record.Duration);
        FreedText = formatter.Bytes(record.FreedBytes);
        FilesText = formatter.Count(record.DeletedFileCount);
        ModeText = localizer.Get($"S.ScanMode.{record.Mode}");
        SkippedText = record.SkippedCount == 0 ? localizer.Get("S.History.NoneSkipped") : formatter.Count(record.SkippedCount);
        StateText = record.WasCancelled
            ? localizer.Get("S.History.State.Cancelled")
            : record.FailedCount > 0
                ? localizer.Get("S.History.State.CompletedWithErrors")
                : localizer.Get("S.History.State.Completed");

        CategoriesText = record.Categories.Count == 0
            ? "—"
            : string.Join(", ", record.Categories.OrderByDescending(c => c.FreedBytes)
                .Select(c => $"{localizer.Get(ScanItemViewModel.CategoryKey(c.Category))} ({formatter.Bytes(c.FreedBytes)})"));

        SkippedDetail = record.Skipped.Count == 0
            ? string.Empty
            : string.Join(
                Environment.NewLine,
                record.Skipped.Take(20).Select(sk =>
                    $"{sk.Path} — {ReasonResolver.Resolve(localizer, sk.Reason, localizer.Get($"S.Issue.{sk.Kind}"))}"));

        RanElevatedText = record.RanElevated ? localizer.Get("S.History.Elevated") : localizer.Get("S.History.Standard");
    }

    public CleanupRunRecord Record { get; }

    public string WhenText { get; }

    public string DurationText { get; }

    public string FreedText { get; }

    public string FilesText { get; }

    public string ModeText { get; }

    public string SkippedText { get; }

    public string StateText { get; }

    public string CategoriesText { get; }

    public string SkippedDetail { get; }

    public string RanElevatedText { get; }
}

/// <summary>History page: what was removed, when, how much was freed, what was skipped and why.</summary>
public sealed partial class HistoryViewModel : SectionViewModel
{
    private readonly IHistoryService _history;
    private readonly IDialogService _dialogs;
    private readonly IShellService _shell;
    private readonly IValueFormatter _formatter;
    private readonly ApplicationPaths _paths;
    private readonly IUiDispatcher _dispatcher;

    public HistoryViewModel(
        IHistoryService history,
        IDialogService dialogs,
        IShellService shell,
        IValueFormatter formatter,
        ApplicationPaths paths,
        IUiDispatcher dispatcher,
        IStringLocalizer localizer)
        : base(Section.History, "S.Nav.History", "\uE823", localizer)
    {
        _history = history;
        _dialogs = dialogs;
        _shell = shell;
        _formatter = formatter;
        _paths = paths;
        _dispatcher = dispatcher;

        _history.HistoryChanged += OnHistoryChanged;
        Refresh();
    }

    public ObservableCollection<HistoryRunViewModel> Runs { get; } = [];

    [ObservableProperty]
    private string totalFreedText = "—";

    [ObservableProperty]
    private string summaryText = string.Empty;

    [ObservableProperty]
    private bool hasRuns;

    protected override void OnLanguageChangedCore() => Refresh();

    [RelayCommand]
    private void Refresh()
    {
        Runs.Clear();

        foreach (var record in _history.Records)
        {
            Runs.Add(new HistoryRunViewModel(record, _formatter, Localizer));
        }

        HasRuns = Runs.Count > 0;
        TotalFreedText = HasRuns ? _formatter.Bytes(_history.TotalFreedBytes) : "—";
        SummaryText = HasRuns
            ? Localizer.Format("S.History.Summary", _formatter.Count(Runs.Count), _formatter.Bytes(_history.TotalFreedBytes))
            : Localizer.Get("S.History.SummaryNone");

        StatusText = SummaryText;
    }

    [RelayCommand]
    private async Task ClearAsync()
    {
        if (Runs.Count == 0)
        {
            return;
        }

        var confirmed = await _dialogs.ConfirmAsync(
            Localizer.Get("S.History.ClearConfirmTitle"),
            Localizer.Format("S.History.ClearConfirm", _formatter.Count(Runs.Count), _paths.HistoryFile),
            Localizer.Get("S.History.Clear"));

        if (confirmed)
        {
            await _history.ClearAsync();
            Refresh();
        }
    }

    [RelayCommand]
    private void OpenHistoryFile() => _shell.OpenFileLocation(_paths.HistoryFile);

    private void OnHistoryChanged(object? sender, EventArgs e) =>
        // JsonHistoryService raises this after ConfigureAwait(false), i.e. on a
        // thread-pool thread. Runs is bound to the UI, so hop to the dispatcher.
        _dispatcher.Post(Refresh);

    public override Task OnNavigatedToAsync()
    {
        Refresh();
        return Task.CompletedTask;
    }
}
