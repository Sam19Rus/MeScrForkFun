using CommunityToolkit.Mvvm.ComponentModel;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One row of the "Skipped" list, exactly as §23 of the spec asks for.</summary>
/// <remarks>
/// Text is resolved through the localizer on demand. These rows are transient (they are
/// rebuilt on every scan), so they deliberately do <b>not</b> subscribe to
/// <see cref="IStringLocalizer.LanguageChanged"/>: doing so would leak every row into a
/// singleton event for the lifetime of the process.
/// </remarks>
public sealed class ScanIssueViewModel(IStringLocalizer localizer, bool processIsElevated)
{
    public required string Path { get; init; }

    public required ScanIssueKind Kind { get; init; }

    /// <summary>Stable, non-localised reason key produced by the scanner.</summary>
    public required string ReasonKey { get; init; }

    /// <summary>English reason carried by the model; used when no translation exists.</summary>
    public required string FallbackReason { get; init; }

    public bool MayRequireElevation { get; init; }

    public long EstimatedSize { get; init; }

    public string SizeText { get; init; } = "—";

    /// <summary>Truncated for the grid; the full path goes into the tooltip.</summary>
    public string ShortPath => PathUtils.ShortenForDisplay(Path, 78);

    public string KindText => localizer.Get(KindKey(Kind));

    public string Reason
    {
        get
        {
            var key = ReasonKey.StartsWith("issue.", StringComparison.Ordinal)
                ? "S.IssueReason." + ReasonKey["issue.".Length..]
                : ReasonKey;

            var translated = localizer.Get(key);
            return string.Equals(translated, key, StringComparison.Ordinal) ? FallbackReason : translated;
        }
    }

    /// <summary>
    /// Access can be denied for two completely different reasons, and the advice differs:
    /// a standard user can fix it by elevating; an administrator cannot, because the ACL
    /// grants access to SYSTEM/TrustedInstaller only.
    /// </summary>
    public bool IsSystemOnly => MayRequireElevation && processIsElevated;

    public bool CanBeFixedByElevation => MayRequireElevation && !processIsElevated;

    public string Tooltip =>
        $"{KindText}: {Path}\n{Reason}" +
        (CanBeFixedByElevation ? localizer.Get("S.Issue.ElevationHint")
            : IsSystemOnly ? localizer.Get("S.Issue.SystemOnlyHint")
            : string.Empty);

    public static ScanIssueViewModel From(ScanIssue issue, IStringLocalizer localizer, IValueFormatter formatter, bool processIsElevated) => new(localizer, processIsElevated)
    {
        Path = issue.Path,
        Kind = issue.Kind,
        ReasonKey = issue.ReasonKey,
        FallbackReason = issue.Reason,
        MayRequireElevation = issue.MayRequireElevation,
        EstimatedSize = issue.EstimatedSize,
        SizeText = issue.EstimatedSize > 0 ? formatter.Bytes(issue.EstimatedSize) : "—",
    };

    private static string KindKey(ScanIssueKind kind) => kind switch
    {
        ScanIssueKind.AccessDenied => "S.Issue.AccessDenied",
        ScanIssueKind.PathTooLong => "S.Issue.PathTooLong",
        ScanIssueKind.FileInUse => "S.Issue.FileInUse",
        ScanIssueKind.NotFound => "S.Issue.NotFound",
        ScanIssueKind.IoError => "S.Issue.IoError",
        ScanIssueKind.ReparsePointSkipped => "S.Issue.ReparsePointSkipped",
        ScanIssueKind.Excluded => "S.Issue.Excluded",
        ScanIssueKind.Cancelled => "S.Issue.Cancelled",
        _ => "S.Issue.Unknown",
    };
}
