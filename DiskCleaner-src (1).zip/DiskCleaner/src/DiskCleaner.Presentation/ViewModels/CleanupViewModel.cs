using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One row of the confirmed plan.</summary>
public sealed class CleanupOperationViewModel
{
    public CleanupOperationViewModel(CleanupOperation operation, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Operation = operation;
        Path = operation.TargetPath;
        Name = operation.DisplayName;
        SizeText = formatter.Bytes(operation.ExpectedBytes);
        CategoryText = localizer.Get($"S.Results.Category.{operation.Category}");
        RiskText = localizer.Get(RiskKey(operation.RiskLevel));
        MethodText = localizer.Get(MethodKey(operation.Method));

        // Reason key first (translated), the analyzer's English text as fallback —
        // never a raw key in a tooltip.
        ReasonText = ReasonResolver.Resolve(localizer, operation.Reason, operation.Explanation);
    }

    public CleanupOperation Operation { get; }

    public string Path { get; }

    public string Name { get; }

    public string SizeText { get; }

    public string CategoryText { get; }

    public string RiskText { get; }

    public string MethodText { get; }

    public string ReasonText { get; }

    public bool IsHighRisk => Operation.RiskLevel >= RiskLevel.High;

    public bool IsRecycled => Operation.Method == DeletionMethod.RecycleBin;

    public bool IsSystemApi => Operation.Method == DeletionMethod.SystemApi;

    /// <summary>Five internal levels collapse into the four labels the UI shows.</summary>
    private static string RiskKey(RiskLevel level) => level switch
    {
        RiskLevel.None or RiskLevel.Low => "S.Results.Risk.Low",
        RiskLevel.Medium => "S.Results.Risk.Medium",
        RiskLevel.High => "S.Results.Risk.High",
        _ => "S.Results.Risk.Critical",
    };

    /// <summary>Refreshed while the run is in flight.</summary>
    public string StatusText { get; set; } = string.Empty;

    private static string MethodKey(DeletionMethod method) => method switch
    {
        DeletionMethod.RecycleBin => "S.Cleanup.Method.RecycleBin",
        DeletionMethod.Permanent => "S.Cleanup.Method.Permanent",
        DeletionMethod.SystemApi => "S.Cleanup.Method.SystemApi",
        _ => "S.Cleanup.Method.None",
    };
}

/// <summary>
/// Phase 8: the confirmation screen and the executor's control surface.
/// </summary>
/// <remarks>
/// The screen never decides what to delete — it shows the plan the user built elsewhere
/// and asks for one explicit confirmation. While a run is in flight every control that
/// could change the plan is disabled, and the only extra action offered is "stop", which
/// abandons the rest of the plan rather than interrupting a deletion mid-way.
/// <para/>
/// Results are shown as they were actually observed: freed bytes, per-category breakdown,
/// and every skipped item with its reason. A locked file is reported, never forced.
/// </remarks>
public sealed partial class CleanupViewModel : SectionViewModel
{
    private readonly ICleanupPlanner _planner;
    private readonly ICleanupExecutor _executor;
    private readonly IValueFormatter _formatter;
    private readonly IUiDispatcher _dispatcher;
    private readonly IDialogService _dialogs;
    private readonly IPrivilegeService _privileges;
    private readonly ISettingsService _settings;
    private readonly INavigationService _navigation;

    private CancellationTokenSource? _runCancellation;
    private CleanupRunRecord? _lastRecord;

    public CleanupViewModel(
        ICleanupPlanner planner,
        ICleanupExecutor executor,
        IValueFormatter formatter,
        IUiDispatcher dispatcher,
        IDialogService dialogs,
        IPrivilegeService privileges,
        ISettingsService settings,
        INavigationService navigation,
        IStringLocalizer localizer)
        : base(Section.Cleanup, "S.Nav.Cleanup", "\uEA99", localizer)
    {
        _planner = planner;
        _executor = executor;
        _formatter = formatter;
        _dispatcher = dispatcher;
        _dialogs = dialogs;
        _privileges = privileges;
        _settings = settings;
        _navigation = navigation;

        // Sections outlive the window, so these subscriptions are never released.
        _planner.PlanChanged += (_, _) => _dispatcher.Post(RefreshPlan);

        RefreshPlan();
    }

    public ObservableCollection<CleanupOperationViewModel> Operations { get; } = [];

    public ObservableCollection<CategoryBreakdownViewModel> ResultCategories { get; } = [];

    public ObservableCollection<SkippedFileViewModel> ResultSkipped { get; } = [];

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasPlan))]
    [NotifyPropertyChangedFor(nameof(IsEmpty))]
    private int operationCount;

    [ObservableProperty]
    private string totalSizeText = string.Empty;

    [ObservableProperty]
    private string summaryText = string.Empty;

    [ObservableProperty]
    private string deletionModeText = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ExecuteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ClearPlanCommand))]
    private bool isExecuting;

    [ObservableProperty]
    private double progressValue;

    [ObservableProperty]
    private string progressText = string.Empty;

    [ObservableProperty]
    private string? currentPathText;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ExecuteCommand))]
    private bool needsElevation;

    [ObservableProperty]
    private bool hasHighRiskOperation;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(CancelRunCommand))]
    private bool canCancel;

    [ObservableProperty]
    private bool hasResult;

    [ObservableProperty]
    private string resultHeadline = string.Empty;

    [ObservableProperty]
    private string resultDetail = string.Empty;

    [ObservableProperty]
    private string? resultError;

    public bool HasPlan => OperationCount > 0 && !IsExecuting;

    public bool IsEmpty => OperationCount == 0 && !HasResult;

    /// <summary>The plan that will be shown in the confirmation dialog.</summary>
    public string ConfirmationPreview { get; private set; } = string.Empty;

    // ------------------------------------------------------------------ commands

    [RelayCommand(CanExecute = nameof(CanExecute))]
    private async Task ExecuteAsync()
    {
        if (IsExecuting || _planner.Current.IsEmpty)
        {
            return;
        }

        var plan = _planner.Current;

        // One explicit confirmation, with the numbers the user is about to accept.
        var message = string.Join(
            Environment.NewLine,
            Localizer.Format("S.Cleanup.Confirm.Summary", _formatter.Count(plan.Count), _formatter.Bytes(plan.TotalExpectedBytes)),
            BuildConfirmationPreview(plan),
            string.Empty,
            Localizer.Get("S.Cleanup.Confirm.Question"));

        var confirmed = await _dialogs.ConfirmAsync(
            Localizer.Get("S.Cleanup.Confirm.Title"),
            message,
            Localizer.Get("S.Cleanup.Confirm.Accept"),
            Localizer.Get("S.Cleanup.Confirm.Decline")).ConfigureAwait(true);

        if (!confirmed)
        {
            return;
        }

        await RunAsync(plan, ScanMode.Custom).ConfigureAwait(true);
    }

    [RelayCommand(CanExecute = nameof(CanCancelRun))]
    private void CancelRun() => _runCancellation?.Cancel();

    [RelayCommand(CanExecute = nameof(CanExecute))]
    private void ClearPlan()
    {
        _planner.Clear();
        RefreshPlan();
    }

    [RelayCommand]
    private void RemoveOperation(CleanupOperationViewModel? operation)
    {
        if (operation is null || IsExecuting)
        {
            return;
        }

        _planner.Remove(operation.Path);
        RefreshPlan();
    }

    [RelayCommand]
    private void OpenHistory() => _navigation.Navigate(Section.History);

    [RelayCommand]
    private async Task RequestElevationAsync()
    {
        var granted = await _privileges.RequestElevationAsync(
            Localizer.Get("S.Cleanup.Elevation.Reason")).ConfigureAwait(true);

        if (!granted)
        {
            _dialogs.ShowInfo(
                Localizer.Get("S.Cleanup.Elevation.Title"),
                Localizer.Get("S.Cleanup.Elevation.Declined"));
        }

        // A granted elevation relaunches the process; this instance simply refreshes.
        RefreshPlan();
    }

    /// <summary>The plan can only be run or cleared when there is something in it.</summary>
    private bool CanExecute() => !IsExecuting && _planner.Count > 0;

    private static string RiskLabel(RiskLevel level) => level switch
    {
        RiskLevel.None or RiskLevel.Low => "S.Results.Risk.Low",
        RiskLevel.Medium => "S.Results.Risk.Medium",
        RiskLevel.High => "S.Results.Risk.High",
        _ => "S.Results.Risk.Critical",
    };

    private bool CanCancelRun() => IsExecuting && CanCancel;

    // ---------------------------------------------------------------- execution

    private async Task RunAsync(CleanupPlan plan, ScanMode mode)
    {
        IsExecuting = true;
        CanCancel = true;
        HasResult = false;
        ResultError = null;
        ProgressValue = 0;
        ResultCategories.Clear();
        ResultSkipped.Clear();

        _runCancellation = new CancellationTokenSource();
        var progress = new Progress<CleanupProgress>(ReportProgress);

        try
        {
            // Deletions are blocking I/O: run them off the UI thread.
            var record = await Task.Run(
                () => _executor.ExecuteAsync(plan, mode, progress, _runCancellation.Token),
                CancellationToken.None).ConfigureAwait(true);

            _lastRecord = record;
            RenderResult(record);
        }
        catch (Exception ex)
        {
            ResultError = Localizer.Format("S.Cleanup.Result.Error", ex.GetType().Name);
            HasResult = true;
        }
        finally
        {
            IsExecuting = false;
            CanCancel = false;
            CurrentPathText = null;
            _runCancellation.Dispose();
            _runCancellation = null;
            RefreshPlan();
        }
    }

    private void ReportProgress(CleanupProgress progress)
    {
        ProgressValue = progress.PercentComplete ?? 0d;
        CurrentPathText = progress.CurrentPath;
        ProgressText = Localizer.Format(
            "S.Cleanup.Progress",
            _formatter.Count(progress.CompletedOperations),
            _formatter.Count(progress.TotalOperations),
            _formatter.Bytes(progress.FreedBytes),
            _formatter.Count(progress.SkippedCount));
    }

    /// <summary>Turns a run record into translated, displayable text. Idempotent.</summary>
    private void RenderResult(CleanupRunRecord record)
    {
        ResultCategories.Clear();
        ResultSkipped.Clear();

        ResultHeadline = Localizer.Format(
            record.WasCancelled ? "S.Cleanup.Result.CancelledHeadline" : "S.Cleanup.Result.Headline",
            _formatter.Bytes(record.FreedBytes));

        var detail = Localizer.Format(
            "S.Cleanup.Result.Detail",
            _formatter.Count(record.DeletedFileCount),
            _formatter.Count(record.DeletedDirectoryCount),
            _formatter.Count(record.SkippedCount),
            _formatter.Duration(record.Duration));

        if (record.FreeBytesBefore != record.FreeBytesAfter)
        {
            detail += Environment.NewLine + Localizer.Format(
                "S.Cleanup.Result.VolumeDelta",
                _formatter.Bytes(Math.Abs(record.FreeBytesAfter - record.FreeBytesBefore)),
                record.FreeBytesAfter > record.FreeBytesBefore
                    ? Localizer.Get("S.Cleanup.Result.VolumeFreed")
                    : Localizer.Get("S.Cleanup.Result.VolumeConsumed"));
        }

        if (record.RanElevated)
        {
            detail += Environment.NewLine + Localizer.Get("S.Cleanup.Result.RanElevated");
        }

        ResultDetail = detail;

        foreach (var category in record.Categories.OrderByDescending(c => c.FreedBytes))
        {
            ResultCategories.Add(new CategoryBreakdownViewModel(category, _formatter, Localizer));
        }

        foreach (var skipped in record.Skipped)
        {
            ResultSkipped.Add(new SkippedFileViewModel(skipped, _formatter, Localizer));
        }

        HasResult = true;

        // The plan is spent. Keeping it would invite a second, unintended run.
        _planner.Clear();
    }

    // ------------------------------------------------------------------- refresh

    private void RefreshPlan()
    {
        var plan = _planner.Current;

        Operations.Clear();
        foreach (var operation in plan.Operations.OrderByDescending(o => o.ExpectedBytes))
        {
            Operations.Add(new CleanupOperationViewModel(operation, _formatter, Localizer));
        }

        OperationCount = plan.Count;
        TotalSizeText = _formatter.Bytes(plan.TotalExpectedBytes);
        ConfirmationPreview = BuildConfirmationPreview(plan);

        NeedsElevation = plan.Operations.Any(o => o.RequiresElevation) && !_privileges.IsElevated;
        HasHighRiskOperation = plan.HighRiskOperations.Any();

        SummaryText = plan.Count == 0
            ? Localizer.Get("S.Cleanup.Empty")
            : Localizer.Format(
                "S.Cleanup.Summary",
                _formatter.Count(plan.Count),
                _formatter.Bytes(plan.TotalExpectedBytes));

        DeletionModeText = Localizer.Get(_settings.Current.RecycleBinBehavior switch
        {
            RecycleBinBehavior.Never => "S.Cleanup.Mode.Never",
            RecycleBinBehavior.Always => "S.Cleanup.Mode.Always",
            _ => "S.Cleanup.Mode.Smart",
        });

        StatusText = SummaryText;

        ExecuteCommand.NotifyCanExecuteChanged();
        ClearPlanCommand.NotifyCanExecuteChanged();
    }

    /// <summary>
    /// The per-category lines shown in the confirmation dialog: what, how much, how risky.
    /// </summary>
    private string BuildConfirmationPreview(CleanupPlan plan)
    {
        var lines = new List<string>();

        foreach (var group in plan.ByCategory.OrderByDescending(g => g.Sum(o => o.ExpectedBytes)))
        {
            var risk = group.Max(o => o.RiskLevel);
            lines.Add(Localizer.Format(
                "S.Cleanup.Confirm.Line",
                Localizer.Get($"S.Results.Category.{group.Key}"),
                _formatter.Count(group.Count()),
                _formatter.Bytes(group.Sum(o => o.ExpectedBytes)),
                Localizer.Get(RiskLabel(risk))));
        }

        return string.Join(Environment.NewLine, lines);
    }

    protected override void OnLanguageChangedCore()
    {
        base.OnLanguageChangedCore();

        // Every label is derived text, so a language switch re-renders both the plan
        // and the result of the last run from the record itself.
        RefreshPlan();

        if (_lastRecord is not null)
        {
            RenderResult(_lastRecord);
        }
    }
}

/// <summary>One line of the post-run breakdown.</summary>
public sealed class CategoryBreakdownViewModel
{
    public CategoryBreakdownViewModel(CategoryBreakdown breakdown, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Name = localizer.Get($"S.Results.Category.{breakdown.Category}");
        SizeText = formatter.Bytes(breakdown.FreedBytes);
        DetailText = localizer.Format(
            "S.Cleanup.Result.CategoryDetail",
            formatter.Count(breakdown.FileCount),
            formatter.Count(breakdown.DirectoryCount),
            formatter.Count(breakdown.SkippedCount));
    }

    public string Name { get; }

    public string SizeText { get; }

    public string DetailText { get; }
}

/// <summary>One skipped item with the reason it was left alone.</summary>
public sealed class SkippedFileViewModel
{
    public SkippedFileViewModel(SkippedFile skipped, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Path = skipped.Path;
        Name = PathUtils.GetFileName(skipped.Path);
        KindText = localizer.Get($"S.Issue.{skipped.Kind}");
        ReasonText = ResolveReason(localizer, skipped.Reason, KindText);
        SizeText = formatter.Bytes(skipped.EstimatedBytes);
        NeedsElevation = skipped.Kind == ScanIssueKind.AccessDenied;
    }

    public string Path { get; }

    public string Name { get; }

    public string ReasonText { get; }

    public string KindText { get; }

    public string SizeText { get; }

    public bool NeedsElevation { get; }

    /// <summary>
    /// Reason keys come from two places (cleanup-specific and scan-issue classification).
    /// Whichever table has the key wins; otherwise the issue label is shown. A raw key is
    /// never surfaced to the user.
    /// </summary>
    private static string ResolveReason(IStringLocalizer localizer, string key, string fallback)
    {
        foreach (var candidate in new[] { "S.Cleanup.Reason." + key, "S.Reason." + key })
        {
            if (localizer.CurrentTable.ContainsKey(candidate))
            {
                return localizer.Get(candidate);
            }
        }

        return fallback;
    }
}
