using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Infrastructure.Formatting;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>
/// Settings page. Every entry here is one a real user would change — the list is
/// deliberately short (§21 of the spec).
/// </summary>
public sealed partial class SettingsViewModel : SectionViewModel
{
    private readonly ISettingsService _settings;
    private readonly IAppearanceService _appearance;
    private readonly IShellService _shell;
    private readonly IDialogService _dialogs;
    private readonly ApplicationPaths _paths;
    private readonly IScanService _scanService;
    private readonly IValueFormatter _formatter;
    private readonly ILogger _logger;

    private bool _loading;

    public SettingsViewModel(
        ISettingsService settings,
        IAppearanceService appearance,
        IShellService shell,
        IDialogService dialogs,
        ApplicationPaths paths,
        IScanService scanService,
        IValueFormatter formatter,
        IStringLocalizer localizer,
        ILogger<SettingsViewModel>? logger = null)
        : base(Section.Settings, "S.Nav.Settings", "\uE713", localizer)
    {
        _settings = settings;
        _appearance = appearance;
        _shell = shell;
        _dialogs = dialogs;
        _paths = paths;
        _scanService = scanService;
        _formatter = formatter;
        _logger = logger ?? NullLogger<SettingsViewModel>.Instance;

        StorageLocationText = paths.RootDirectory;
        LoadFrom(_settings.Current);
    }

    public IReadOnlyList<AppTheme> Themes { get; } = [AppTheme.System, AppTheme.Light, AppTheme.Dark];

    /// <summary>Russian first: it is the primary language of the product.</summary>
    public IReadOnlyList<string> Languages { get; } = ["ru", "en"];

    public IReadOnlyList<RecycleBinBehavior> RecycleBinOptions { get; } =
    [
        RecycleBinBehavior.PreferForUserData,
        RecycleBinBehavior.Always,
        RecycleBinBehavior.Never,
    ];

    public IReadOnlyList<ScanDepth> Depths { get; } = [ScanDepth.Fast, ScanDepth.Standard, ScanDepth.Exhaustive];

    public ObservableCollection<string> ExcludedPaths { get; } = [];

    public ObservableCollection<string> ExcludedExtensions { get; } = [];

    [ObservableProperty]
    private AppTheme theme;

    [ObservableProperty]
    private string language = "en";

    [ObservableProperty]
    private ScanDepth depth;

    [ObservableProperty]
    private RecycleBinBehavior recycleBinBehavior;

    [ObservableProperty]
    private string largeFileThresholdText = "256 MB";

    [ObservableProperty]
    private bool enableDeveloperAnalysis;

    [ObservableProperty]
    private bool followReparsePoints;

    [ObservableProperty]
    private bool saveHistoryAutomatically;

    [ObservableProperty]
    private bool enableVerboseLogging;

    [ObservableProperty]
    private int maxDegreeOfParallelism;

    [ObservableProperty]
    private int maxHistoryRecords = 200;

    [ObservableProperty]
    private string newExcludedPath = string.Empty;

    [ObservableProperty]
    private string newExcludedExtension = string.Empty;

    [ObservableProperty]
    private string? validationMessage;

    [ObservableProperty]
    private bool hasUnsavedChanges;

    [ObservableProperty]
    private string storageLocationText = string.Empty;

    [ObservableProperty]
    private string? settingsErrorText;

    // --- engine self-test ----------------------------------------------------

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(RunDiagnosticsCommand))]
    private bool isDiagnosticsRunning;

    [ObservableProperty]
    private string diagnosticsText = string.Empty;

    [ObservableProperty]
    private bool diagnosticsFailed;

    // --- live behaviour ------------------------------------------------------

    partial void OnThemeChanged(AppTheme value)
    {
        MarkDirty();
        if (!_loading)
        {
            _appearance.Apply(value, Language);
        }
    }

    partial void OnLanguageChanged(string value)
    {
        MarkDirty();
        if (!_loading)
        {
            _appearance.Apply(Theme, value);
        }
    }

    partial void OnDepthChanged(ScanDepth value) => MarkDirty();

    partial void OnRecycleBinBehaviorChanged(RecycleBinBehavior value) => MarkDirty();

    partial void OnLargeFileThresholdTextChanged(string value) => MarkDirty();

    partial void OnEnableDeveloperAnalysisChanged(bool value) => MarkDirty();

    partial void OnFollowReparsePointsChanged(bool value) => MarkDirty();

    partial void OnSaveHistoryAutomaticallyChanged(bool value) => MarkDirty();

    partial void OnEnableVerboseLoggingChanged(bool value) => MarkDirty();

    partial void OnMaxDegreeOfParallelismChanged(int value) => MarkDirty();

    private void MarkDirty()
    {
        if (!_loading)
        {
            HasUnsavedChanges = true;
        }
    }

    // --- commands ------------------------------------------------------------

    [RelayCommand]
    private void AddExcludedPath()
    {
        var path = NewExcludedPath.Trim();
        if (path.Length == 0)
        {
            return;
        }

        // A relative exclusion would never match anything the scanner sees.
        if (!DiskCleaner.Core.Infrastructure.IO.PathUtils.IsPathRooted(path))
        {
            ValidationMessage = Localizer.Get("S.Settings.NeedAbsolutePath");
            return;
        }

        if (!ExcludedPaths.Contains(path, DiskCleaner.Core.Infrastructure.IO.PathUtils.Comparer))
        {
            ExcludedPaths.Add(path);
            MarkDirty();
        }

        NewExcludedPath = string.Empty;
    }

    [RelayCommand]
    private async Task BrowseExcludedPathAsync()
    {
        var picked = await _dialogs.PickFolderAsync(null);
        if (!string.IsNullOrWhiteSpace(picked))
        {
            NewExcludedPath = picked;
            AddExcludedPath();
        }
    }

    [RelayCommand]
    private void RemoveExcludedPath(string? path)
    {
        if (path is not null && ExcludedPaths.Remove(path))
        {
            MarkDirty();
        }
    }

    [RelayCommand]
    private void AddExcludedExtension()
    {
        var extension = NewExcludedExtension.Trim().TrimStart('.');
        if (extension.Length == 0)
        {
            return;
        }

        if (!ExcludedExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
        {
            ExcludedExtensions.Add(extension);
            MarkDirty();
        }

        NewExcludedExtension = string.Empty;
        MarkDirty();
    }

    [RelayCommand]
    private void RemoveExcludedExtension(string? extension)
    {
        if (extension is not null && ExcludedExtensions.Remove(extension))
        {
            MarkDirty();
        }
    }

    [RelayCommand]
    private async Task SaveAsync()
    {
        if (!BytesFormatter.TryParseHuman(LargeFileThresholdText, out var threshold))
        {
            ValidationMessage = Localizer.Get("S.Settings.InvalidSize");
            _dialogs.ShowWarning(Localizer.Get("S.Settings.InvalidSizeTitle"), ValidationMessage);
            return;
        }

        ValidationMessage = null;

        _settings.Update(s =>
        {
            s.Theme = Theme;
            s.Language = Language;
            s.ScanDepth = Depth;
            s.RecycleBinBehavior = RecycleBinBehavior;
            s.LargeFileThresholdBytes = threshold;
            s.EnableDeveloperAnalysis = EnableDeveloperAnalysis;
            s.FollowReparsePoints = FollowReparsePoints;
            s.SaveHistoryAutomatically = SaveHistoryAutomatically;
            s.EnableVerboseLogging = EnableVerboseLogging;
            s.MaxDegreeOfParallelism = Math.Clamp(MaxDegreeOfParallelism, 0, 64);
            s.MaxHistoryRecords = Math.Clamp(MaxHistoryRecords, 10, 5000);
            s.ExcludedPaths = [.. ExcludedPaths];
            s.ExcludedExtensions = [.. ExcludedExtensions];
        });

        await _settings.SaveAsync();

        SettingsErrorText = _settings.LastError;
        HasUnsavedChanges = false;
        StatusText = _settings.LastError is null
            ? Localizer.Get("S.Settings.Saved")
            : Localizer.Get("S.Settings.NotSaved");
    }

    [RelayCommand]
    private void Revert()
    {
        LoadFrom(_settings.Current);
        HasUnsavedChanges = false;
        ValidationMessage = null;
        StatusText = Localizer.Get("S.Settings.Discarded");
    }

    [RelayCommand]
    private void OpenDataFolder() => _shell.OpenFolder(_paths.RootDirectory);

    [RelayCommand]
    private void OpenLogsFolder() => _shell.OpenFolder(_paths.LogsDirectory);

    private bool CanRunDiagnostics() => !IsDiagnosticsRunning;

    /// <summary>
    /// Runs the real scan pipeline over a small folder.
    /// </summary>
    /// <remarks>
    /// Remote debugging aid: it separates "the engine does not work on this machine"
    /// from "the engine breaks on a large tree", and it prints the exact exception
    /// type and message instead of a generic failure. Read-only, deletes nothing.
    /// </remarks>
    [RelayCommand(CanExecute = nameof(CanRunDiagnostics))]
    private async Task RunDiagnosticsAsync()
    {
        IsDiagnosticsRunning = true;
        DiagnosticsFailed = false;
        DiagnosticsText = Localizer.Get("S.Settings.DiagnosticsRunning");

        try
        {
            _paths.EnsureCreated();

            var result = await _scanService.RunAsync(
                ScanMode.Custom,
                [_paths.RootDirectory],
                progress: null,
                cancellationToken: CancellationToken.None);

            DiagnosticsText = Localizer.Format(
                "S.Settings.DiagnosticsOk",
                _formatter.Count(result.Statistics.FilesScanned),
                _formatter.Count(result.Statistics.DirectoriesScanned),
                _formatter.Duration(result.Duration),
                _formatter.Count(result.Statistics.IssuesCount));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Engine self-test failed on {Root}", _paths.RootDirectory);
            DiagnosticsFailed = true;
            DiagnosticsText = Localizer.Format("S.Settings.DiagnosticsFailed", ex.GetType().Name, OneLine(ex.Message));
        }
        finally
        {
            IsDiagnosticsRunning = false;
        }
    }

    private static string OneLine(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return "—";
        }

        var collapsed = text.Replace("\r", " ").Replace("\n", " ").Trim();
        return collapsed.Length > 240 ? collapsed[..240] + "…" : collapsed;
    }

    public override Task OnNavigatedToAsync()
    {
        SettingsErrorText = _settings.LastError;
        StorageLocationText = _paths.RootDirectory;
        return Task.CompletedTask;
    }

    private void LoadFrom(AppSettings settings)
    {
        _loading = true;
        try
        {
            Theme = settings.Theme;
            Language = settings.Language;
            Depth = settings.ScanDepth;
            RecycleBinBehavior = settings.RecycleBinBehavior;
            LargeFileThresholdText = BytesFormatter.Format(settings.LargeFileThresholdBytes);
            EnableDeveloperAnalysis = settings.EnableDeveloperAnalysis;
            FollowReparsePoints = settings.FollowReparsePoints;
            SaveHistoryAutomatically = settings.SaveHistoryAutomatically;
            EnableVerboseLogging = settings.EnableVerboseLogging;
            MaxDegreeOfParallelism = settings.MaxDegreeOfParallelism;
            MaxHistoryRecords = settings.MaxHistoryRecords;

            ExcludedPaths.Clear();
            foreach (var path in settings.ExcludedPaths)
            {
                ExcludedPaths.Add(path);
            }

            ExcludedExtensions.Clear();
            foreach (var extension in settings.ExcludedExtensions)
            {
                ExcludedExtensions.Add(extension.TrimStart('.'));
            }
        }
        finally
        {
            _loading = false;
        }

        _appearance.Apply(settings.Theme, settings.Language);
    }
}
