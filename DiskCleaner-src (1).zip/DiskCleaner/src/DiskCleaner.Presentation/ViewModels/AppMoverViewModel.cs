using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Moving;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One row of the discovered application list.</summary>
public sealed class MovableAppRowViewModel
{
    public MovableAppRowViewModel(MovableApplication app, IValueFormatter formatter, IStringLocalizer localizer)
    {
        App = app;
        Name = app.Name;
        Path = app.Path;
        Bytes = app.Bytes;
        SizeText = formatter.Bytes(app.Bytes);
        FilesText = localizer.Format("S.Results.FilesCount", formatter.Count(app.FileCount));
        IsAlreadyMoved = app.IsAlreadyMoved;
        LinkTarget = app.LinkTarget ?? string.Empty;
        StateText = app.IsAlreadyMoved
            ? localizer.Format("S.AppMover.State.Moved", app.LinkTarget ?? "—")
            : localizer.Get("S.AppMover.State.OnSystemDrive");
    }

    public MovableApplication App { get; }

    public string Name { get; }

    public string Path { get; }

    public long Bytes { get; }

    public string SizeText { get; }

    public string FilesText { get; }

    public bool IsAlreadyMoved { get; }

    public string LinkTarget { get; }

    public string StateText { get; }

    public override string ToString() => $"{Name} — {SizeText}";
}

/// <summary>One entry of the destination-volume drop-down.</summary>
public sealed class VolumeOptionViewModel(DriveSnapshot drive, string display)
{
    public DriveSnapshot Drive { get; } = drive;

    public string Display { get; } = display;

    public string RootPath => Drive.RootPath;

    public override string ToString() => Display;
}

/// <summary>
/// The application mover: relocate a per-user installed application to another volume
/// and leave a junction behind so it keeps working from its original path.
/// </summary>
/// <remarks>
/// The screen is deliberately conservative. It moves only what the user picked, only
/// after an explicit confirmation that spells out the destination, and it refuses
/// Store apps, protected locations and same-volume moves with a translated reason.
/// While a move runs, the section reports busy (the shell asks before closing) and
/// every phase is visible: copy → verify → replace → link.
/// </remarks>
public sealed partial class AppMoverViewModel : SectionViewModel
{
    private readonly IAppMover _mover;
    private readonly IDriveService _drives;
    private readonly IDialogService _dialogs;
    private readonly IShellService _shell;
    private readonly IValueFormatter _formatter;

    private IReadOnlyList<MovableApplication> _discovered = [];
    private CancellationTokenSource? _discoveryCancellation;
    private bool _destinationEdited;

    public AppMoverViewModel(
        IAppMover mover,
        IDriveService drives,
        IDialogService dialogs,
        IShellService shell,
        IValueFormatter formatter,
        IStringLocalizer localizer)
        : base(Section.AppMover, "S.Nav.AppMover", "\uE8DE", localizer)
    {
        _mover = mover;
        _drives = drives;
        _dialogs = dialogs;
        _shell = shell;
        _formatter = formatter;

        RootDirectory = _mover.DefaultRoot ?? string.Empty;
        RootText = string.IsNullOrEmpty(RootDirectory)
            ? Localizer.Get("S.AppMover.RootUnavailable")
            : RootDirectory;

        ReloadVolumes();
        StatusText = Localizer.Get("S.AppMover.Status.Idle");
    }

    public ObservableCollection<MovableAppRowViewModel> Apps { get; } = [];

    public ObservableCollection<VolumeOptionViewModel> VolumeOptions { get; } = [];

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(MoveCommand))]
    [NotifyCanExecuteChangedFor(nameof(MoveBackCommand))]
    private MovableAppRowViewModel? selectedApp;

    [ObservableProperty]
    private string rootDirectory;

    [ObservableProperty]
    private string rootText = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(MoveCommand))]
    private VolumeOptionViewModel? selectedVolume;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(MoveCommand))]
    private string destinationDirectory = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(MoveCommand))]
    [NotifyCanExecuteChangedFor(nameof(MoveBackCommand))]
    private bool isWorking;

    [ObservableProperty]
    private bool isDiscovering;

    [ObservableProperty]
    private string discoveryText = string.Empty;

    [ObservableProperty]
    private bool hasApps;

    [ObservableProperty]
    private string emptyText = string.Empty;

    [ObservableProperty]
    private bool isMoving;

    [ObservableProperty]
    private string phaseText = string.Empty;

    [ObservableProperty]
    private double progressValue;

    [ObservableProperty]
    private string progressDetailText = string.Empty;

    [ObservableProperty]
    private string? currentPathText;

    [ObservableProperty]
    private bool hasResult;

    [ObservableProperty]
    private string resultText = string.Empty;

    [ObservableProperty]
    private bool resultIsError;

    [ObservableProperty]
    private bool resultIsWarning;

    [ObservableProperty]
    private string? lastMovedSource;

    [ObservableProperty]
    private string? lastMovedDestination;

    public override bool IsBusy => IsWorking;

    // ------------------------------------------------------------------ commands

    [RelayCommand]
    private async Task RefreshAsync()
    {
        if (IsWorking)
        {
            return;
        }

        // Volumes come and go (USB, network): refresh them together with the list.
        ReloadVolumes();
        await DiscoverAsync(RootDirectory).ConfigureAwait(true);
    }

    [RelayCommand]
    private async Task PickRootAsync()
    {
        if (IsWorking)
        {
            return;
        }

        var picked = await _dialogs.PickFolderAsync(RootDirectory).ConfigureAwait(true);
        if (!string.IsNullOrWhiteSpace(picked))
        {
            RootDirectory = PathUtils.Normalize(picked);
            RootText = RootDirectory;
            await DiscoverAsync(RootDirectory).ConfigureAwait(true);
        }
    }

    [RelayCommand]
    private async Task PickDestinationAsync()
    {
        if (IsWorking)
        {
            return;
        }

        var initial = SelectedVolume?.RootPath;
        var picked = await _dialogs.PickFolderAsync(initial).ConfigureAwait(true);
        if (!string.IsNullOrWhiteSpace(picked))
        {
            _destinationEdited = true;
            DestinationDirectory = PathUtils.Normalize(picked);
        }
    }

    partial void OnDestinationDirectoryChanged(string value)
    {
        // A manual edit wins over the volume-derived default from now on.
        if (!_destinationEdited && VolumeOptions.Count > 0)
        {
            var derived = DeriveDestination(SelectedVolume);
            if (!string.Equals(value, derived, StringComparison.Ordinal))
            {
                _destinationEdited = true;
            }
        }
    }

    partial void OnSelectedVolumeChanged(VolumeOptionViewModel? value)
    {
        if (!_destinationEdited)
        {
            DestinationDirectory = DeriveDestination(value);
        }
    }

    partial void OnSelectedAppChanged(MovableAppRowViewModel? value)
    {
        // The result of the last operation intentionally survives a selection change:
        // the post-move refresh rebuilds the rows and re-selects the same path, and a
        // user browsing the list must still see what just happened. A new operation
        // clears it when it starts.
        StatusText = value is null
            ? Localizer.Get("S.AppMover.Status.Idle")
            : Localizer.Format("S.AppMover.Status.Selected", value.Name, value.SizeText);
    }

    [RelayCommand(CanExecute = nameof(CanMove))]
    private async Task MoveAsync()
    {
        var app = SelectedApp;
        if (app is null || IsWorking)
        {
            return;
        }

        var destination = DestinationDirectory.Trim();
        if (destination.Length == 0)
        {
            ShowResult(Localizer.Get("S.AppMover.Error.NoDestination"), isError: true, isWarning: false);
            return;
        }

        // Pre-flight validation off the UI thread: measuring the folder takes a moment.
        IsWorking = true;
        AppMoveValidation validation;
        try
        {
            validation = await Task.Run(() => _mover.ValidateMoveAsync(app.Path, destination)).ConfigureAwait(true);
        }
        finally
        {
            IsWorking = false;
        }

        if (!validation.IsValid)
        {
            ShowResult(TranslateValidation(validation), isError: true, isWarning: false);
            return;
        }

        var confirmed = await _dialogs.ConfirmAsync(
            Localizer.Get("S.AppMover.Confirm.Title"),
            string.Join(
                Environment.NewLine,
                Localizer.Format("S.AppMover.Confirm.Summary", app.Name, app.SizeText, validation.DestinationPath ?? destination),
                string.Empty,
                Localizer.Get("S.AppMover.Confirm.Warning"),
                string.Empty,
                Localizer.Get("S.AppMover.Confirm.Question")),
            Localizer.Get("S.AppMover.Confirm.Accept"),
            Localizer.Get("S.AppMover.Confirm.Decline")).ConfigureAwait(true);

        if (!confirmed)
        {
            return;
        }

        IsWorking = true;
        IsMoving = true;
        HasResult = false;
        ProgressValue = 0;
        PhaseText = Localizer.Get("S.AppMover.Phase.Preparing");
        StatusText = Localizer.Format("S.AppMover.Status.Moving", app.Name);

        var progress = new Progress<AppMoveProgress>(ReportProgress);

        try
        {
            var record = await Task.Run(
                () => _mover.MoveAsync(app.Path, destination, progress, CancellationToken.None),
                CancellationToken.None).ConfigureAwait(true);

            RenderRecord(record);
        }
        catch (Exception ex)
        {
            ShowResult(Localizer.Format("S.AppMover.Error.Unexpected", ex.GetType().Name), isError: true, isWarning: false);
        }
        finally
        {
            IsMoving = false;
            IsWorking = false;
            CurrentPathText = null;
            StatusText = Localizer.Get("S.AppMover.Status.Idle");
        }

        // The list must show the truth: the app is now a junction (or untouched).
        await DiscoverAsync(RootDirectory).ConfigureAwait(true);
    }

    [RelayCommand(CanExecute = nameof(CanMoveBack))]
    private async Task MoveBackAsync()
    {
        var app = SelectedApp;
        if (app is null || !app.IsAlreadyMoved || IsWorking)
        {
            return;
        }

        var confirmed = await _dialogs.ConfirmAsync(
            Localizer.Get("S.AppMover.Back.Confirm.Title"),
            string.Join(
                Environment.NewLine,
                Localizer.Format("S.AppMover.Back.Confirm.Summary", app.Name, app.LinkTarget, app.Path),
                string.Empty,
                Localizer.Get("S.AppMover.Confirm.Warning"),
                string.Empty,
                Localizer.Get("S.AppMover.Confirm.Question")),
            Localizer.Get("S.AppMover.Confirm.Accept"),
            Localizer.Get("S.AppMover.Confirm.Decline")).ConfigureAwait(true);

        if (!confirmed)
        {
            return;
        }

        IsWorking = true;
        IsMoving = true;
        HasResult = false;
        ProgressValue = 0;
        PhaseText = Localizer.Get("S.AppMover.Phase.Preparing");
        StatusText = Localizer.Format("S.AppMover.Status.MovingBack", app.Name);

        var progress = new Progress<AppMoveProgress>(ReportProgress);

        try
        {
            var record = await Task.Run(
                () => _mover.MoveBackAsync(app.Path, progress, CancellationToken.None),
                CancellationToken.None).ConfigureAwait(true);

            RenderRecord(record);
        }
        catch (Exception ex)
        {
            ShowResult(Localizer.Format("S.AppMover.Error.Unexpected", ex.GetType().Name), isError: true, isWarning: false);
        }
        finally
        {
            IsMoving = false;
            IsWorking = false;
            CurrentPathText = null;
            StatusText = Localizer.Get("S.AppMover.Status.Idle");
        }

        await DiscoverAsync(RootDirectory).ConfigureAwait(true);
    }

    [RelayCommand]
    private void OpenSelectedFolder()
    {
        if (SelectedApp is { } app)
        {
            _shell.OpenFolder(app.Path);
        }
    }

    [RelayCommand]
    private void OpenMovedTarget()
    {
        if (LastMovedDestination is { Length: > 0 } destination)
        {
            _shell.OpenFolder(destination);
        }
    }

    private bool CanMove() => SelectedApp is { IsAlreadyMoved: false } && !IsWorking && DestinationDirectory.Trim().Length > 0;

    private bool CanMoveBack() => SelectedApp is { IsAlreadyMoved: true } && !IsWorking;

    // ------------------------------------------------------------------ discovery

    private async Task DiscoverAsync(string root)
    {
        var previous = _discoveryCancellation;
        _discoveryCancellation = new CancellationTokenSource();
        var token = _discoveryCancellation.Token;
        previous?.Cancel();
        previous?.Dispose();

        IsWorking = true;
        IsDiscovering = true;
        DiscoveryText = Localizer.Get("S.AppMover.Discovering");

        try
        {
            _discovered = await Task.Run(() => _mover.DiscoverAsync(root, token), CancellationToken.None).ConfigureAwait(true);
            RebuildApps(keepSelection: true);
        }
        catch (OperationCanceledException)
        {
            // A newer discovery superseded this one; its result will replace the list.
        }
        catch (Exception ex)
        {
            _discovered = [];
            RebuildApps(keepSelection: false);
            ShowResult(Localizer.Format("S.AppMover.Error.Discovery", ex.GetType().Name), isError: true, isWarning: false);
        }
        finally
        {
            IsDiscovering = false;
            IsWorking = false;
            DiscoveryText = string.Empty;
        }
    }

    private void RebuildApps(bool keepSelection)
    {
        var selectedPath = keepSelection ? SelectedApp?.Path : null;

        Apps.Clear();
        foreach (var app in _discovered)
        {
            Apps.Add(new MovableAppRowViewModel(app, _formatter, Localizer));
        }

        HasApps = Apps.Count > 0;
        EmptyText = Localizer.Get(string.IsNullOrEmpty(RootDirectory)
            ? "S.AppMover.Empty.NoRoot"
            : "S.AppMover.Empty.NoApps");

        SelectedApp = selectedPath is not null
            ? Apps.FirstOrDefault(a => string.Equals(a.Path, selectedPath, PathUtils.Comparison))
            : null;
    }

    private void ReloadVolumes()
    {
        var previousRoot = SelectedVolume?.RootPath;

        VolumeOptions.Clear();
        foreach (var drive in _drives.GetScannableDrives())
        {
            VolumeOptions.Add(new VolumeOptionViewModel(
                drive,
                Localizer.Format(
                    "S.AppMover.VolumeOption",
                    drive.RootPath.TrimEnd('\\'),
                    _formatter.Bytes(drive.FreeBytes))));
        }

        // Prefer a volume other than the system one; remember the previous choice across refreshes.
        SelectedVolume =
            VolumeOptions.FirstOrDefault(v => string.Equals(v.RootPath, previousRoot, PathUtils.Comparison)) ??
            VolumeOptions.FirstOrDefault(v => !IsSystemVolume(v.RootPath)) ??
            VolumeOptions.FirstOrDefault();

        if (!_destinationEdited)
        {
            DestinationDirectory = DeriveDestination(SelectedVolume);
        }
    }

    private bool IsSystemVolume(string rootPath)
    {
        var defaultRoot = _mover.DefaultRoot;
        var sourceRoot = defaultRoot is null ? null : PathUtils.GetDriveRoot(defaultRoot);
        return sourceRoot is not null && string.Equals(rootPath, sourceRoot, PathUtils.Comparison);
    }

    /// <summary>Folder created on the target volume by default. Deliberately ASCII: it becomes a real path.</summary>
    internal const string DefaultFolderName = "MovedApps";

    private string DeriveDestination(VolumeOptionViewModel? volume) =>
        volume is null ? string.Empty : PathUtils.Combine(volume.RootPath, DefaultFolderName);

    // ------------------------------------------------------------------ progress & result

    private void ReportProgress(AppMoveProgress progress)
    {
        PhaseText = Localizer.Get($"S.AppMover.Phase.{progress.Phase}");
        ProgressValue = progress.Fraction ?? 0d;
        CurrentPathText = progress.CurrentPath is { Length: > 0 } path
            ? PathUtils.ShortenForDisplay(path, 96)
            : null;
        ProgressDetailText = Localizer.Format(
            "S.AppMover.Progress.Detail",
            _formatter.Bytes(progress.BytesCopied),
            _formatter.Bytes(progress.TotalBytes),
            _formatter.Count(progress.FilesCopied),
            _formatter.Count(progress.TotalFiles));
    }

    private void RenderRecord(AppMoveRecord record)
    {
        LastMovedSource = record.SourcePath;
        LastMovedDestination = record.Succeeded ? record.DestinationPath : null;

        if (record.Succeeded)
        {
            var warning = record.FailureReasonKey is { Length: > 0 }
                ? Environment.NewLine + TranslateReason(record.FailureReasonKey, record.FailureDetails)
                : null;

            ShowResult(
                Localizer.Format(
                    "S.AppMover.Result.Success",
                    _formatter.Bytes(record.Bytes),
                    _formatter.Count(record.Files),
                    _formatter.Duration(record.Duration),
                    record.DestinationPath) + (warning ?? string.Empty),
                isError: false,
                isWarning: warning is not null);
            return;
        }

        var text = TranslateReason(record.FailureReasonKey ?? "move.unknown", record.FailureDetails);

        if (record.DataAtDestinationOnly)
        {
            text += Environment.NewLine + Localizer.Format("S.AppMover.Result.DataAtDestination", record.DestinationPath);
        }
        else if (record.RolledBack)
        {
            text += Environment.NewLine + Localizer.Get("S.AppMover.Result.RolledBack");
        }

        ShowResult(text, isError: true, isWarning: false);
    }

    private string TranslateValidation(AppMoveValidation validation)
    {
        var text = TranslateReason(validation.ReasonKey ?? "move.unknown", validation.Details);

        if (validation.ReasonKey == "move.not-enough-space")
        {
            text += Environment.NewLine + Localizer.Format(
                "S.AppMover.Space.Detail",
                _formatter.Bytes(validation.RequiredBytes),
                validation.AvailableBytes is { } available ? _formatter.Bytes(available) : "—");
        }

        return text;
    }

    private string TranslateReason(string reasonKey, string? details)
    {
        var key = "S.AppMover.Reason." + reasonKey;
        var translated = Localizer.Get(key);
        if (string.Equals(translated, key, StringComparison.Ordinal))
        {
            // Unknown key: show the stable key rather than nothing, and never crash.
            translated = reasonKey;
        }

        return string.IsNullOrWhiteSpace(details) ? translated : $"{translated} ({details})";
    }

    private void ShowResult(string text, bool isError, bool isWarning)
    {
        ResultText = text;
        ResultIsError = isError;
        ResultIsWarning = isWarning && !isError;
        HasResult = true;
    }

    // ------------------------------------------------------------------ lifecycle

    public override Task OnNavigatedToAsync()
    {
        if (Apps.Count == 0 && !IsWorking)
        {
            return DiscoverAsync(RootDirectory);
        }

        return Task.CompletedTask;
    }

    protected override void OnLanguageChangedCore()
    {
        RebuildApps(keepSelection: true);
        ReloadVolumes();
        StatusText = Localizer.Get("S.AppMover.Status.Idle");
        HasResult = false;
    }
}
