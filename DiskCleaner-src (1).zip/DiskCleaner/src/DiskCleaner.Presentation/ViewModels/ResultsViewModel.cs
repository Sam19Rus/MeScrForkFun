using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One node of the expandable AppData directory tree.</summary>
public sealed class AppDataNodeViewModel
{
    public AppDataNodeViewModel(
        AppDataDirectoryNode node,
        IValueFormatter formatter,
        IStringLocalizer localizer,
        ICleanupLedger? ledger = null)
    {
        Path = node.Path;
        Name = node.Name;
        SizeText = formatter.Bytes(node.SubtreeBytes);
        Bytes = node.SubtreeBytes;
        OwnSizeText = formatter.Bytes(node.OwnBytes);
        FilesText = localizer.Format("S.Results.FilesCount", formatter.Count(node.FileCount));

        // Deleted subtrees disappear recursively, not just at the top level.
        Children = [.. node.Children
            .Where(c => ledger is null || !ledger.IsDeleted(c.Path))
            .OrderByDescending(c => c.SubtreeBytes)
            .Select(c => new AppDataNodeViewModel(c, formatter, localizer, ledger))];
    }

    public string Path { get; }

    public string Name { get; }

    public string SizeText { get; }

    public long Bytes { get; }

    public string OwnSizeText { get; }

    public string FilesText { get; }

    public IReadOnlyList<AppDataNodeViewModel> Children { get; }

    public bool HasChildren => Children.Count > 0;
}

/// <summary>One classified content group of an application (its cache, its logs, its data…).</summary>
public sealed class AppDataContentViewModel
{
    public AppDataContentViewModel(AppDataContentGroup group, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Path = group.Path;
        Name = group.Name;
        Kind = group.Kind;
        KindText = localizer.Get(KindKey(group.Kind));
        SizeText = formatter.Bytes(group.Bytes);
        Bytes = group.Bytes;
        Confidence = group.Confidence;
        ConfidenceText = localizer.Get(group.Confidence switch
        {
            CleanupConfidence.Safe => "S.Results.Confidence.Safe",
            CleanupConfidence.Likely => "S.Results.Confidence.Likely",
            _ => "S.Results.Confidence.NeedsReview",
        });
        IsReclaimable = group.IsReclaimable;

        // The analyzer's English text is the fallback; the reason key carries the translation.
        Explanation = ReasonResolver.Resolve(localizer, group.ReasonKey, group.Explanation);
        RiskText = localizer.Get(group.Risk switch
        {
            RiskLevel.None or RiskLevel.Low => "S.Results.Risk.Low",
            RiskLevel.Medium => "S.Results.Risk.Medium",
            RiskLevel.High => "S.Results.Risk.High",
            _ => "S.Results.Risk.Critical",
        });
    }

    public string Path { get; }

    public string Name { get; }

    public AppDataContentKind Kind { get; }

    public string KindText { get; }

    public string SizeText { get; }

    public long Bytes { get; }

    public CleanupConfidence Confidence { get; }

    public string ConfidenceText { get; }

    public bool IsReclaimable { get; }

    public string Explanation { get; }

    public string RiskText { get; }

    public static string KindKey(AppDataContentKind kind) => kind switch
    {
        AppDataContentKind.Cache => "S.Results.Kind.Cache",
        AppDataContentKind.Logs => "S.Results.Kind.Logs",
        AppDataContentKind.Temp => "S.Results.Kind.Temp",
        AppDataContentKind.Packages => "S.Results.Kind.Packages",
        AppDataContentKind.DeveloperCache => "S.Results.Kind.DeveloperCache",
        AppDataContentKind.CrashDumps => "S.Results.Kind.CrashDumps",
        AppDataContentKind.Data => "S.Results.Kind.Data",
        _ => "S.Results.Kind.Unknown",
    };
}

/// <summary>One row of the application list, plus its detail panel content.</summary>
public sealed partial class AppDataApplicationViewModel : ObservableObject
{
    [ObservableProperty]
    private bool isSelected;

    public AppDataApplicationViewModel(
        AppDataApplication application,
        IValueFormatter formatter,
        IStringLocalizer localizer,
        ICleanupLedger? ledger = null)
    {
        Model = application;
        Path = application.Path;
        DisplayName = application.DisplayName;
        Vendor = application.Vendor ?? string.Empty;
        IsKnown = application.IsKnown;
        Bytes = application.Bytes;
        SizeText = formatter.Bytes(application.Bytes);
        ReclaimableText = formatter.Bytes(application.ReclaimableBytes);
        HasReclaimable = application.ReclaimableBytes > 0;
        RootText = localizer.Get(application.Root switch
        {
            AppDataRoot.Local => "S.Results.Root.Local",
            AppDataRoot.Roaming => "S.Results.Root.Roaming",
            _ => "S.Results.Root.LocalLow",
        });
        ProfileText = application.Profile;
        FilesText = localizer.Format("S.Results.FilesCount", formatter.Count(application.FileCount));

        // Known apps: per-app key, then family default, then the catalog's English text.
        // Unknown apps: the honest localised "not in the catalog" line.
        Explanation = application.IsKnown
            ? ReasonResolver.ResolveAppExplanation(localizer, application.ExplanationKey, application.Family, application.Explanation)
            : localizer.Get("S.Results.UnknownFolder");

        // Content groups and tree nodes that a cleanup run already removed disappear
        // from the stale report; sizes stay as measured at scan time (the note says so).
        var contents = application.Contents.Where(c => ledger is null || !ledger.IsDeleted(c.Path));
        Contents = [.. contents.Select(c => new AppDataContentViewModel(c, formatter, localizer))];

        var tree = application.LargestDirectories.Where(n => ledger is null || !ledger.IsDeleted(n.Path));
        Tree = [.. tree.Select(n => new AppDataNodeViewModel(n, formatter, localizer, ledger))];
    }

    public AppDataApplication Model { get; }

    public string Path { get; }

    public string DisplayName { get; }

    public string Vendor { get; }

    public bool IsKnown { get; }

    public long Bytes { get; }

    public string SizeText { get; }

    public string ReclaimableText { get; }

    public bool HasReclaimable { get; }

    public string RootText { get; }

    public string ProfileText { get; }

    public string FilesText { get; }

    public string Explanation { get; }

    public IReadOnlyList<AppDataContentViewModel> Contents { get; }

    public IReadOnlyList<AppDataNodeViewModel> Tree { get; }

    public bool HasContents => Contents.Count > 0;

    public bool HasTree => Tree.Count > 0;

    public override string ToString() => $"{DisplayName} — {SizeText}";
}

/// <summary>One AppData root row (Local / Roaming / LocalLow).</summary>
public sealed class AppDataRootViewModel
{
    public AppDataRootViewModel(AppDataRootSummary summary, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Path = summary.Path;
        Profile = summary.Profile;
        RootText = localizer.Get(summary.Root switch
        {
            AppDataRoot.Local => "S.Results.Root.Local",
            AppDataRoot.Roaming => "S.Results.Root.Roaming",
            _ => "S.Results.Root.LocalLow",
        });
        SizeText = summary.Exists ? formatter.Bytes(summary.Bytes) : "—";
        Exists = summary.Exists;
        ApplicationCountText = summary.Exists
            ? localizer.Format("S.Results.AppCount", formatter.Count(summary.ApplicationCount))
            : "—";
        Bytes = summary.Bytes;
        IsIncomplete = summary.Exists && !summary.IsComplete;
    }

    public string Path { get; }

    public string Profile { get; }

    public string RootText { get; }

    public string SizeText { get; }

    public string ApplicationCountText { get; }

    public bool Exists { get; }

    public long Bytes { get; }

    public bool IsIncomplete { get; }
}

/// <summary>One row of the cleanup plan review list.</summary>
public sealed record PlanRowViewModel(
    string ShortPath,
    string FullPath,
    string SizeText,
    string FileCountText,
    string CategoryText,
    bool RequiresElevation);

/// <summary>One row of the content-kind summary.</summary>
public sealed class ContentKindViewModel
{
    public ContentKindViewModel(AppDataContentTotals totals, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Kind = totals.Kind;
        KindText = localizer.Get(AppDataContentViewModel.KindKey(totals.Kind));
        SizeText = formatter.Bytes(totals.Bytes);
        Bytes = totals.Bytes;
        GroupCountText = formatter.Count(totals.GroupCount);
        ReclaimableText = totals.ReclaimableBytes > 0 ? formatter.Bytes(totals.ReclaimableBytes) : "—";
        HasReclaimable = totals.ReclaimableBytes > 0;
    }

    public AppDataContentKind Kind { get; }

    public string KindText { get; }

    public string SizeText { get; }

    public long Bytes { get; }

    public string GroupCountText { get; }

    public string ReclaimableText { get; }

    public bool HasReclaimable { get; }
}

/// <summary>
/// Results screen. Phase 5 delivers the AppData breakdown; the category-tier report for
/// every analyzer arrives in phase 6, and the screen says so instead of implying otherwise.
/// </summary>
public sealed partial class ResultsViewModel : SectionViewModel
{
    private readonly IScanService _scanService;
    private readonly IValueFormatter _formatter;
    private readonly IUiDispatcher _dispatcher;
    private readonly IShellService _shell;
    private readonly INavigationService _navigation;
    private readonly ICleanupPlanner _planner;
    private readonly IReportExclusions _exclusions;
    private readonly ICleanupLedger _ledger;

    private ScanResult? _result;
    private List<AppDataApplicationViewModel> _all = [];
    private List<ScanItemViewModel> _allItems = [];

    public ResultsViewModel(
        IScanService scanService,
        IValueFormatter formatter,
        IUiDispatcher dispatcher,
        IShellService shell,
        INavigationService navigation,
        ICleanupPlanner planner,
        IReportExclusions exclusions,
        ICleanupLedger ledger,
        IStringLocalizer localizer)
        : base(Section.Results, "S.Nav.Results", "\uE9D5", localizer)
    {
        _scanService = scanService;
        _formatter = formatter;
        _dispatcher = dispatcher;
        _shell = shell;
        _navigation = navigation;
        _planner = planner;
        _exclusions = exclusions;
        _ledger = ledger;

        // Both are raised from background threads as well as from the UI; always marshal.
        _planner.PlanChanged += OnPlanChanged;
        _exclusions.Changed += OnExclusionsChanged;

        // Raised from a background thread — marshalling is mandatory (see ScanCompleted).
        _scanService.ScanCompleted += OnScanCompleted;

        // After a cleanup run the stale report must not show deleted rows any more.
        _ledger.Changed += OnLedgerChanged;

        if (_scanService.LastResult is { } existing)
        {
            Apply(existing);
        }
        else
        {
            SummaryText = Localizer.Get("S.Results.NoScan");
        }
    }

    public ObservableCollection<AppDataApplicationViewModel> Applications { get; } = [];

    /// <summary>Candidates by confidence tier. Only the Safe tier is offered in bulk.</summary>
    public ObservableCollection<ScanItemViewModel> SafeItems { get; } = [];

    public ObservableCollection<ScanItemViewModel> LikelyItems { get; } = [];

    public ObservableCollection<ScanItemViewModel> ReviewItems { get; } = [];

    public ObservableCollection<ScanItemViewModel> ExcludedItems { get; } = [];

    /// <summary>What is currently in the plan, for review before execution (Phase 8).</summary>
    public ObservableCollection<PlanRowViewModel> PlanRows { get; } = [];

    public ObservableCollection<AppDataRootViewModel> Roots { get; } = [];

    public ObservableCollection<ContentKindViewModel> ContentKinds { get; } = [];

    [ObservableProperty]
    private AppDataApplicationViewModel? selectedApplication;

    [ObservableProperty]
    private string filterText = string.Empty;

    [ObservableProperty]
    private bool hasReport;

    [ObservableProperty]
    private string summaryText = string.Empty;

    [ObservableProperty]
    private string totalText = "—";

    [ObservableProperty]
    private string knownText = "—";

    [ObservableProperty]
    private string unknownText = "—";

    [ObservableProperty]
    private string reclaimableText = "—";

    [ObservableProperty]
    private string safeReclaimableText = "—";

    [ObservableProperty]
    private bool isIncomplete;

    [ObservableProperty]
    private string scanSummaryText = string.Empty;

    [ObservableProperty]
    private bool hasCandidates;

    [ObservableProperty]
    private string candidateSummaryText = string.Empty;

    [ObservableProperty]
    private string planSummaryText = string.Empty;

    [ObservableProperty]
    private bool hasPlan;

    [ObservableProperty]
    private bool showExcluded;

    [ObservableProperty]
    private string excludedCountText = string.Empty;

    [ObservableProperty]
    private string? rejectionText;

    [ObservableProperty]
    private bool hasDeletedNote;

    [ObservableProperty]
    private string deletedNoteText = string.Empty;

    public override Task OnNavigatedToAsync()
    {
        if (_result is null && _scanService.LastResult is { } result)
        {
            Apply(result);
        }

        return Task.CompletedTask;
    }

    partial void OnFilterTextChanged(string value) => ApplyFilter();

    partial void OnSelectedApplicationChanged(AppDataApplicationViewModel? value)
    {
        if (value is not null)
        {
            value.IsSelected = true;
        }
    }

    protected override void OnLanguageChangedCore()
    {
        if (_result is { } result)
        {
            Apply(result);
        }
    }

    [RelayCommand]
    private void Refresh()
    {
        if (_scanService.LastResult is { } result)
        {
            Apply(result);
        }
    }

    [RelayCommand]
    private void GoToScan() => _navigation.Navigate(Section.Scan);

    /// <summary>
    /// Bulk-adds the Safe tier only. "Likely" and "Requires review" items must be picked
    /// one by one: that separation is the whole point of the confidence model.
    /// </summary>
    [RelayCommand]
    private void AddAllSafeToPlan()
    {
        var added = 0;
        var refused = 0;
        string? lastRejection = null;
        foreach (var item in SafeItems.Where(i => !i.IsInPlan && i.IsDeletable))
        {
            if (_planner.TryAdd(item.Item, out var rejection))
            {
                added++;
            }
            else
            {
                refused++;
                lastRejection = rejection;
            }
        }

        if (refused > 0)
        {
            RejectionText = Localizer.Format(
                "S.Results.Rejected",
                ReasonResolver.Resolve(Localizer, lastRejection, lastRejection));
        }
        else if (added > 0)
        {
            RejectionText = null;
        }

        // Refresh synchronously: the button must feel instant rather than waiting for
        // the dispatcher round-trip that PlanChanged also schedules.
        RefreshPlanSummary();
    }

    [RelayCommand]
    private void ClearPlan()
    {
        _planner.Clear();
        RefreshPlanSummary();
    }

    [RelayCommand]
    private void RestoreAllExcluded()
    {
        _exclusions.Clear();
        ShowExcluded = false;

        if (_result is { } result)
        {
            RebuildItems(result);
        }
    }

    [RelayCommand]
    private void DismissRejection() => RejectionText = null;

    [RelayCommand]
    private void OpenSelectedFolder()
    {
        if (SelectedApplication is { } selected)
        {
            _shell.OpenFolder(selected.Path);
        }
    }

    [RelayCommand]
    private void OpenNodeFolder(AppDataNodeViewModel? node)
    {
        if (node is not null)
        {
            _shell.OpenFolder(node.Path);
        }
    }

    private void OnScanCompleted(object? sender, ScanResult result) =>
        _dispatcher.Post(() => Apply(result));

    private void OnLedgerChanged(object? sender, EventArgs e) =>
        _dispatcher.Post(() =>
        {
            // Re-apply the current result: the ledger changes what is still "there".
            // A fresh scan resets the ledger itself, so this cannot hide new data.
            if (_result is { } result)
            {
                Apply(result);
            }

            UpdateDeletedNote();
        });

    private void UpdateDeletedNote()
    {
        HasDeletedNote = _ledger.DeletedCount > 0;
        if (!HasDeletedNote)
        {
            DeletedNoteText = string.Empty;
            return;
        }

        DeletedNoteText = Localizer.Format(
            _ledger.AnyRecycled ? "S.Results.DeletedNote.Recycled" : "S.Results.DeletedNote",
            _formatter.Count(_ledger.DeletedCount),
            _formatter.Bytes(_ledger.DeletedBytes));
    }

    private void OnPlanChanged(object? sender, EventArgs e) =>
        _dispatcher.Post(RefreshPlanSummary);

    private void OnExclusionsChanged(object? sender, EventArgs e) =>
        _dispatcher.Post(() =>
        {
            if (_result is { } result)
            {
                RebuildItems(result);
            }
        });

    private void RefreshPlanSummary()
    {
        foreach (var item in _allItems)
        {
            item.IsInPlan = _planner.Contains(item.Path);
        }

        HasPlan = _planner.Count > 0;

        PlanRows.Clear();
        foreach (var operation in _planner.Current.Operations.OrderByDescending(o => o.ExpectedBytes))
        {
            PlanRows.Add(new PlanRowViewModel(
                PathUtils.ShortenForDisplay(operation.TargetPath, 60),
                operation.TargetPath,
                _formatter.Bytes(operation.ExpectedBytes),
                _formatter.Count(operation.ExpectedFileCount),
                Localizer.Get(ScanItemViewModel.CategoryKey(operation.Category)),
                operation.RequiresElevation));
        }

        PlanSummaryText = _planner.Count == 0
            ? Localizer.Get("S.Results.PlanEmpty")
            : Localizer.Format(
                "S.Results.PlanSummary",
                _formatter.Count(_planner.Count),
                _formatter.Count(_planner.TotalFileCount),
                _formatter.Bytes(_planner.TotalBytes));
    }

    private void Apply(ScanResult result)
    {
        _result = result;

        ScanSummaryText = result.WasCancelled
            ? Localizer.Format("S.Overview.ScanCancelled", _formatter.Duration(result.Duration), _formatter.Count(result.Statistics.FilesScanned))
            : Localizer.Format("S.Overview.ScanFinished",
                Localizer.Get($"S.ScanMode.{result.Mode}"),
                _formatter.Duration(result.Duration),
                _formatter.Count(result.Statistics.FilesScanned),
                _formatter.Count(result.Statistics.DirectoriesScanned));

        var report = result.AppData;
        HasReport = report is not null && report.Applications.Count > 0;

        if (report is null)
        {
            SummaryText = Localizer.Get("S.Results.NoScan");
            Applications.Clear();
            Roots.Clear();
            ContentKinds.Clear();
            _all = [];
            return;
        }

        TotalText = _formatter.Bytes(report.TotalBytes);
        KnownText = _formatter.Bytes(report.KnownBytes);
        UnknownText = _formatter.Bytes(report.UnknownBytes);
        ReclaimableText = _formatter.Bytes(report.ReclaimableBytes);
        SafeReclaimableText = _formatter.Bytes(report.SafeReclaimableBytes);
        IsIncomplete = !report.IsComplete;

        SummaryText = Localizer.Format(
            "S.Results.Summary",
            _formatter.Bytes(report.TotalBytes),
            _formatter.Count(report.Applications.Count),
            _formatter.Count(report.TotalFiles));

        Roots.Clear();
        foreach (var root in report.Roots.Where(r => r.Exists))
        {
            Roots.Add(new AppDataRootViewModel(root, _formatter, Localizer));
        }

        ContentKinds.Clear();
        foreach (var totals in report.ByContentKind)
        {
            ContentKinds.Add(new ContentKindViewModel(totals, _formatter, Localizer));
        }

        _all = [.. report.Applications
            .Where(a => !_ledger.IsDeleted(a.Path))
            .Select(a => new AppDataApplicationViewModel(a, _formatter, Localizer, _ledger))];
        ApplyFilter();

        RebuildItems(result);
        UpdateDeletedNote();
        StatusText = SummaryText;
    }

    /// <summary>
    /// Projects the flat candidate list into confidence tiers, hiding excluded rows.
    /// </summary>
    private void RebuildItems(ScanResult result)
    {
        _allItems = [.. result.Items
            .Where(i => !_ledger.IsDeleted(i.Path))
            .Select(i => new ScanItemViewModel(i, _planner, _exclusions, Localizer, _formatter, _shell))];

        SafeItems.Clear();
        LikelyItems.Clear();
        ReviewItems.Clear();
        ExcludedItems.Clear();

        foreach (var item in _allItems.OrderByDescending(i => i.Bytes))
        {
            if (item.IsExcluded)
            {
                ExcludedItems.Add(item);
                continue;
            }

            switch (item.Confidence)
            {
                case CleanupConfidence.Safe:
                    SafeItems.Add(item);
                    break;
                case CleanupConfidence.Likely:
                    LikelyItems.Add(item);
                    break;
                default:
                    ReviewItems.Add(item);
                    break;
            }
        }

        var visible = SafeItems.Count + LikelyItems.Count + ReviewItems.Count;
        HasCandidates = visible > 0;
        CandidateSummaryText = visible == 0
            ? Localizer.Get("S.Results.NoCandidates")
            : Localizer.Format(
                "S.Results.CandidateSummary",
                _formatter.Count(visible),
                _formatter.Bytes(SafeItems.Sum(i => i.Bytes) + LikelyItems.Sum(i => i.Bytes) + ReviewItems.Sum(i => i.Bytes)));

        ExcludedCountText = Localizer.Format("S.Results.ExcludedCount", _formatter.Count(ExcludedItems.Count));
        ShowExcluded = ExcludedItems.Count > 0 && ShowExcluded;

        RefreshPlanSummary();
    }

    private void ApplyFilter()
    {
        var filter = FilterText?.Trim() ?? string.Empty;
        var selectedPath = SelectedApplication?.Path;

        Applications.Clear();
        foreach (var application in _all)
        {
            if (filter.Length == 0 ||
                application.DisplayName.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                application.Vendor.Contains(filter, StringComparison.OrdinalIgnoreCase))
            {
                Applications.Add(application);
            }
        }

        // Keep the selection across filtering so the detail panel does not jump away.
        SelectedApplication = Applications.FirstOrDefault(a => a.Path == selectedPath) ?? Applications.FirstOrDefault();
    }
}
