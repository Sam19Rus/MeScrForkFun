using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/*
 * The section below is a real view model with a real contract, but its data
 * pipeline lands in a later phase. Results graduated in phase 5 (AppData breakdown),
 * Cleanup in phase 8, Large Files in phase 4. Rather than rendering invented numbers,
 * each pending section reports which phase fills it in. When a phase lands,
 * ImplementationPhase becomes null and the real content takes over — the view does
 * not have to be rewritten.
 */

/// <summary>Possible leftovers of uninstalled applications (Phase 7).</summary>
public sealed class AppLeftoversViewModel(IStringLocalizer localizer)
    : SectionViewModel(Section.AppLeftovers, "S.Nav.AppLeftovers", "\uE74D", localizer)
{
    public override int? ImplementationPhase => 7;

    public override string? PlannedContent => Localizer.Get("S.Pending.Leftovers.Planned");
}
