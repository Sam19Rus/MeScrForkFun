using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>One row of the "main categories" panel on the dashboard.</summary>
public sealed class CategorySummaryViewModel
{
    public CategorySummaryViewModel(ScanCategory category, long bytes, int count, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Category = category;
        Bytes = bytes;
        SizeText = formatter.Bytes(bytes);
        CountText = formatter.Count(count);
        CategoryText = localizer.Get(ScanItemViewModel.CategoryKey(category));
    }

    public ScanCategory Category { get; }

    public long Bytes { get; }

    public string SizeText { get; }

    public string CountText { get; }

    public string CategoryText { get; }
}

/// <summary>
/// Dashboard: volumes, free/used space and the headline numbers of the last analysis.
/// </summary>
public sealed partial class OverviewViewModel : SectionViewModel
{
    private readonly IDriveService _driveService;
    private readonly IScanService _scanService;
    private readonly INavigationService _navigation;
    private readonly IValueFormatter _formatter;
    private readonly IUiDispatcher _dispatcher;

    private ScanResult? _lastResult;

    public OverviewViewModel(
        IDriveService driveService,
        IScanService scanService,
        INavigationService navigation,
        IValueFormatter formatter,
        IUiDispatcher dispatcher,
        IStringLocalizer localizer)
        : base(Section.Overview, "S.Nav.Overview", "\uE80F", localizer)
    {
        _driveService = driveService;
        _scanService = scanService;
        _navigation = navigation;
        _formatter = formatter;
        _dispatcher = dispatcher;

        // The service is a singleton with the same lifetime as this view model,
        // so the subscription never needs to be released.
        _scanService.ScanCompleted += OnScanCompleted;

        Refresh();
    }

    public ObservableCollection<DriveCardViewModel> Drives { get; } = [];

    public ObservableCollection<CategorySummaryViewModel> Categories { get; } = [];

    [ObservableProperty]
    private string drivesSummaryText = string.Empty;

    [ObservableProperty]
    private string combinedUsedText = "—";

    [ObservableProperty]
    private string combinedFreeText = "—";

    [ObservableProperty]
    private string potentialCleanupText = "—";

    [ObservableProperty]
    private string safeToCleanText = "—";

    [ObservableProperty]
    private string lastScanSummaryText = string.Empty;

    [ObservableProperty]
    private bool hasLastScan;

    [ObservableProperty]
    private string biggestDirectoryText = "—";

    protected override void OnLanguageChangedCore()
    {
        Refresh();
    }

    [RelayCommand]
    private void Refresh()
    {
        Drives.Clear();

        long total = 0;
        long used = 0;
        long free = 0;
        var ready = 0;

        foreach (var snapshot in _driveService.GetDrives())
        {
            Drives.Add(new DriveCardViewModel(snapshot, _formatter, Localizer));

            if (!snapshot.IsReady)
            {
                continue;
            }

            ready++;
            total += snapshot.TotalBytes;
            used += snapshot.UsedBytes;
            free += snapshot.FreeBytes;
        }

        CombinedUsedText = total > 0 ? _formatter.Bytes(used) : "—";
        CombinedFreeText = total > 0 ? _formatter.Bytes(free) : "—";
        DrivesSummaryText = Localizer.Format("S.Overview.DrivesSummary", _formatter.Count(ready), _formatter.Bytes(total));

        _lastResult ??= _scanService.LastResult;

        if (_lastResult is { } result)
        {
            Apply(result);
        }
        else
        {
            LastScanSummaryText = Localizer.Get("S.Overview.NoScanYet");
        }
    }

    [RelayCommand]
    private void GoToScan() => _navigation.Navigate(Section.Scan);

    [RelayCommand]
    private void GoToResults() => _navigation.Navigate(Section.Results);

    private void OnScanCompleted(object? sender, ScanResult result)
    {
        // The scan pipeline completes on a thread-pool thread. Touching the bound
        // ObservableCollection from there makes WPF throw, so hop to the UI thread.
        _dispatcher.Post(() =>
        {
            _lastResult = result;
            Apply(result);
        });
    }

    private void Apply(ScanResult result)
    {
        HasLastScan = true;
        PotentialCleanupText = _formatter.Bytes(result.PotentialCleanupBytes);
        SafeToCleanText = _formatter.Bytes(result.SafeBytes);

        var modeText = Localizer.Get(ModeKey(result.Mode)) + " " + Localizer.Get("S.Nav.Scan").ToLowerInvariant();

        LastScanSummaryText = result.WasCancelled
            ? Localizer.Format(
                "S.Overview.ScanCancelled",
                _formatter.Duration(result.Duration),
                _formatter.Count(result.Statistics.FilesScanned))
            : Localizer.Format(
                "S.Overview.ScanFinished",
                modeText,
                _formatter.Duration(result.Duration),
                _formatter.Count(result.Statistics.FilesScanned),
                _formatter.Count(result.Statistics.DirectoriesScanned));

        Categories.Clear();
        foreach (var group in result.BytesByCategory.OrderByDescending(kv => kv.Value).Take(6))
        {
            var count = result.CountByCategory.TryGetValue(group.Key, out var value) ? value : 0;
            Categories.Add(new CategorySummaryViewModel(group.Key, group.Value, count, _formatter, Localizer));
        }

        var largest = result.LargestDirectories.FirstOrDefault();
        BiggestDirectoryText = largest is null
            ? "—"
            : $"{largest.Path} — {_formatter.Bytes(largest.SubtreeBytes)}";

        StatusText = LastScanSummaryText;
    }

    private static string ModeKey(ScanMode mode) => mode switch
    {
        ScanMode.Quick => "S.ScanMode.Quick",
        ScanMode.Deep => "S.ScanMode.Deep",
        _ => "S.ScanMode.Custom",
    };
}
