using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>Age buckets of the Large Files filter. Pure navigation over dates —
/// never a judgement: an old file is not junk and a new file is not treasure.</summary>
public enum LargeFileAgeFilter
{
    Any = 0,
    Last7Days,
    Last30Days,
    Last90Days,
    LastYear,
    OlderThanYear,
}

/// <summary>One entry of a filter drop-down. Rebuilt on language change; the
/// selection survives because it is tracked by <see cref="Value"/>, not by index.</summary>
public sealed class LargeFilesFilterOption<T>(T? value, string display)
{
    public T? Value { get; } = value;

    public string Display { get; } = display;

    public override string ToString() => Display;
}

/// <summary>One row of the large-files list.</summary>
public sealed class LargeFileRowViewModel
{
    public LargeFileRowViewModel(
        ScanItem item,
        IValueFormatter formatter,
        IStringLocalizer localizer,
        DateTime nowUtc)
    {
        Item = item;
        Name = item.Name;
        Path = item.Path;
        ShortPath = PathUtils.ShortenForDisplay(item.Path, 72);
        Bytes = item.Size;
        SizeText = formatter.Bytes(item.Size);
        ExtensionText = string.IsNullOrEmpty(item.Extension) ? "—" : item.Extension;
        DriveText = string.IsNullOrEmpty(item.DriveRoot) ? "—" : item.DriveRoot!;
        ModifiedText = formatter.Date(item.ModifiedAtUtc);
        CategoryText = localizer.Get(ScanItemViewModel.CategoryKey(item.Category));
        AgeText = AgeOf(item.ModifiedAtUtc, nowUtc, localizer);
    }

    public ScanItem Item { get; }

    public string Name { get; }

    public string Path { get; }

    public string ShortPath { get; }

    public long Bytes { get; }

    public string SizeText { get; }

    public string ExtensionText { get; }

    public string DriveText { get; }

    public string ModifiedText { get; }

    public string CategoryText { get; }

    public string AgeText { get; }

    public ScanCategory Category => Item.Category;

    private static string AgeOf(DateTime? modifiedUtc, DateTime nowUtc, IStringLocalizer localizer)
    {
        if (modifiedUtc is not { } modified)
        {
            // Unknown stays unknown: guessing an age would be exactly the invented data
            // this product refuses to show.
            return localizer.Get("S.LargeFiles.Age.Unknown");
        }

        var days = (int)(nowUtc - modified).TotalDays;
        return days switch
        {
            <= 0 => localizer.Get("S.LargeFiles.Age.Today"),
            < 30 => localizer.Format("S.LargeFiles.Age.DaysAgo", days),
            < 365 => localizer.Format("S.LargeFiles.Age.MonthsAgo", Math.Max(1, days / 30)),
            _ => localizer.Format("S.LargeFiles.Age.YearsAgo", Math.Max(1, days / 365)),
        };
    }
}

/// <summary>One node of the directory map built from <see cref="DirectoryAggregate"/>.</summary>
public sealed class LargeDirectoryNodeViewModel
{
    public LargeDirectoryNodeViewModel(DirectoryAggregate aggregate, IValueFormatter formatter, IStringLocalizer localizer)
    {
        Aggregate = aggregate;
        Path = aggregate.Path;
        Name = aggregate.Name;
        Bytes = aggregate.SubtreeBytes;
        SubtreeSizeText = formatter.Bytes(aggregate.SubtreeBytes);
        OwnSizeText = localizer.Format("S.LargeFiles.Tree.Own", formatter.Bytes(aggregate.OwnBytes));
        FilesText = localizer.Format("S.Results.FilesCount", formatter.Count(aggregate.SubtreeFileCount));
    }

    public DirectoryAggregate Aggregate { get; }

    public string Path { get; }

    public string Name { get; }

    public long Bytes { get; }

    public string SubtreeSizeText { get; }

    public string OwnSizeText { get; }

    public string FilesText { get; }

    public List<LargeDirectoryNodeViewModel> Children { get; } = [];

    public bool HasChildren => Children.Count > 0;
}

/// <summary>
/// Phase 4: the Large Files screen. A read-only space map — the largest files with
/// filters and the largest directories as a tree — whose only actions are "open file"
/// and "open folder". Nothing here is offered for deletion: a big file is not junk
/// just because it is big (spec §14), so this screen explains and navigates, while
/// cleanup stays on the Results/Cleanup screens.
/// </summary>
public sealed partial class LargeFilesViewModel : SectionViewModel
{
    private const long OneGb = 1024L * 1024 * 1024;

    private readonly IScanService _scanService;
    private readonly ISettingsService _settings;
    private readonly IValueFormatter _formatter;
    private readonly IUiDispatcher _dispatcher;
    private readonly IShellService _shell;
    private readonly INavigationService _navigation;
    private readonly IClock _clock;
    private readonly ICleanupLedger _ledger;

    private ScanResult? _result;
    private List<ScanItem> _allFiles = [];
    private List<LargeFileRowViewModel> _rows = [];

    public LargeFilesViewModel(
        IScanService scanService,
        ISettingsService settings,
        IValueFormatter formatter,
        IUiDispatcher dispatcher,
        IShellService shell,
        INavigationService navigation,
        IClock clock,
        ICleanupLedger ledger,
        IStringLocalizer localizer)
        : base(Section.LargeFiles, "S.Nav.LargeFiles", "\uE7C3", localizer)
    {
        _scanService = scanService;
        _settings = settings;
        _formatter = formatter;
        _dispatcher = dispatcher;
        _shell = shell;
        _navigation = navigation;
        _clock = clock;
        _ledger = ledger;

        // Raised from a background thread when a scan finishes; marshalling is mandatory.
        _scanService.ScanCompleted += OnScanCompleted;

        // A cleanup run deletes rows this screen still shows from the stale snapshot;
        // the ledger keeps the list honest until the next scan replaces it.
        _ledger.Changed += OnLedgerChanged;

        // The threshold lives in Settings; changing it re-tunes this screen immediately.
        // Both this VM and the event source live for the whole application lifetime.
        _settings.SettingsChanged += OnSettingsChanged;

        if (_scanService.LastResult is { } existing)
        {
            Apply(existing);
        }
        else
        {
            EmptyText = Localizer.Get("S.LargeFiles.Empty");
            EmptyHintText = Localizer.Get("S.LargeFiles.EmptyHint");
        }
    }

    // --------------------------------------------------------------- data

    public ObservableCollection<LargeFileRowViewModel> Files { get; } = [];

    public ObservableCollection<LargeDirectoryNodeViewModel> DirectoryRoots { get; } = [];

    /// <summary>A scan result exists (even an empty one). <c>false</c> → the call-to-scan state.</summary>
    [ObservableProperty]
    private bool hasData;

    [ObservableProperty]
    private bool hasDirectories;

    [ObservableProperty]
    private string emptyText = string.Empty;

    [ObservableProperty]
    private string emptyHintText = string.Empty;

    /// <summary>Honest note about what the current scan mode could and could not see.</summary>
    [ObservableProperty]
    private string scanNoteText = string.Empty;

    [ObservableProperty]
    private bool hasScanNote;

    /// <summary>"Showing N of M · total X" under the file list.</summary>
    [ObservableProperty]
    private string fileSummaryText = string.Empty;

    /// <summary>Shown instead of the list when the filters matched nothing.</summary>
    [ObservableProperty]
    private string noMatchesText = string.Empty;

    [ObservableProperty]
    private bool filesEmptyAfterFilter;

    [ObservableProperty]
    private string directoryNoteText = string.Empty;

    // --------------------------------------------------------------- filters

    public ObservableCollection<LargeFilesFilterOption<string?>> VolumeOptions { get; } = [];

    public ObservableCollection<LargeFilesFilterOption<long>> MinSizeOptions { get; } = [];

    public ObservableCollection<LargeFilesFilterOption<LargeFileAgeFilter>> AgeOptions { get; } = [];

    public ObservableCollection<LargeFilesFilterOption<ScanCategory?>> CategoryOptions { get; } = [];

    [ObservableProperty]
    private LargeFilesFilterOption<string?>? selectedVolume;

    [ObservableProperty]
    private LargeFilesFilterOption<long>? selectedMinSize;

    [ObservableProperty]
    private LargeFilesFilterOption<LargeFileAgeFilter>? selectedAge;

    [ObservableProperty]
    private LargeFilesFilterOption<ScanCategory?>? selectedCategory;

    /// <summary>Extension typed by the user; matched with or without the leading dot.</summary>
    [ObservableProperty]
    private string extensionFilterText = string.Empty;

    public string VolumeLabel => Localizer.Get("S.LargeFiles.Filter.Volume");

    public string MinSizeLabel => Localizer.Get("S.LargeFiles.Filter.MinSize");

    public string AgeLabel => Localizer.Get("S.LargeFiles.Filter.Age");

    public string CategoryLabel => Localizer.Get("S.LargeFiles.Filter.Category");

    public string ExtensionLabel => Localizer.Get("S.LargeFiles.Filter.Extension");

    public string ExtensionHint => Localizer.Get("S.LargeFiles.Filter.ExtensionHint");

    // --------------------------------------------------------------- behaviour

    public override Task OnNavigatedToAsync()
    {
        if (_result is null && _scanService.LastResult is { } result)
        {
            Apply(result);
        }

        return Task.CompletedTask;
    }

    protected override void OnLanguageChangedCore()
    {
        EmptyText = Localizer.Get("S.LargeFiles.Empty");
        EmptyHintText = Localizer.Get("S.LargeFiles.EmptyHint");

        foreach (var label in new[]
                 {
                     nameof(VolumeLabel), nameof(MinSizeLabel), nameof(AgeLabel),
                     nameof(CategoryLabel), nameof(ExtensionLabel), nameof(ExtensionHint),
                 })
        {
            OnPropertyChanged(label);
        }

        if (_result is { } result)
        {
            Apply(result);
        }
    }

    partial void OnSelectedVolumeChanged(LargeFilesFilterOption<string?>? value) => ApplyFilters();

    partial void OnSelectedMinSizeChanged(LargeFilesFilterOption<long>? value) => ApplyFilters();

    partial void OnSelectedAgeChanged(LargeFilesFilterOption<LargeFileAgeFilter>? value) => ApplyFilters();

    partial void OnSelectedCategoryChanged(LargeFilesFilterOption<ScanCategory?>? value) => ApplyFilters();

    partial void OnExtensionFilterTextChanged(string value) => ApplyFilters();

    [RelayCommand]
    private void ResetFilters()
    {
        ExtensionFilterText = string.Empty;
        SelectedVolume = VolumeOptions.FirstOrDefault();
        SelectedAge = AgeOptions.FirstOrDefault();
        SelectedCategory = CategoryOptions.FirstOrDefault();
        SelectedMinSize = MinSizeOptions.FirstOrDefault(o => o.Value == _settings.Current.LargeFileThresholdBytes)
            ?? MinSizeOptions.FirstOrDefault();
    }

    [RelayCommand]
    private void GoToScan() => _navigation.Navigate(Section.Scan);

    [RelayCommand]
    private void Refresh()
    {
        if (_scanService.LastResult is { } result)
        {
            Apply(result);
        }
    }

    [RelayCommand]
    private void OpenFile(LargeFileRowViewModel? row)
    {
        if (row is not null && !_shell.OpenFile(row.Path))
        {
            StatusText = Localizer.Get("S.LargeFiles.OpenFailed");
        }
    }

    [RelayCommand]
    private void OpenLocation(LargeFileRowViewModel? row)
    {
        if (row is not null && !_shell.OpenFileLocation(row.Path))
        {
            StatusText = Localizer.Get("S.LargeFiles.OpenFailed");
        }
    }

    [RelayCommand]
    private void OpenDirectory(LargeDirectoryNodeViewModel? node)
    {
        if (node is not null && !_shell.OpenFolder(node.Path))
        {
            StatusText = Localizer.Get("S.LargeFiles.OpenFailed");
        }
    }

    // --------------------------------------------------------------- pipeline

    private void OnScanCompleted(object? sender, ScanResult result) => _dispatcher.Post(() => Apply(result));

    private void OnLedgerChanged(object? sender, EventArgs e) =>
        _dispatcher.Post(() =>
        {
            if (_result is { } result)
            {
                Apply(result);
            }
        });

    private void OnSettingsChanged(object? sender, AppSettings settings) =>
        _dispatcher.Post(() =>
        {
            if (_result is { } result)
            {
                Apply(result);
            }
        });

    private void Apply(ScanResult result)
    {
        _result = result;
        HasData = true;

        // The builder only ever puts files into LargestFiles; the filter is a seatbelt,
        // not a second source of truth. Files a cleanup run already removed (or that
        // lived inside a removed directory) drop out of the stale snapshot.
        _allFiles = [.. result.LargestFiles
            .Where(f => f.Kind == ScanItemKind.File && !_ledger.IsDeleted(f.Path))];

        // The mode decides what this screen could possibly know — say it out loud.
        if (result.Mode == ScanMode.Quick)
        {
            HasScanNote = true;
            ScanNoteText = Localizer.Get("S.LargeFiles.Note.Quick");
        }
        else if (result.WasCancelled)
        {
            HasScanNote = true;
            ScanNoteText = Localizer.Get("S.LargeFiles.Note.Cancelled");
        }
        else
        {
            HasScanNote = false;
            ScanNoteText = string.Empty;
        }

        RebuildFilterOptions();
        RebuildDirectoryTree(result);
        ApplyFilters();
    }

    private void RebuildFilterOptions()
    {
        var previousVolume = SelectedVolume?.Value;
        var previousMinSize = SelectedMinSize?.Value;
        var previousAge = SelectedAge?.Value;
        var previousCategory = SelectedCategory?.Value;

        VolumeOptions.Clear();
        VolumeOptions.Add(new LargeFilesFilterOption<string?>(null, Localizer.Get("S.LargeFiles.Filter.AnyVolume")));
        foreach (var root in _allFiles
                     .Select(f => f.DriveRoot)
                     .Where(r => !string.IsNullOrEmpty(r))
                     .Distinct(StringComparer.OrdinalIgnoreCase)
                     .OrderBy(r => r, StringComparer.OrdinalIgnoreCase))
        {
            VolumeOptions.Add(new LargeFilesFilterOption<string?>(root, root!));
        }

        MinSizeOptions.Clear();
        var threshold = _settings.Current.LargeFileThresholdBytes;
        var sizes = new SortedSet<long> { 0, threshold, OneGb, 4 * OneGb };
        foreach (var size in sizes)
        {
            var display = size switch
            {
                0 => Localizer.Get("S.LargeFiles.Filter.AnySize"),
                _ when size == threshold => Localizer.Format("S.LargeFiles.Filter.SettingsThreshold", _formatter.Bytes(size)),
                _ => Localizer.Format("S.LargeFiles.Filter.SizeAtLeast", _formatter.Bytes(size)),
            };
            MinSizeOptions.Add(new LargeFilesFilterOption<long>(size, display));
        }

        AgeOptions.Clear();
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.Any, Localizer.Get("S.LargeFiles.Age.Any")));
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.Last7Days, Localizer.Get("S.LargeFiles.Age.Last7")));
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.Last30Days, Localizer.Get("S.LargeFiles.Age.Last30")));
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.Last90Days, Localizer.Get("S.LargeFiles.Age.Last90")));
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.LastYear, Localizer.Get("S.LargeFiles.Age.LastYear")));
        AgeOptions.Add(new LargeFilesFilterOption<LargeFileAgeFilter>(LargeFileAgeFilter.OlderThanYear, Localizer.Get("S.LargeFiles.Age.OlderYear")));

        CategoryOptions.Clear();
        CategoryOptions.Add(new LargeFilesFilterOption<ScanCategory?>(null, Localizer.Get("S.LargeFiles.Filter.AnyCategory")));
        foreach (var category in _allFiles.Select(f => f.Category).Distinct().OrderBy(c => c))
        {
            CategoryOptions.Add(new LargeFilesFilterOption<ScanCategory?>(
                category,
                Localizer.Get(ScanItemViewModel.CategoryKey(category))));
        }

        // Restore the previous selection where it still exists; fall back to the defaults.
        SelectedVolume = VolumeOptions.FirstOrDefault(o => o.Value == previousVolume) ?? VolumeOptions[0];
        SelectedMinSize = MinSizeOptions.FirstOrDefault(o => previousMinSize is { } pm && o.Value == pm)
            ?? MinSizeOptions.FirstOrDefault(o => o.Value == threshold)
            ?? MinSizeOptions[0];
        SelectedAge = AgeOptions.FirstOrDefault(o => previousAge is { } pa && o.Value == pa) ?? AgeOptions[0];
        SelectedCategory = CategoryOptions.FirstOrDefault(o => o.Value == previousCategory) ?? CategoryOptions[0];
    }

    private void RebuildDirectoryTree(ScanResult result)
    {
        DirectoryRoots.Clear();
        HasDirectories = result.LargestDirectories.Count > 0;

        if (!HasDirectories)
        {
            DirectoryNoteText = Localizer.Get("S.LargeFiles.Tree.Empty");
            return;
        }

        DirectoryNoteText = Localizer.Format("S.LargeFiles.Tree.Note", _formatter.Count(result.LargestDirectories.Count));

        var nodes = new Dictionary<string, LargeDirectoryNodeViewModel>(PathUtils.Comparer);
        foreach (var aggregate in result.LargestDirectories)
        {
            // A path can only appear once in the aggregate list; if the engine ever
            // emits duplicates, the first (larger, it is sorted) wins.
            nodes.TryAdd(aggregate.Path, new LargeDirectoryNodeViewModel(aggregate, _formatter, Localizer));
        }

        var roots = new List<LargeDirectoryNodeViewModel>();
        foreach (var node in nodes.Values)
        {
            var parentPath = node.Aggregate.ParentPath;
            if (!string.IsNullOrEmpty(parentPath) &&
                nodes.TryGetValue(parentPath, out var parent) &&
                !ReferenceEquals(parent, node))
            {
                parent.Children.Add(node);
            }
            else
            {
                // Either a scan root, or its parent fell outside the top-N cut:
                // an honest forest instead of a silently broken tree.
                roots.Add(node);
            }
        }

        SortTree(roots);
        foreach (var root in roots)
        {
            DirectoryRoots.Add(root);
        }

        static void SortTree(List<LargeDirectoryNodeViewModel> level)
        {
            level.Sort(static (a, b) => b.Bytes.CompareTo(a.Bytes));
            foreach (var node in level)
            {
                if (node.HasChildren)
                {
                    SortTree(node.Children);
                }
            }
        }
    }

    private void ApplyFilters()
    {
        if (!HasData)
        {
            return;
        }

        var volume = SelectedVolume?.Value;
        var minSize = SelectedMinSize?.Value ?? 0;
        var age = SelectedAge?.Value ?? LargeFileAgeFilter.Any;
        var category = SelectedCategory?.Value;
        var extension = NormaliseExtension(ExtensionFilterText);
        var now = _clock.UtcNow;

        IEnumerable<ScanItem> query = _allFiles;

        if (!string.IsNullOrEmpty(volume))
        {
            query = query.Where(f =>
                f.DriveRoot is { } root && string.Equals(root, volume, PathUtils.Comparison));
        }

        query = query.Where(f => f.Size >= minSize);

        if (extension is { Length: > 0 })
        {
            query = query.Where(f =>
                f.Extension is { Length: > 0 } itemExtension &&
                string.Equals(itemExtension.TrimStart('.'), extension, StringComparison.OrdinalIgnoreCase));
        }

        if (age != LargeFileAgeFilter.Any)
        {
            query = age switch
            {
                LargeFileAgeFilter.Last7Days => query.Where(f => WithinDays(f.ModifiedAtUtc, now, 7)),
                LargeFileAgeFilter.Last30Days => query.Where(f => WithinDays(f.ModifiedAtUtc, now, 30)),
                LargeFileAgeFilter.Last90Days => query.Where(f => WithinDays(f.ModifiedAtUtc, now, 90)),
                LargeFileAgeFilter.LastYear => query.Where(f => WithinDays(f.ModifiedAtUtc, now, 365)),
                // "Older than a year" still requires a known date: an unknown age never
                // matches an age filter, in either direction.
                LargeFileAgeFilter.OlderThanYear => query.Where(f =>
                    f.ModifiedAtUtc is { } modified && modified < now.AddDays(-365)),
                _ => query,
            };
        }

        if (category is { } selected)
        {
            query = query.Where(f => f.Category == selected);
        }

        _rows = [.. query
            .OrderByDescending(f => f.Size)
            .ThenBy(f => f.Path, PathUtils.Comparer)
            .Select(f => new LargeFileRowViewModel(f, _formatter, Localizer, now))];

        Files.Clear();
        foreach (var row in _rows)
        {
            Files.Add(row);
        }

        FilesEmptyAfterFilter = _rows.Count == 0;
        NoMatchesText = _allFiles.Count > 0
            ? Localizer.Get("S.LargeFiles.NoMatches")
            : Localizer.Get("S.LargeFiles.NoFiles");

        FileSummaryText = Localizer.Format(
            "S.LargeFiles.Summary",
            _formatter.Count(_rows.Count),
            _formatter.Count(_allFiles.Count),
            _formatter.Bytes(_rows.Sum(r => r.Bytes)));

        StatusText = FileSummaryText;

        static bool WithinDays(DateTime? modifiedUtc, DateTime now, int days) =>
            modifiedUtc is { } modified && modified >= now.AddDays(-days);
    }

    private static string NormaliseExtension(string raw)
    {
        var trimmed = raw.Trim().TrimStart('*').TrimStart('.');
        return trimmed.Length == 0 ? string.Empty : trimmed;
    }
}
