using System.Collections.ObjectModel;
using System.Reflection;
using CommunityToolkit.Mvvm.ComponentModel;
using DiskCleaner.Core.Application;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.Presentation.ViewModels;

/// <summary>
/// Shell view model: the navigation rail, the status bar and the elevation banner.
/// It owns no file-system access — sections do the work.
/// </summary>
public sealed partial class MainViewModel : ObservableObject
{
    private readonly INavigationService _navigation;
    private readonly IUiDispatcher _dispatcher;
    private readonly IPrivilegeService _privileges;
    private readonly IStringLocalizer _localizer;

    private bool _syncing;
    private SectionViewModel? _previousSection;

    public MainViewModel(
        IEnumerable<SectionViewModel> sections,
        INavigationService navigation,
        IUiDispatcher dispatcher,
        IPrivilegeService privileges,
        IScanService scanService,
        IStringLocalizer localizer)
    {
        _navigation = navigation;
        _dispatcher = dispatcher;
        _privileges = privileges;
        _localizer = localizer;

        ScanService = scanService;
        Sections = [.. sections.OrderBy(s => s.Section)];

        IsElevated = privileges.IsElevated;
        ElevationText = _localizer.Format(
            IsElevated ? "S.Shell.Elevated" : "S.Shell.Standard",
            privileges.UserName);
        StatusText = _localizer.Get("S.Common.Ready");
        VersionText = "v" + (Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? "0.1.0");

        _navigation.Navigated += OnNavigatedExternally;
        _localizer.LanguageChanged += OnLanguageChanged;

        // Suppress the change handler: the initial section is activated exactly once below.
        _syncing = true;
        try
        {
            CurrentSection = Sections.FirstOrDefault(s => s.Section == _navigation.Current) ?? Sections.FirstOrDefault();
        }
        finally
        {
            _syncing = false;
        }

        _ = ActivateAsync(CurrentSection);
    }

    public ObservableCollection<SectionViewModel> Sections { get; }

    public IScanService ScanService { get; }

    [ObservableProperty]
    private SectionViewModel? currentSection;

    [ObservableProperty]
    private string statusText;

    [ObservableProperty]
    private string elevationText = string.Empty;

    [ObservableProperty]
    private bool isElevated;

    [ObservableProperty]
    private string versionText = string.Empty;

    /// <summary>Brand name; intentionally not localised.</summary>
    public string WindowTitle { get; } = "DiskCleaner";

    public string CurrentSectionTitle => CurrentSection?.Title ?? WindowTitle;

    /// <summary>Sections that are not implemented yet show an honest notice instead of empty widgets.</summary>
    public bool CurrentSectionIsPending => CurrentSection is { IsImplemented: false };

    /// <summary>Any section doing real work; the shell asks before closing in that case.</summary>
    public bool IsBusy => Sections.Any(s => s.IsBusy);

    partial void OnCurrentSectionChanged(SectionViewModel? value)
    {
        OnPropertyChanged(nameof(CurrentSectionTitle));
        OnPropertyChanged(nameof(CurrentSectionIsPending));

        if (_syncing || value is null)
        {
            return;
        }

        if (value.Section != _navigation.Current)
        {
            _navigation.Navigate(value.Section);
        }

        _ = ActivateAsync(value);
    }

    private void OnLanguageChanged(object? sender, EventArgs e)
    {
        ElevationText = _localizer.Format(
            IsElevated ? "S.Shell.Elevated" : "S.Shell.Standard",
            _privileges.UserName);

        OnPropertyChanged(nameof(CurrentSectionTitle));
        RefreshStatusForCurrentSection();
    }

    private void OnNavigatedExternally(object? sender, Section section)
    {
        // A view model asked for navigation (e.g. dashboard → Scan). Reflect it in the rail.
        _dispatcher.Post(() =>
        {
            var target = Sections.FirstOrDefault(s => s.Section == section);
            if (target is null || ReferenceEquals(target, CurrentSection))
            {
                return;
            }

            _syncing = true;
            try
            {
                CurrentSection = target;
            }
            finally
            {
                _syncing = false;
            }

            _ = ActivateAsync(target);
        });
    }

    private async Task ActivateAsync(SectionViewModel? next)
    {
        var previous = _previousSection;
        _previousSection = next;

        if (previous is not null && !ReferenceEquals(previous, next))
        {
            previous.IsActive = false;
            await previous.OnNavigatedFromAsync();
        }

        if (next is null)
        {
            return;
        }

        next.IsActive = true;
        RefreshStatusForCurrentSection();

        await next.OnNavigatedToAsync();

        RefreshStatusForCurrentSection();
    }

    private void RefreshStatusForCurrentSection()
    {
        var section = CurrentSection;
        if (section is null)
        {
            return;
        }

        StatusText = section.IsImplemented
            ? (string.IsNullOrWhiteSpace(section.StatusText) ? section.Title : section.StatusText)
            : _localizer.Format("S.Shell.PendingStatus", section.Title, section.ImplementationPhase);
    }

    /// <summary>Called by the shell when a long-running operation changes global state.</summary>
    public void UpdateStatus(string text) => StatusText = text;
}
