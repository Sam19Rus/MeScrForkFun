using CommunityToolkit.Mvvm.ComponentModel;
using DiskCleaner.Presentation.Application;

namespace DiskCleaner.Presentation.Services;

/// <summary>
/// Plain section navigation. Not WPF-specific, so it can be unit-tested and reused.
/// </summary>
public sealed class NavigationService(Section initial = Section.Overview) : INavigationService
{
    public Section Current { get; private set; } = initial;

    public event EventHandler<Section>? Navigated;

    public void Navigate(Section section)
    {
        if (Current == section)
        {
            return;
        }

        Current = section;
        Navigated?.Invoke(this, section);
    }
}
