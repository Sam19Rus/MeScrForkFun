namespace DiskCleaner.Core.Moving;

/// <summary>
/// Creates, inspects and removes directory junctions (NTFS mount points).
/// </summary>
/// <remarks>
/// A junction is the mechanism that makes "move an installed app to another disk"
/// work without the app noticing: the original path keeps resolving, but the bytes
/// live elsewhere. Junctions — unlike symlinks — need no administrator rights and
/// are honoured by every Win32 path API, which is exactly why the mover uses them.
/// <para/>
/// The abstraction exists so the whole mover is testable off Windows.
/// </remarks>
public interface IJunctionService
{
    /// <summary><c>true</c> when the path is a junction/symlink (a reparse point).</summary>
    bool IsLink(string path);

    /// <summary>Immediate target of a link, or <c>null</c> when it is not a link or unreadable.</summary>
    string? TryGetLinkTarget(string path);

    /// <summary>
    /// Turns <paramref name="linkPath"/> into a junction pointing at <paramref name="targetPath"/>.
    /// An empty directory is created at the link path when it does not exist; an existing
    /// non-link path is refused. The target must exist.
    /// </summary>
    bool TryCreateJunction(string linkPath, string targetPath, out string? error);

    /// <summary>Removes the junction itself. Never touches the target's contents.</summary>
    bool TryDeleteJunction(string linkPath, out string? error);
}
