namespace DiskCleaner.Core.Moving;

/// <summary>One application folder the mover can see.</summary>
public sealed record MovableApplication
{
    public required string Name { get; init; }

    public required string Path { get; init; }

    /// <summary>Size on disk. For an already-moved app: the size at the junction target.</summary>
    public long Bytes { get; init; }

    public int FileCount { get; init; }

    /// <summary><c>true</c> when the folder is already a junction — the app lives on another volume.</summary>
    public bool IsAlreadyMoved { get; init; }

    /// <summary>Where the junction points, when <see cref="IsAlreadyMoved"/>.</summary>
    public string? LinkTarget { get; init; }

    public DateTime? LastWriteUtc { get; init; }
}

/// <summary>Stage of a move, for honest progress reporting.</summary>
public enum AppMovePhase
{
    Idle = 0,
    Preparing,
    Copying,
    Verifying,
    ReplacingSource,
    CreatingLink,
    Completed,
    Failed,
    RolledBack,
    Cancelled,
}

/// <summary>Live progress of a move.</summary>
public sealed record AppMoveProgress
{
    public AppMovePhase Phase { get; init; } = AppMovePhase.Idle;

    public long BytesCopied { get; init; }

    public long TotalBytes { get; init; }

    public int FilesCopied { get; init; }

    public int TotalFiles { get; init; }

    public string? CurrentPath { get; init; }

    public double? Fraction => TotalBytes > 0
        ? Math.Clamp((double)BytesCopied / TotalBytes, 0d, 1d)
        : null;
}

/// <summary>
/// The answer to "may this folder be moved there?".
/// </summary>
/// <remarks>
/// A refusal is a stable key, not prose: the presentation layer translates it.
/// The mover validates twice — once for the UI (before the user confirms) and once
/// immediately before touching anything — because the world may have changed.
/// </remarks>
public sealed record AppMoveValidation
{
    public bool IsValid { get; init; }

    /// <summary>Stable reason key (<c>move.*</c>) when refused.</summary>
    public string? ReasonKey { get; init; }

    /// <summary>Non-localised detail for the log/tooltip (exception message, path…).</summary>
    public string? Details { get; init; }

    /// <summary>Bytes the move needs on the destination volume.</summary>
    public long RequiredBytes { get; init; }

    /// <summary>Free bytes on the destination volume, when it could be read.</summary>
    public long? AvailableBytes { get; init; }

    /// <summary>Directory the folder will be copied into.</summary>
    public string? DestinationPath { get; init; }

    public static AppMoveValidation Ok(long requiredBytes, long? availableBytes, string destination) => new()
    {
        IsValid = true,
        RequiredBytes = requiredBytes,
        AvailableBytes = availableBytes,
        DestinationPath = destination,
    };

    public static AppMoveValidation Fail(string reasonKey, string? details = null) => new()
    {
        IsValid = false,
        ReasonKey = reasonKey,
        Details = details,
    };
}

/// <summary>Outcome of one move (or move back). Nothing is silently dropped.</summary>
public sealed record AppMoveRecord
{
    public required string SourcePath { get; init; }

    public required string DestinationPath { get; init; }

    public bool Succeeded { get; init; }

    public long Bytes { get; init; }

    public int Files { get; init; }

    public DateTime StartedAtUtc { get; init; }

    public DateTime CompletedAtUtc { get; init; }

    public TimeSpan Duration => CompletedAtUtc - StartedAtUtc;

    public AppMovePhase FinalPhase { get; init; }

    /// <summary>Stable <c>move.*</c> key when the move did not succeed.</summary>
    public string? FailureReasonKey { get; init; }

    public string? FailureDetails { get; init; }

    /// <summary><c>true</c> when a failed move restored the original state.</summary>
    public bool RolledBack { get; init; }

    /// <summary>
    /// <c>true</c> when the junction at the original location was created. When a move
    /// fails after the copy but the data survives at the destination, this is where the
    /// user can find it — the record says so instead of pretending nothing happened.
    /// </summary>
    public bool LinkCreated { get; init; }

    /// <summary>Set when the data is safe at the destination but the original path could not be restored.</summary>
    public bool DataAtDestinationOnly { get; init; }
}
