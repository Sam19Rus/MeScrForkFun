using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Moving;

/// <summary>
/// Moves an installed application folder to another volume and leaves a junction behind,
/// so the original path keeps working.
/// </summary>
/// <remarks>
/// Why a junction and not "just move it": per-user applications (Ollama, VS Code,
/// Electron apps under <c>%LOCALAPPDATA%\Programs</c>) are registered by absolute path —
/// in shortcuts, in the uninstall registry, in their own config. A directory junction
/// (NTFS mount point) keeps the original path valid at the file-system level: every
/// Win32 API transparently lands on the new volume, the app cannot tell the difference,
/// and no administrator rights are needed to create one.
/// <para/>
/// The move is copy → verify → remove original → link, in exactly that order, and every
/// failure after the copy is rolled back. The original folder is only deleted once the
/// copy has been verified file-for-file. If the copy fails midway (the classic case: the
/// app is running and its <c>.exe</c> is locked), the source is untouched and the partial
/// copy is removed — a failed move changes nothing.
/// <para/>
/// Honest limits, enforced here rather than hoped for:
/// <list type="bullet">
///   <item>Store/UWP apps are refused — their container paths are managed by Windows.</item>
///   <item>Hard-blocked locations (Windows, Program Files) are refused by the safety policy.</item>
///   <item>Source and destination must be on different volumes — a junction to the same
///   volume frees nothing.</item>
///   <item>The destination must have room for the whole folder plus a margin.</item>
/// </list>
/// </remarks>
public interface IAppMover
{
    /// <summary>The folder the mover suggests by default: <c>%LOCALAPPDATA%\Programs</c>.</summary>
    string? DefaultRoot { get; }

    /// <summary>Lists application folders under <see cref="DefaultRoot"/> (or a given root), with sizes.</summary>
    Task<IReadOnlyList<MovableApplication>> DiscoverAsync(string? rootDirectory = null, CancellationToken cancellationToken = default);

    /// <summary>Checks a move without performing it. Runs off the UI thread: measuring a large folder takes a moment.</summary>
    Task<AppMoveValidation> ValidateMoveAsync(string sourcePath, string destinationDirectory, CancellationToken cancellationToken = default);

    /// <summary>Performs the move. Never throws for expected failures — returns a record.</summary>
    Task<AppMoveRecord> MoveAsync(
        string sourcePath,
        string destinationDirectory,
        IProgress<AppMoveProgress>? progress = null,
        CancellationToken cancellationToken = default);

    /// <summary>Undoes a previous move: copies the folder back and removes the junction.</summary>
    Task<AppMoveRecord> MoveBackAsync(
        string linkPath,
        IProgress<AppMoveProgress>? progress = null,
        CancellationToken cancellationToken = default);
}

public sealed class AppMover : IAppMover
{
    /// <summary>Destination free space must cover the folder plus this margin.</summary>
    internal const long MinFreeSpaceMarginBytes = 64L * 1024 * 1024;

    internal const double FreeSpaceMarginRatio = 0.05;

    /// <summary>Destination paths beyond this length are refused: apps themselves often choke on them.</summary>
    internal const int MaxDestinationPathLength = 240;

    private const int ProgressFileInterval = 64;

    private readonly IFileSystem _fileSystem;
    private readonly IJunctionService _junctions;
    private readonly IDriveService _drives;
    private readonly ISafetyPolicy _safety;
    private readonly IEnvironmentInfo _environment;
    private readonly IClock _clock;
    private readonly ILogger _logger;

    public AppMover(
        IFileSystem fileSystem,
        IJunctionService junctions,
        IDriveService drives,
        ISafetyPolicy safety,
        IEnvironmentInfo environment,
        IClock? clock = null,
        ILogger<AppMover>? logger = null)
    {
        _fileSystem = fileSystem ?? throw new ArgumentNullException(nameof(fileSystem));
        _junctions = junctions ?? throw new ArgumentNullException(nameof(junctions));
        _drives = drives ?? throw new ArgumentNullException(nameof(drives));
        _safety = safety ?? throw new ArgumentNullException(nameof(safety));
        _environment = environment ?? throw new ArgumentNullException(nameof(environment));
        _clock = clock ?? SystemClock.Instance;
        _logger = logger ?? NullLogger<AppMover>.Instance;
    }

    public string? DefaultRoot
    {
        get
        {
            var local = _environment.Folders.LocalAppData;
            return string.IsNullOrWhiteSpace(local) ? null : PathUtils.Combine(local, "Programs");
        }
    }

    // ------------------------------------------------------------------ discovery

    public async Task<IReadOnlyList<MovableApplication>> DiscoverAsync(
        string? rootDirectory = null,
        CancellationToken cancellationToken = default)
    {
        var root = PathUtils.Normalize(rootDirectory ?? DefaultRoot ?? string.Empty);
        if (root.Length == 0 || !_fileSystem.DirectoryExists(root))
        {
            return [];
        }

        var result = new List<MovableApplication>();

        foreach (var entry in SafeEnumerate(root))
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (!entry.IsDirectory)
            {
                continue;
            }

            var isLink = _junctions.IsLink(entry.FullPath);
            var target = isLink ? _junctions.TryGetLinkTarget(entry.FullPath) : null;

            // For a moved app the bytes live at the target; a dangling junction reports zero.
            var measured = isLink
                ? target is { Length: > 0 } && _fileSystem.DirectoryExists(target)
                    ? await MeasureAsync(target, cancellationToken).ConfigureAwait(false)
                    : (Bytes: 0L, Files: 0)
                : await MeasureAsync(entry.FullPath, cancellationToken).ConfigureAwait(false);

            result.Add(new MovableApplication
            {
                Name = entry.Name,
                Path = entry.FullPath,
                Bytes = measured.Bytes,
                FileCount = measured.Files,
                IsAlreadyMoved = isLink,
                LinkTarget = target,
                LastWriteUtc = entry.LastWriteUtc,
            });
        }

        return [.. result.OrderByDescending(a => a.Bytes)];
    }

    // ------------------------------------------------------------------ validation

    public async Task<AppMoveValidation> ValidateMoveAsync(string sourcePath, string destinationDirectory, CancellationToken cancellationToken = default)
    {
        var source = PathUtils.Normalize(sourcePath);
        var destinationRoot = PathUtils.Normalize(destinationDirectory);

        if (source.Length == 0 || !_fileSystem.DirectoryExists(source))
        {
            return AppMoveValidation.Fail("move.source-missing");
        }

        if (PathUtils.IsRoot(source))
        {
            return AppMoveValidation.Fail("move.source-protected", "A volume root cannot be moved.");
        }

        if (_junctions.IsLink(source))
        {
            return AppMoveValidation.Fail("move.source-is-link");
        }

        if (IsStorePackageContainer(source))
        {
            return AppMoveValidation.Fail("move.store-app");
        }

        // Hard-blocked trees are off limits even where deletion has an enclave
        // (C:\Windows\Temp is cleanable, but moving it somewhere else is nonsense
        // and dangerous): the mover is for application folders, not for Windows.
        if (_safety.Roots.HardBlocked.Any(blocked => PathUtils.IsUnder(source, blocked)))
        {
            return AppMoveValidation.Fail("move.source-protected", "hard-blocked tree");
        }

        var verdict = _safety.Evaluate(source, ScanCategory.Unknown, ScanItemKind.Directory, explicitUserChoice: true);
        if (!verdict.IsAllowed)
        {
            return AppMoveValidation.Fail("move.source-protected", verdict.RuleName);
        }

        if (destinationRoot.Length == 0 || !PathUtils.IsPathRooted(destinationRoot))
        {
            return AppMoveValidation.Fail("move.destination-invalid", "The destination must be an absolute path.");
        }

        var fileName = PathUtils.GetFileName(source);
        if (fileName.Length == 0)
        {
            return AppMoveValidation.Fail("move.destination-invalid", "The source path has no folder name.");
        }

        var destination = PathUtils.Combine(destinationRoot, fileName);

        if (PathUtils.IsUnder(destination, source))
        {
            return AppMoveValidation.Fail("move.destination-under-source");
        }

        if (string.Equals(PathUtils.GetDriveRoot(source), PathUtils.GetDriveRoot(destination), PathUtils.Comparison))
        {
            return AppMoveValidation.Fail("move.same-volume");
        }

        if (destination.Length > MaxDestinationPathLength)
        {
            return AppMoveValidation.Fail("move.path-too-long", destination);
        }

        if (_fileSystem.DirectoryExists(destination) || _fileSystem.FileExists(destination))
        {
            return AppMoveValidation.Fail("move.destination-exists", destination);
        }

        var measurement = await MeasureAsync(source, cancellationToken).ConfigureAwait(false);
        var required = measurement.Bytes + Math.Max(MinFreeSpaceMarginBytes, (long)(measurement.Bytes * FreeSpaceMarginRatio));

        var destinationVolume = PathUtils.GetDriveRoot(destination);
        long? available = destinationVolume is null ? null : _drives.GetFreeBytes(destinationVolume);

        if (available is { } free && free < required)
        {
            return new AppMoveValidation
            {
                IsValid = false,
                ReasonKey = "move.not-enough-space",
                RequiredBytes = required,
                AvailableBytes = free,
                DestinationPath = destination,
            };
        }

        return AppMoveValidation.Ok(required, available, destination);
    }

    // ------------------------------------------------------------------ move

    public async Task<AppMoveRecord> MoveAsync(
        string sourcePath,
        string destinationDirectory,
        IProgress<AppMoveProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var startedAt = _clock.UtcNow;
        var source = PathUtils.Normalize(sourcePath);

        Report(progress, AppMovePhase.Preparing, 0, 0, 0, 0, source);

        AppMoveValidation validation;
        (long Bytes, int Files) total;
        try
        {
            validation = await ValidateMoveAsync(source, destinationDirectory, cancellationToken).ConfigureAwait(false);
            if (!validation.IsValid)
            {
                _logger.LogWarning("Move refused for {Source}: {Reason} ({Details})", source, validation.ReasonKey, validation.Details);
                return Fail(source, validation.DestinationPath ?? string.Empty, AppMovePhase.Preparing, validation.ReasonKey!, validation.Details, startedAt);
            }

            total = await MeasureAsync(source, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Cancelled before anything was created: nothing to roll back.
            return Fail(source, string.Empty, AppMovePhase.Cancelled, "move.cancelled", null, startedAt);
        }

        var destination = validation.DestinationPath!;

        // 1. copy -------------------------------------------------------------
        if (!_fileSystem.TryCreateDirectory(destination))
        {
            return Fail(source, destination, AppMovePhase.Preparing, "move.destination-invalid", destination, startedAt);
        }

        var copy = await CopyTreeAsync(source, destination, total, progress, cancellationToken).ConfigureAwait(false);
        if (!copy.Succeeded)
        {
            RemoveTreeQuietly(destination);
            var phase = copy.Cancelled ? AppMovePhase.Cancelled : AppMovePhase.Failed;
            return Fail(source, destination, phase, copy.ReasonKey!, copy.Details, startedAt, rolledBack: true);
        }

        // 2. verify -----------------------------------------------------------
        Report(progress, AppMovePhase.Verifying, total.Bytes, total.Bytes, total.Files, total.Files, destination);

        var verified = await MeasureAsync(destination, cancellationToken).ConfigureAwait(false);
        if (verified.Files != total.Files || verified.Bytes != total.Bytes)
        {
            _logger.LogError(
                "Verification failed moving {Source} → {Destination}: {SrcFiles}/{SrcBytes} vs {DstFiles}/{DstBytes}",
                source, destination, total.Files, total.Bytes, verified.Files, verified.Bytes);

            RemoveTreeQuietly(destination);
            return Fail(source, destination, AppMovePhase.Failed, "move.verify-failed",
                $"{total.Files}/{total.Bytes} != {verified.Files}/{verified.Bytes}", startedAt, rolledBack: true);
        }

        // 3. remove the original ----------------------------------------------
        Report(progress, AppMovePhase.ReplacingSource, total.Bytes, total.Bytes, total.Files, total.Files, source);

        if (!_fileSystem.TryDeleteDirectory(source, recursive: true, out var deleteError))
        {
            // The source is still there and complete; the copy is redundant. Remove it and
            // tell the user the likely cause: something inside the folder is still running.
            _logger.LogWarning("Could not remove the original {Source} after copying: {Error}", source, deleteError);
            RemoveTreeQuietly(destination);
            return Fail(source, destination, AppMovePhase.Failed, "move.source-delete-failed", deleteError, startedAt, rolledBack: true);
        }

        // 4. junction -----------------------------------------------------------
        Report(progress, AppMovePhase.CreatingLink, total.Bytes, total.Bytes, total.Files, total.Files, source);

        if (!_junctions.TryCreateJunction(source, destination, out var linkError))
        {
            // Worst point of the whole operation: the original path is empty and the data
            // lives at the destination. Try to put it back; if that fails too, the record
            // says exactly where the data is — it is never silently lost.
            _logger.LogError("Junction creation failed for {Source} → {Destination}: {Error}", source, destination, linkError);

            var restored = await RestoreAfterLinkFailureAsync(destination, source, cancellationToken).ConfigureAwait(false);
            return restored
                ? Fail(source, destination, AppMovePhase.RolledBack, "move.link-failed", linkError, startedAt, rolledBack: true)
                : new AppMoveRecord
                {
                    SourcePath = source,
                    DestinationPath = destination,
                    Succeeded = false,
                    Bytes = total.Bytes,
                    Files = total.Files,
                    StartedAtUtc = startedAt,
                    CompletedAtUtc = _clock.UtcNow,
                    FinalPhase = AppMovePhase.Failed,
                    FailureReasonKey = "move.link-failed-data-safe",
                    FailureDetails = linkError,
                    DataAtDestinationOnly = true,
                };
        }

        var completedAt = _clock.UtcNow;
        _logger.LogInformation(
            "Moved {Source} → {Destination} ({Bytes} bytes, {Files} files) in {Duration}",
            source, destination, total.Bytes, total.Files, completedAt - startedAt);

        Report(progress, AppMovePhase.Completed, total.Bytes, total.Bytes, total.Files, total.Files, destination);

        return new AppMoveRecord
        {
            SourcePath = source,
            DestinationPath = destination,
            Succeeded = true,
            Bytes = total.Bytes,
            Files = total.Files,
            StartedAtUtc = startedAt,
            CompletedAtUtc = completedAt,
            FinalPhase = AppMovePhase.Completed,
            LinkCreated = true,
        };
    }

    // ------------------------------------------------------------------ move back

    public async Task<AppMoveRecord> MoveBackAsync(
        string linkPath,
        IProgress<AppMoveProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var startedAt = _clock.UtcNow;
        var link = PathUtils.Normalize(linkPath);

        Report(progress, AppMovePhase.Preparing, 0, 0, 0, 0, link);

        if (!_junctions.IsLink(link))
        {
            return Fail(link, string.Empty, AppMovePhase.Preparing, "move.back-not-a-link", null, startedAt);
        }

        var target = _junctions.TryGetLinkTarget(link);
        if (target is null || !_fileSystem.DirectoryExists(target))
        {
            return Fail(link, target ?? string.Empty, AppMovePhase.Preparing, "move.back-target-missing", target, startedAt);
        }

        (long Bytes, int Files) total;
        try
        {
            total = await MeasureAsync(target, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            return Fail(link, target, AppMovePhase.Cancelled, "move.cancelled", null, startedAt);
        }

        var linkVolume = PathUtils.GetDriveRoot(link);
        var available = linkVolume is null ? null : _drives.GetFreeBytes(linkVolume);
        var required = total.Bytes + Math.Max(MinFreeSpaceMarginBytes, (long)(total.Bytes * FreeSpaceMarginRatio));
        if (available is { } free && free < required)
        {
            return new AppMoveRecord
            {
                SourcePath = target,
                DestinationPath = link,
                Succeeded = false,
                Bytes = total.Bytes,
                Files = total.Files,
                StartedAtUtc = startedAt,
                CompletedAtUtc = _clock.UtcNow,
                FinalPhase = AppMovePhase.Failed,
                FailureReasonKey = "move.not-enough-space",
            };
        }

        // The junction has to go first — its location is where the data returns to.
        if (!_junctions.TryDeleteJunction(link, out var junctionError))
        {
            return Fail(target, link, AppMovePhase.Failed, "move.back-junction-delete-failed", junctionError, startedAt);
        }

        if (!_fileSystem.TryCreateDirectory(link))
        {
            _junctions.TryCreateJunction(link, target, out _);
            return Fail(target, link, AppMovePhase.Failed, "move.destination-invalid", link, startedAt);
        }

        var copy = await CopyTreeAsync(target, link, total, progress, cancellationToken).ConfigureAwait(false);
        if (!copy.Succeeded)
        {
            // Put the junction back: the data at the target is intact and reachable again.
            RemoveTreeQuietly(link);
            _junctions.TryCreateJunction(link, target, out _);
            return Fail(target, link, copy.Cancelled ? AppMovePhase.Cancelled : AppMovePhase.Failed,
                copy.ReasonKey!, copy.Details, startedAt, rolledBack: true);
        }

        Report(progress, AppMovePhase.Verifying, total.Bytes, total.Bytes, total.Files, total.Files, link);

        var verified = await MeasureAsync(link, cancellationToken).ConfigureAwait(false);
        if (verified.Files != total.Files || verified.Bytes != total.Bytes)
        {
            RemoveTreeQuietly(link);
            _junctions.TryCreateJunction(link, target, out _);
            return Fail(target, link, AppMovePhase.Failed, "move.verify-failed",
                $"{total.Files}/{total.Bytes} != {verified.Files}/{verified.Bytes}", startedAt, rolledBack: true);
        }

        Report(progress, AppMovePhase.ReplacingSource, total.Bytes, total.Bytes, total.Files, total.Files, target);

        if (!_fileSystem.TryDeleteDirectory(target, recursive: true, out var removeError))
        {
            // The app works from the restored original path; the stale copy at the target
            // is reported honestly instead of being left as a mystery.
            _logger.LogWarning("Move back succeeded but the copy at {Target} could not be removed: {Error}", target, removeError);
            return new AppMoveRecord
            {
                SourcePath = target,
                DestinationPath = link,
                Succeeded = true,
                Bytes = total.Bytes,
                Files = total.Files,
                StartedAtUtc = startedAt,
                CompletedAtUtc = _clock.UtcNow,
                FinalPhase = AppMovePhase.Completed,
                FailureReasonKey = "move.back-stale-copy-remains",
                FailureDetails = removeError,
            };
        }

        Report(progress, AppMovePhase.Completed, total.Bytes, total.Bytes, total.Files, total.Files, link);

        return new AppMoveRecord
        {
            SourcePath = target,
            DestinationPath = link,
            Succeeded = true,
            Bytes = total.Bytes,
            Files = total.Files,
            StartedAtUtc = startedAt,
            CompletedAtUtc = _clock.UtcNow,
            FinalPhase = AppMovePhase.Completed,
        };
    }

    // ------------------------------------------------------------------ internals

    private sealed record CopyOutcome(bool Succeeded, bool Cancelled, string? ReasonKey, string? Details)
    {
        public static CopyOutcome Ok() => new(true, false, null, null);
        public static CopyOutcome Fail(string reasonKey, string? details) => new(false, false, reasonKey, details);
        public static CopyOutcome Cancel() => new(false, true, "move.cancelled", null);
    }

    /// <summary>
    /// Copies a tree, recreating inner junctions instead of following them. A copy
    /// failure is fatal for the whole move: partial data is never presented as success.
    /// </summary>
    private async Task<CopyOutcome> CopyTreeAsync(
        string source,
        string destination,
        (long Bytes, int Files) total,
        IProgress<AppMoveProgress>? progress,
        CancellationToken cancellationToken)
    {
        long bytesCopied = 0;
        var filesCopied = 0;
        var sinceReport = 0;

        // Explicit stack instead of recursion: deep trees must not depend on stack size.
        var stack = new Stack<(string Source, string Destination)>();
        stack.Push((source, destination));

        // Junctions whose target lies inside the moved tree are remapped; everything
        // else keeps pointing where it pointed.
        var sourcePrefix = PathUtils.EnsureTrailingSeparator(source);

        try
        {
            while (stack.Count > 0)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var (src, dst) = stack.Pop();

                foreach (var entry in SafeEnumerateThrow(src))
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    var targetPath = PathUtils.Combine(dst, entry.Name);

                    if (entry.IsDirectory)
                    {
                        if (entry.IsReparsePoint)
                        {
                            // Never follow a link out of (or into) the tree being moved:
                            // recreate it, remapping targets that point inside the tree.
                            var linkTarget = _fileSystem.TryResolveLinkTarget(entry.FullPath);
                            var remapped = linkTarget is { Length: > 0 } && linkTarget.StartsWith(sourcePrefix, PathUtils.Comparison)
                                ? PathUtils.Combine(destination, linkTarget[sourcePrefix.Length..])
                                : linkTarget;

                            if (remapped is null)
                            {
                                return CopyOutcome.Fail("move.copy-failed", $"Unresolvable link: {entry.FullPath}");
                            }

                            if (!_junctions.TryCreateJunction(targetPath, remapped, out var linkError))
                            {
                                return CopyOutcome.Fail("move.copy-failed", $"{entry.FullPath}: {linkError}");
                            }

                            continue;
                        }

                        if (!_fileSystem.TryCreateDirectory(targetPath))
                        {
                            return CopyOutcome.Fail("move.copy-failed", $"Cannot create directory: {targetPath}");
                        }

                        stack.Push((entry.FullPath, targetPath));
                        continue;
                    }

                    if (!_fileSystem.TryCopyFile(entry.FullPath, targetPath, out var copyError))
                    {
                        // The classic reason: the application is running and the file is locked.
                        return CopyOutcome.Fail("move.copy-failed", $"{entry.FullPath}: {copyError}");
                    }

                    bytesCopied += entry.Size;
                    filesCopied++;

                    if (++sinceReport >= ProgressFileInterval)
                    {
                        sinceReport = 0;
                        Report(progress, AppMovePhase.Copying, bytesCopied, total.Bytes, filesCopied, total.Files, entry.FullPath);
                    }
                }
            }
        }
        catch (OperationCanceledException)
        {
            return CopyOutcome.Cancel();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return CopyOutcome.Fail("move.copy-failed", ex.Message);
        }

        // Let the UI see 100% before the phase changes.
        await Task.Yield();
        Report(progress, AppMovePhase.Copying, total.Bytes, total.Bytes, total.Files, total.Files, destination);

        return CopyOutcome.Ok();
    }

    /// <summary>Counts files and bytes of a tree, treating reparse points as leaves.</summary>
    private async Task<(long Bytes, int Files)> MeasureAsync(string root, CancellationToken cancellationToken)
    {
        long bytes = 0;
        var files = 0;

        var stack = new Stack<string>();
        stack.Push(root);

        while (stack.Count > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();

            foreach (var entry in SafeEnumerate(stack.Pop()))
            {
                if (entry.IsDirectory)
                {
                    if (!entry.IsReparsePoint)
                    {
                        stack.Push(entry.FullPath);
                    }

                    continue;
                }

                bytes += entry.Size;
                files++;
            }

            await Task.Yield();
        }

        return (bytes, files);
    }

    /// <summary>
    /// Last-resort recovery: the original path is already gone and the junction could not
    /// be created, so the copied tree is brought back file by file. Returns <c>true</c>
    /// when the original location is whole again.
    /// </summary>
    private async Task<bool> RestoreAfterLinkFailureAsync(string destination, string source, CancellationToken cancellationToken)
    {
        try
        {
            if (!_fileSystem.TryCreateDirectory(source))
            {
                return false;
            }

            var total = await MeasureAsync(destination, cancellationToken).ConfigureAwait(false);
            var copy = await CopyTreeAsync(destination, source, total, null, cancellationToken).ConfigureAwait(false);
            if (!copy.Succeeded)
            {
                return false;
            }

            var verified = await MeasureAsync(source, cancellationToken).ConfigureAwait(false);
            if (verified.Files != total.Files || verified.Bytes != total.Bytes)
            {
                return false;
            }

            RemoveTreeQuietly(destination);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Restore after junction failure did not succeed for {Source}", source);
            return false;
        }
    }

    private void RemoveTreeQuietly(string path)
    {
        try
        {
            _fileSystem.TryDeleteDirectory(path, recursive: true, out _);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not remove the partial copy at {Path}", path);
        }
    }

    /// <summary>Store/UWP containers must be moved through Windows Settings, not by a junction.</summary>
    private bool IsStorePackageContainer(string normalizedSource)
    {
        var local = _environment.Folders.LocalAppData;
        return !string.IsNullOrWhiteSpace(local) &&
               PathUtils.IsUnder(normalizedSource, PathUtils.Combine(local!, "Packages"));
    }

    private IEnumerable<ScannedEntry> SafeEnumerate(string directory)
    {
        try
        {
            return _fileSystem.EnumerateEntries(directory);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _logger.LogWarning("Cannot enumerate {Directory}: {Message}", directory, ex.Message);
            return [];
        }
    }

    /// <summary>Enumeration whose failures must abort the operation (copy/measure of the subject itself).</summary>
    private IEnumerable<ScannedEntry> SafeEnumerateThrow(string directory) => _fileSystem.EnumerateEntries(directory);

    private static void Report(
        IProgress<AppMoveProgress>? progress,
        AppMovePhase phase,
        long bytesCopied,
        long totalBytes,
        int filesCopied,
        int totalFiles,
        string? currentPath)
    {
        progress?.Report(new AppMoveProgress
        {
            Phase = phase,
            BytesCopied = bytesCopied,
            TotalBytes = totalBytes,
            FilesCopied = filesCopied,
            TotalFiles = totalFiles,
            CurrentPath = currentPath,
        });
    }

    private AppMoveRecord Fail(
        string source,
        string destination,
        AppMovePhase phase,
        string reasonKey,
        string? details,
        DateTime startedAt,
        bool rolledBack = false) => new()
        {
            SourcePath = source,
            DestinationPath = destination,
            Succeeded = false,
            StartedAtUtc = startedAt,
            CompletedAtUtc = _clock.UtcNow,
            FinalPhase = phase,
            FailureReasonKey = reasonKey,
            FailureDetails = details,
            RolledBack = rolledBack,
        };
}
