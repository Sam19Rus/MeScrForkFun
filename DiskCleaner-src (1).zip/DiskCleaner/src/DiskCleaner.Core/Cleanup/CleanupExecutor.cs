using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Core.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Cleanup;

/// <summary>
/// Executes a plan the user has explicitly confirmed.
/// </summary>
/// <remarks>
/// The separation demanded by the specification is enforced structurally: the scanner
/// analyses, the planner collects the user's choices, and this class is the only thing
/// that deletes. It never decides on its own — it walks a plan that already passed the
/// safety policy — and it re-checks the policy before every single operation, so a stale
/// plan cannot be used to reach a path that has since become protected.
/// <para/>
/// Expected failures are not errors: a locked file is <c>Skipped</c> with a reason, never
/// forced. No process is ever terminated.
/// </remarks>
public interface ICleanupExecutor
{
    bool IsRunning { get; }

    Task<CleanupRunRecord> ExecuteAsync(
        CleanupPlan plan,
        ScanMode mode,
        IProgress<CleanupProgress>? progress = null,
        CancellationToken cancellationToken = default);

    event EventHandler<CleanupRunRecord>? RunCompleted;
}

public sealed class CleanupExecutor : ICleanupExecutor
{
    /// <summary>Cap on retained per-file skip records so a huge run cannot exhaust memory.</summary>
    public const int MaxRetainedSkipped = 1_000;

    private readonly IDeletionService _deletion;
    private readonly ISafetyPolicy _safety;
    private readonly IFileSystem _fileSystem;
    private readonly IDriveService _drives;
    private readonly IHistoryService _history;
    private readonly ISettingsService _settings;
    private readonly IPrivilegeService _privileges;
    private readonly IClock _clock;
    private readonly ILogger _logger;
    private readonly SemaphoreSlim _gate = new(1, 1);

    public CleanupExecutor(
        IDeletionService deletion,
        ISafetyPolicy safety,
        IFileSystem fileSystem,
        IDriveService drives,
        IHistoryService history,
        ISettingsService settings,
        IPrivilegeService privileges,
        IClock clock,
        ILogger<CleanupExecutor>? logger = null)
    {
        _deletion = deletion ?? throw new ArgumentNullException(nameof(deletion));
        _safety = safety ?? throw new ArgumentNullException(nameof(safety));
        _fileSystem = fileSystem ?? throw new ArgumentNullException(nameof(fileSystem));
        _drives = drives ?? throw new ArgumentNullException(nameof(drives));
        _history = history ?? throw new ArgumentNullException(nameof(history));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _privileges = privileges;
        _clock = clock ?? throw new ArgumentNullException(nameof(clock));
        _logger = logger ?? NullLogger<CleanupExecutor>.Instance;
    }

    public bool IsRunning { get; private set; }

    public event EventHandler<CleanupRunRecord>? RunCompleted;

    public async Task<CleanupRunRecord> ExecuteAsync(
        CleanupPlan plan,
        ScanMode mode,
        IProgress<CleanupProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(plan);

        // Deliberately without the token: a pre-cancelled run must still return a record
        // saying nothing was deleted, rather than throwing.
        if (!await _gate.WaitAsync(0).ConfigureAwait(false))
        {
            throw new InvalidOperationException("A cleanup run is already in progress.");
        }

        try
        {
            IsRunning = true;

            var operations = plan.Operations.ToArray();
            var startedAt = _clock.UtcNow;
            var volumes = AffectedVolumes(operations);
            var freeBefore = TotalFreeBytes(volumes);

            _logger.LogInformation(
                "Cleanup started: {Operations} operation(s), {Bytes} planned, volumes={Volumes}, elevated={Elevated}",
                operations.Length, operations.Sum(o => o.ExpectedBytes), string.Join(",", volumes), _privileges?.IsElevated ?? false);

            long freed = 0;
            var deletedFiles = 0;
            var deletedDirectories = 0;
            var skippedCount = 0;
            var failedCount = 0;
            var cancelled = false;
            var skipped = new List<SkippedFile>();
            var deleted = new List<DeletedEntry>();
            var perCategory = new Dictionary<ScanCategory, (long Bytes, int Files, int Dirs, int Skipped)>();

            for (var index = 0; index < operations.Length; index++)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    // Remaining operations are recorded as cancelled, not silently dropped.
                    for (var rest = index; rest < operations.Length; rest++)
                    {
                        operations[rest].Status = CleanupOperationStatus.Cancelled;
                    }

                    cancelled = true;
                    break;
                }

                var operation = operations[index];
                Report(progress, index, operations.Length, operation.TargetPath, freed, skippedCount, failedCount, startedAt);

                // Yield so the caller's thread stays responsive and progress can reach
                // the UI between operations.
                await Task.Yield();

                try
                {
                    var outcome = ExecuteOne(operation);

                    // An access-denied failure on a path that needs elevation is a
                    // permissions problem the user can act on, not a mystery: say so.
                    if (!outcome.Succeeded &&
                        outcome.FailureKind == ScanIssueKind.AccessDenied &&
                        (operation.RequiresElevation || _safety.RequiresElevation(operation.TargetPath)))
                    {
                        outcome = outcome with { FailureReasonKey = "cleanup.needs-elevation" };
                    }

                    operation.ExecutedAtUtc = _clock.UtcNow;
                    operation.Status = outcome.Succeeded ? CleanupOperationStatus.Succeeded : CleanupOperationStatus.Skipped;
                    operation.FreedBytes = outcome.FreedBytes;
                    operation.RemovedFileCount = outcome.RemovedFileCount;
                    operation.ErrorKind = outcome.FailureKind;
                    operation.ErrorMessage = outcome.FailureReasonKey;

                    if (outcome.Succeeded)
                    {
                        // SHFileOperation does not report sizes, so the size measured at plan
                        // time is what gets credited. FreeBytesBefore/After is the ground truth.
                        operation.FreedBytes = outcome.FreedBytes > 0 ? outcome.FreedBytes : operation.ExpectedBytes;
                        freed += operation.FreedBytes;

                        if (operation.Kind == ScanItemKind.Directory)
                        {
                            deletedDirectories++;
                        }
                        else
                        {
                            deletedFiles++;
                        }

                        // The ledger of what is really gone: the report screens use it to
                        // drop deleted rows from the stale scan result.
                        deleted.Add(new DeletedEntry
                        {
                            Path = operation.TargetPath,
                            Kind = operation.Kind,
                            Bytes = operation.FreedBytes,
                            Recycled = outcome.WasRecycled,
                        });
                    }
                    else
                    {
                        skippedCount++;
                        if (skipped.Count < MaxRetainedSkipped)
                        {
                            skipped.Add(new SkippedFile
                            {
                                Path = operation.TargetPath,
                                Kind = outcome.FailureKind ?? ScanIssueKind.Unknown,
                                Reason = outcome.FailureReasonKey ?? "cleanup.unknown",
                                EstimatedBytes = operation.ExpectedBytes,
                            });
                        }
                    }

                    Accumulate(perCategory, operation, outcome);
                }
                catch (Exception ex)
                {
                    // One bad operation must not abort the run.
                    failedCount++;
                    operation.Status = CleanupOperationStatus.Failed;
                    operation.ErrorMessage = ex.GetType().Name;
                    operation.ExecutedAtUtc = _clock.UtcNow;
                    _logger.LogError(ex, "Cleanup operation failed unexpectedly: {Path}", operation.TargetPath);

                    if (skipped.Count < MaxRetainedSkipped)
                    {
                        skipped.Add(new SkippedFile
                        {
                            Path = operation.TargetPath,
                            Kind = ScanIssueKind.Unknown,
                            Reason = "cleanup.unexpected",
                            EstimatedBytes = operation.ExpectedBytes,
                        });
                    }

                    Accumulate(perCategory, operation, DeletionOutcome.Fail(ScanIssueKind.Unknown, "cleanup.unexpected"));
                }
            }

            var completedAt = _clock.UtcNow;
            var freeAfter = TotalFreeBytes(volumes);

            Report(progress, operations.Length, operations.Length, null, freed, skippedCount, failedCount, startedAt);

            var record = new CleanupRunRecord
            {
                StartedAtUtc = startedAt,
                CompletedAtUtc = completedAt,
                Mode = mode,
                FreeBytesBefore = freeBefore,
                FreeBytesAfter = freeAfter,
                FreedBytes = freed,
                DeletedFileCount = deletedFiles,
                DeletedDirectoryCount = deletedDirectories,
                SkippedCount = skippedCount,
                FailedCount = failedCount,
                WasCancelled = cancelled,
                RanElevated = _privileges?.IsElevated ?? false,
                Categories = [.. perCategory
                    .Select(kv => new CategoryBreakdown
                    {
                        Category = kv.Key,
                        FreedBytes = kv.Value.Bytes,
                        FileCount = kv.Value.Files,
                        DirectoryCount = kv.Value.Dirs,
                        SkippedCount = kv.Value.Skipped,
                    })
                    .OrderByDescending(c => c.FreedBytes)],
                Skipped = skipped,
                Deleted = deleted,
            };

            _logger.LogInformation(
                "Cleanup finished: freed={Freed} bytes, files={Files}, directories={Dirs}, skipped={Skipped}, failed={Failed}, cancelled={Cancelled}, volume delta={Delta}",
                freed, deletedFiles, deletedDirectories, skippedCount, failedCount, cancelled, freeAfter - freeBefore);

            if (_settings.Current.SaveHistoryAutomatically)
            {
                await _history.AppendAsync(record, CancellationToken.None).ConfigureAwait(false);
            }

            RunCompleted?.Invoke(this, record);
            return record;
        }
        finally
        {
            IsRunning = false;
            _gate.Release();
        }
    }

    /// <summary>
    /// Performs one operation, with the safety policy re-checked immediately beforehand.
    /// </summary>
    private DeletionOutcome ExecuteOne(CleanupOperation operation)
    {
        // Defense in depth: the plan was validated when it was built, but the world may
        // have changed and the executor must never trust a stored decision blindly.
        var verdict = _safety.Evaluate(
            operation.TargetPath,
            operation.Category,
            operation.Kind,
            explicitUserChoice: true);

        if (!verdict.IsAllowed)
        {
            _logger.LogWarning("Refusing to delete {Path}: {Reason}", operation.TargetPath, verdict.RejectionReason);
            return DeletionOutcome.Fail(ScanIssueKind.Excluded, "cleanup.refused-by-policy");
        }

        if (operation.Method == DeletionMethod.None)
        {
            return DeletionOutcome.Fail(ScanIssueKind.Excluded, "cleanup.not-deletable");
        }

        if (operation.Method == DeletionMethod.SystemApi)
        {
            var volume = PathUtils.GetDriveRoot(operation.TargetPath);
            return _deletion.EmptyRecycleBin(volume);
        }

        var isDirectory = operation.Kind == ScanItemKind.Directory;
        if (!isDirectory && !_fileSystem.FileExists(operation.TargetPath))
        {
            return DeletionOutcome.Fail(ScanIssueKind.NotFound, "cleanup.already-gone");
        }

        if (isDirectory && !_fileSystem.DirectoryExists(operation.TargetPath))
        {
            return DeletionOutcome.Fail(ScanIssueKind.NotFound, "cleanup.already-gone");
        }

        var method = ResolveMethod(operation);
        return _deletion.Delete(operation.TargetPath, method, isDirectory);
    }

    /// <summary>
    /// Applies the user's Recycle Bin preference without overriding the plan's intent:
    /// temporary and cache data is deleted permanently, everything else is recycled when
    /// the volume supports it.
    /// </summary>
    private DeletionMethod ResolveMethod(CleanupOperation operation)
    {
        var behavior = _settings.Current.RecycleBinBehavior;

        if (behavior == RecycleBinBehavior.Never)
        {
            return DeletionMethod.Permanent;
        }

        if (operation.Method == DeletionMethod.RecycleBin)
        {
            return _deletion.SupportsRecycleBin(operation.TargetPath) ? DeletionMethod.RecycleBin : DeletionMethod.Permanent;
        }

        // The analyzer chose Permanent (TEMP, caches) — that stays permanent unless the
        // user asked for everything to go through the Recycle Bin.
        return behavior == RecycleBinBehavior.Always && _deletion.SupportsRecycleBin(operation.TargetPath)
            ? DeletionMethod.RecycleBin
            : DeletionMethod.Permanent;
    }

    private static void Accumulate(
        Dictionary<ScanCategory, (long Bytes, int Files, int Dirs, int Skipped)> perCategory,
        CleanupOperation operation,
        DeletionOutcome outcome)
    {
        perCategory.TryGetValue(operation.Category, out var current);

        var isDirectory = operation.Kind == ScanItemKind.Directory;

        perCategory[operation.Category] = outcome.Succeeded
            ? (current.Bytes + operation.FreedBytes,
               current.Files + (isDirectory ? 0 : 1),
               current.Dirs + (isDirectory ? 1 : 0),
               current.Skipped)
            : (current.Bytes, current.Files, current.Dirs, current.Skipped + 1);
    }

    private static void Report(
        IProgress<CleanupProgress>? progress,
        int completed,
        int total,
        string? currentPath,
        long freed,
        int skipped,
        int failed,
        DateTime startedAt)
    {
        progress?.Report(new CleanupProgress
        {
            CompletedOperations = completed,
            TotalOperations = total,
            CurrentPath = currentPath,
            FreedBytes = freed,
            SkippedCount = skipped,
            FailedCount = failed,
            Elapsed = DateTime.UtcNow - startedAt,
        });
    }

    private static IReadOnlyList<string> AffectedVolumes(IEnumerable<CleanupOperation> operations)
    {
        var volumes = new HashSet<string>(PathUtils.Comparer);
        foreach (var operation in operations)
        {
            var root = PathUtils.GetDriveRoot(operation.TargetPath);
            if (!string.IsNullOrEmpty(root))
            {
                volumes.Add(root);
            }
        }

        return [.. volumes];
    }

    private long TotalFreeBytes(IReadOnlyList<string> volumes)
    {
        long total = 0;
        foreach (var volume in volumes)
        {
            total += _drives.GetFreeBytes(volume) ?? 0;
        }

        return total;
    }
}
