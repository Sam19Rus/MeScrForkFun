using DiskCleaner.Core.Application;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Cleanup;

/// <summary>
/// Session-scoped memory of what has actually been deleted.
/// </summary>
/// <remarks>
/// A scan result is a snapshot: after a cleanup run it is stale, and showing a deleted
/// folder as if it were still there is a lie the user notices immediately. The ledger
/// bridges the gap without re-scanning — every report screen asks it "does this path
/// still exist as far as we know?" and hides the rows it says are gone.
/// <para/>
/// It is deliberately conservative in the other direction too: a new scan proves paths
/// exist again (TEMP regenerates within minutes), so <see cref="IScanService.ScanCompleted"/>
/// resets the ledger. Nothing here ever decides what to delete — it only records facts
/// the executor already established.
/// </remarks>
public interface ICleanupLedger
{
    /// <summary><c>true</c> when the path itself was deleted, or lies under a deleted directory.</summary>
    bool IsDeleted(string path);

    /// <summary>Number of top-level deleted paths registered this session.</summary>
    int DeletedCount { get; }

    /// <summary>Bytes credited to deletions this session.</summary>
    long DeletedBytes { get; }

    /// <summary><c>true</c> when at least one of the recorded deletions went to the Recycle Bin.</summary>
    bool AnyRecycled { get; }

    /// <summary>Drops the memory of all deletions (a fresh scan supersedes it).</summary>
    void Reset();

    /// <summary>Raised on a background thread whenever the ledger changes.</summary>
    event EventHandler? Changed;
}

/// <summary>Default <see cref="ICleanupLedger"/>: exact paths plus deleted directory prefixes.</summary>
public sealed class CleanupLedger : ICleanupLedger
{
    private readonly object _gate = new();
    private readonly HashSet<string> _deletedPaths = new(PathUtils.Comparer);
    private readonly List<string> _deletedDirectories = [];

    private long _deletedBytes;
    private bool _anyRecycled;

    /// <summary>
    /// Wires itself to the executor and the scanner: run records feed the ledger, a new
    /// scan clears it. Both are process-lifetime singletons, so nothing is unsubscribed.
    /// </summary>
    public CleanupLedger(ICleanupExecutor executor, IScanService scanService)
    {
        ArgumentNullException.ThrowIfNull(executor);
        ArgumentNullException.ThrowIfNull(scanService);

        executor.RunCompleted += (_, record) => Register(record);
        scanService.ScanCompleted += (_, _) => Reset();
    }

    /// <summary>Parameterless construction for hosts that call <see cref="Register"/> themselves.</summary>
    public CleanupLedger()
    {
    }

    public int DeletedCount
    {
        get { lock (_gate) { return _deletedPaths.Count; } }
    }

    public long DeletedBytes
    {
        get { lock (_gate) { return _deletedBytes; } }
    }

    public bool AnyRecycled
    {
        get { lock (_gate) { return _anyRecycled; } }
    }

    public event EventHandler? Changed;

    public bool IsDeleted(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return false;
        }

        var normalized = PathUtils.Normalize(path);

        lock (_gate)
        {
            if (_deletedPaths.Contains(normalized))
            {
                return true;
            }

            foreach (var directory in _deletedDirectories)
            {
                if (PathUtils.IsUnder(normalized, directory))
                {
                    return true;
                }
            }

            return false;
        }
    }

    /// <summary>Records every successful deletion of one run.</summary>
    public void Register(CleanupRunRecord record)
    {
        ArgumentNullException.ThrowIfNull(record);

        if (record.Deleted.Count == 0)
        {
            return;
        }

        lock (_gate)
        {
            foreach (var entry in record.Deleted)
            {
                var normalized = PathUtils.Normalize(entry.Path);
                if (normalized.Length == 0 || !_deletedPaths.Add(normalized))
                {
                    // Already registered (e.g. two runs over an overlapping plan): the
                    // bytes were credited once and stay credited once.
                    continue;
                }

                _deletedBytes += entry.Bytes;
                _anyRecycled |= entry.Recycled;

                if (entry.Kind == ScanItemKind.Directory)
                {
                    _deletedDirectories.Add(normalized);
                }
            }
        }

        Changed?.Invoke(this, EventArgs.Empty);
    }

    public void Reset()
    {
        bool hadEntries;
        lock (_gate)
        {
            hadEntries = _deletedPaths.Count > 0;
            _deletedPaths.Clear();
            _deletedDirectories.Clear();
            _deletedBytes = 0;
            _anyRecycled = false;
        }

        if (hadEntries)
        {
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }
}
