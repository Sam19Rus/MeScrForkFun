using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Cleanup;

/// <summary>Outcome of one deletion attempt.</summary>
public sealed record DeletionOutcome
{
    public bool Succeeded { get; init; }

    /// <summary>What was actually used, which may differ from what was planned (Recycle Bin → permanent).</summary>
    public DeletionMethod MethodUsed { get; init; } = DeletionMethod.None;

    /// <summary><c>true</c> when the data went to the Recycle Bin and can be restored.</summary>
    public bool WasRecycled { get; init; }

    public long FreedBytes { get; init; }

    public int RemovedFileCount { get; init; }

    public ScanIssueKind? FailureKind { get; init; }

    /// <summary>Stable, non-localised reason key (see <c>S.Cleanup.Reason.*</c>).</summary>
    public string? FailureReasonKey { get; init; }

    public int ErrorCode { get; init; }

    /// <summary>Set when administrator rights would probably have been enough.</summary>
    public bool MayRequireElevation => FailureKind == ScanIssueKind.AccessDenied;

    public static DeletionOutcome Recycled(long freedBytes, int removedFiles) => new()
    {
        Succeeded = true,
        MethodUsed = DeletionMethod.RecycleBin,
        WasRecycled = true,
        FreedBytes = freedBytes,
        RemovedFileCount = removedFiles,
    };

    public static DeletionOutcome Deleted(long freedBytes, int removedFiles) => new()
    {
        Succeeded = true,
        MethodUsed = DeletionMethod.Permanent,
        FreedBytes = freedBytes,
        RemovedFileCount = removedFiles,
    };

    public static DeletionOutcome Emptied(long freedBytes, int removedFiles) => new()
    {
        Succeeded = true,
        MethodUsed = DeletionMethod.SystemApi,
        FreedBytes = freedBytes,
        RemovedFileCount = removedFiles,
    };

    public static DeletionOutcome Fail(ScanIssueKind kind, string reasonKey, int errorCode = 0) => new()
    {
        Succeeded = false,
        FailureKind = kind,
        FailureReasonKey = reasonKey,
        ErrorCode = errorCode,
    };
}

/// <summary>
/// Performs the actual removal. Implemented per platform; the executor only ever talks
/// to this interface, which is what makes the whole deletion pipeline testable.
/// </summary>
/// <remarks>
/// Contract: never throw for an expected failure (locked file, denied access, vanished
/// path). Report it as a <see cref="DeletionOutcome"/> instead. Never terminate a process
/// that holds a file. Never bypass a sharing violation by force.
/// </remarks>
public interface IDeletionService
{
    /// <summary><c>false</c> when the volume has no Recycle Bin (network shares, some removable media).</summary>
    bool SupportsRecycleBin(string path);

    /// <summary>Deletes one file or one directory tree.</summary>
    DeletionOutcome Delete(string path, DeletionMethod method, bool isDirectory);

    /// <summary>Empties the Recycle Bin, optionally of a single volume.</summary>
    DeletionOutcome EmptyRecycleBin(string? volumeRoot);
}

/// <summary>Live progress of a cleanup run.</summary>
public sealed record CleanupProgress
{
    public int CompletedOperations { get; init; }

    public int TotalOperations { get; init; }

    public string? CurrentPath { get; init; }

    public long FreedBytes { get; init; }

    public int SkippedCount { get; init; }

    public int FailedCount { get; init; }

    public TimeSpan Elapsed { get; init; }

    public double? PercentComplete =>
        TotalOperations > 0 ? Math.Clamp((double)CompletedOperations / TotalOperations, 0d, 1d) : null;

    public bool IsIndeterminate => TotalOperations == 0;
}
