using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Cleanup;

/// <summary>
/// Holds the plan the user is building.
/// </summary>
/// <remarks>
/// The plan is a first-class object with a single writer and one rule: an operation can
/// only enter it through <see cref="TryAdd"/>, which consults the safety policy. Nothing
/// downstream may add to <see cref="CleanupPlan"/> directly, so "the user confirmed it"
/// can never become a way to reach a protected path.
/// </remarks>
public interface ICleanupPlanner
{
    CleanupPlan Current { get; }

    int Count { get; }

    long TotalBytes { get; }

    int TotalFileCount { get; }

    bool Contains(string path);

    /// <summary>Adds an item the user explicitly picked.</summary>
    /// <returns><c>false</c> with a human-readable <paramref name="rejection"/> when refused.</returns>
    bool TryAdd(ScanItem item, out string? rejection);

    bool Remove(string path);

    void Clear();

    event EventHandler? PlanChanged;
}

public sealed class CleanupPlanner(ISafetyPolicy safetyPolicy) : ICleanupPlanner
{
    private readonly ISafetyPolicy _safety = safetyPolicy ?? throw new ArgumentNullException(nameof(safetyPolicy));
    private readonly object _gate = new();

    private CleanupPlan _plan = new();

    public CleanupPlan Current
    {
        get { lock (_gate) { return _plan; } }
    }

    public int Count
    {
        get { lock (_gate) { return _plan.Count; } }
    }

    public long TotalBytes
    {
        get { lock (_gate) { return _plan.TotalExpectedBytes; } }
    }

    public int TotalFileCount
    {
        get { lock (_gate) { return _plan.TotalExpectedFileCount; } }
    }

    public event EventHandler? PlanChanged;

    public bool Contains(string path)
    {
        lock (_gate)
        {
            return _plan.Operations.Any(o =>
                string.Equals(o.TargetPath, path, Infrastructure.IO.PathUtils.Comparison));
        }
    }

    public bool TryAdd(ScanItem item, out string? rejection)
    {
        ArgumentNullException.ThrowIfNull(item);

        bool added;
        lock (_gate)
        {
            // explicitUserChoice: true — the user picked this exact item, which is the only
            // way user-data paths may ever be acted on. Hard-blocked paths stay refused.
            added = _plan.TryAdd(CleanupOperation.FromItem(item), _safety, out rejection, explicitUserChoice: true);
        }

        if (added)
        {
            PlanChanged?.Invoke(this, EventArgs.Empty);
        }

        return added;
    }

    public bool Remove(string path)
    {
        bool removed;
        lock (_gate)
        {
            removed = _plan.Remove(path);
        }

        if (removed)
        {
            PlanChanged?.Invoke(this, EventArgs.Empty);
        }

        return removed;
    }

    public void Clear()
    {
        lock (_gate)
        {
            if (_plan.Count == 0)
            {
                return;
            }

            _plan.Clear();
        }

        PlanChanged?.Invoke(this, EventArgs.Empty);
    }
}

/// <summary>
/// Items the user dismissed from the report ("исключить").
/// </summary>
/// <remarks>
/// Session-scoped on purpose: dismissing a row is a view decision, not a permanent
/// settings change. Permanent exclusions belong in <see cref="AppSettings.ExcludedPaths"/>,
/// which stops the scanner from entering a folder at all.
/// </remarks>
public interface IReportExclusions
{
    bool IsExcluded(string path);

    bool Exclude(string path);

    bool Include(string path);

    void Clear();

    int Count { get; }

    IReadOnlyCollection<string> Paths { get; }

    event EventHandler? Changed;
}

public sealed class ReportExclusions : IReportExclusions
{
    private readonly HashSet<string> _paths = new(Infrastructure.IO.PathUtils.Comparer);
    private readonly object _gate = new();

    public int Count
    {
        get { lock (_gate) { return _paths.Count; } }
    }

    public IReadOnlyCollection<string> Paths
    {
        get { lock (_gate) { return _paths.ToArray(); } }
    }

    public event EventHandler? Changed;

    public bool IsExcluded(string path)
    {
        lock (_gate)
        {
            return _paths.Contains(Infrastructure.IO.PathUtils.Normalize(path));
        }
    }

    public bool Exclude(string path)
    {
        bool added;
        lock (_gate)
        {
            added = _paths.Add(Infrastructure.IO.PathUtils.Normalize(path));
        }

        if (added)
        {
            Changed?.Invoke(this, EventArgs.Empty);
        }

        return added;
    }

    public bool Include(string path)
    {
        bool removed;
        lock (_gate)
        {
            removed = _paths.Remove(Infrastructure.IO.PathUtils.Normalize(path));
        }

        if (removed)
        {
            Changed?.Invoke(this, EventArgs.Empty);
        }

        return removed;
    }

    public void Clear()
    {
        lock (_gate)
        {
            if (_paths.Count == 0)
            {
                return;
            }

            _paths.Clear();
        }

        Changed?.Invoke(this, EventArgs.Empty);
    }
}
