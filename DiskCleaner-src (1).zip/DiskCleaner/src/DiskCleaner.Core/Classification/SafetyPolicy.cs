using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Classification;

/// <summary>
/// The single authority on "may this be touched at all".
/// Every deletion path in the application — planner, executor, UI context menu —
/// must consult it. Analyzers propose; this policy disposes.
/// </summary>
public interface ISafetyPolicy
{
    ProtectedRoots Roots { get; }

    /// <summary>
    /// Evaluates one path.
    /// </summary>
    /// <param name="path">Absolute path of a file or directory.</param>
    /// <param name="category">Category an analyzer assigned, when known.</param>
    /// <param name="kind">File, directory or virtual target.</param>
    /// <param name="explicitUserChoice">
    /// <c>true</c> only when the user deliberately picked this exact item.
    /// User data is refused for automatic selection and accepted for an explicit choice.
    /// </param>
    SafetyVerdict Evaluate(
        string path,
        ScanCategory category = ScanCategory.Unknown,
        ScanItemKind kind = ScanItemKind.File,
        bool explicitUserChoice = false);

    /// <summary><c>true</c> for hard-blocked paths and for user-data paths.</summary>
    bool IsProtected(string path);

    /// <summary><c>true</c> when acting on the path needs an elevated process.</summary>
    bool RequiresElevation(string path);
}

/// <summary>Default <see cref="ISafetyPolicy"/>: prefix rules over <see cref="ProtectedRoots"/>.</summary>
/// <remarks>
/// The rule set is intentionally written as explicit prefixes. There is no
/// "folder name contains cache/temp/log" heuristic anywhere in this class: a name
/// is never evidence of what a directory is for.
/// </remarks>
public sealed class SafetyPolicy : ISafetyPolicy
{
    private readonly IEnvironmentInfo? _environment;

    public SafetyPolicy(ProtectedRoots roots, IEnvironmentInfo? environment = null)
    {
        Roots = roots ?? throw new ArgumentNullException(nameof(roots));
        _environment = environment;
    }

    public ProtectedRoots Roots { get; }

    public SafetyVerdict Evaluate(
        string path,
        ScanCategory category = ScanCategory.Unknown,
        ScanItemKind kind = ScanItemKind.File,
        bool explicitUserChoice = false)
    {
        var normalized = PathUtils.Normalize(path);
        if (normalized.Length == 0)
        {
            return SafetyVerdict.Deny("empty-path", "The path could not be determined.");
        }

        // Operating-system data is never a cleanup candidate.
        if (category == ScanCategory.SystemData)
        {
            return SafetyVerdict.Deny("category.system-data", "This is operating-system data. DiskCleaner does not remove it.");
        }

        if (IsBlockedFileName(normalized))
        {
            return SafetyVerdict.Deny("blocked-file-name", "This is a system file required by Windows.");
        }

        // The Recycle Bin is emptied through the shell API, never by deleting files
        // inside $Recycle.Bin. The exception is narrow on purpose: it requires the
        // category, the virtual-target kind AND the exact folder name, so it cannot be
        // used to reach anything else on the volume.
        if (category == ScanCategory.RecycleBin &&
            kind == ScanItemKind.VirtualTarget &&
            string.Equals(PathUtils.GetFileName(normalized), "$Recycle.Bin", StringComparison.OrdinalIgnoreCase))
        {
            return SafetyVerdict.Allow(
                "recycle-bin.system-api",
                maxConfidence: CleanupConfidence.Safe,
                minRisk: RiskLevel.Medium);
        }

        // A volume root itself is never deletable.
        if (PathUtils.IsRoot(normalized))
        {
            return SafetyVerdict.Deny("volume-root", "A volume root cannot be deleted.");
        }

        // Container directories (C:\Users, C:\ProgramData) must not be removed themselves,
        // but their contents are evaluated by the normal rules below.
        if (Roots.SelfOnlyBlocked.Any(blocked => string.Equals(normalized, blocked, PathUtils.Comparison)))
        {
            return SafetyVerdict.Deny("blocked.self-only", "This directory is a system container and must not be removed.");
        }

        var hardBlocked = FindLongestMatch(normalized, Roots.HardBlocked);
        if (hardBlocked is not null)
        {
            if (string.Equals(normalized, hardBlocked, PathUtils.Comparison))
            {
                return SafetyVerdict.Deny("hard-blocked.self", "This directory is part of Windows or of an installed program and must not be removed.");
            }

            var enclave = FindLongestMatch(normalized, Roots.HardBlockedEnclaves);
            if (enclave is null)
            {
                return SafetyVerdict.Deny("hard-blocked", "This location is part of Windows or of an installed program and must not be removed.");
            }

            return SafetyVerdict.Allow(
                "hard-blocked.enclave",
                maxConfidence: CleanupConfidence.Safe,
                minRisk: RiskLevel.Low,
                requiresElevation: true,
                requiresExplicitUserChoice: false);
        }

        var userDataRoot = FindLongestMatch(normalized, Roots.UserData);
        if (userDataRoot is not null)
        {
            // Tier 2: never automatic, always explained, allowed only as a deliberate choice.
            return explicitUserChoice
                ? SafetyVerdict.Allow(
                    "user-data.explicit",
                    maxConfidence: CleanupConfidence.NeedsReview,
                    minRisk: RiskLevel.High,
                    requiresElevation: RequiresElevationCore(normalized),
                    requiresExplicitUserChoice: true)
                : SafetyVerdict.Deny("user-data", "This is user data (documents, media or downloads). It is never selected automatically — review the item and decide explicitly.");
        }

        return SafetyVerdict.Allow(
            "default",
            maxConfidence: CleanupConfidence.Safe,
            minRisk: RiskLevel.None,
            requiresElevation: RequiresElevationCore(normalized));
    }

    public bool IsProtected(string path)
    {
        var normalized = PathUtils.Normalize(path);
        if (normalized.Length == 0)
        {
            return true; // Unknown paths are protected by definition.
        }

        if (PathUtils.IsRoot(normalized) || IsBlockedFileName(normalized))
        {
            return true;
        }

        if (Roots.SelfOnlyBlocked.Any(blocked => string.Equals(normalized, blocked, PathUtils.Comparison)))
        {
            return true;
        }

        if (FindLongestMatch(normalized, Roots.HardBlocked) is { } blocked &&
            FindLongestMatch(normalized, Roots.HardBlockedEnclaves) is null)
        {
            return true;
        }

        return FindLongestMatch(normalized, Roots.UserData) is not null;
    }

    public bool RequiresElevation(string path) => RequiresElevationCore(PathUtils.Normalize(path));

    private bool RequiresElevationCore(string normalizedPath)
    {
        var folders = _environment?.Folders;

        if (folders?.Windows is { Length: > 0 } windows && PathUtils.IsUnder(normalizedPath, windows))
        {
            return true;
        }

        if (folders?.ProgramData is { Length: > 0 } programData && PathUtils.IsUnder(normalizedPath, programData))
        {
            return true;
        }

        // Another user's profile cannot be modified without elevation.
        var currentProfile = folders?.UserProfile;
        if (folders?.UsersRoot is { Length: > 0 } usersRoot &&
            PathUtils.IsUnder(normalizedPath, usersRoot) &&
            !string.IsNullOrWhiteSpace(currentProfile) &&
            !PathUtils.IsUnder(normalizedPath, currentProfile))
        {
            return true;
        }

        return false;
    }

    private bool IsBlockedFileName(string normalizedPath)
    {
        if (Roots.BlockedFileNames.Count == 0)
        {
            return false;
        }

        var name = PathUtils.GetFileName(normalizedPath);
        return Roots.BlockedFileNames.Contains(name, StringComparer.OrdinalIgnoreCase);
    }

    private static string? FindLongestMatch(string normalizedPath, IReadOnlyList<string> candidates)
    {
        string? best = null;
        foreach (var candidate in candidates)
        {
            if (!PathUtils.IsUnder(normalizedPath, candidate))
            {
                continue;
            }

            if (best is null || candidate.Length > best.Length)
            {
                best = candidate;
            }
        }

        return best;
    }
}
