using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Classification;

/// <summary>
/// The answer of the safety policy for one path.
/// </summary>
/// <remarks>
/// A verdict never says "delete this". It says what is <em>permitted</em>, how
/// confident the app is allowed to be, and how risky the operation is at minimum.
/// The classification layer then decides what to actually offer.
/// </remarks>
public readonly record struct SafetyVerdict
{
    /// <summary>Required because a struct with field initializers must declare its parameterless constructor.</summary>
    public SafetyVerdict()
    {
    }

    /// <summary><c>false</c> means the path must never be touched, not even on explicit user request.</summary>
    public bool IsAllowed { get; init; }

    /// <summary>Name of the rule that produced this verdict (shown in the "why" tooltip and in logs).</summary>
    public string? RuleName { get; init; }

    /// <summary>Plain-language reason for a rejection.</summary>
    public string? RejectionReason { get; init; }

    /// <summary>
    /// Ceiling for <see cref="CleanupConfidence"/>. A path inside a user library can
    /// never be reported as <see cref="CleanupConfidence.Safe"/>, whatever its name is.
    /// </summary>
    public CleanupConfidence MaxConfidence { get; init; } = CleanupConfidence.Safe;

    /// <summary>Floor for <see cref="RiskLevel"/>.</summary>
    public RiskLevel MinRisk { get; init; } = RiskLevel.None;

    /// <summary>Deletion needs an elevated process (e.g. <c>C:\Windows\Temp</c>).</summary>
    public bool RequiresElevation { get; init; }

    /// <summary>Only a deliberate, explicit user choice may act on this path.</summary>
    public bool RequiresExplicitUserChoice { get; init; }

    public static SafetyVerdict Allow(
        string ruleName,
        CleanupConfidence maxConfidence = CleanupConfidence.Safe,
        RiskLevel minRisk = RiskLevel.None,
        bool requiresElevation = false,
        bool requiresExplicitUserChoice = false) => new()
        {
            IsAllowed = true,
            RuleName = ruleName,
            MaxConfidence = maxConfidence,
            MinRisk = minRisk,
            RequiresElevation = requiresElevation,
            RequiresExplicitUserChoice = requiresExplicitUserChoice,
        };

    public static SafetyVerdict Deny(string ruleName, string reason) => new()
        {
            IsAllowed = false,
            RuleName = ruleName,
            RejectionReason = reason,
            MaxConfidence = CleanupConfidence.NeedsReview,
            MinRisk = RiskLevel.Critical,
        };
}
