namespace DiskCleaner.Core.Application;

/// <summary>
/// Elevation awareness. The application starts as a standard user; this service
/// tells the UI whether a specific operation needs more rights and offers to
/// relaunch for it.
/// </summary>
public interface IPrivilegeService
{
    /// <summary><c>true</c> when the current process is running elevated.</summary>
    bool IsElevated { get; }

    /// <summary>Windows user name, for the "running as" indicator.</summary>
    string UserName { get; }

    /// <summary>
    /// Relaunches the application elevated, optionally continuing a specific action
    /// (e.g. re-running a scan scope). Returns <c>false</c> when the user declined UAC.
    /// </summary>
    Task<bool> RequestElevationAsync(string? reason = null, CancellationToken cancellationToken = default);
}
