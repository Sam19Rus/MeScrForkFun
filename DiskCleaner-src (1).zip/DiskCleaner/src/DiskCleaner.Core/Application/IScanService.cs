using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Application;

/// <summary>
/// Runs a scan and returns the report. This is the only entry point the UI needs:
/// view models never touch <see cref="Scanning.FileSystemScanner"/> directly.
/// </summary>
public interface IScanService
{
    /// <summary>Whether a scan is currently running (used to disable the UI and the close button).</summary>
    bool IsRunning { get; }

    /// <summary>The last completed result, if any. Used by the dashboard between runs.</summary>
    ScanResult? LastResult { get; }

    Task<ScanResult> RunAsync(
        ScanMode mode,
        IReadOnlyList<string> roots,
        IProgress<ScanProgress>? progress = null,
        CancellationToken cancellationToken = default);

    /// <summary>Raised when a run finishes, fails or is cancelled.</summary>
    event EventHandler<ScanResult>? ScanCompleted;
}
