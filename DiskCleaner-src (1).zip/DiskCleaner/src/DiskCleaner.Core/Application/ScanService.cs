using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Core.Services;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Application;

/// <summary>
/// Turns "scan these roots in this mode" into a full report.
/// </summary>
/// <remarks>
/// Two genuinely different strategies, one entry point:
/// <list type="bullet">
///   <item><description><b>Quick</b> — no volume walk at all. The safe-location analyzers
///   name the folders they care about and only those are measured, which is why it takes
///   seconds instead of minutes.</description></item>
///   <item><description><b>Deep / Custom</b> — one full enumeration pass builds the space map
///   and the top-N files, then the analyzers add classified candidates on top.</description></item>
/// </list>
/// Both paths assemble their report through <see cref="ScanResultBuilder"/>, so the summary
/// numbers mean the same thing whichever mode produced them.
/// </remarks>
public sealed class ScanService : IScanService
{
    private readonly FileSystemScanner _scanner;
    private readonly AnalyzerPipeline _pipeline;
    private readonly ISettingsService _settings;
    private readonly IDriveService _drives;
    private readonly IClock _clock;
    private readonly ILogger _logger;
    private readonly SemaphoreSlim _gate = new(1, 1);

    public ScanService(
        FileSystemScanner scanner,
        AnalyzerPipeline pipeline,
        ISettingsService settings,
        IDriveService drives,
        IClock clock,
        ILogger<ScanService>? logger = null)
    {
        _scanner = scanner ?? throw new ArgumentNullException(nameof(scanner));
        _pipeline = pipeline ?? throw new ArgumentNullException(nameof(pipeline));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _drives = drives ?? throw new ArgumentNullException(nameof(drives));
        _clock = clock ?? throw new ArgumentNullException(nameof(clock));
        _logger = logger ?? NullLogger<ScanService>.Instance;
    }

    public bool IsRunning { get; private set; }

    public ScanResult? LastResult { get; private set; }

    public event EventHandler<ScanResult>? ScanCompleted;

    public async Task<ScanResult> RunAsync(
        ScanMode mode,
        IReadOnlyList<string> roots,
        IProgress<ScanProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        if (!await _gate.WaitAsync(0, cancellationToken).ConfigureAwait(false))
        {
            throw new InvalidOperationException("A scan is already running.");
        }

        try
        {
            IsRunning = true;

            var snapshots = _drives.GetDrives();
            var settings = _settings.Current;
            var options = BuildOptions(mode, roots, snapshots);
            var startedAt = _clock.UtcNow;

            _logger.LogInformation(
                "Starting {Mode} scan over {RootCount} root(s): parallelism={Parallelism}, expectedBytes={ExpectedBytes}, analyzers={Analyzers}",
                mode, options.Roots.Count, options.ResolveParallelism(), options.ExpectedTotalBytes,
                string.Join(", ", _pipeline.SelectFor(mode, settings).Select(a => a.Name)));

            var result = mode == ScanMode.Quick
                ? await RunTargetedAsync(options, settings, snapshots, mode, startedAt, progress, cancellationToken).ConfigureAwait(false)
                : await RunFullPassAsync(options, settings, snapshots, mode, startedAt, progress, cancellationToken).ConfigureAwait(false);

            LastResult = result;

            _logger.LogInformation(
                "Scan finished: files={Files}, directories={Directories}, bytes={Bytes}, issues={Issues}, candidates={Candidates}, potential={Potential}, cancelled={Cancelled}",
                result.Statistics.FilesScanned, result.Statistics.DirectoriesScanned, result.Statistics.BytesScanned,
                result.Statistics.IssuesCount, result.Items.Count, result.PotentialCleanupBytes, result.WasCancelled);

            RaiseCompleted(result);

            return result;
        }
        catch (OperationCanceledException)
        {
            _logger.LogInformation("Scan cancelled by the user.");
            throw;
        }
        catch (Exception ex)
        {
            // Never swallow: the caller shows a short reason, the log keeps the detail.
            _logger.LogError(ex, "Scan failed.");
            throw;
        }
        finally
        {
            IsRunning = false;
            _gate.Release();
        }
    }

    /// <summary>
    /// Quick scan: measure only the whitelisted locations. No volume walk, no space map.
    /// </summary>
    private async Task<ScanResult> RunTargetedAsync(
        ScanOptions options,
        AppSettings settings,
        IReadOnlyList<DriveSnapshot> snapshots,
        ScanMode mode,
        DateTime startedAt,
        IProgress<ScanProgress>? progress,
        CancellationToken cancellationToken)
    {
        progress?.Report(new ScanProgress
        {
            Phase = ScanPhase.Analyzing,
            CurrentRoot = snapshots.FirstOrDefault()?.RootPath,
            RootsTotal = snapshots.Count,
            PercentComplete = null,       // targeted work: no honest denominator
        });

        var outcome = await _pipeline
            .RunAsync(AnalyzerInput.Empty(options, settings, snapshots), mode, cancellationToken)
            .ConfigureAwait(false);

        var completedAt = _clock.UtcNow;
        // Measured totals come from the analyzers, not from the candidates they kept:
        // a quick scan examines far more than it is allowed to offer.
        var statistics = new ScanStatistics
        {
            FilesScanned = Math.Max(outcome.MeasuredFiles, outcome.Items.Sum(i => (long)i.FileCount)),
            DirectoriesScanned = Math.Max(outcome.MeasuredDirectories, outcome.Items.Count(i => i.Kind == ScanItemKind.Directory)),
            BytesScanned = Math.Max(outcome.MeasuredBytes, outcome.Items.Sum(i => i.Size)),
            IssuesCount = outcome.Issues.Count,
            InaccessibleDirectories = outcome.Issues.Count(i => i.Kind == ScanIssueKind.AccessDenied),
            Elapsed = completedAt - startedAt,
            WasCancelled = cancellationToken.IsCancellationRequested,
        };

        progress?.Report(new ScanProgress
        {
            Phase = ScanPhase.Completed,
            FilesScanned = statistics.FilesScanned,
            DirectoriesScanned = statistics.DirectoriesScanned,
            BytesScanned = statistics.BytesScanned,
            IssuesCount = (int)Math.Min(int.MaxValue, statistics.IssuesCount),
            RootsTotal = snapshots.Count,
            RootsCompleted = snapshots.Count,
            Elapsed = statistics.Elapsed,
            PercentComplete = null,
        });

        return ScanResultBuilder.Build(
            mode,
            options.Depth,
            options.Roots,
            startedAt,
            completedAt,
            statistics,
            ScanResultBuilder.SortForReport(outcome.Items),
            largestDirectories: [],
            issues: outcome.Issues,
            drives: snapshots,
            appData: ExtractAppDataReport(outcome));
    }

    /// <summary>
    /// Deep / Custom: one full enumeration pass, then the analyzers classify what it found.
    /// </summary>
    private async Task<ScanResult> RunFullPassAsync(
        ScanOptions options,
        AppSettings settings,
        IReadOnlyList<DriveSnapshot> snapshots,
        ScanMode mode,
        DateTime startedAt,
        IProgress<ScanProgress>? progress,
        CancellationToken cancellationToken)
    {
        var collector = new ScanResultCollector(options);

        ScanStatistics statistics;
        try
        {
            statistics = await _scanner.ScanAsync(options, collector, progress, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            statistics = new ScanStatistics { WasCancelled = true, Elapsed = _clock.UtcNow - startedAt };
        }

        var passResult = collector.BuildResult(statistics, mode, startedAt, _clock.UtcNow, snapshots);

        // Analyzers run even on a cancelled pass: a partial map is still useful.
        var outcome = await _pipeline.RunAsync(
            new AnalyzerInput(options, settings, snapshots, passResult.LargestDirectories, passResult.LargestFiles),
            mode,
            cancellationToken).ConfigureAwait(false);

        var completedAt = _clock.UtcNow;
        var mergedItems = ScanResultBuilder.SortForReport(passResult.Items.Concat(outcome.Items));
        var mergedIssues = passResult.Issues.Concat(outcome.Issues).ToArray();

        return ScanResultBuilder.Build(
            mode,
            options.Depth,
            options.Roots,
            startedAt,
            completedAt,
            statistics with
            {
                IssuesCount = statistics.IssuesCount + outcome.Issues.Count,
                Elapsed = completedAt - startedAt,
                PeakTrackedDirectories = collector.Aggregator.PeakTrackedCount,
            },
            mergedItems,
            passResult.LargestDirectories,
            mergedIssues,
            snapshots,
            ExtractAppDataReport(outcome));
    }

    /// <summary>Pulls the structured AppData report out of the analyzer run, if one was produced.</summary>
    private static AppDataReport? ExtractAppDataReport(AnalyzerRunOutcome outcome) =>
        outcome.Reports.TryGetValue(AppDataAnalyzer.ReportKey, out var report) ? report as AppDataReport : null;

    /// <summary>
    /// Notifies subscribers. This runs on a background thread (the whole pipeline uses
    /// ConfigureAwait(false)), so subscribers must marshal to the UI thread themselves.
    /// A throwing subscriber must never turn a successful scan into a failure.
    /// </summary>
    private void RaiseCompleted(ScanResult result)
    {
        var handler = ScanCompleted;
        if (handler is null)
        {
            return;
        }

        foreach (var subscriber in handler.GetInvocationList())
        {
            try
            {
                ((EventHandler<ScanResult>)subscriber)(this, result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "A ScanCompleted subscriber failed; the scan result itself is valid.");
            }
        }
    }

    /// <summary>
    /// Merges user settings with the requested scope and computes the byte total that
    /// makes an honest percentage possible for whole-volume scans.
    /// </summary>
    public ScanOptions BuildOptions(ScanMode mode, IReadOnlyList<string> roots, IReadOnlyList<DriveSnapshot> snapshots)
    {
        var settings = _settings.Current;
        var effectiveRoots = ResolveRoots(mode, roots, snapshots);
        var options = settings.ToScanOptions(mode, effectiveRoots);

        // Only whole volumes provide a meaningful denominator. A folder-scoped or targeted
        // scan stays indeterminate instead of showing a made-up percentage.
        long expected = 0;
        foreach (var root in options.Roots)
        {
            if (!PathUtils.IsRoot(root))
            {
                continue;
            }

            var snapshot = snapshots.FirstOrDefault(s => string.Equals(s.RootPath, root, PathUtils.Comparison));
            if (snapshot is { IsReady: true })
            {
                expected += snapshot.UsedBytes;
            }
        }

        return (options with { ExpectedTotalBytes = expected }).Normalise();
    }

    private static IReadOnlyList<string> ResolveRoots(ScanMode mode, IReadOnlyList<string> roots, IReadOnlyList<DriveSnapshot> snapshots)
    {
        if (roots.Count > 0)
        {
            return roots;
        }

        if (mode == ScanMode.Deep)
        {
            // Every fixed, ready volume.
            return [.. snapshots.Where(s => s.IsScannableByDefault).Select(s => s.RootPath)];
        }

        // Quick scan enumerates its own targets through the analyzers, so it needs no roots.
        return [];
    }
}
