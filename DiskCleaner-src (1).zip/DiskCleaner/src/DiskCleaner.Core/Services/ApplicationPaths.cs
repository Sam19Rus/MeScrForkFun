using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Services;

/// <summary>
/// Where the application keeps its own data. Everything is inside the user's
/// profile: nothing is written to Program Files, nothing needs elevation, and
/// nothing leaves the machine.
/// </summary>
public sealed class ApplicationPaths
{
    public const string DirectoryName = "DiskCleaner";

    public ApplicationPaths(IEnvironmentInfo? environment = null, IFileSystem? fileSystem = null)
    {
        Environment = environment ?? new SystemEnvironmentInfo(fileSystem);
        FileSystem = fileSystem ?? new PhysicalFileSystem();
        RootDirectory = ResolveRoot(Environment);
    }

    public IEnvironmentInfo Environment { get; }

    public IFileSystem FileSystem { get; }

    /// <summary><c>%LOCALAPPDATA%\DiskCleaner</c></summary>
    public string RootDirectory { get; }

    public string SettingsFile => PathUtils.Combine(RootDirectory, "settings.json");

    public string HistoryFile => PathUtils.Combine(RootDirectory, "history.json");

    public string LogsDirectory => PathUtils.Combine(RootDirectory, "logs");

    public string ScanCacheDirectory => PathUtils.Combine(RootDirectory, "cache");

    public string LogFileFor(DateTime utcDate) =>
        PathUtils.Combine(LogsDirectory, $"diskcleaner-{utcDate:yyyy-MM-dd}.log");

    /// <summary>Creates the directory tree. Failures are non-fatal: the app must still start.</summary>
    public bool EnsureCreated()
    {
        var ok = FileSystem.TryCreateDirectory(RootDirectory);
        ok &= FileSystem.TryCreateDirectory(LogsDirectory);
        ok &= FileSystem.TryCreateDirectory(ScanCacheDirectory);
        return ok;
    }

    private static string ResolveRoot(IEnvironmentInfo environment)
    {
        var folders = environment.Folders;

        var basePath = !string.IsNullOrWhiteSpace(folders.LocalAppData) ? folders.LocalAppData
            : !string.IsNullOrWhiteSpace(folders.RoamingAppData) ? folders.RoamingAppData
            : !string.IsNullOrWhiteSpace(folders.UserProfile) ? folders.UserProfile
            : null;

        if (string.IsNullOrWhiteSpace(basePath))
        {
            // Last resort: a hidden folder next to the temporary directory.
            basePath = Path.GetTempPath();
            return PathUtils.Combine(basePath, "." + DirectoryName);
        }

        return PathUtils.Combine(basePath!, DirectoryName);
    }
}
