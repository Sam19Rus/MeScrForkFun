using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Services;

/// <summary>Volume information, without any UI dependency.</summary>
public interface IDriveService
{
    /// <summary>All volumes currently visible to the OS, including not-ready ones.</summary>
    IReadOnlyList<DriveSnapshot> GetDrives();

    /// <summary>Only fixed local volumes that are ready — the default scan targets.</summary>
    IReadOnlyList<DriveSnapshot> GetScannableDrives();

    DriveSnapshot? GetDrive(string rootPath);

    /// <summary>Free bytes on a volume, or <c>null</c> when it cannot be read.</summary>
    long? GetFreeBytes(string rootPath);
}

/// <summary>Portable implementation based on <see cref="DriveInfo"/>.</summary>
public sealed class DriveService(ILogger<DriveService>? logger = null) : IDriveService
{
    private readonly ILogger _logger = logger ?? NullLogger<DriveService>.Instance;

    public IReadOnlyList<DriveSnapshot> GetDrives()
    {
        var result = new List<DriveSnapshot>();

        DriveInfo[] drives;
        try
        {
            drives = DriveInfo.GetDrives();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            _logger.LogWarning(ex, "Could not enumerate volumes");
            return result;
        }

        foreach (var drive in drives)
        {
            try
            {
                result.Add(Map(drive));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
            {
                // A card reader with no media throws on almost every property.
                result.Add(new DriveSnapshot
                {
                    RootPath = SafeName(drive),
                    DriveType = SafeTypeName(drive),
                    IsReady = false,
                    IsScannableByDefault = false,
                });
            }
        }

        return result;
    }

    public IReadOnlyList<DriveSnapshot> GetScannableDrives() =>
        [.. GetDrives().Where(d => d.IsScannableByDefault)];

    public DriveSnapshot? GetDrive(string rootPath)
    {
        var normalized = PathUtils.Normalize(rootPath);
        var root = PathUtils.GetDriveRoot(normalized) ?? normalized;
        return GetDrives().FirstOrDefault(d => string.Equals(d.RootPath, root, PathUtils.Comparison));
    }

    public long? GetFreeBytes(string rootPath)
    {
        try
        {
            var info = new DriveInfo(PathUtils.GetDriveRoot(PathUtils.Normalize(rootPath)) ?? rootPath);
            return info.IsReady ? info.AvailableFreeSpace : null;
        }
        catch (Exception ex) when (ex is IOException or ArgumentException or UnauthorizedAccessException or NotSupportedException)
        {
            return null;
        }
    }

    private static DriveSnapshot Map(DriveInfo drive)
    {
        var isReady = drive.IsReady;
        var total = isReady ? drive.TotalSize : 0;
        var free = isReady ? drive.AvailableFreeSpace : 0;

        return new DriveSnapshot
        {
            RootPath = PathUtils.Normalize(drive.Name),
            Label = isReady ? drive.VolumeLabel : string.Empty,
            DriveType = drive.DriveType.ToString(),
            FileSystemName = isReady ? drive.DriveFormat : string.Empty,
            TotalBytes = total,
            FreeBytes = free,
            IsReady = isReady,
            // Only fixed, ready volumes are scanned by default. Removable media and
            // network shares are opt-in: their contents are rarely "junk" and a
            // network scan can be very slow.
            IsScannableByDefault = isReady && drive.DriveType == DriveType.Fixed && total > 0,
            RequiresElevation = false,
        };
    }

    private static string SafeName(DriveInfo drive)
    {
        try
        {
            return PathUtils.Normalize(drive.Name);
        }
        catch (IOException)
        {
            return string.Empty;
        }
    }

    private static string SafeTypeName(DriveInfo drive)
    {
        try
        {
            return drive.DriveType.ToString();
        }
        catch (IOException)
        {
            return nameof(DriveType.Unknown);
        }
    }
}
