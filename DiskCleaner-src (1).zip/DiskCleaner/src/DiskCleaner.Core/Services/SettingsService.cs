using System.Text.Json;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Services;

/// <summary>Read/write access to the user settings.</summary>
public interface ISettingsService
{
    /// <summary>The live settings object. Never null after construction.</summary>
    AppSettings Current { get; }

    /// <summary>Loads from disk, falling back to defaults on any problem.</summary>
    Task<AppSettings> LoadAsync(CancellationToken cancellationToken = default);

    /// <summary>Persists atomically (temp file + replace).</summary>
    Task SaveAsync(CancellationToken cancellationToken = default);

    /// <summary>Applies a mutation and raises <see cref="SettingsChanged"/>. Does not persist.</summary>
    AppSettings Update(Action<AppSettings> mutate);

    /// <summary>Last load/save failure, surfaced in Settings → Diagnostics. Never a stack trace.</summary>
    string? LastError { get; }

    event EventHandler<AppSettings>? SettingsChanged;
}

/// <summary>JSON-file backed settings stored under <c>%LOCALAPPDATA%\DiskCleaner</c>.</summary>
public sealed class JsonSettingsService : ISettingsService
{
    private const int CurrentSchemaVersion = 1;

    private readonly ApplicationPaths _paths;
    private readonly ILogger _logger;
    private readonly object _gate = new();
    private readonly SemaphoreSlim _ioGate = new(1, 1);

    private AppSettings _current = new();

    public JsonSettingsService(ApplicationPaths paths, ILogger<JsonSettingsService>? logger = null)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
        _logger = logger ?? NullLogger<JsonSettingsService>.Instance;
    }

    public AppSettings Current
    {
        get { lock (_gate) { return _current; } }
    }

    public string? LastError { get; private set; }

    public event EventHandler<AppSettings>? SettingsChanged;

    public async Task<AppSettings> LoadAsync(CancellationToken cancellationToken = default)
    {
        await _ioGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var path = _paths.SettingsFile;
            if (!_paths.FileSystem.FileExists(path))
            {
                lock (_gate)
                {
                    _current = new AppSettings();
                }

                return Current;
            }

            var json = await Task.Run(() => _paths.FileSystem.TryReadAllText(path), cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(json))
            {
                lock (_gate)
                {
                    _current = new AppSettings();
                }

                return Current;
            }

            var loaded = JsonSerializer.Deserialize(json, DiskCleanerJsonContext.Default.AppSettings);
            if (loaded is null)
            {
                LastError = "The settings file could not be read and was reset to defaults.";
                lock (_gate)
                {
                    _current = new AppSettings();
                }

                return Current;
            }

            if (loaded.SchemaVersion > CurrentSchemaVersion)
            {
                // Written by a newer version: keep what we understand, do not overwrite silently.
                _logger.LogWarning("Settings file has schema version {Version}, this build understands {Current}", loaded.SchemaVersion, CurrentSchemaVersion);
                LastError = $"Settings were created by a newer version (schema {loaded.SchemaVersion}).";
            }

            loaded.SchemaVersion = CurrentSchemaVersion;
            loaded.Sanitise();

            lock (_gate)
            {
                _current = loaded;
            }

            return Current;
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            LastError = "Settings could not be loaded: " + ex.Message;
            _logger.LogWarning(ex, "Failed to load settings from {Path}", _paths.SettingsFile);
            lock (_gate)
            {
                _current = new AppSettings();
            }

            return Current;
        }
        finally
        {
            _ioGate.Release();
        }
    }

    public async Task SaveAsync(CancellationToken cancellationToken = default)
    {
        await _ioGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var snapshot = Current;
            var json = JsonSerializer.Serialize(snapshot, DiskCleanerJsonContext.Default.AppSettings);

            await Task.Run(() =>
            {
                _paths.EnsureCreated();
                _paths.FileSystem.WriteAllTextAtomic(_paths.SettingsFile, json);
            }, cancellationToken).ConfigureAwait(false);

            LastError = null;
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            LastError = "Settings could not be saved: " + ex.Message;
            _logger.LogError(ex, "Failed to save settings to {Path}", _paths.SettingsFile);
        }
        finally
        {
            _ioGate.Release();
        }
    }

    public AppSettings Update(Action<AppSettings> mutate)
    {
        ArgumentNullException.ThrowIfNull(mutate);

        AppSettings snapshot;
        lock (_gate)
        {
            mutate(_current);
            _current.Sanitise();
            snapshot = _current;
        }

        SettingsChanged?.Invoke(this, snapshot);
        return snapshot;
    }
}
