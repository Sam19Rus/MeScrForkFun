using System.Text.Json;
using System.Text.Json.Serialization;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Services;

/// <summary>
/// Source-generated serialization context.
/// </summary>
/// <remarks>
/// Required rather than optional: the release build is a single-file executable,
/// and reflection-based serialization would (a) emit trimming warnings and
/// (b) risk failing at runtime on a type the linker removed. Generated code keeps
/// settings/history files stable across versions.
/// </remarks>
[JsonSourceGenerationOptions(
    WriteIndented = true,
    PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase,
    UseStringEnumConverter = true,
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    GenerationMode = JsonSourceGenerationMode.Default)]
[JsonSerializable(typeof(AppSettings))]
[JsonSerializable(typeof(CleanupRunRecord))]
[JsonSerializable(typeof(CategoryBreakdown))]
[JsonSerializable(typeof(SkippedFile))]
[JsonSerializable(typeof(DeletedEntry))]
[JsonSerializable(typeof(HistoryStore))]
[JsonSerializable(typeof(List<CleanupRunRecord>))]
internal sealed partial class DiskCleanerJsonContext : JsonSerializerContext
{
    public static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.General)
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() },
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };
}

/// <summary>On-disk shape of <c>history.json</c>.</summary>
public sealed class HistoryStore
{
    public int SchemaVersion { get; set; } = 1;

    public List<CleanupRunRecord> Runs { get; set; } = [];
}
