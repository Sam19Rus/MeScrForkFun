using System.Text.Json;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Services;

/// <summary>
/// Append-only record of executed cleanups.
/// The MVP does not restore files, so the history is the user's audit trail:
/// what was removed, when, how much was freed and what had to be skipped.
/// </summary>
public interface IHistoryService
{
    IReadOnlyList<CleanupRunRecord> Records { get; }

    long TotalFreedBytes { get; }

    string? LastError { get; }

    event EventHandler? HistoryChanged;

    Task<IReadOnlyList<CleanupRunRecord>> LoadAsync(CancellationToken cancellationToken = default);

    Task AppendAsync(CleanupRunRecord record, CancellationToken cancellationToken = default);

    Task RemoveAsync(Guid id, CancellationToken cancellationToken = default);

    Task ClearAsync(CancellationToken cancellationToken = default);
}

/// <summary>JSON-file backed history under <c>%LOCALAPPDATA%\DiskCleaner\history.json</c>.</summary>
public sealed class JsonHistoryService : IHistoryService
{
    private readonly ApplicationPaths _paths;
    private readonly ISettingsService _settings;
    private readonly ILogger _logger;
    private readonly object _gate = new();
    private readonly SemaphoreSlim _ioGate = new(1, 1);

    private List<CleanupRunRecord> _records = [];

    public JsonHistoryService(ApplicationPaths paths, ISettingsService settings, ILogger<JsonHistoryService>? logger = null)
    {
        _paths = paths ?? throw new ArgumentNullException(nameof(paths));
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _logger = logger ?? NullLogger<JsonHistoryService>.Instance;
    }

    public IReadOnlyList<CleanupRunRecord> Records
    {
        get { lock (_gate) { return _records.ToArray(); } }
    }

    public long TotalFreedBytes
    {
        get { lock (_gate) { return _records.Sum(r => r.FreedBytes); } }
    }

    public string? LastError { get; private set; }

    public event EventHandler? HistoryChanged;

    public async Task<IReadOnlyList<CleanupRunRecord>> LoadAsync(CancellationToken cancellationToken = default)
    {
        await _ioGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var path = _paths.HistoryFile;
            if (!_paths.FileSystem.FileExists(path))
            {
                return Records;
            }

            var json = await Task.Run(() => _paths.FileSystem.TryReadAllText(path), cancellationToken).ConfigureAwait(false);
            if (string.IsNullOrWhiteSpace(json))
            {
                return Records;
            }

            var store = JsonSerializer.Deserialize(json, DiskCleanerJsonContext.Default.HistoryStore);
            lock (_gate)
            {
                _records = store?.Runs is null ? [] : [.. store.Runs.OrderByDescending(r => r.StartedAtUtc)];
            }

            TrimToLimit();
            return Records;
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            LastError = "History could not be loaded: " + ex.Message;
            _logger.LogWarning(ex, "Failed to load history from {Path}", _paths.HistoryFile);
            return Records;
        }
        finally
        {
            _ioGate.Release();
        }
    }

    public async Task AppendAsync(CleanupRunRecord record, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(record);

        lock (_gate)
        {
            _records.Insert(0, record);
        }

        TrimToLimit();
        await PersistAsync(cancellationToken).ConfigureAwait(false);
        HistoryChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task RemoveAsync(Guid id, CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            _records.RemoveAll(r => r.Id == id);
        }

        await PersistAsync(cancellationToken).ConfigureAwait(false);
        HistoryChanged?.Invoke(this, EventArgs.Empty);
    }

    public async Task ClearAsync(CancellationToken cancellationToken = default)
    {
        lock (_gate)
        {
            _records.Clear();
        }

        await PersistAsync(cancellationToken).ConfigureAwait(false);
        HistoryChanged?.Invoke(this, EventArgs.Empty);
    }

    private void TrimToLimit()
    {
        var limit = Math.Max(10, _settings.Current.MaxHistoryRecords);
        lock (_gate)
        {
            if (_records.Count > limit)
            {
                _records.RemoveRange(limit, _records.Count - limit);
            }
        }
    }

    private async Task PersistAsync(CancellationToken cancellationToken)
    {
        if (!_settings.Current.SaveHistoryAutomatically)
        {
            return;
        }

        await _ioGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var store = new HistoryStore { SchemaVersion = 2 };
            lock (_gate)
            {
                store.Runs = [.. _records];
            }

            var json = JsonSerializer.Serialize(store, DiskCleanerJsonContext.Default.HistoryStore);
            await Task.Run(() =>
            {
                _paths.EnsureCreated();
                _paths.FileSystem.WriteAllTextAtomic(_paths.HistoryFile, json);
            }, cancellationToken).ConfigureAwait(false);

            LastError = null;
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException or NotSupportedException)
        {
            LastError = "History could not be saved: " + ex.Message;
            _logger.LogError(ex, "Failed to persist history to {Path}", _paths.HistoryFile);
        }
        finally
        {
            _ioGate.Release();
        }
    }
}
