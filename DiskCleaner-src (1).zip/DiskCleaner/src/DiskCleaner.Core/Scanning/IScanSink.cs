using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Receives the scan stream. Implementations are called concurrently from several
/// worker threads and must be thread-safe. They must also be cheap: the scanner
/// enumerates millions of entries.
/// </summary>
public interface IScanSink
{
    /// <summary>Called once per directory, before its children are enumerated.</summary>
    void OnDirectory(in ScannedEntry entry, int depth);

    /// <summary>
    /// Called once per file. <paramref name="directory"/> is the parent path, supplied
    /// by the scanner so sinks do not have to re-derive (and re-allocate) it per file.
    /// </summary>
    void OnFile(in ScannedEntry entry, int depth, string directory);

    /// <summary>Called for anything that could not be processed.</summary>
    void OnIssue(ScanIssue issue);
}

/// <summary>Fans the scan stream out to several sinks (e.g. aggregator + analyzer).</summary>
public sealed class CompositeScanSink(params IScanSink[] sinks) : IScanSink
{
    private readonly IScanSink[] _sinks = sinks ?? [];

    public void OnDirectory(in ScannedEntry entry, int depth)
    {
        foreach (var sink in _sinks)
        {
            sink.OnDirectory(in entry, depth);
        }
    }

    public void OnFile(in ScannedEntry entry, int depth, string directory)
    {
        foreach (var sink in _sinks)
        {
            sink.OnFile(in entry, depth, directory);
        }
    }

    public void OnIssue(ScanIssue issue)
    {
        foreach (var sink in _sinks)
        {
            sink.OnIssue(issue);
        }
    }
}

/// <summary>Discards everything. Used by measurements and by analyzer-only passes.</summary>
public sealed class NullScanSink : IScanSink
{
    public static readonly NullScanSink Instance = new();

    public void OnDirectory(in ScannedEntry entry, int depth)
    {
    }

    public void OnFile(in ScannedEntry entry, int depth, string directory)
    {
    }

    public void OnIssue(ScanIssue issue)
    {
    }
}
