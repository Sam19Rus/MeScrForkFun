using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Translates raw exceptions into the small, honest set of reasons a user can act on.
/// Stack traces never leave the logging layer.
/// </summary>
public static class ScanIssueFactory
{
    private const int FacilityWin32 = unchecked((int)0x80070000);

    public static ScanIssue FromException(string path, Exception exception, long estimatedSize = 0)
    {
        var errorCode = TryGetWin32Error(exception);
        var (kind, reasonKey, reason) = Classify(exception, errorCode);

        return new ScanIssue
        {
            Path = path,
            Kind = kind,
            Reason = reason,
            ReasonKey = reasonKey,
            ExceptionType = exception.GetType().Name,
            ErrorCode = errorCode,
            EstimatedSize = estimatedSize,
        };
    }

    public static ScanIssue Create(string path, ScanIssueKind kind, string reasonKey, string reason, long estimatedSize = 0) =>
        new()
        {
            Path = path,
            Kind = kind,
            Reason = reason,
            ReasonKey = reasonKey,
            EstimatedSize = estimatedSize,
        };

    private static (ScanIssueKind Kind, string ReasonKey, string Reason) Classify(Exception exception, int? errorCode)
    {
        if (exception is OperationCanceledException)
        {
            return (ScanIssueKind.Cancelled, "issue.cancelled", "Cancelled");
        }

        if (exception is PathTooLongException)
        {
            return (ScanIssueKind.PathTooLong, "issue.path-too-long", "Path is too long to be processed");
        }

        if (exception is UnauthorizedAccessException)
        {
            return (ScanIssueKind.AccessDenied, "issue.access-denied", "Access denied");
        }

        if (exception is DirectoryNotFoundException or FileNotFoundException)
        {
            return (ScanIssueKind.NotFound, "issue.not-found", "No longer exists (removed or renamed during the scan)");
        }

        if (exception is IOException)
        {
            return errorCode switch
            {
                5 => (ScanIssueKind.AccessDenied, "issue.access-denied", "Access denied"),
                32 => (ScanIssueKind.FileInUse, "issue.file-in-use", "The file is being used by another process"),
                33 => (ScanIssueKind.FileInUse, "issue.file-in-use", "The file is locked by another process"),
                2 or 3 => (ScanIssueKind.NotFound, "issue.not-found", "No longer exists (removed or renamed during the scan)"),
                206 or 0xCE => (ScanIssueKind.PathTooLong, "issue.path-too-long", "Path is too long to be processed"),
                _ => (ScanIssueKind.IoError, "issue.io-error", "Input/output error"),
            };
        }

        return (ScanIssueKind.Unknown, "issue.unknown", "Could not be processed");
    }

    /// <summary>Extracts the Win32 error code from an HRESULT-shaped <see cref="Exception.HResult"/>.</summary>
    public static int? TryGetWin32Error(Exception exception)
    {
        var hresult = exception.HResult;
        if ((hresult & unchecked((int)0xFFFF0000)) == FacilityWin32)
        {
            return hresult & 0xFFFF;
        }

        return null;
    }
}
