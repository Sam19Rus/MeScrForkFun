using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Decides, per entry, whether the scanner should report it and whether it should
/// descend into it. Pure logic, no IO — directly unit-testable.
/// </summary>
public sealed class ScanFilter
{
    private readonly (string WithSeparator, string Exact)[] _excludedPrefixes;
    private readonly HashSet<string> _excludedExtensions;

    public ScanFilter(
        IReadOnlyList<string>? excludedPaths = null,
        IReadOnlyList<string>? excludedExtensions = null,
        long minReportedFileSize = 0,
        int? maxDepth = null,
        bool includeHiddenAndSystem = true)
    {
        MinReportedFileSize = Math.Max(0, minReportedFileSize);
        MaxDepth = maxDepth;
        IncludeHiddenAndSystem = includeHiddenAndSystem;

        _excludedPrefixes = (excludedPaths ?? [])
            .Where(p => !string.IsNullOrWhiteSpace(p))
            .Select(p => PathUtils.Normalize(p))
            .Where(p => p.Length > 0)
            .Distinct(PathUtils.Comparer)
            .Select(p => (WithSeparator: PathUtils.EnsureTrailingSeparator(p), Exact: p))
            .ToArray();

        _excludedExtensions = new HashSet<string>(
            (excludedExtensions ?? [])
                .Where(e => !string.IsNullOrWhiteSpace(e))
                .Select(e => e.StartsWith('.') ? e : "." + e)
                .Select(e => e.ToLowerInvariant()),
            StringComparer.Ordinal);
    }

    public static ScanFilter FromOptions(ScanOptions options) => new(
        options.ExcludedPaths,
        options.ExcludedExtensions,
        options.MinReportedFileSize,
        options.MaxDepth,
        options.IncludeHiddenAndSystem);

    public long MinReportedFileSize { get; }

    public int? MaxDepth { get; }

    public bool IncludeHiddenAndSystem { get; }

    public int ExcludedPathCount => _excludedPrefixes.Length;

    /// <summary><c>true</c> when the path is one of the excluded prefixes or lives below one.</summary>
    public bool IsPathExcluded(string? path)
    {
        if (_excludedPrefixes.Length == 0 || string.IsNullOrWhiteSpace(path))
        {
            return false;
        }

        var normalized = PathUtils.Normalize(path);
        foreach (var (withSeparator, exact) in _excludedPrefixes)
        {
            if (string.Equals(normalized, exact, PathUtils.Comparison) ||
                normalized.StartsWith(withSeparator, PathUtils.Comparison))
            {
                return true;
            }
        }

        return false;
    }

    public bool IsExtensionExcluded(string? fileName)
    {
        if (_excludedExtensions.Count == 0)
        {
            return false;
        }

        var extension = PathUtils.GetExtensionOrNull(fileName ?? string.Empty);
        return extension is not null && _excludedExtensions.Contains(extension);
    }

    /// <summary>Depth 0 is the root itself.</summary>
    public bool IsDepthAllowed(int depth) => MaxDepth is null || depth <= MaxDepth.Value;

    /// <summary>Whether a file should be reported individually (it is still counted in sizes).</summary>
    public bool ShouldReportFile(in ScannedEntry entry)
    {
        if (entry.IsDirectory)
        {
            return false;
        }

        if (!IncludeHiddenAndSystem && (entry.IsHidden || entry.IsSystem))
        {
            return false;
        }

        if (IsExtensionExcluded(entry.Name))
        {
            return false;
        }

        return entry.Size >= MinReportedFileSize;
    }

    /// <summary>Whether the scanner may descend into this directory entry.</summary>
    public bool ShouldEnterDirectory(in ScannedEntry entry, int childDepth)
    {
        if (!entry.IsDirectory)
        {
            return false;
        }

        if (!IsDepthAllowed(childDepth))
        {
            return false;
        }

        if (!IncludeHiddenAndSystem && (entry.IsHidden || entry.IsSystem))
        {
            return false;
        }

        return !IsPathExcluded(entry.FullPath);
    }
}
