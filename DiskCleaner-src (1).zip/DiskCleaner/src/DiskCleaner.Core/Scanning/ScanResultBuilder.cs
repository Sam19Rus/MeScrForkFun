using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Assembles a <see cref="ScanResult"/> from whatever a run produced.
/// </summary>
/// <remarks>
/// Extracted so that the full-volume pass and the targeted quick pass build their report
/// the same way: the summary numbers, the confidence tiers and the category totals must
/// not drift between the two code paths.
/// </remarks>
public static class ScanResultBuilder
{
    public static ScanResult Build(
        ScanMode mode,
        ScanDepth depth,
        IReadOnlyList<string> roots,
        DateTime startedAtUtc,
        DateTime completedAtUtc,
        ScanStatistics statistics,
        IReadOnlyList<ScanItem> items,
        IReadOnlyList<DirectoryAggregate> largestDirectories,
        IReadOnlyList<ScanIssue> issues,
        IReadOnlyList<DriveSnapshot> drives,
        AppDataReport? appData = null)
    {
        // Classification tiers count only items that may actually be removed.
        var selectable = items.Where(i => i.IsDeletable && !i.IsProtected).ToArray();

        var byCategory = selectable
            .GroupBy(i => i.Category)
            .ToDictionary(g => g.Key, g => g.Sum(i => i.Size));

        var countByCategory = selectable
            .GroupBy(i => i.Category)
            .ToDictionary(g => g.Key, g => g.Count());

        var byConfidence = selectable
            .GroupBy(i => i.Confidence)
            .ToDictionary(g => g.Key, g => g.Sum(i => i.Size));

        long Sum(CleanupConfidence confidence) =>
            byConfidence.TryGetValue(confidence, out var value) ? value : 0;

        return new ScanResult
        {
            Mode = mode,
            Depth = depth,
            Roots = roots,
            StartedAtUtc = startedAtUtc,
            CompletedAtUtc = completedAtUtc,
            Statistics = statistics,
            Items = items,
            LargestFiles = [.. items.Where(i => i.Kind == ScanItemKind.File).OrderByDescending(i => i.Size).Take(200)],
            LargestDirectories = largestDirectories,
            Issues = issues,
            Drives = drives,
            PotentialCleanupBytes = selectable.Sum(i => i.Size),
            SafeBytes = Sum(CleanupConfidence.Safe),
            LikelyBytes = Sum(CleanupConfidence.Likely),
            NeedsReviewBytes = Sum(CleanupConfidence.NeedsReview),
            BytesByCategory = byCategory,
            CountByCategory = countByCategory,
            BytesByConfidence = byConfidence,
            AppData = appData,
        };
    }

    /// <summary>Sorted, largest first, ready for the report.</summary>
    public static IReadOnlyList<ScanItem> SortForReport(IEnumerable<ScanItem> items) =>
        [.. items.OrderByDescending(i => i.Size).ThenBy(i => i.Path, PathUtils.Comparer)];
}
