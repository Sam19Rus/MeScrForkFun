using DiskCleaner.Core.Infrastructure.Collections;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Default <see cref="IScanSink"/>: turns the raw entry stream into a bounded,
/// reportable result — a directory size map, a top-N file ranking and the list of
/// everything that had to be skipped.
/// </summary>
/// <remarks>
/// Memory is bounded by design:
/// <list type="bullet">
///   <item><description>directory counters: one per tracked directory, capped by
///   <see cref="ScanOptions.MaxTrackedDirectories"/>;</description></item>
///   <item><description>largest files: fixed <see cref="ScanOptions.TopFilesCapacity"/> entries;</description></item>
///   <item><description>issues: fixed <see cref="MaxRetainedIssues"/> entries plus a dropped counter,
///   because a volume with broken ACLs can produce hundreds of thousands of them.</description></item>
/// </list>
/// </remarks>
public sealed class ScanResultCollector : IScanSink
{
    /// <summary>Hard cap on retained issues so a mis-permissioned volume cannot exhaust memory.</summary>
    public const int MaxRetainedIssues = 20_000;

    private readonly ScanOptions _options;
    private readonly ScanFilter _filter;
    private readonly TopNCollector<ScanItem> _largestFiles;
    private readonly List<ScanIssue> _issues = new(256);
    private readonly object _issueGate = new();

    private long _issuesTotal;
    private long _issuesDropped;
    private long _bytesFound;

    public ScanResultCollector(ScanOptions options, DirectorySizeAggregator? aggregator = null)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _filter = ScanFilter.FromOptions(options);
        Aggregator = aggregator ?? new DirectorySizeAggregator(options.MaxTrackedDirectories);
        _largestFiles = new TopNCollector<ScanItem>(
            Math.Max(10, options.TopFilesCapacity),
            static item => item.Size);
    }

    public DirectorySizeAggregator Aggregator { get; }

    /// <summary>The options this collector was built with (reused by tree measurements).</summary>
    public ScanOptions Options => _options;

    public long IssuesTotal => Interlocked.Read(ref _issuesTotal);

    public long IssuesDropped => Interlocked.Read(ref _issuesDropped);

    public void OnDirectory(in ScannedEntry entry, int depth)
    {
        Aggregator.TryRegisterDirectory(
            entry.FullPath,
            depth,
            PathUtils.GetParent(entry.FullPath),
            entry.Name,
            entry.LastWriteUtc);
    }

    public void OnFile(in ScannedEntry entry, int depth, string directory)
    {
        // Sizes are always accounted for, even for files we do not report.
        Aggregator.AddFile(directory, entry.Size);

        if (entry.Size < _options.LargeFileThresholdBytes)
        {
            return;
        }

        if (!_filter.ShouldReportFile(entry))
        {
            return;
        }

        var item = ScanItem.FromEntry(entry, WellKnownAnalyzers.FileSystemScanner);
        if (_largestFiles.TryAdd(item))
        {
            Interlocked.Add(ref _bytesFound, entry.Size);
        }
    }

    public void OnIssue(ScanIssue issue)
    {
        var total = Interlocked.Increment(ref _issuesTotal);

        lock (_issueGate)
        {
            if (_issues.Count >= MaxRetainedIssues)
            {
                Interlocked.Increment(ref _issuesDropped);
                return;
            }

            _issues.Add(issue);
        }
    }

    /// <summary>Snapshot of the retained issues, ordered by size descending then path.</summary>
    public IReadOnlyList<ScanIssue> GetIssues()
    {
        lock (_issueGate)
        {
            return _issues
                .OrderByDescending(i => i.EstimatedSize)
                .ThenBy(i => i.Path, PathUtils.Comparer)
                .ToArray();
        }
    }

    /// <summary>Largest files found, biggest first.</summary>
    public IReadOnlyList<ScanItem> GetLargestFiles() => _largestFiles.ToDescendingList();

    /// <summary>Largest directories by subtree size.</summary>
    public IReadOnlyList<DirectoryAggregate> GetLargestDirectories(int count) =>
        Aggregator.BuildAggregates()
            .OrderByDescending(d => d.SubtreeBytes)
            .Take(Math.Max(1, count))
            .ToArray();

    /// <summary>
    /// Assembles the report from the full-volume pass. Summary numbers are computed by
    /// <see cref="ScanResultBuilder"/> so the targeted quick pass cannot drift from them.
    /// </summary>
    public ScanResult BuildResult(
        ScanStatistics statistics,
        ScanMode mode,
        DateTime startedAtUtc,
        DateTime completedAtUtc,
        IReadOnlyList<DriveSnapshot>? drives = null) =>
        ScanResultBuilder.Build(
            mode,
            _options.Depth,
            _options.Roots,
            startedAtUtc,
            completedAtUtc,
            statistics with { PeakTrackedDirectories = Aggregator.PeakTrackedCount },
            ScanResultBuilder.SortForReport(GetLargestFiles()),
            GetLargestDirectories(_options.TopDirectoriesCapacity),
            GetIssues(),
            drives ?? [],
            appData: null);
}

/// <summary>Stable analyzer identifiers, so <c>SourceAnalyzer</c> never drifts into magic strings.</summary>
public static class WellKnownAnalyzers
{
    public const string FileSystemScanner = "FileSystemScanner";
    public const string Drive = "DriveAnalyzer";
    public const string LargeFiles = "LargeFilesAnalyzer";
    public const string AppData = "AppDataAnalyzer";
    public const string Temp = "TempAnalyzer";
    public const string BrowserCache = "BrowserCacheAnalyzer";
    public const string LeftoverApplications = "LeftoverApplicationsAnalyzer";
    public const string Log = "LogAnalyzer";
    public const string DeveloperCache = "DeveloperCacheAnalyzer";
    public const string CrashDumps = "CrashDumpAnalyzer";
    public const string WindowsUpdate = "WindowsUpdateAnalyzer";
    public const string Thumbnails = "ThumbnailAnalyzer";
    public const string RecycleBin = "RecycleBinAnalyzer";
}
