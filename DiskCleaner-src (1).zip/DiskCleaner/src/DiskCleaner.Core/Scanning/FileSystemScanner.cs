using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Channels;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// The enumeration engine. Streams the file system into an <see cref="IScanSink"/>
/// with bounded parallelism, bounded memory and honest error reporting.
/// </summary>
/// <remarks>
/// Design rules this class exists to satisfy:
/// <list type="bullet">
///   <item><description><b>No UI element per file.</b> Files are streamed to a sink; nothing here
///   knows about views.</description></item>
///   <item><description><b>Bounded memory.</b> A work queue with back-pressure, an explicit stack
///   per worker, fixed-size rankings. The file list of a whole volume is never held.</description></item>
///   <item><description><b>Bounded parallelism.</b> At most <see cref="ScanOptions.MaxUsefulParallelism"/>
///   workers by default: more threads do not make a disk faster, they just thrash it.</description></item>
///   <item><description><b>Resilience.</b> One unreadable directory produces a <see cref="ScanIssue"/>
///   and the scan continues. One unreadable file does not even stop its directory.</description></item>
///   <item><description><b>No cycles.</b> Reparse points are not followed by default; when they are,
///   <see cref="ReparsePointGuard"/> refuses duplicates and links outside the tree.</description></item>
///   <item><description><b>Cancellable.</b> Every loop observes the token, including inside long
///   directory listings.</description></item>
/// </list>
/// </remarks>
public sealed class FileSystemScanner
{
    /// <summary>How often the cancellation token is checked inside a huge directory listing.</summary>
    private const int CancellationCheckStride = 512;

    private readonly IFileSystem _fileSystem;
    private readonly ILogger _logger;

    public FileSystemScanner(IFileSystem fileSystem, ILogger<FileSystemScanner>? logger = null)
    {
        _fileSystem = fileSystem ?? throw new ArgumentNullException(nameof(fileSystem));
        _logger = logger ?? NullLogger<FileSystemScanner>.Instance;
    }

    /// <summary>Runs the scan. Never throws for per-file/per-directory IO problems.</summary>
    /// <exception cref="ArgumentNullException"><paramref name="sink"/> is null.</exception>
    public async Task<ScanStatistics> ScanAsync(
        ScanOptions options,
        IScanSink sink,
        IProgress<ScanProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(sink);

        var opts = options.Normalise();
        var stopwatch = Stopwatch.StartNew();

        if (opts.Roots.Count == 0)
        {
            return new ScanStatistics { Elapsed = stopwatch.Elapsed };
        }

        var filter = ScanFilter.FromOptions(opts);
        var state = new ScanState(opts.Roots.Count, opts.ExpectedTotalBytes);
        var guard = new ReparsePointGuard();

        var queue = Channel.CreateBounded<WorkItem>(
            new BoundedChannelOptions(Math.Max(16, opts.DirectoryQueueCapacity))
            {
                FullMode = BoundedChannelFullMode.Wait,
                SingleReader = false,
                SingleWriter = false,
            });

        var countdown = new AsyncCountdown(1);
        using var progressCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        var parallelism = opts.ResolveParallelism();
        var workers = new Task<WorkerOutcome>[parallelism];
        for (var i = 0; i < parallelism; i++)
        {
            var workerId = i;
            workers[i] = Task.Run(
                () => WorkerAsync(workerId, queue, state, filter, opts, sink, countdown, guard, cancellationToken),
                CancellationToken.None);
        }

        var progressTask = progress is null
            ? null
            : Task.Run(() => PublishProgressAsync(state, opts, progress, progressCts.Token), CancellationToken.None);

        // Seed the queue with the requested roots.
        try
        {
            foreach (var root in opts.Roots)
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (filter.IsPathExcluded(root))
                {
                    sink.OnIssue(ScanIssueFactory.Create(root, ScanIssueKind.Excluded, "issue.excluded", "Excluded by settings"));
                    continue;
                }

                if (!_fileSystem.DirectoryExists(root))
                {
                    sink.OnIssue(ScanIssueFactory.Create(root, ScanIssueKind.NotFound, "issue.not-found", "Directory does not exist"));
                    continue;
                }

                var metadata = _fileSystem.TryGetDirectoryMetadata(root);

                // Register the root itself so a junction pointing back at it is refused
                // instead of silently double-counting everything below it.
                guard.MarkVisited(root);

                countdown.AddCount(1);
                await queue.Writer.WriteAsync(
                    new WorkItem(root, 0, root, metadata?.Attributes ?? FileAttributes.Directory, metadata?.LastWriteUtc, metadata?.IsReparsePoint ?? false),
                    cancellationToken).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException)
        {
            state.MarkCancelled();
        }
        finally
        {
            countdown.Signal();
        }

        try
        {
            await countdown.WaitAsync(cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            state.MarkCancelled();
        }
        finally
        {
            queue.Writer.TryComplete();
            progressCts.Cancel();
        }

        WorkerOutcome[] outcomes;
        try
        {
            outcomes = await Task.WhenAll(workers).ConfigureAwait(false);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // Workers swallow their own faults, so reaching this branch means the
            // coordination itself broke. Log the context and let the caller surface it.
            _logger.LogError(ex, "Scanner coordination failed after {Directories} directories / {Files} files",
                state.Snapshot(opts, stopwatch.Elapsed, 0, final: true).DirectoriesScanned,
                state.Snapshot(opts, stopwatch.Elapsed, 0, final: true).FilesScanned);
            throw;
        }

        foreach (var outcome in outcomes)
        {
            state.Merge(outcome);
        }

        if (progressTask is not null)
        {
            try
            {
                await progressTask.ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                // Expected: the publisher is stopped by progressCts.
            }
        }

        stopwatch.Stop();
        progress?.Report(state.Snapshot(opts, stopwatch.Elapsed, entriesPerSecond: 0, final: true));

        return state.ToStatistics(stopwatch.Elapsed);
    }

    // --- worker --------------------------------------------------------------

    private async Task<WorkerOutcome> WorkerAsync(
        int workerId,
        Channel<WorkItem> queue,
        ScanState state,
        ScanFilter filter,
        ScanOptions opts,
        IScanSink sink,
        AsyncCountdown countdown,
        ReparsePointGuard guard,
        CancellationToken cancellationToken)
    {
        // Each worker keeps its own overflow stack. When the shared queue is full
        // the worker keeps the directory for itself instead of blocking, which is
        // what makes the bounded queue deadlock-free.
        var local = new Stack<WorkItem>(64);
        var outcome = new WorkerOutcome();

        try
        {
            while (true)
            {
                WorkItem item;

                if (local.Count > 0)
                {
                    item = local.Pop();
                }
                else
                {
                    if (!await queue.Reader.WaitToReadAsync(cancellationToken).ConfigureAwait(false))
                    {
                        break;
                    }

                    if (!queue.Reader.TryRead(out item))
                    {
                        continue;
                    }
                }

                ProcessDirectory(item, local, queue, state, filter, opts, sink, countdown, guard, cancellationToken, workerId, outcome);
            }
        }
        catch (OperationCanceledException)
        {
            outcome.Cancelled = true;
            state.MarkCancelled();
        }
        catch (Exception ex)
        {
            // A worker must never bring the scan down.
            outcome.Faulted = true;
            _logger.LogError(ex, "Scan worker {WorkerId} terminated unexpectedly", workerId);
        }

        return outcome;
    }

    private void ProcessDirectory(
        in WorkItem item,
        Stack<WorkItem> local,
        Channel<WorkItem> queue,
        ScanState state,
        ScanFilter filter,
        ScanOptions opts,
        IScanSink sink,
        AsyncCountdown countdown,
        ReparsePointGuard guard,
        CancellationToken cancellationToken,
        int workerId,
        WorkerOutcome outcome)
    {
        var path = item.Path;

        try
        {
            cancellationToken.ThrowIfCancellationRequested();

            state.EnterDirectory(path, item.Root);

            var entry = new ScannedEntry(
                fullPath: path,
                name: PathUtils.GetFileName(path),
                isDirectory: true,
                size: 0,
                attributes: item.Attributes | FileAttributes.Directory,
                createdUtc: null,
                lastWriteUtc: item.LastWriteUtc,
                isReparsePoint: item.IsReparsePoint,
                driveRoot: PathUtils.GetDriveRoot(path));

            sink.OnDirectory(in entry, item.Depth);
            state.CountDirectory();

            var index = 0;
            foreach (var child in _fileSystem.EnumerateEntries(path))
            {
                if ((++index % CancellationCheckStride) == 0)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }

                if (child.IsDirectory)
                {
                    HandleChildDirectory(child, item, local, queue, state, filter, opts, sink, countdown, guard);
                }
                else
                {
                    state.CountFile(child.Size);
                    sink.OnFile(in child, item.Depth + 1, path);
                }
            }

            if (item.Depth == 0)
            {
                state.CountRootCompleted();
            }
        }
        catch (OperationCanceledException)
        {
            outcome.Cancelled = true;
            state.MarkCancelled();
            throw;
        }
        catch (UnauthorizedAccessException ex)
        {
            Report(sink, state, outcome, path, ex, inaccessibleDirectory: true);
        }
        catch (Exception ex) when (ex is IOException or NotSupportedException or ArgumentException or PathTooLongException or InvalidOperationException)
        {
            Report(sink, state, outcome, path, ex, inaccessibleDirectory: true);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected failure while enumerating {Path} (worker {WorkerId})", path, workerId);
            Report(sink, state, outcome, path, ex, inaccessibleDirectory: true);
        }
        finally
        {
            countdown.Signal();
        }
    }

    private void HandleChildDirectory(
        in ScannedEntry child,
        in WorkItem parent,
        Stack<WorkItem> local,
        Channel<WorkItem> queue,
        ScanState state,
        ScanFilter filter,
        ScanOptions opts,
        IScanSink sink,
        AsyncCountdown countdown,
        ReparsePointGuard guard)
    {
        var childDepth = parent.Depth + 1;

        if (child.IsReparsePoint && !opts.FollowReparsePoints)
        {
            // Default policy: never follow junctions / symlinks / mount points.
            // Following them double-counts data and can create cycles.
            state.CountReparseSkipped();
            return;
        }

        if (!filter.ShouldEnterDirectory(child, childDepth))
        {
            if (filter.IsPathExcluded(child.FullPath))
            {
                sink.OnIssue(ScanIssueFactory.Create(child.FullPath, ScanIssueKind.Excluded, "issue.excluded", "Excluded by settings"));
            }

            return;
        }

        if (child.IsReparsePoint)
        {
            var target = _fileSystem.TryResolveLinkTarget(child.FullPath);
            if (!guard.TryFollow(child.FullPath, target, parent.Root, allowOutsideTree: false))
            {
                state.CountReparseSkipped();
                sink.OnIssue(ScanIssueFactory.Create(
                    child.FullPath,
                    ScanIssueKind.ReparsePointSkipped,
                    "issue.reparse-not-followed",
                    "Not followed: the link points outside the scanned tree or the target was already visited"));
                return;
            }
        }

        countdown.AddCount(1);

        var work = new WorkItem(
            child.FullPath,
            childDepth,
            parent.Root,
            child.Attributes,
            child.LastWriteUtc,
            child.IsReparsePoint);

        if (!queue.Writer.TryWrite(work))
        {
            local.Push(work);
        }
    }

    private void Report(IScanSink sink, ScanState state, WorkerOutcome outcome, string path, Exception exception, bool inaccessibleDirectory)
    {
        state.CountIssue(inaccessibleDirectory);
        outcome.Issues++;

        var issue = ScanIssueFactory.FromException(path, exception);
        sink.OnIssue(issue);

        if (issue.Kind is ScanIssueKind.AccessDenied)
        {
            _logger.LogDebug("Access denied: {Path}", path);
        }
        else
        {
            _logger.LogDebug(exception, "Skipped {Path}: {Reason}", path, issue.Reason);
        }
    }

    // --- progress ------------------------------------------------------------

    private async Task PublishProgressAsync(
        ScanState state,
        ScanOptions opts,
        IProgress<ScanProgress> progress,
        CancellationToken cancellationToken)
    {
        using var timer = new PeriodicTimer(opts.ProgressInterval);
        var lastEntries = 0L;
        var lastSample = Stopwatch.GetTimestamp();

        try
        {
            while (await timer.WaitForNextTickAsync(cancellationToken).ConfigureAwait(false))
            {
                var now = Stopwatch.GetTimestamp();
                var entries = state.TotalEntries;
                var elapsedSeconds = Stopwatch.GetElapsedTime(lastSample, now).TotalSeconds;
                var rate = elapsedSeconds > 0.01 ? (entries - lastEntries) / elapsedSeconds : 0d;

                lastEntries = entries;
                lastSample = now;

                progress.Report(state.Snapshot(opts, state.Elapsed, rate, final: false));
            }
        }
        catch (OperationCanceledException)
        {
            // Normal shutdown of the publisher.
        }
    }

    // --- internals -----------------------------------------------------------

    private readonly record struct WorkItem(
        string Path,
        int Depth,
        string Root,
        FileAttributes Attributes,
        DateTime? LastWriteUtc,
        bool IsReparsePoint);

    private sealed class WorkerOutcome
    {
        public long Issues;
        public bool Cancelled;
        public bool Faulted;
    }

    private sealed class ScanState(int rootsTotal, long expectedTotalBytes)
    {
        private readonly Stopwatch _watch = Stopwatch.StartNew();
        private readonly int _rootsTotal = rootsTotal;
        private readonly long _expectedTotalBytes = expectedTotalBytes;

        private long _files;
        private long _directories;
        private long _bytes;
        private long _issues;
        private long _reparseSkipped;
        private long _inaccessibleDirectories;
        private long _rootsCompleted;
        private int _cancelled;

        private string? _currentDirectory;
        private string? _currentRoot;

        public long TotalEntries => Interlocked.Read(ref _files) + Interlocked.Read(ref _directories);

        public TimeSpan Elapsed => _watch.Elapsed;

        public long ReparsePointsSkipped { get; set; }

        public void MarkCancelled() => Interlocked.Exchange(ref _cancelled, 1);

        public void EnterDirectory(string path, string root)
        {
            Volatile.Write(ref _currentDirectory, path);
            Volatile.Write(ref _currentRoot, root);
        }

        public void CountDirectory() => Interlocked.Increment(ref _directories);

        public void CountFile(long size)
        {
            Interlocked.Increment(ref _files);
            Interlocked.Add(ref _bytes, size);
        }

        public void CountIssue(bool inaccessibleDirectory)
        {
            Interlocked.Increment(ref _issues);
            if (inaccessibleDirectory)
            {
                Interlocked.Increment(ref _inaccessibleDirectories);
            }
        }

        public void CountReparseSkipped() => Interlocked.Increment(ref _reparseSkipped);

        public void CountRootCompleted() => Interlocked.Increment(ref _rootsCompleted);

        public void Merge(WorkerOutcome outcome)
        {
            if (outcome.Cancelled)
            {
                MarkCancelled();
            }
        }

        public ScanProgress Snapshot(ScanOptions opts, TimeSpan elapsed, double entriesPerSecond, bool final)
        {
            var files = Interlocked.Read(ref _files);
            var directories = Interlocked.Read(ref _directories);
            var bytes = Interlocked.Read(ref _bytes);
            var rootsCompleted = Interlocked.Read(ref _rootsCompleted);
            var cancelled = Volatile.Read(ref _cancelled) != 0;

            double? percent = null;
            if (_expectedTotalBytes > 0)
            {
                // Byte-based estimate: honest for whole-volume scans, capped below
                // 100% while running because unreadable directories are unknown.
                var raw = (double)bytes / _expectedTotalBytes;
                percent = final
                    ? Math.Clamp(raw, 0d, 1d)
                    : Math.Clamp(raw, 0d, 0.99d);
            }

            var phase = final
                ? (cancelled ? ScanPhase.Cancelled : ScanPhase.Completed)
                : ScanPhase.Enumerating;

            return new ScanProgress
            {
                Phase = phase,
                CurrentRoot = Volatile.Read(ref _currentRoot),
                CurrentDirectory = Volatile.Read(ref _currentDirectory),
                FilesScanned = files,
                DirectoriesScanned = directories,
                BytesScanned = bytes,
                BytesFound = 0,
                ItemsFound = 0,
                IssuesCount = (int)Math.Min(int.MaxValue, Interlocked.Read(ref _issues)),
                RootsCompleted = (int)Math.Min(_rootsTotal, rootsCompleted),
                RootsTotal = _rootsTotal,
                Elapsed = elapsed,
                EntriesPerSecond = entriesPerSecond,
                PercentComplete = percent,
            };
        }

        public ScanStatistics ToStatistics(TimeSpan elapsed) => new()
        {
            FilesScanned = Interlocked.Read(ref _files),
            DirectoriesScanned = Interlocked.Read(ref _directories),
            BytesScanned = Interlocked.Read(ref _bytes),
            IssuesCount = Interlocked.Read(ref _issues),
            ReparsePointsSkipped = Interlocked.Read(ref _reparseSkipped) + ReparsePointsSkipped,
            InaccessibleDirectories = Interlocked.Read(ref _inaccessibleDirectories),
            Elapsed = elapsed,
            WasCancelled = Volatile.Read(ref _cancelled) != 0,
        };
    }
}
