using System.Collections.Concurrent;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Builds the "what occupies the disk" map: per-directory own size plus, at the
/// end, subtree sizes.
/// </summary>
/// <remarks>
/// Memory strategy (a full disk can contain millions of directories):
/// <list type="bullet">
///   <item><description>one small counter object per <em>tracked</em> directory, capped by
///   <see cref="ScanOptions.MaxTrackedDirectories"/>;</description></item>
///   <item><description>once the cap is hit, new directories are not registered; their bytes are
///   attributed to the nearest tracked ancestor, so the totals stay correct;</description></item>
///   <item><description>subtree sums are computed once, bottom-up, after enumeration — the per-file
///   hot path never walks ancestors.</description></item>
/// </list>
/// </remarks>
public sealed class DirectorySizeAggregator
{
    private sealed class Counter
    {
        public long Bytes;
        public int Files;
        public int Depth;
        public string? Parent;
        public string Name = string.Empty;
        public DateTime? LastWriteUtc;
    }

    private readonly ConcurrentDictionary<string, Counter> _directories;
    private readonly int _maxTracked;
    private long _untrackedBytes;
    private int _peak;

    public DirectorySizeAggregator(int maxTrackedDirectories = 400_000, StringComparer? comparer = null)
    {
        _maxTracked = Math.Max(1024, maxTrackedDirectories);
        _directories = new ConcurrentDictionary<string, Counter>(
            concurrencyLevel: Math.Min(16, Environment.ProcessorCount * 2),
            capacity: 4096,
            comparer: comparer ?? PathUtils.Comparer);
    }

    public int TrackedCount => _directories.Count;

    public int PeakTrackedCount => Volatile.Read(ref _peak);

    /// <summary>Bytes that could not be attributed to a tracked directory (cap reached).</summary>
    public long UntrackedBytes => Interlocked.Read(ref _untrackedBytes);

    public bool TryRegisterDirectory(string path, int depth, string? parent, string name, DateTime? lastWriteUtc)
    {
        if (_directories.TryGetValue(path, out var existing))
        {
            // Refresh metadata; sizes are accumulated separately.
            existing.Depth = Math.Min(existing.Depth, depth);
            existing.LastWriteUtc ??= lastWriteUtc;
            return true;
        }

        if (_directories.Count >= _maxTracked)
        {
            return false;
        }

        var counter = new Counter
        {
            Depth = depth,
            Parent = parent is null ? null : PathUtils.Normalize(parent),
            Name = name,
            LastWriteUtc = lastWriteUtc,
        };

        if (_directories.TryAdd(path, counter))
        {
            var count = _directories.Count;
            if (count > Volatile.Read(ref _peak))
            {
                Interlocked.Exchange(ref _peak, count);
            }

            return true;
        }

        return false;
    }

    /// <summary>Adds a file's size to its directory (or to the nearest tracked ancestor).</summary>
    public void AddFile(string directory, long size)
    {
        if (_directories.TryGetValue(directory, out var counter))
        {
            Interlocked.Add(ref counter.Bytes, size);
            Interlocked.Increment(ref counter.Files);
            return;
        }

        // Overflow path: walk up until a tracked ancestor is found.
        var current = PathUtils.GetParent(directory);
        while (!string.IsNullOrEmpty(current))
        {
            if (_directories.TryGetValue(current, out var ancestor))
            {
                Interlocked.Add(ref ancestor.Bytes, size);
                Interlocked.Increment(ref ancestor.Files);
                return;
            }

            current = PathUtils.GetParent(current);
        }

        Interlocked.Add(ref _untrackedBytes, size);
    }

    /// <summary>Total bytes of all files seen by the aggregator.</summary>
    public long TotalBytes
    {
        get
        {
            var total = Interlocked.Read(ref _untrackedBytes);
            foreach (var counter in _directories.Values)
            {
                total += Interlocked.Read(ref counter.Bytes);
            }

            return total;
        }
    }

    /// <summary>Computes subtree sizes bottom-up. Called once, after enumeration.</summary>
    public IReadOnlyList<DirectoryAggregate> BuildAggregates()
    {
        var snapshot = _directories.ToArray();

        // Deepest first so children are folded into their parents exactly once.
        Array.Sort(snapshot, static (a, b) => b.Value.Depth.CompareTo(a.Value.Depth));

        var subtreeBytes = new Dictionary<string, long>(snapshot.Length, PathUtils.Comparer);
        var subtreeFiles = new Dictionary<string, int>(snapshot.Length, PathUtils.Comparer);

        var result = new List<DirectoryAggregate>(snapshot.Length);

        foreach (var (path, counter) in snapshot)
        {
            subtreeBytes.TryGetValue(path, out var childBytes);
            subtreeFiles.TryGetValue(path, out var childFiles);

            var totalBytes = Interlocked.Read(ref counter.Bytes) + childBytes;
            var totalFiles = Volatile.Read(ref counter.Files) + childFiles;

            result.Add(new DirectoryAggregate
            {
                Path = path,
                Name = counter.Name.Length > 0 ? counter.Name : PathUtils.GetFileName(path),
                OwnBytes = Interlocked.Read(ref counter.Bytes),
                SubtreeBytes = totalBytes,
                OwnFileCount = Volatile.Read(ref counter.Files),
                SubtreeFileCount = totalFiles,
                Depth = counter.Depth,
                ParentPath = counter.Parent,
                LastWriteUtc = counter.LastWriteUtc,
            });

            if (counter.Parent is { Length: > 0 } parent)
            {
                subtreeBytes.TryGetValue(parent, out var parentBytes);
                subtreeFiles.TryGetValue(parent, out var parentFiles);
                subtreeBytes[parent] = parentBytes + totalBytes;
                subtreeFiles[parent] = parentFiles + totalFiles;
            }
        }

        return result;
    }

    /// <summary>The <paramref name="count"/> largest directories by subtree size.</summary>
    public IReadOnlyList<DirectoryAggregate> TopDirectories(int count) =>
        BuildAggregates()
            .OrderByDescending(d => d.SubtreeBytes)
            .Take(count)
            .ToArray();

    public void Clear()
    {
        _directories.Clear();
        Interlocked.Exchange(ref _untrackedBytes, 0);
        Interlocked.Exchange(ref _peak, 0);
    }
}
