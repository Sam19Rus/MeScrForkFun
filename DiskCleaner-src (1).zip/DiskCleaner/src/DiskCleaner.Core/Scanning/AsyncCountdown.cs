namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Minimal awaitable countdown latch used to know when the scanner's work queue
/// has drained.
/// </summary>
/// <remarks>
/// .NET 10 does not ship an <c>AsyncCountdownEvent</c>, and pulling in a package
/// for eleven lines of logic is not worth it. Protocol used by
/// <see cref="FileSystemScanner"/>:
/// <list type="bullet">
///   <item><description>the producer starts at 1 and signals once after seeding the roots;</description></item>
///   <item><description>every queued directory adds 1 <em>before</em> being enqueued;</description></item>
///   <item><description>the worker that finishes a directory signals 1.</description></item>
/// </list>
/// Because a worker always holds the token of the directory it is processing, the
/// count can never reach zero while work is still in flight.
/// </remarks>
internal sealed class AsyncCountdown(int initialCount)
{
    private readonly TaskCompletionSource _completed = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private int _count = initialCount;

    public int CurrentCount => Volatile.Read(ref _count);

    public bool IsCompleted => Volatile.Read(ref _count) <= 0;

    /// <exception cref="InvalidOperationException">The latch already reached zero (programming error).</exception>
    public void AddCount(int delta = 1)
    {
        if (delta <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(delta));
        }

        var updated = Interlocked.Add(ref _count, delta);
        if (updated <= 0)
        {
            throw new InvalidOperationException("The countdown had already completed.");
        }
    }

    public void Signal()
    {
        if (Interlocked.Decrement(ref _count) <= 0)
        {
            _completed.TrySetResult();
        }
    }

    /// <summary>Completes when the count reaches zero, or throws when cancelled.</summary>
    public async Task WaitAsync(CancellationToken cancellationToken)
    {
        if (IsCompleted)
        {
            return;
        }

        cancellationToken.ThrowIfCancellationRequested();

        using var registration = cancellationToken.Register(
            static state => ((TaskCompletionSource)state!).TrySetCanceled(),
            _completed);

        await _completed.Task.ConfigureAwait(false);
    }
}
