using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Scanning;

/// <summary>
/// Prevents the scanner from walking in circles or double-counting data when
/// reparse points (junctions, symlinks, mount points) are followed.
/// </summary>
/// <remarks>
/// Two independent protections:
/// <list type="number">
///   <item><description>a visited set of resolved targets, so the same physical
///   directory is never enumerated twice;</description></item>
///   <item><description>an "inside the current tree" rule — a junction that points
///   outside the scanned root is not followed, which is the default policy
///   requested for this product.</description></item>
/// </list>
/// </remarks>
public sealed class ReparsePointGuard
{
    private readonly HashSet<string> _visited = new(PathUtils.Comparer);
    private readonly object _gate = new();

    /// <summary>Total number of reparse points refused (diagnostics).</summary>
    public int RefusedCount { get; private set; }

    /// <summary>
    /// Decides whether a reparse point may be followed.
    /// </summary>
    /// <param name="linkPath">Path of the junction/symlink itself.</param>
    /// <param name="resolvedTarget">Final target, or <c>null</c> when it could not be resolved.</param>
    /// <param name="root">Scan root that owns this link.</param>
    /// <param name="allowOutsideTree">When <c>false</c>, targets outside <paramref name="root"/> are refused.</param>
    public bool TryFollow(string linkPath, string? resolvedTarget, string root, bool allowOutsideTree)
    {
        if (string.IsNullOrWhiteSpace(resolvedTarget))
        {
            // Unresolvable target: following it would mean trusting a raw path.
            lock (_gate)
            {
                RefusedCount++;
            }

            return false;
        }

        var target = PathUtils.Normalize(resolvedTarget);

        if (!allowOutsideTree && !PathUtils.IsUnder(target, root))
        {
            lock (_gate)
            {
                RefusedCount++;
            }

            return false;
        }

        lock (_gate)
        {
            if (!_visited.Add(target))
            {
                RefusedCount++;
                return false;
            }

            // Remember the link too, so two links to the same target are not both walked.
            _visited.Add(PathUtils.Normalize(linkPath));
            return true;
        }
    }

    /// <summary>
    /// Pre-registers a path (normally a scan root) so that any link resolving to it
    /// is refused later. Without this, following a junction that points at the root
    /// would count the root's data twice.
    /// </summary>
    public void MarkVisited(string path)
    {
        lock (_gate)
        {
            _visited.Add(PathUtils.Normalize(path));
        }
    }

    public void Reset()
    {
        lock (_gate)
        {
            _visited.Clear();
            RefusedCount = 0;
        }
    }
}
