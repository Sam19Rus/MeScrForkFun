using System.Globalization;
using System.Text;

namespace DiskCleaner.Core.Infrastructure.Formatting;

/// <summary>
/// Sizes as a user expects to see them in a disk utility: binary units,
/// Explorer-style labels, one decimal place.
/// </summary>
public static class BytesFormatter
{
    private static readonly string[] Units = ["B", "KB", "MB", "GB", "TB", "PB", "EB"];

    /// <summary>Formats a byte count. <c>Format(1536)</c> → <c>"1.5 KB"</c>.</summary>
    public static string Format(long bytes, IFormatProvider? provider = null, int decimals = 1)
    {
        provider ??= CultureInfo.InvariantCulture;
        var negative = bytes < 0;
        var value = (double)Math.Abs(bytes);

        var unit = 0;
        while (value >= 1024d && unit < Units.Length - 1)
        {
            value /= 1024d;
            unit++;
        }

        // Below 1 KB the value is an integer; "N0" would render "1,023 B" only for
        // values >= 1024, which by then have moved to the next unit anyway.
        var format = unit == 0 ? "0" : "N" + decimals.ToString(CultureInfo.InvariantCulture);
        var text = value.ToString(format, provider);

        return (negative ? "-" : string.Empty) + text + " " + Units[unit];
    }

    /// <summary>Two decimals, for the headline numbers of the report.</summary>
    public static string FormatPrecise(long bytes, IFormatProvider? provider = null) =>
        Format(bytes, provider, 2);

    /// <summary>Compact form for tight table cells: <c>11.2G</c>, <c>480M</c>, <c>92K</c>.</summary>
    public static string FormatCompact(long bytes, IFormatProvider? provider = null)
    {
        provider ??= CultureInfo.InvariantCulture;
        var value = (double)Math.Abs(bytes);
        var unit = 0;
        while (value >= 1024d && unit < Units.Length - 1)
        {
            value /= 1024d;
            unit++;
        }

        // B, K, M, G, T, P, E
        var suffix = unit == 0 ? "B" : Units[unit][..1];
        return value.ToString(unit == 0 ? "N0" : "0.#", provider) + suffix;
    }

    public static string FormatRate(double bytesPerSecond, IFormatProvider? provider = null) =>
        bytesPerSecond <= 0d
            ? "—"
            : Format((long)bytesPerSecond, provider) + "/s";

    public static string FormatCount(long count, IFormatProvider? provider = null) =>
        count.ToString("N0", provider ?? CultureInfo.InvariantCulture);

    /// <summary>
    /// Parses user input from the settings screen: <c>"256 MB"</c>, <c>1.5gb</c>, <c>4096</c>.
    /// Returns <c>false</c> instead of throwing so the UI can validate inline.
    /// </summary>
    public static bool TryParseHuman(string? text, out long bytes, IFormatProvider? provider = null)
    {
        bytes = 0;
        if (string.IsNullOrWhiteSpace(text))
        {
            return false;
        }

        provider ??= CultureInfo.InvariantCulture;
        var trimmed = text.Trim();

        var numberPart = new StringBuilder();
        var unitPart = new StringBuilder();
        foreach (var c in trimmed)
        {
            if (char.IsDigit(c) || c is '.' or ',' or '-')
            {
                numberPart.Append(c);
            }
            else if (!char.IsWhiteSpace(c))
            {
                unitPart.Append(c);
            }
        }

        if (!double.TryParse(numberPart.ToString(), NumberStyles.Float, provider, out var number) || number < 0)
        {
            return false;
        }

        var multiplier = unitPart.ToString().Trim().ToUpperInvariant() switch
        {
            "" or "B" => 1L,
            "K" or "KB" or "KIB" => 1024L,
            "M" or "MB" or "MIB" => 1024L * 1024,
            "G" or "GB" or "GIB" => 1024L * 1024 * 1024,
            "T" or "TB" or "TIB" => 1024L * 1024 * 1024 * 1024,
            _ => -1L,
        };

        if (multiplier < 0)
        {
            return false;
        }

        bytes = (long)(number * multiplier);
        return true;
    }
}
