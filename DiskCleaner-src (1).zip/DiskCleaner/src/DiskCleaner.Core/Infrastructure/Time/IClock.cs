namespace DiskCleaner.Core.Infrastructure.Time;

/// <summary>Time source. Injected so tests never depend on the wall clock.</summary>
public interface IClock
{
    DateTime UtcNow { get; }
}

public sealed class SystemClock : IClock
{
    public static readonly SystemClock Instance = new();

    public DateTime UtcNow => DateTime.UtcNow;
}

/// <summary>Test clock: fully deterministic, advanced explicitly.</summary>
public sealed class ManualClock(DateTime utcNow) : IClock
{
    private DateTime _now = utcNow.Kind == DateTimeKind.Utc ? utcNow : utcNow.ToUniversalTime();

    public DateTime UtcNow => _now;

    public void Advance(TimeSpan by) => _now = _now.Add(by);

    public void Set(DateTime utcNow) => _now = utcNow.Kind == DateTimeKind.Utc ? utcNow : utcNow.ToUniversalTime();
}
