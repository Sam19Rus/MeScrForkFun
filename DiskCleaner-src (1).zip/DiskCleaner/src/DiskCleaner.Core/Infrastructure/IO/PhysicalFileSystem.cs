using System.Runtime.InteropServices;

namespace DiskCleaner.Core.Infrastructure.IO;

/// <summary>
/// Production <see cref="IFileSystem"/>: thin, allocation-conscious wrappers over
/// <see cref="System.IO"/>, with Windows long-path support.
/// </summary>
/// <remarks>
/// Long paths: the app manifest sets <c>longPathAware</c>, but the group policy
/// <c>LongPathsEnabled</c> can still be off on a corporate machine. Prepending
/// <c>\\?\</c> bypasses MAX_PATH without depending on that policy, so we do it
/// for any path that is already uncomfortably long.
/// </remarks>
public sealed class PhysicalFileSystem : IFileSystem
{
    /// <summary>Paths at or beyond this length get the extended-length prefix on Windows.</summary>
    internal const int LongPathThreshold = 240;

    private static readonly EnumerationOptions ChildOptions = new()
    {
        IgnoreInaccessible = false,          // we want to report denied directories
        RecurseSubdirectories = false,        // the scanner drives recursion itself
        AttributesToSkip = 0,                 // include hidden + system: caches live there
        ReturnSpecialDirectories = false,     // skip "." and ".."
        MatchType = MatchType.Win32,
        BufferSize = 64 * 1024,
    };

    public bool DirectoryExists(string path) => Directory.Exists(ForApi(path));

    public bool FileExists(string path) => File.Exists(ForApi(path));

    public IEnumerable<ScannedEntry> EnumerateEntries(string directory)
    {
        var apiPath = ForApi(directory);
        var root = PathUtils.GetDriveRoot(directory);

        var info = new DirectoryInfo(apiPath);
        foreach (var entry in info.EnumerateFileSystemInfos("*", ChildOptions))
        {
            ScannedEntry scanned;
            try
            {
                var isDirectory = entry is DirectoryInfo;
                var attributes = SafeAttributes(entry);
                var fullPath = FromApi(entry.FullName);

                scanned = new ScannedEntry(
                    fullPath: fullPath,
                    name: entry.Name,
                    isDirectory: isDirectory,
                    size: isDirectory ? 0 : SafeLength((FileInfo)entry),
                    attributes: attributes,
                    createdUtc: SafeDate(() => entry.CreationTimeUtc),
                    lastWriteUtc: SafeDate(() => entry.LastWriteTimeUtc),
                    isReparsePoint: (attributes & FileAttributes.ReparsePoint) != 0,
                    driveRoot: root);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
            {
                // One unreadable entry must not kill the directory listing.
                continue;
            }

            yield return scanned;
        }
    }

    public DirectoryMetadata? TryGetDirectoryMetadata(string path)
    {
        try
        {
            var info = new DirectoryInfo(ForApi(path));
            if (!info.Exists)
            {
                return null;
            }

            var attributes = SafeAttributes(info);
            return new DirectoryMetadata(
                path,
                attributes,
                SafeDate(() => info.CreationTimeUtc),
                SafeDate(() => info.LastWriteTimeUtc),
                (attributes & FileAttributes.ReparsePoint) != 0);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    public FileMetadata? TryGetFileMetadata(string path)
    {
        try
        {
            var info = new FileInfo(ForApi(path));
            if (!info.Exists)
            {
                return null;
            }

            return new FileMetadata(
                path,
                SafeLength(info),
                SafeAttributes(info),
                SafeDate(() => info.CreationTimeUtc),
                SafeDate(() => info.LastWriteTimeUtc));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    public string? TryResolveLinkTarget(string path)
    {
        try
        {
            var target = File.ResolveLinkTarget(ForApi(path), returnFinalTarget: true);
            return target?.FullName is { Length: > 0 } resolved ? FromApi(resolved) : null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    public bool TryCreateDirectory(string path)
    {
        try
        {
            Directory.CreateDirectory(ForApi(path));
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return false;
        }
    }

    public string? TryReadAllText(string path)
    {
        try
        {
            return File.ReadAllText(ForApi(path));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    public void WriteAllTextAtomic(string path, string contents)
    {
        var target = ForApi(path);
        var directory = Path.GetDirectoryName(target);
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        var temp = target + ".tmp";
        File.WriteAllText(temp, contents);

        if (File.Exists(target))
        {
            var backup = target + ".bak";
            File.Replace(temp, target, backup, ignoreMetadataErrors: true);
        }
        else
        {
            File.Move(temp, target, overwrite: true);
        }
    }

    public bool TryDeleteFile(string path, out string? error)
    {
        try
        {
            File.Delete(ForApi(path));
            error = null;
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            error = ex.Message;
            return false;
        }
    }

    public bool TryDeleteDirectory(string path, bool recursive, out string? error)
    {
        try
        {
            Directory.Delete(ForApi(path), recursive);
            error = null;
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            error = ex.Message;
            return false;
        }
    }

    public bool TryCopyFile(string sourcePath, string destinationPath, out string? error)
    {
        try
        {
            var source = ForApi(sourcePath);
            var destination = ForApi(destinationPath);

            File.Copy(source, destination, overwrite: false);

            // Preserve what an application may rely on: modification time drives
            // incremental builds and update checks, attributes carry Hidden/System
            // flags. Best effort — a metadata failure does not fail the copy itself.
            try
            {
                var sourceInfo = new FileInfo(source);
                var destinationInfo = new FileInfo(destination);
                destinationInfo.CreationTimeUtc = sourceInfo.CreationTimeUtc;
                destinationInfo.LastWriteTimeUtc = sourceInfo.LastWriteTimeUtc;
                destinationInfo.LastAccessTimeUtc = sourceInfo.LastAccessTimeUtc;

                var attributes = sourceInfo.Attributes &
                    ~(FileAttributes.ReparsePoint | FileAttributes.Directory | FileAttributes.Offline);
                if (attributes != 0)
                {
                    destinationInfo.Attributes = attributes;
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
            {
            }

            error = null;
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException)
        {
            error = ex.Message;
            return false;
        }
    }

    /// <summary>Applies the extended-length prefix when running on Windows and the path is long.</summary>
    internal static string ForApi(string path)
    {
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            return path;
        }

        if (path.Length < LongPathThreshold)
        {
            return path;
        }

        return PathUtils.ToExtendedLengthPath(path);
    }

    internal static string FromApi(string path) => PathUtils.FromExtendedLengthPath(path);

    private static FileAttributes SafeAttributes(FileSystemInfo info)
    {
        try
        {
            return info.Attributes;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return FileAttributes.Normal;
        }
    }

    private static long SafeLength(FileInfo info)
    {
        try
        {
            return info.Length;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or FileNotFoundException)
        {
            return 0;
        }
    }

    private static DateTime? SafeDate(Func<DateTime> getter)
    {
        try
        {
            var value = getter();
            return value == default ? null : value;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentOutOfRangeException)
        {
            return null;
        }
    }
}
