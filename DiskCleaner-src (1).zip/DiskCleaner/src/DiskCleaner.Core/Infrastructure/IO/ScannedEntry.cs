namespace DiskCleaner.Core.Infrastructure.IO;

/// <summary>
/// One entry yielded by the scanner.
/// </summary>
/// <remarks>
/// A <c>readonly record struct</c> on purpose: a deep scan touches millions of
/// entries and a reference type here would put the whole run at the mercy of the
/// GC. Values are copied, never allocated.
/// </remarks>
public readonly record struct ScannedEntry
{
    public ScannedEntry(
        string fullPath,
        string name,
        bool isDirectory,
        long size,
        FileAttributes attributes,
        DateTime? createdUtc,
        DateTime? lastWriteUtc,
        bool isReparsePoint,
        string? driveRoot)
    {
        FullPath = fullPath;
        Name = name;
        IsDirectory = isDirectory;
        Size = isDirectory ? 0 : size;
        Attributes = attributes;
        CreatedUtc = createdUtc;
        LastWriteUtc = lastWriteUtc;
        IsReparsePoint = isReparsePoint;
        DriveRoot = driveRoot;
    }

    public string FullPath { get; }

    public string Name { get; }

    public bool IsDirectory { get; }

    /// <summary>File size in bytes. Always 0 for directories (sizes come from aggregation).</summary>
    public long Size { get; }

    public FileAttributes Attributes { get; }

    public DateTime? CreatedUtc { get; }

    public DateTime? LastWriteUtc { get; }

    /// <summary>Junction, symlink, mount point or any other reparse point.</summary>
    public bool IsReparsePoint { get; }

    /// <summary>Volume root, e.g. <c>C:\</c>. <c>null</c> when it could not be determined.</summary>
    public string? DriveRoot { get; }

    public bool IsHidden => (Attributes & FileAttributes.Hidden) != 0;

    public bool IsSystem => (Attributes & FileAttributes.System) != 0;

    public bool IsSparseFile => (Attributes & FileAttributes.SparseFile) != 0;

    /// <summary>
    /// Windows attribute values that .NET's <see cref="FileAttributes"/> does not expose.
    /// They matter for a disk-space tool: a cloud-only file reports its full size but
    /// occupies (almost) nothing on the volume.
    /// </summary>
    private const FileAttributes RecallOnOpen = (FileAttributes)0x00040000;      // FILE_ATTRIBUTE_RECALL_ON_OPEN
    private const FileAttributes RecallOnDataAccess = (FileAttributes)0x00400000; // FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS
    private const FileAttributes Pinned = (FileAttributes)0x00080000;             // FILE_ATTRIBUTE_PINNED
    private const FileAttributes Unpinned = (FileAttributes)0x00100000;           // FILE_ATTRIBUTE_UNPINNED

    /// <summary>
    /// <c>true</c> for OneDrive / cloud placeholders whose content is not resident.
    /// Their reported size is the logical size, not the space used on disk.
    /// </summary>
    public bool IsCloudPlaceholder =>
        (Attributes & (FileAttributes.Offline | RecallOnOpen | RecallOnDataAccess | Pinned | Unpinned)) != 0;

    /// <summary>Content is not on the local volume and would have to be fetched to be read.</summary>
    public bool IsOfflineOrRecall =>
        (Attributes & (FileAttributes.Offline | RecallOnOpen | RecallOnDataAccess)) != 0;

    public override string ToString() => $"{(IsDirectory ? "D" : "F")} {Size,12} {FullPath}";
}

/// <summary>Metadata of a directory, used when the scanner needs to inspect a node itself.</summary>
public readonly record struct DirectoryMetadata(
    string Path,
    FileAttributes Attributes,
    DateTime? CreatedUtc,
    DateTime? LastWriteUtc,
    bool IsReparsePoint);
