namespace DiskCleaner.Core.Infrastructure.IO;

/// <summary>
/// The single door to the file system. Everything above this interface is pure
/// logic, which is why the scanner, the analyzers and the safety policy can all
/// be unit-tested against an in-memory file system.
/// </summary>
public interface IFileSystem
{
    bool DirectoryExists(string path);

    bool FileExists(string path);

    /// <summary>
    /// Streams the direct children of <paramref name="directory"/>.
    /// Implementations must not materialise the listing: a directory can hold
    /// hundreds of thousands of entries.
    /// </summary>
    /// <exception cref="UnauthorizedAccessException">Access denied. The caller reports it and moves on.</exception>
    /// <exception cref="IOException">Any IO failure. The caller reports it and moves on.</exception>
    IEnumerable<ScannedEntry> EnumerateEntries(string directory);

    /// <summary>Metadata of a directory, or <c>null</c> when it cannot be read.</summary>
    DirectoryMetadata? TryGetDirectoryMetadata(string path);

    /// <summary>Metadata of a file, or <c>null</c> when it cannot be read.</summary>
    FileMetadata? TryGetFileMetadata(string path);

    /// <summary>
    /// Final target of a junction / symlink / mount point, or <c>null</c> when it is
    /// not a link or the target cannot be resolved. Used by the cycle guard.
    /// </summary>
    string? TryResolveLinkTarget(string path);

    /// <summary>Creates the directory if missing. Returns <c>false</c> on failure.</summary>
    bool TryCreateDirectory(string path);

    /// <summary>Reads all text, or <c>null</c> when the file cannot be read.</summary>
    string? TryReadAllText(string path);

    /// <summary>Writes text atomically (temp file + replace) so a crash cannot corrupt settings/history.</summary>
    void WriteAllTextAtomic(string path, string contents);

    bool TryDeleteFile(string path, out string? error);

    bool TryDeleteDirectory(string path, bool recursive, out string? error);

    /// <summary>
    /// Copies one file, never overwriting an existing destination. Used by the
    /// application mover, which must leave the source untouched until the whole copy
    /// is verified.
    /// </summary>
    bool TryCopyFile(string sourcePath, string destinationPath, out string? error);
}

/// <summary>Metadata of a single file.</summary>
public readonly record struct FileMetadata(
    string Path,
    long Size,
    FileAttributes Attributes,
    DateTime? CreatedUtc,
    DateTime? LastWriteUtc);
