using System.Runtime.InteropServices;
using System.Text;

namespace DiskCleaner.Core.Infrastructure.IO;

/// <summary>
/// Path helpers that behave identically on every OS so they can be unit-tested
/// off Windows, plus the Windows-specific extended-length ("\\?\") handling that
/// a disk scanner cannot live without.
/// </summary>
public static class PathUtils
{
    public static readonly StringComparer Comparer =
        RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;

    public static readonly StringComparison Comparison =
        RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

    private const char WindowsSeparator = '\\';
    private const char UnixSeparator = '/';
    private const string ExtendedPrefix = @"\\?\";
    private const string UncPrefix = @"\\?\" + "UNC" + @"\";
    private const string DevicePrefix = @"\\.\";

    /// <summary>Collapses duplicate separators, unifies them and trims a redundant trailing one.</summary>
    public static string Normalize(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return string.Empty;
        }

        var input = path.Trim();
        var isWindowsStyle = LooksLikeWindowsPath(input);
        var separator = isWindowsStyle ? WindowsSeparator : UnixSeparator;

        var sb = new StringBuilder(input.Length);
        var unc = isWindowsStyle && input.StartsWith(@"\\", StringComparison.Ordinal);
        if (unc)
        {
            sb.Append(WindowsSeparator).Append(WindowsSeparator);
        }

        var previousWasSeparator = false;
        for (var i = unc ? 2 : 0; i < input.Length; i++)
        {
            var c = input[i];
            if (c is WindowsSeparator or UnixSeparator)
            {
                if (!previousWasSeparator)
                {
                    sb.Append(separator);
                }

                previousWasSeparator = true;
            }
            else
            {
                sb.Append(c);
                previousWasSeparator = false;
            }
        }

        var result = sb.ToString();

        // Keep "C:\", "\" and "\\srv\share" intact; drop a redundant trailing separator elsewhere.
        while (result.Length > 1 && result[^1] == separator && !IsRootCore(result))
        {
            result = result[..^1];
        }

        return result;
    }

    public static bool LooksLikeWindowsPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return false;
        }

        if (path.Contains('\\'))
        {
            return true;
        }

        return path.Length >= 2 && path[1] == ':' && IsAsciiLetter(path[0]);
    }

    public static bool IsRoot(string? path) => IsRootCore(Normalize(path));

    /// <summary>
    /// Root test for an already-collapsed path. Never calls <see cref="Normalize"/>:
    /// the two used to recurse into each other and blew the stack.
    /// </summary>
    private static bool IsRootCore(string path)
    {
        if (path.Length == 0)
        {
            return false;
        }

        // "/" or "\"
        if (path.Length == 1 && (path[0] == WindowsSeparator || path[0] == UnixSeparator))
        {
            return true;
        }

        // "C:\"
        if (path.Length == 3 && path[1] == ':' && (path[2] == WindowsSeparator || path[2] == UnixSeparator))
        {
            return true;
        }

        // UNC share root: "\\server\share" with nothing after it.
        if (path.StartsWith(@"\\", StringComparison.Ordinal))
        {
            var firstSeparator = path.IndexOf(WindowsSeparator, 2);
            if (firstSeparator < 0)
            {
                return false;
            }

            var secondSeparator = path.IndexOf(WindowsSeparator, firstSeparator + 1);
            return secondSeparator < 0;
        }

        return false;
    }

    public static string EnsureTrailingSeparator(string path)
    {
        var p = Normalize(path);
        if (p.Length == 0)
        {
            return p;
        }

        var separator = LooksLikeWindowsPath(p) ? WindowsSeparator : UnixSeparator;
        return p[^1] == separator ? p : p + separator;
    }

    /// <summary><c>true</c> when <paramref name="child"/> is <paramref name="parent"/> or lives below it.</summary>
    public static bool IsUnder(string? child, string? parent)
    {
        if (string.IsNullOrWhiteSpace(child) || string.IsNullOrWhiteSpace(parent))
        {
            return false;
        }

        var c = Normalize(child);
        var p = EnsureTrailingSeparator(parent);

        if (string.Equals(c, p.TrimEnd(WindowsSeparator, UnixSeparator), Comparison) ||
            string.Equals(EnsureTrailingSeparator(c), p, Comparison))
        {
            return true;
        }

        return c.StartsWith(p, Comparison);
    }

    /// <summary>Number of path segments between <paramref name="root"/> and <paramref name="path"/> (0 for the root itself).</summary>
    public static int GetDepth(string? path, string? root)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return 0;
        }

        var p = Normalize(path);
        if (!string.IsNullOrWhiteSpace(root))
        {
            var r = EnsureTrailingSeparator(root);
            if (p.StartsWith(r, Comparison))
            {
                p = p[r.Length..];
            }
        }

        return p.Split([WindowsSeparator, UnixSeparator], StringSplitOptions.RemoveEmptyEntries).Length;
    }

    public static string? GetParent(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return null;
        }

        var p = Normalize(path);
        if (IsRoot(p))
        {
            return null;
        }

        var index = p.LastIndexOfAny([WindowsSeparator, UnixSeparator]);
        if (index < 0)
        {
            return null;
        }

        // "/foo" -> "/"  and  "C:\Foo" -> "C:\" must keep their root.
        if (index == 0)
        {
            return p[..1];
        }

        if (index == 2 && p[1] == ':')
        {
            return p[..3];
        }

        var parent = p[..index];

        return parent.Length == 0 ? null : parent;
    }

    public static string GetFileName(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return string.Empty;
        }

        var p = Normalize(path);
        var index = p.LastIndexOfAny([WindowsSeparator, UnixSeparator]);
        return index < 0 || index == p.Length - 1 ? p : p[(index + 1)..];
    }

    /// <summary>Lower-case extension including the dot, or <c>null</c> when the name has none.</summary>
    public static string? GetExtensionOrNull(string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return null;
        }

        var index = name.LastIndexOf('.');
        if (index <= 0 || index == name.Length - 1)
        {
            return null; // ".gitignore" style dot-files and extension-less names
        }

        return name[index..].ToLowerInvariant();
    }

    public static string? GetDriveRoot(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return null;
        }

        var p = Normalize(path);
        if (p.Length >= 2 && p[1] == ':' && IsAsciiLetter(p[0]))
        {
            return p[..2] + WindowsSeparator;
        }

        if (p.StartsWith(@"\\", StringComparison.Ordinal))
        {
            var parts = p.Split(WindowsSeparator, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length >= 2 ? $@"\\{parts[0]}\{parts[1]}\" : null;
        }

        if (p.StartsWith(UnixSeparator.ToString(), StringComparison.Ordinal))
        {
            return UnixSeparator.ToString();
        }

        return null;
    }

    /// <summary>
    /// Prefixes a Windows path so that paths longer than MAX_PATH work even when
    /// the OS long-path policy is off. Pure function: safe to test on any OS.
    /// </summary>
    public static string ToExtendedLengthPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return string.Empty;
        }

        var p = Normalize(path);
        if (p.StartsWith(ExtendedPrefix, StringComparison.Ordinal) ||
            p.StartsWith(DevicePrefix, StringComparison.Ordinal))
        {
            return p;
        }

        if (p.StartsWith(@"\\", StringComparison.Ordinal))
        {
            return UncPrefix + p[2..];
        }

        if (p.Length >= 2 && p[1] == ':' && IsAsciiLetter(p[0]))
        {
            return ExtendedPrefix + p;
        }

        return p;
    }

    /// <summary>Inverse of <see cref="ToExtendedLengthPath"/>.</summary>
    public static string FromExtendedLengthPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return string.Empty;
        }

        if (path.StartsWith(UncPrefix, StringComparison.Ordinal))
        {
            return @"\\" + path[UncPrefix.Length..];
        }

        if (path.StartsWith(ExtendedPrefix, StringComparison.Ordinal))
        {
            return path[ExtendedPrefix.Length..];
        }

        return path;
    }

    /// <summary>Applies the extended-length prefix only where it is meaningful (Windows).</summary>
    public static string ToExtendedLengthPathIfWindows(string path) =>
        RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? ToExtendedLengthPath(path) : Normalize(path);

    public static string ExpandEnvironmentVariables(string? path) =>
        string.IsNullOrWhiteSpace(path) ? string.Empty : Environment.ExpandEnvironmentVariables(path);

    /// <summary>
    /// Combines segments and normalises, without the surprises of
    /// <see cref="Path.Combine(string,string)"/> when a segment is already rooted.
    /// </summary>
    public static string Combine(params string?[] segments)
    {
        var builder = new StringBuilder();
        foreach (var segment in segments)
        {
            if (string.IsNullOrWhiteSpace(segment))
            {
                continue;
            }

            var s = segment.Trim();
            if (builder.Length == 0 || IsPathRooted(s))
            {
                builder.Clear();
                builder.Append(s);
                continue;
            }

            var separator = LooksLikeWindowsPath(builder.ToString()) ? WindowsSeparator : UnixSeparator;
            if (builder[^1] != separator)
            {
                builder.Append(separator);
            }

            builder.Append(s);
        }

        return Normalize(builder.ToString());
    }

    /// <summary>
    /// OS-independent "is this an absolute path". <see cref="Path.IsPathRooted"/> is
    /// useless here: on Linux it reports <c>false</c> for <c>C:\Windows</c>, and the
    /// classification rules are written with Windows paths no matter where they run.
    /// </summary>
    public static bool IsPathRooted(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return false;
        }

        var p = path.Trim();
        if (p[0] is WindowsSeparator or UnixSeparator)
        {
            return true;
        }

        if (p.Length >= 2 && p[1] == ':' && IsAsciiLetter(p[0]))
        {
            return p.Length == 2 || p[2] is WindowsSeparator or UnixSeparator || p.Contains('\\');
        }

        return false;
    }

    /// <summary>Shortens a long path for display: <c>C:\Very\Long\...\file.txt</c>.</summary>
    public static string ShortenForDisplay(string? path, int maxLength = 90)
    {
        var p = path ?? string.Empty;
        if (p.Length <= maxLength)
        {
            return p;
        }

        var name = GetFileName(p);
        var budget = maxLength - name.Length - 4; // "...\ "
        if (budget <= 8)
        {
            return "..." + p[^Math.Min(p.Length, maxLength - 3)..];
        }

        var head = p[..budget];
        var cut = head.LastIndexOfAny([WindowsSeparator, UnixSeparator]);
        if (cut > 8)
        {
            head = head[..cut];
        }

        return head + "\\...\\" + name;
    }

    private static bool IsAsciiLetter(char c) => (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}
