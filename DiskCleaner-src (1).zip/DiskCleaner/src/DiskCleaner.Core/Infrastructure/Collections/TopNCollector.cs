namespace DiskCleaner.Core.Infrastructure.Collections;

/// <summary>
/// Thread-safe "top N by size" collector with <b>fixed</b> memory.
/// </summary>
/// <remarks>
/// A deep scan sees millions of files. Keeping them all to sort at the end is
/// not an option, so only the N best entries are retained and every rejected
/// entry costs one interlocked read (no lock) thanks to <see cref="_threshold"/>.
/// </remarks>
public sealed class TopNCollector<T>(int capacity, Func<T, long> keySelector)
    where T : notnull
{
    private readonly int _capacity = Math.Max(1, capacity);
    private readonly List<T> _items = [];           // kept sorted ASCENDING by key
    private readonly object _gate = new();

    private long _threshold;      // key of the worst retained item; 0 while not full
    private long _totalSeen;
    private long _totalBytes;

    public int Capacity => _capacity;

    public int Count { get { lock (_gate) { return _items.Count; } } }

    public long TotalSeen => Interlocked.Read(ref _totalSeen);

    /// <summary>Sum of keys of every item ever offered, including rejected ones.</summary>
    public long TotalBytes => Interlocked.Read(ref _totalBytes);

    /// <summary>Smallest key currently retained (0 while the collector is not full yet).</summary>
    public long Threshold => Interlocked.Read(ref _threshold);

    /// <summary>
    /// Offers an item. Returns <c>true</c> when it entered the ranking.
    /// </summary>
    public bool TryAdd(T item)
    {
        var key = keySelector(item);

        Interlocked.Increment(ref _totalSeen);
        Interlocked.Add(ref _totalBytes, key);

        // Fast rejection without touching the lock.
        var threshold = Interlocked.Read(ref _threshold);
        if (threshold > 0 && key < threshold)
        {
            return false;
        }

        lock (_gate)
        {
            var index = FindInsertIndex(key);

            if (_items.Count >= _capacity && index == 0)
            {
                return false;
            }

            _items.Insert(index, item);
            if (_items.Count > _capacity)
            {
                _items.RemoveAt(0);
            }

            _threshold = _items.Count > 0 ? keySelector(_items[0]) : 0;
            return true;
        }
    }

    /// <summary>Snapshot ordered largest-first. Allocation only on demand.</summary>
    public IReadOnlyList<T> ToDescendingList()
    {
        lock (_gate)
        {
            var copy = new List<T>(_items.Count);
            for (var i = _items.Count - 1; i >= 0; i--)
            {
                copy.Add(_items[i]);
            }

            return copy;
        }
    }

    public void Clear()
    {
        lock (_gate)
        {
            _items.Clear();
            _threshold = 0;
        }
    }

    /// <summary>Leftmost position where <paramref name="key"/> keeps the list ascending.</summary>
    private int FindInsertIndex(long key)
    {
        var low = 0;
        var high = _items.Count;
        while (low < high)
        {
            var mid = low + ((high - low) / 2);
            if (keySelector(_items[mid]) < key)
            {
                low = mid + 1;
            }
            else
            {
                high = mid;
            }
        }

        return low;
    }
}
