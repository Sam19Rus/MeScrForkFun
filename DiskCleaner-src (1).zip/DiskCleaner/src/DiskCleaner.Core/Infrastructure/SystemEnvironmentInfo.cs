using System.Runtime.InteropServices;
using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Infrastructure;

/// <summary>Portable implementation of <see cref="IEnvironmentInfo"/>.</summary>
/// <remarks>
/// Uses environment variables plus <see cref="Environment.SpecialFolder"/> rather
/// than Win32 APIs so the same code runs (and can be tested) anywhere. Values
/// that cannot be resolved stay <c>null</c> — callers must treat them as
/// "unknown", never as "absent".
/// </remarks>
public sealed class SystemEnvironmentInfo(IFileSystem? fileSystem = null) : IEnvironmentInfo
{
    private static readonly string[] NonProfileDirectories =
    [
        "public", "default", "default user", "all users", "desktop.ini",
    ];

    private readonly IFileSystem _fileSystem = fileSystem ?? new PhysicalFileSystem();
    private readonly Lazy<SpecialFolders> _folders = new(ResolveFolders);

    public bool IsWindows => RuntimeInformation.IsOSPlatform(OSPlatform.Windows);

    public string MachineName => Environment.MachineName;

    public Version? OsVersion => Environment.OSVersion.Version;

    public SpecialFolders Folders => _folders.Value;

    public IReadOnlyList<string> EnumerateUserProfiles()
    {
        var usersRoot = Folders.UsersRoot;
        if (string.IsNullOrWhiteSpace(usersRoot))
        {
            var current = Folders.UserProfile;
            return string.IsNullOrWhiteSpace(current) ? [] : [current];
        }

        try
        {
            var result = new List<string>();
            foreach (var entry in _fileSystem.EnumerateEntries(usersRoot))
            {
                if (!entry.IsDirectory)
                {
                    continue;
                }

                if (NonProfileDirectories.Contains(entry.Name, StringComparer.OrdinalIgnoreCase))
                {
                    continue;
                }

                // A profile always has an AppData folder; anything else is not a user.
                if (_fileSystem.DirectoryExists(PathUtils.Combine(entry.FullPath, "AppData")))
                {
                    result.Add(entry.FullPath);
                }
            }

            // The current user must always be present, even when the heuristic missed it.
            var profile = Folders.UserProfile;
            if (!string.IsNullOrWhiteSpace(profile) && !result.Contains(profile, PathUtils.Comparer))
            {
                result.Insert(0, profile);
            }

            return result;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
        {
            var current = Folders.UserProfile;
            return string.IsNullOrWhiteSpace(current) ? [] : [current];
        }
    }

    private static SpecialFolders ResolveFolders()
    {
        var windows = FirstNonEmpty(
            Environment.GetEnvironmentVariable("SystemRoot"),
            Environment.GetEnvironmentVariable("windir"),
            TrySpecialFolder(Environment.SpecialFolder.Windows));

        var userProfile = FirstNonEmpty(
            Environment.GetEnvironmentVariable("USERPROFILE"),
            TrySpecialFolder(Environment.SpecialFolder.UserProfile));

        var programFiles = FirstNonEmpty(
            Environment.GetEnvironmentVariable("ProgramW6432"),
            Environment.GetEnvironmentVariable("ProgramFiles"),
            TrySpecialFolder(Environment.SpecialFolder.ProgramFiles));

        var usersRoot = FirstNonEmpty(
            Environment.GetEnvironmentVariable("PUBLIC") is { Length: > 0 } pub ? PathUtils.GetParent(pub) : null,
            userProfile is not null ? PathUtils.GetParent(userProfile) : null,
            windows is not null ? PathUtils.Combine(PathUtils.GetDriveRoot(windows) ?? @"C:\", "Users") : null);

        var localAppData = FirstNonEmpty(
            Environment.GetEnvironmentVariable("LOCALAPPDATA"),
            TrySpecialFolder(Environment.SpecialFolder.LocalApplicationData));

        var roamingAppData = FirstNonEmpty(
            Environment.GetEnvironmentVariable("APPDATA"),
            TrySpecialFolder(Environment.SpecialFolder.ApplicationData));

        return new SpecialFolders
        {
            Windows = EmptyToNull(windows),
            System32 = EmptyToNull(windows is null ? TrySpecialFolder(Environment.SpecialFolder.System) : PathUtils.Combine(windows, "System32")),
            ProgramFiles = EmptyToNull(programFiles),
            ProgramFilesX86 = EmptyToNull(FirstNonEmpty(
                Environment.GetEnvironmentVariable("ProgramFiles(x86)"),
                TrySpecialFolder(Environment.SpecialFolder.ProgramFilesX86))),
            ProgramData = EmptyToNull(FirstNonEmpty(
                Environment.GetEnvironmentVariable("ProgramData"),
                TrySpecialFolder(Environment.SpecialFolder.CommonApplicationData))),
            UsersRoot = EmptyToNull(usersRoot),
            UserProfile = EmptyToNull(userProfile),
            RoamingAppData = EmptyToNull(roamingAppData),
            LocalAppData = EmptyToNull(localAppData),
            LocalAppDataLow = EmptyToNull(userProfile is null ? null : PathUtils.Combine(userProfile, "AppData", "LocalLow")),
            UserTemp = EmptyToNull(FirstNonEmpty(
                Environment.GetEnvironmentVariable("TEMP"),
                Environment.GetEnvironmentVariable("TMP"),
                Path.GetTempPath())),
            WindowsTemp = EmptyToNull(windows is null ? null : PathUtils.Combine(windows, "Temp")),
            StartMenuPrograms = EmptyToNull(FirstNonEmpty(
                TrySpecialFolder(Environment.SpecialFolder.Programs),
                roamingAppData is null ? null : PathUtils.Combine(roamingAppData, @"Microsoft\Windows\Start Menu\Programs"))),
            CommonStartMenuPrograms = EmptyToNull(FirstNonEmpty(
                TrySpecialFolder(Environment.SpecialFolder.CommonPrograms),
                Environment.GetEnvironmentVariable("ProgramData") is { Length: > 0 } pd
                    ? PathUtils.Combine(pd, @"Microsoft\Windows\Start Menu\Programs")
                    : null)),
        };
    }

    private static string? TrySpecialFolder(Environment.SpecialFolder folder)
    {
        try
        {
            var value = Environment.GetFolderPath(folder);
            return string.IsNullOrWhiteSpace(value) ? null : value;
        }
        catch (Exception ex) when (ex is PlatformNotSupportedException or ArgumentException)
        {
            return null;
        }
    }

    private static string? FirstNonEmpty(params string?[] candidates)
    {
        foreach (var candidate in candidates)
        {
            if (!string.IsNullOrWhiteSpace(candidate))
            {
                return candidate;
            }
        }

        return null;
    }

    private static string? EmptyToNull(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : PathUtils.Normalize(value);
}
