using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Infrastructure;

/// <summary>
/// Minimal <c>*</c> / <c>?</c> matcher for file names.
/// </summary>
/// <remarks>
/// Written by hand instead of pulling in a globbing package: the patterns used by the
/// safe-location catalog are simple (<c>thumbcache_*.db</c>, <c>*.dmp</c>) and this keeps
/// the semantics explicit, allocation-free and unit-testable.
/// </remarks>
public static class WildcardMatcher
{
    public static bool IsMatch(string? input, string? pattern)
    {
        if (string.IsNullOrEmpty(pattern))
        {
            return true;
        }

        if (input is null)
        {
            return false;
        }

        return Match(input.AsSpan(), pattern.AsSpan());
    }

    private static bool Match(ReadOnlySpan<char> input, ReadOnlySpan<char> pattern)
    {
        var i = 0;
        var p = 0;
        var star = -1;
        var resume = 0;

        while (i < input.Length)
        {
            if (p < pattern.Length && (pattern[p] == '?' || char.ToUpperInvariant(pattern[p]) == char.ToUpperInvariant(input[i])))
            {
                i++;
                p++;
                continue;
            }

            if (p < pattern.Length && pattern[p] == '*')
            {
                star = p++;
                resume = i;
                continue;
            }

            if (star >= 0)
            {
                p = star + 1;
                i = ++resume;
                continue;
            }

            return false;
        }

        while (p < pattern.Length && pattern[p] == '*')
        {
            p++;
        }

        return p == pattern.Length;
    }
}
