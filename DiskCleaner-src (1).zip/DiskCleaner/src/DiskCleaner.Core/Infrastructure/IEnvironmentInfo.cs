using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Infrastructure;

/// <summary>Well-known Windows folders, resolved once at startup.</summary>
public sealed record SpecialFolders
{
    /// <summary><c>C:\Windows</c></summary>
    public string? Windows { get; init; }

    /// <summary><c>C:\Windows\System32</c></summary>
    public string? System32 { get; init; }

    /// <summary><c>C:\Program Files</c></summary>
    public string? ProgramFiles { get; init; }

    /// <summary><c>C:\Program Files (x86)</c></summary>
    public string? ProgramFilesX86 { get; init; }

    /// <summary><c>C:\ProgramData</c></summary>
    public string? ProgramData { get; init; }

    /// <summary><c>C:\Users</c></summary>
    public string? UsersRoot { get; init; }

    /// <summary><c>C:\Users\alice</c></summary>
    public string? UserProfile { get; init; }

    /// <summary><c>%APPDATA%</c></summary>
    public string? RoamingAppData { get; init; }

    /// <summary><c>%LOCALAPPDATA%</c></summary>
    public string? LocalAppData { get; init; }

    /// <summary><c>%USERPROFILE%\AppData\LocalLow</c></summary>
    public string? LocalAppDataLow { get; init; }

    /// <summary><c>%TEMP%</c> of the current user.</summary>
    public string? UserTemp { get; init; }

    /// <summary><c>C:\Windows\Temp</c></summary>
    public string? WindowsTemp { get; init; }

    /// <summary>Per-user Start Menu → Programs.</summary>
    public string? StartMenuPrograms { get; init; }

    /// <summary>All-users Start Menu → Programs.</summary>
    public string? CommonStartMenuPrograms { get; init; }

    /// <summary>All folders that actually resolved to something.</summary>
    public IEnumerable<string> All()
    {
        foreach (var value in new[]
                 {
                     Windows, System32, ProgramFiles, ProgramFilesX86, ProgramData, UsersRoot, UserProfile,
                     RoamingAppData, LocalAppData, LocalAppDataLow, UserTemp, WindowsTemp,
                     StartMenuPrograms, CommonStartMenuPrograms,
                 })
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                yield return value!;
            }
        }
    }
}

/// <summary>
/// Machine facts the analyzers need. Abstracted so classification rules can be
/// tested with fabricated folder layouts instead of a real Windows install.
/// </summary>
public interface IEnvironmentInfo
{
    bool IsWindows { get; }

    string MachineName { get; }

    Version? OsVersion { get; }

    SpecialFolders Folders { get; }

    /// <summary>Every real user profile directory under <c>C:\Users</c>.</summary>
    IReadOnlyList<string> EnumerateUserProfiles();
}
