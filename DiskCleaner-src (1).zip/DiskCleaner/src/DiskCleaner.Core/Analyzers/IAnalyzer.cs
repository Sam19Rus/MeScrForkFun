using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.Core.Analyzers;

/// <summary>
/// The extension point for everything that turns "bytes on disk" into
/// "this is what those bytes are".
/// </summary>
/// <remarks>
/// Adding a new analyzer (a new browser, a new build tool, a new dump location)
/// must never require touching <see cref="Scanning.FileSystemScanner"/>. An analyzer:
/// <list type="number">
///   <item><description>declares which scan modes it participates in;</description></item>
///   <item><description>either reads the shared aggregation of the full pass, or measures
///   the specific folders it knows about through <see cref="IDirectoryMeasurer"/>;</description></item>
///   <item><description>emits <see cref="ScanItem"/>s through the context, which applies the
///   safety policy before anything reaches the report.</description></item>
/// </list>
/// Analyzers must not delete, must not throw (a failing analyzer is logged and skipped,
/// never fatal to the scan) and must not use name-pattern heuristics as evidence of what
/// a folder is for.
/// </remarks>
public interface IAnalyzer
{
    /// <summary>Stable identifier, recorded on every <see cref="ScanItem.SourceAnalyzer"/>.</summary>
    string Name { get; }

    /// <summary>Short description shown in the "why was this found" tooltip.</summary>
    string Description { get; }

    /// <summary>Modes this analyzer runs in. Quick scan only runs targeted, cheap analyzers.</summary>
    IReadOnlyCollection<ScanMode> SupportedModes { get; }

    /// <summary>Order of execution. Lower runs first.</summary>
    int Order { get; }

    /// <summary>Whether the user turned this analyzer on (e.g. developer analysis).</summary>
    bool IsEnabled(AppSettings settings);

    Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken);
}

/// <summary>
/// Everything an analyzer is given: read-only inputs plus one output channel.
/// </summary>
public sealed class AnalyzerContext
{
    private readonly List<ScanItem> _items = [];
    private readonly HashSet<string> _emittedPaths;
    private readonly List<ScanIssue> _issues = [];
    private readonly Dictionary<string, object> _reports = new(StringComparer.Ordinal);
    private readonly object _gate = new();

    /// <summary>Hard cap: a mis-permissioned machine can produce thousands of them.</summary>
    public const int MaxRetainedIssues = 5_000;

    public AnalyzerContext(
        ScanOptions options,
        AppSettings settings,
        IReadOnlyList<DriveSnapshot> drives,
        IReadOnlyList<DirectoryAggregate> directories,
        IReadOnlyList<ScanItem> largestFiles,
        IEnvironmentInfo environment,
        IFileSystem fileSystem,
        IDirectoryMeasurer measurer,
        ISafetyPolicy safety,
        ILogger? logger = null)
    {
        Options = options;
        Settings = settings;
        Drives = drives;
        Directories = directories;
        LargestFiles = largestFiles;
        Environment = environment;
        FileSystem = fileSystem;
        Measurer = measurer;
        Safety = safety;
        Logger = logger ?? Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance;
        Resolver = new LocationResolver(environment, fileSystem);
        _emittedPaths = new HashSet<string>(PathUtils.Comparer);
    }

    public ScanOptions Options { get; }

    public AppSettings Settings { get; }

    public IReadOnlyList<DriveSnapshot> Drives { get; }

    /// <summary>The whole space map from the full pass. Empty for targeted quick scans.</summary>
    public IReadOnlyList<DirectoryAggregate> Directories { get; }

    /// <summary>Pre-ranked largest files, biggest first.</summary>
    public IReadOnlyList<ScanItem> LargestFiles { get; }

    public IEnvironmentInfo Environment { get; }

    public IFileSystem FileSystem { get; }

    public IDirectoryMeasurer Measurer { get; }

    public ISafetyPolicy Safety { get; }

    public ILogger Logger { get; }

    public LocationResolver Resolver { get; }

    public CancellationToken CancellationToken { get; init; }

    /// <summary>Items accepted into the report, in emission order.</summary>
    public IReadOnlyList<ScanItem> Items
    {
        get { lock (_gate) { return _items.ToArray(); } }
    }

    /// <summary>Number of items accepted into the report.</summary>
    public int EmittedCount { get; private set; }

    private long _measuredFiles;
    private long _measuredBytes;
    private long _measuredDirectories;

    /// <summary>
    /// Records what the analyzers actually walked. Targeted scans never run the full
    /// enumeration pass, so without these counters the report would describe only the
    /// candidates it kept — understating how much of the disk was examined.
    /// </summary>
    public void AddMeasured(long files, long bytes, long directories)
    {
        Interlocked.Add(ref _measuredFiles, files);
        Interlocked.Add(ref _measuredBytes, bytes);
        Interlocked.Add(ref _measuredDirectories, directories);
    }

    public long MeasuredFiles => Interlocked.Read(ref _measuredFiles);

    public long MeasuredBytes => Interlocked.Read(ref _measuredBytes);

    public long MeasuredDirectories => Interlocked.Read(ref _measuredDirectories);

    /// <summary>
    /// Number of items dropped because another analyzer already reported the same path
    /// <b>or a folder containing it</b>. Several rules legitimately resolve to the same
    /// folder (the current user's TEMP is also "a profile's TEMP"), and counting it twice
    /// would inflate the promise.
    /// </summary>
    public int DuplicateCount { get; private set; }

    /// <summary>
    /// Number of already-accepted items retracted because a later analyzer claimed a folder
    /// that contains them (npm logs inside the npm cache). The outer, more complete claim wins.
    /// </summary>
    public int SupersededCount { get; private set; }

    /// <summary>Resolves a whitelist template into the paths that exist on this machine.</summary>
    public IEnumerable<string> ResolveLocation(SafeLocation location) => Resolver.Resolve(location);

    /// <summary>
    /// Records something an analyzer could not read, so the report can say the number is
    /// a lower bound instead of silently understating it.
    /// </summary>
    public void ReportIssue(ScanIssue issue)
    {
        lock (_gate)
        {
            if (_issues.Count < MaxRetainedIssues)
            {
                _issues.Add(issue);
            }
        }
    }

    public IReadOnlyList<ScanIssue> Issues
    {
        get { lock (_gate) { return _issues.ToArray(); } }
    }

    /// <summary>
    /// Attaches a structured report that does not fit the flat <see cref="ScanItem"/> model
    /// (the AppData tree, later the leftover-application evidence). Keyed by analyzer.
    /// </summary>
    public void AttachReport(string key, object report)
    {
        lock (_gate)
        {
            _reports[key] = report;
        }
    }

    public IReadOnlyDictionary<string, object> Reports
    {
        get { lock (_gate) { return new Dictionary<string, object>(_reports, StringComparer.Ordinal); } }
    }

    /// <summary>
    /// Publishes a candidate. The safety policy is applied here, centrally, so no
    /// analyzer can accidentally propose a protected path: confidence is capped, risk is
    /// floored and <see cref="ScanItem.IsProtected"/> is set before the item is accepted.
    /// </summary>
    /// <returns><c>true</c> when the item was accepted into the report.</returns>
    public bool Emit(ScanItem item, bool explicitUserChoice = false)
    {
        var verdict = Safety.Evaluate(item.Path, item.Category, item.Kind, explicitUserChoice);

        item.IsProtected = !verdict.IsAllowed || Safety.IsProtected(item.Path);
        item.RequiresElevation = verdict.RequiresElevation;

        if (!verdict.IsAllowed)
        {
            item.IsDeletable = false;
            item.DeletionMethod = DeletionMethod.None;
            item.Confidence = CleanupConfidence.NeedsReview;
            item.RiskLevel = RiskLevel.Critical;
            item.Reason ??= verdict.RuleName;
            item.Explanation ??= verdict.RejectionReason;
            return false;
        }

        // The policy sets the ceiling; an analyzer can be more cautious but never bolder.
        if (item.Confidence > verdict.MaxConfidence)
        {
            item.Confidence = verdict.MaxConfidence;
        }

        if (item.RiskLevel < verdict.MinRisk)
        {
            item.RiskLevel = verdict.MinRisk;
        }

        if (item.DeletionMethod == DeletionMethod.None)
        {
            item.IsDeletable = false;
        }

        lock (_gate)
        {
            if (_emittedPaths.Contains(item.Path))
            {
                DuplicateCount++;
                return false;
            }

            // Inside an already-accepted item: the outer claim already owns these bytes.
            // Analyzers run in Order, so the more targeted rule usually gets here first.
            if (ContainsAncestor(item.Path))
            {
                DuplicateCount++;
                return false;
            }

            // The new claim contains previously accepted ones and is more complete
            // (the whole npm cache vs. only its _logs folder). Retract the children so the
            // same bytes are never promised twice.
            for (var i = _items.Count - 1; i >= 0; i--)
            {
                if (PathUtils.IsUnder(_items[i].Path, item.Path))
                {
                    _emittedPaths.Remove(_items[i].Path);
                    _items.RemoveAt(i);
                    SupersededCount++;
                }
            }

            _items.Add(item);
            _emittedPaths.Add(item.Path);
            EmittedCount++;
        }

        return true;
    }

    /// <summary>Must be called under <see cref="_gate"/>.</summary>
    private bool ContainsAncestor(string path)
    {
        foreach (var accepted in _items)
        {
            if (PathUtils.IsUnder(path, accepted.Path))
            {
                return true;
            }
        }

        return false;
    }
}
