using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Analyzers;

/// <summary>
/// One entry of the safe-cleanup whitelist.
/// </summary>
/// <remarks>
/// Every entry is an explicit, hand-written decision about a specific location. There is
/// deliberately no pattern matching on names anywhere in this catalog: "folder contains
/// cache" is never evidence of what a folder is for.
/// </remarks>
public sealed record SafeLocation
{
    /// <summary>
    /// Path template. Supported tokens: <c>{Windows}</c>, <c>{ProgramData}</c>,
    /// <c>{ProgramFiles}</c>, <c>{ProgramFilesX86}</c>, <c>{UserProfile}</c>,
    /// <c>{AnyProfile}</c> (expands to every real profile), <c>{LocalAppData}</c>,
    /// <c>{RoamingAppData}</c>, <c>{LocalAppDataLow}</c>, <c>{UserTemp}</c>,
    /// <c>{WindowsTemp}</c>. A path segment equal to <c>*</c> expands to matching
    /// subdirectories (used for browser profile folders).
    /// </summary>
    public required string PathTemplate { get; init; }

    public required ScanCategory Category { get; init; }

    /// <summary>Ceiling proposed by this rule. The safety policy can still lower it.</summary>
    public required CleanupConfidence Confidence { get; init; }

    public required RiskLevel Risk { get; init; }

    public required DeletionMethod Method { get; init; }

    /// <summary>Stable key used for localisation and for tests, e.g. <c>temp.user</c>.</summary>
    public required string ReasonKey { get; init; }

    /// <summary>English fallback explanation; the UI resolves <see cref="ReasonKey"/> first.</summary>
    public required string Explanation { get; init; }

    /// <summary>Owning application, when the location belongs to one.</summary>
    public string? OwnerApplication { get; init; }

    /// <summary>Match files inside the folder rather than the folder itself.</summary>
    public string? FileNamePattern { get; init; }
}

/// <summary>
/// The whitelist. Reviewing this file is reviewing what the product considers safe.
/// </summary>
public static class SafeLocationCatalog
{
    /// <summary>
    /// Temporary files. Recreated by the owning application on demand; files that are
    /// still in use are skipped by the executor, never force-deleted.
    /// </summary>
    public static readonly IReadOnlyList<SafeLocation> Temporary =
    [
        new()
        {
            PathTemplate = "{UserTemp}",
            Category = ScanCategory.TemporaryFiles,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "temp.user",
            Explanation = "The current user's TEMP folder. Applications write scratch files here and are expected to work with an empty one.",
        },
        new()
        {
            PathTemplate = "{AnyProfile}\\AppData\\Local\\Temp",
            Category = ScanCategory.TemporaryFiles,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "temp.profile",
            Explanation = "TEMP folder of a user profile. Requires administrator rights when it belongs to another user.",
        },
        new()
        {
            PathTemplate = "{WindowsTemp}",
            Category = ScanCategory.TemporaryFiles,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "temp.windows",
            Explanation = "Windows TEMP folder. An explicitly whitelisted enclave inside the Windows directory; needs administrator rights.",
        },
    ];

    /// <summary>
    /// Browser caches. Each entry lists the concrete cache directories of a concrete
    /// browser — never "any folder named Cache".
    /// </summary>
    public static readonly IReadOnlyList<SafeLocation> BrowserCaches = BuildBrowserCaches();

    /// <summary>Crash dumps and Windows error reporting queues.</summary>
    public static readonly IReadOnlyList<SafeLocation> CrashDumps =
    [
        new()
        {
            PathTemplate = "{Windows}\\Minidump",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "dump.minidump",
            Explanation = "Kernel minidumps written after a bugcheck. Useful only for diagnosing a past crash; Windows does not need them.",
        },
        new()
        {
            PathTemplate = "{Windows}\\LiveKernelReports",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "dump.live-kernel-reports",
            Explanation = "Live kernel reports (often watchdog timeouts from drivers). Regenerated on the next event.",
        },
        new()
        {
            PathTemplate = "{Windows}\\MEMORY.DMP",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Medium,
            Method = DeletionMethod.Permanent,
            ReasonKey = "dump.memory-dmp",
            Explanation = "Full memory dump of a past bugcheck. It can be several gigabytes and is only needed to analyse that specific crash.",
        },
        new()
        {
            PathTemplate = "{LocalAppData}\\CrashDumps",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "dump.local-crashdumps",
            Explanation = "User-mode crash dumps written by Windows Error Reporting for the current user.",
        },
        new()
        {
            PathTemplate = "{LocalAppData}\\Microsoft\\Windows\\WER\\ReportQueue",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wer.report-queue",
            Explanation = "Windows Error Reporting queue: reports prepared for sending. Safe to clear; WER recreates the folder.",
        },
        new()
        {
            PathTemplate = "{LocalAppData}\\Microsoft\\Windows\\WER\\ReportArchive",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wer.report-archive",
            Explanation = "Windows Error Reporting archive of already-processed reports.",
        },
        new()
        {
            PathTemplate = "{ProgramData}\\Microsoft\\Windows\\WER\\ReportQueue",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wer.report-queue.machine",
            Explanation = "Machine-wide Windows Error Reporting queue. Needs administrator rights.",
        },
        new()
        {
            PathTemplate = "{ProgramData}\\Microsoft\\Windows\\WER\\ReportArchive",
            Category = ScanCategory.CrashDumps,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wer.report-archive.machine",
            Explanation = "Machine-wide Windows Error Reporting archive. Needs administrator rights.",
        },
    ];

    /// <summary>Explorer thumbnail and icon caches.</summary>
    public static readonly IReadOnlyList<SafeLocation> Thumbnails =
    [
        new()
        {
            PathTemplate = "{LocalAppData}\\Microsoft\\Windows\\Explorer",
            Category = ScanCategory.Thumbnails,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "cache.thumbnails",
            Explanation = "Explorer thumbnail cache. Rebuilt automatically the next time a folder with images is opened.",
            FileNamePattern = "thumbcache_*.db",
        },
        new()
        {
            PathTemplate = "{LocalAppData}\\Microsoft\\Windows\\Explorer",
            Category = ScanCategory.Thumbnails,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "cache.iconcache",
            Explanation = "Explorer icon cache. Rebuilt automatically; icons may briefly appear generic afterwards.",
            FileNamePattern = "iconcache_*.db",
        },
    ];

    private static IReadOnlyList<SafeLocation> BuildBrowserCaches()
    {
        // Chromium-family browsers share the same profile layout, so the cache set is
        // declared once and applied to each browser's User Data directory.
        string[] chromiumCacheDirectories =
        [
            "Cache",
            "Code Cache",
            "GPUCache",
            "DawnCache",
            "DawnGraphiteCache",
            "DawnWebGPUCache",
            "GrShaderCache",
            "ShaderCache",
            "Service Worker\\CacheStorage",
            "Service Worker\\ScriptStorage",
        ];

        (string Owner, string UserData)[] chromiumBrowsers =
        [
            ("Google Chrome", "{LocalAppData}\\Google\\Chrome\\User Data"),
            ("Microsoft Edge", "{LocalAppData}\\Microsoft\\Edge\\User Data"),
            ("Brave", "{LocalAppData}\\BraveSoftware\\Brave-Browser\\User Data"),
            ("Vivaldi", "{LocalAppData}\\Vivaldi\\User Data"),
            ("Chromium", "{LocalAppData}\\Chromium\\User Data"),
            ("Opera", "{RoamingAppData}\\Opera Software\\Opera Stable"),
            ("Opera GX", "{LocalAppData}\\Opera Software\\Opera GX Stable"),
        ];

        var locations = new List<SafeLocation>();

        foreach (var (owner, userData) in chromiumBrowsers)
        {
            foreach (var cache in chromiumCacheDirectories)
            {
                locations.Add(new SafeLocation
                {
                    PathTemplate = $"{userData}\\*\\{cache}",
                    Category = ScanCategory.BrowserCache,
                    Confidence = CleanupConfidence.Safe,
                    Risk = RiskLevel.Low,
                    Method = DeletionMethod.Permanent,
                    ReasonKey = "cache.browser.chromium",
                    Explanation = $"{owner} cache. The browser rebuilds it; you are not signed out and no bookmarks, history or passwords are touched.",
                    OwnerApplication = owner,
                });
            }

            locations.Add(new SafeLocation
            {
                PathTemplate = $"{userData}\\ShaderCache",
                Category = ScanCategory.BrowserCache,
                Confidence = CleanupConfidence.Safe,
                Risk = RiskLevel.Low,
                Method = DeletionMethod.Permanent,
                ReasonKey = "cache.browser.shader",
                Explanation = $"{owner} shader cache. Regenerated on the next run; the first page loads may be marginally slower.",
                OwnerApplication = owner,
            });
        }

        // Firefox uses a different layout: one cache2 per profile.
        locations.Add(new SafeLocation
        {
            PathTemplate = "{LocalAppData}\\Mozilla\\Firefox\\Profiles\\*\\cache2",
            Category = ScanCategory.BrowserCache,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "cache.browser.firefox",
            Explanation = "Firefox cache. The browser rebuilds it; profiles, bookmarks and passwords are stored elsewhere.",
            OwnerApplication = "Mozilla Firefox",
        });

        locations.Add(new SafeLocation
        {
            PathTemplate = "{LocalAppData}\\Mozilla\\Firefox\\Profiles\\*\\startupCache",
            Category = ScanCategory.BrowserCache,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "cache.browser.firefox.startup",
            Explanation = "Firefox startup cache. Regenerated on the next launch.",
            OwnerApplication = "Mozilla Firefox",
        });

        return locations;
    }
}

/// <summary>
/// Turns <see cref="SafeLocation.PathTemplate"/> into real, existing paths.
/// </summary>
/// <remarks>
/// The resolver never invents a path: tokens are substituted with folders that actually
/// resolved on this machine, <c>{AnyProfile}</c> expands to enumerated profiles, and
/// <c>*</c> expands only to directories that exist. Anything unresolvable is dropped,
/// which keeps the report free of phantom entries.
/// </remarks>
public sealed class LocationResolver(IEnvironmentInfo environment, IFileSystem fileSystem)
{
    private const int MaxWildcardExpansion = 256;

    public IEnumerable<string> Resolve(SafeLocation location)
    {
        foreach (var path in ExpandTokens(location.PathTemplate))
        {
            foreach (var expanded in ExpandWildcards(path))
            {
                if (fileSystem.DirectoryExists(expanded) || fileSystem.FileExists(expanded))
                {
                    yield return expanded;
                }
            }
        }
    }

    private IEnumerable<string> ExpandTokens(string template)
    {
        var folders = environment.Folders;

        if (template.Contains("{AnyProfile}", StringComparison.Ordinal))
        {
            foreach (var profile in environment.EnumerateUserProfiles())
            {
                foreach (var path in ExpandTokens(template.Replace("{AnyProfile}", profile, StringComparison.Ordinal)))
                {
                    yield return path;
                }
            }

            yield break;
        }

        var substituted = template
            .Replace("{Windows}", folders.Windows ?? "\u0000", StringComparison.Ordinal)
            .Replace("{WindowsTemp}", folders.WindowsTemp ?? "\u0000", StringComparison.Ordinal)
            .Replace("{ProgramData}", folders.ProgramData ?? "\u0000", StringComparison.Ordinal)
            .Replace("{ProgramFiles}", folders.ProgramFiles ?? "\u0000", StringComparison.Ordinal)
            .Replace("{ProgramFilesX86}", folders.ProgramFilesX86 ?? "\u0000", StringComparison.Ordinal)
            .Replace("{UserProfile}", folders.UserProfile ?? "\u0000", StringComparison.Ordinal)
            .Replace("{LocalAppData}", folders.LocalAppData ?? "\u0000", StringComparison.Ordinal)
            .Replace("{RoamingAppData}", folders.RoamingAppData ?? "\u0000", StringComparison.Ordinal)
            .Replace("{LocalAppDataLow}", folders.LocalAppDataLow ?? "\u0000", StringComparison.Ordinal)
            .Replace("{UserTemp}", folders.UserTemp ?? "\u0000", StringComparison.Ordinal);

        // A token that did not resolve means this machine has no such folder: skip it
        // rather than emit a broken path.
        if (HasUnresolvedToken(substituted))
        {
            yield break;
        }

        yield return PathUtils.Normalize(substituted);
    }

    /// <summary>Unresolved tokens are replaced with NUL so they can be detected here.</summary>
    private static bool HasUnresolvedToken(string value) => value.Contains('\u0000');

    private IEnumerable<string> ExpandWildcards(string path)
    {
        var segments = path.Split(['\\', '/'], StringSplitOptions.None);
        var firstWildcard = Array.FindIndex(segments, s => s == "*");

        if (firstWildcard < 0)
        {
            yield return path;
            yield break;
        }

        var parent = string.Join('\\', segments[..firstWildcard]);
        if (parent.Length == 0 || !fileSystem.DirectoryExists(parent))
        {
            yield break;
        }

        var count = 0;
        foreach (var entry in SafeEnumerate(parent))
        {
            if (!entry.IsDirectory)
            {
                continue;
            }

            if (++count > MaxWildcardExpansion)
            {
                yield break;
            }

            var candidate = string.Join('\\', segments[..firstWildcard].Append(entry.Name).Concat(segments[(firstWildcard + 1)..]));
            foreach (var deeper in ExpandWildcards(PathUtils.Normalize(candidate)))
            {
                yield return deeper;
            }
        }
    }

    /// <summary>
    /// Lists the direct children of a directory, swallowing IO failures.
    /// Enumeration is lazy, so the whole listing is drained inside the try block.
    /// </summary>
    private List<ScannedEntry> SafeEnumerate(string directory)
    {
        var buffer = new List<ScannedEntry>();
        try
        {
            foreach (var entry in fileSystem.EnumerateEntries(directory))
            {
                buffer.Add(entry);
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException)
        {
            // An unreadable profile directory simply contributes no candidates.
        }

        return buffer;
    }
}
