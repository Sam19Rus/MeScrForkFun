using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Analyzers;

/// <summary>
/// Shared behaviour for analyzers driven by the safe-location whitelist:
/// resolve templates → measure what exists → emit classified items.
/// </summary>
/// <remarks>
/// Empty locations are skipped: offering to "clean 0 bytes" is noise. A location that
/// could only be read partially is still reported, but the item carries the honest
/// explanation that the number is a lower bound.
/// </remarks>
public abstract class LocationAnalyzerBase : IAnalyzer
{
    public abstract string Name { get; }

    public abstract string Description { get; }

    public virtual IReadOnlyCollection<ScanMode> SupportedModes { get; } =
        [ScanMode.Quick, ScanMode.Deep, ScanMode.Custom];

    public virtual int Order => 100;

    public virtual bool IsEnabled(AppSettings settings) => true;

    /// <summary>The slice of <see cref="SafeLocationCatalog"/> this analyzer owns.</summary>
    protected abstract IReadOnlyList<SafeLocation> Locations { get; }

    public async Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken)
    {
        foreach (var location in Locations)
        {
            cancellationToken.ThrowIfCancellationRequested();

            foreach (var path in context.ResolveLocation(location))
            {
                cancellationToken.ThrowIfCancellationRequested();

                var measurement = await context.Measurer
                    .MeasureAsync(path, location.FileNamePattern, cancellationToken)
                    .ConfigureAwait(false);

                if (!measurement.Exists)
                {
                    continue;
                }

                // Whatever could not be read must stay visible in the report.
                foreach (var issue in measurement.Issues.Take(20))
                {
                    context.ReportIssue(issue);
                }

                context.AddMeasured(measurement.FileCount, measurement.Bytes, measurement.DirectoryCount);

                if (location.FileNamePattern is null)
                {
                    EmitDirectory(context, location, measurement);
                }
                else
                {
                    // Two rules can point at the same folder with different patterns
                    // (thumbcache_*.db and iconcache_*.db), so those are reported per
                    // file — precise, individually excludable and impossible to
                    // double-count.
                    EmitMatchingFiles(context, location, measurement);
                }
            }
        }
    }

    private void EmitDirectory(AnalyzerContext context, SafeLocation location, DirectoryMeasurement measurement)
    {
        if (measurement.Bytes <= 0 && measurement.FileCount == 0)
        {
            return;
        }

        context.Emit(new ScanItem
        {
            Path = measurement.Path,
            Name = PathUtils.GetFileName(measurement.Path),
            Kind = measurement.IsFile ? ScanItemKind.File : ScanItemKind.Directory,
            Size = measurement.Bytes,
            FileCount = Math.Max(1, measurement.FileCount),
            CreatedAtUtc = measurement.IsFile ? measurement.OldestModificationUtc : null,
            ModifiedAtUtc = measurement.NewestModificationUtc,
            Category = location.Category,
            Confidence = location.Confidence,
            RiskLevel = location.Risk,
            IsDeletable = location.Method != DeletionMethod.None,
            DeletionMethod = location.Method,
            Reason = location.ReasonKey,
            Explanation = measurement.IsComplete
                ? location.Explanation
                : location.Explanation + " Part of this folder could not be read, so the size shown is a lower bound.",
            SourceAnalyzer = Name,
            OwnerApplication = location.OwnerApplication,
            DriveRoot = PathUtils.GetDriveRoot(measurement.Path),
        });
    }

    private void EmitMatchingFiles(AnalyzerContext context, SafeLocation location, DirectoryMeasurement measurement)
    {
        foreach (var file in measurement.MatchingFiles)
        {
            if (file.Size <= 0)
            {
                continue;
            }

            context.Emit(new ScanItem
            {
                Path = file.FullPath,
                Name = file.Name,
                Kind = ScanItemKind.File,
                Size = file.Size,
                FileCount = 1,
                CreatedAtUtc = file.CreatedUtc,
                ModifiedAtUtc = file.LastWriteUtc,
                Extension = PathUtils.GetExtensionOrNull(file.Name),
                Category = location.Category,
                Confidence = location.Confidence,
                RiskLevel = location.Risk,
                IsDeletable = location.Method != DeletionMethod.None,
                DeletionMethod = location.Method,
                Reason = location.ReasonKey,
                Explanation = location.Explanation,
                SourceAnalyzer = Name,
                OwnerApplication = location.OwnerApplication,
                DriveRoot = file.DriveRoot,
            });
        }
    }
}
