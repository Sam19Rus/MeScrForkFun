using DiskCleaner.Core.Analyzers.AppData;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Core.Analyzers;

/// <summary>
/// AppData analysis (§8 of the specification).
/// </summary>
/// <remarks>
/// Produces two different things, because they answer two different questions:
/// <list type="bullet">
///   <item><description>a structured <see cref="AppDataReport"/> — "what occupies AppData":
///   per-profile, per-root totals, per-application sizes, known cache / logs / temp /
///   packages / unknown breakdown and an expandable directory tree;</description></item>
///   <item><description>a small number of <see cref="ScanItem"/>s — only the groups an explicit
///   rule marks as reclaimable. Aggregate application entries are never emitted: a 12 GB
///   Chrome profile is an explanation, not a cleanup candidate.</description></item>
/// </list>
/// Attribution comes from <see cref="KnownApplications"/>. A folder that is not in the
/// catalog is reported as unknown with its size — never with an invented purpose.
/// </remarks>
/// <remarks>
/// Performance contract: the per-directory map of one AppData root can hold hundreds of
/// thousands of entries, and there are hundreds of application folders. Matching every
/// aggregate against every application would be quadratic and would dominate the scan, so
/// aggregates are grouped by their nearest application ancestor in a single pass
/// (<see cref="GroupByOwner"/>) and each application only ever sees its own slice.
/// </remarks>
public sealed class AppDataAnalyzer : IAnalyzer
{
    /// <summary>Key the report is attached under in <see cref="AnalyzerRunOutcome.Reports"/>.</summary>
    public const string ReportKey = "AppData";

    /// <summary>Quick scan stays fast: only the current profile, shallower tree.</summary>
    private const int QuickMaxDepth = 8;

    private const int FullMaxDepth = 12;

    /// <summary>Largest directories kept per application for the tree view.</summary>
    private const int MaxTreeNodesPerApp = 40;

    /// <summary>Largest directories kept per AppData root for the "biggest folders" list.</summary>
    private const int MaxTreeNodesPerRoot = 60;

    public string Name => WellKnownAnalyzers.AppData;

    public string Description => "Breakdown of %APPDATA%, %LOCALAPPDATA% and LocalLow per application and per content type.";

    public IReadOnlyCollection<ScanMode> SupportedModes { get; } =
        [ScanMode.Quick, ScanMode.Deep, ScanMode.Custom];

    /// <summary>Runs after the targeted analyzers so overlapping paths deduplicate to the more specific rule.</summary>
    public int Order => 60;

    public bool IsEnabled(AppSettings settings) => true;

    public async Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken)
    {
        var environment = context.Environment;
        var folders = environment.Folders;

        var quick = context.Options.Mode == ScanMode.Quick;
        var maxDepth = quick ? QuickMaxDepth : FullMaxDepth;

        // Quick scan looks at the current profile only; a deep scan covers every profile.
        IReadOnlyList<string> profiles = quick
            ? (string.IsNullOrWhiteSpace(folders.UserProfile) ? [] : [folders.UserProfile!])
            : [.. environment.EnumerateUserProfiles().Distinct(PathUtils.Comparer)];

        var roots = new List<AppDataRootSummary>();
        var applications = new List<AppDataApplication>();
        var incomplete = false;

        foreach (var profile in profiles)
        {
            foreach (var (kind, path) in ResolveRoots(profile, folders))
            {
                cancellationToken.ThrowIfCancellationRequested();

                var measurement = await context.Measurer
                    .MeasureTreeAsync(path, maxDepth, cancellationToken)
                    .ConfigureAwait(false);

                if (!measurement.Exists)
                {
                    roots.Add(new AppDataRootSummary { Root = kind, Path = path, Profile = profile, Exists = false });
                    continue;
                }

                incomplete |= !measurement.IsComplete;

                foreach (var issue in measurement.Issues.Take(50))
                {
                    context.ReportIssue(issue);
                }

                context.AddMeasured(measurement.FileCount, measurement.Bytes, measurement.DirectoryCount);

                var found = BuildApplications(kind, profile, path, measurement);
                applications.AddRange(found);

                roots.Add(new AppDataRootSummary
                {
                    Root = kind,
                    Path = path,
                    Profile = profile,
                    Exists = true,
                    Bytes = measurement.Bytes,
                    FileCount = measurement.FileCount,
                    ApplicationCount = found.Count,
                    IsComplete = measurement.IsComplete,
                    Issues = measurement.Issues.Take(50).ToArray(),
                });

                // Only groups an explicit rule marks reclaimable become cleanup candidates.
                foreach (var application in found)
                {
                    foreach (var group in application.Contents)
                    {
                        if (!group.IsReclaimable)
                        {
                            continue;
                        }

                        cancellationToken.ThrowIfCancellationRequested();
                        EmitGroup(context, application, group);
                    }
                }
            }
        }

        context.AttachReport(ReportKey, BuildReport(roots, applications, incomplete));
    }

    /// <summary>Resolves the three AppData roots of one profile.</summary>
    private static IEnumerable<(AppDataRoot Kind, string Path)> ResolveRoots(string profile, SpecialFolders folders)
    {
        var isCurrentProfile = !string.IsNullOrWhiteSpace(folders.UserProfile) &&
                               string.Equals(PathUtils.Normalize(profile), PathUtils.Normalize(folders.UserProfile), PathUtils.Comparison);

        yield return (AppDataRoot.Local, isCurrentProfile && folders.LocalAppData is { Length: > 0 }
            ? folders.LocalAppData!
            : PathUtils.Combine(profile, "AppData", "Local"));

        yield return (AppDataRoot.Roaming, isCurrentProfile && folders.RoamingAppData is { Length: > 0 }
            ? folders.RoamingAppData!
            : PathUtils.Combine(profile, "AppData", "Roaming"));

        yield return (AppDataRoot.LocalLow, isCurrentProfile && folders.LocalAppDataLow is { Length: > 0 }
            ? folders.LocalAppDataLow!
            : PathUtils.Combine(profile, "AppData", "LocalLow"));
    }

    /// <summary>
    /// Attributes every top-level AppData folder to an application, a vendor or "unknown".
    /// </summary>
    /// <remarks>
    /// Catalog entries may sit at any depth (<c>Microsoft\Windows\Explorer</c>) and may use
    /// <c>*</c> segments (Store package family names). Matching is indexed by the first path
    /// segment and limited to the catalog's own depth, so it stays linear in the number of
    /// directories rather than quadratic in directories × catalog entries.
    /// </remarks>
    private static List<AppDataApplication> BuildApplications(
        AppDataRoot kind,
        string profile,
        string rootPath,
        TreeMeasurement measurement)
    {
        var catalog = KnownApplications.ForRoot(kind);
        if (catalog.Count == 0)
        {
            catalog = [];
        }

        var maxCatalogDepth = catalog.Count == 0 ? 0 : catalog.Max(e => e.RelativePath.Split('\\').Length);
        var byFirstSegment = catalog
            .GroupBy(e => e.RelativePath.Split('\\')[0], PathUtils.Comparer)
            .ToDictionary(g => g.Key, g => g.ToArray(), PathUtils.Comparer);

        // --- pass 1: which catalog entries actually exist here? --------------
        var matched = new List<(KnownAppDataEntry Entry, DirectoryAggregate Aggregate)>();

        foreach (var aggregate in measurement.Aggregates)
        {
            if (aggregate.SubtreeBytes <= 0 || aggregate.Depth < 1 || aggregate.Depth > maxCatalogDepth)
            {
                continue;
            }

            var relative = AppDataContentRules.RelativeSegments(aggregate.Path, rootPath);
            if (relative.Count == 0 || relative.Count > maxCatalogDepth)
            {
                continue;
            }

            if (!byFirstSegment.TryGetValue(relative[0], out var candidates))
            {
                continue;
            }

            var entry = candidates.FirstOrDefault(e => KnownApplications.MatchesRelative(e, relative));
            if (entry is not null)
            {
                matched.Add((entry, aggregate));
            }
        }

        // Keep only the most specific matches: a catalog entry inside another catalog entry
        // would otherwise have its bytes counted twice in the parent's leftover.
        // Containers are the exception — they must survive even when a more specific entry
        // matches one of their children (Packages holds both ordinary Store apps and the
        // WSL distribution packages), because the container is what drives the expansion.
        var maximal = new List<(KnownAppDataEntry Entry, DirectoryAggregate Aggregate)>();
        foreach (var candidate in matched)
        {
            if (candidate.Entry.TreatChildrenAsApplications)
            {
                maximal.Add(candidate);
                continue;
            }

            var nested = matched.Any(other =>
                other.Aggregate.Path.Length > candidate.Aggregate.Path.Length &&
                PathUtils.IsUnder(other.Aggregate.Path, candidate.Aggregate.Path));

            if (!nested)
            {
                maximal.Add(candidate);
            }
        }

        // --- pass 2: build the plan from the top-level folders ---------------
        var plan = new List<AppPlan>();

        foreach (var top in measurement.Aggregates.Where(a => a.Depth == 1 && a.SubtreeBytes > 0))
        {
            var own = maximal.FirstOrDefault(m => string.Equals(m.Aggregate.Path, top.Path, PathUtils.Comparison));
            if (own.Entry is not null)
            {
                // A container (Packages) is not an application itself: each direct child is.
                if (own.Entry.TreatChildrenAsApplications)
                {
                    ExpandContainer(kind, own.Entry, top, maximal, measurement, plan);
                    continue;
                }

                plan.Add(new AppPlan(own.Entry, top, IsKnown: true));
                continue;
            }

            var under = maximal.Where(m => PathUtils.IsUnder(m.Aggregate.Path, top.Path)).ToArray();
            if (under.Length > 0)
            {
                long attributed = 0;
                foreach (var m in under)
                {
                    attributed += m.Aggregate.SubtreeBytes;
                    plan.Add(new AppPlan(m.Entry, m.Aggregate, IsKnown: true));
                }

                var leftover = top.SubtreeBytes - attributed;
                if (leftover > 0)
                {
                    var vendor = KnownApplications.FindVendor(kind, top.Name) ?? top.Name;
                    plan.Add(new AppPlan(
                        new KnownAppDataEntry(
                            kind, top.Name, vendor, null, KnownApplications.FamilyUnknown,
                            "Part of a vendor folder that could not be attributed to a known product."),
                        top with { SubtreeBytes = leftover },
                        IsKnown: false,
                        VendorOverride: vendor));
                }

                continue;
            }

            // Not in the catalog: report the size, never invent a purpose.
            plan.Add(new AppPlan(
                new KnownAppDataEntry(kind, top.Name, top.Name, null, KnownApplications.FamilyUnknown, string.Empty),
                top,
                IsKnown: false));
        }

        // --- pass 3: one grouping pass for every application slice -----------
        var slices = GroupByOwner(measurement.Aggregates, [.. plan.Select(p => p.Aggregate.Path)]);

        var result = new List<AppDataApplication>(plan.Count);
        foreach (var item in plan)
        {
            var slice = slices.TryGetValue(item.Aggregate.Path, out var found) ? found : [];
            result.Add(BuildApplication(item, kind, profile, slice));
        }

        return result;
    }

    /// <summary>
    /// Turns each direct child of a container folder into its own application, preferring a
    /// more specific catalog entry (the WSL distribution packages inside <c>Packages</c>).
    /// </summary>
    private static void ExpandContainer(
        AppDataRoot kind,
        KnownAppDataEntry container,
        DirectoryAggregate top,
        IReadOnlyList<(KnownAppDataEntry Entry, DirectoryAggregate Aggregate)> maximal,
        TreeMeasurement measurement,
        List<AppPlan> plan)
    {
        var prefix = PathUtils.EnsureTrailingSeparator(top.Path);

        foreach (var child in measurement.Aggregates.Where(a => a.Depth == top.Depth + 1 && a.SubtreeBytes > 0))
        {
            if (!child.Path.StartsWith(prefix, PathUtils.Comparison))
            {
                continue;
            }

            var specific = maximal.FirstOrDefault(m => string.Equals(m.Aggregate.Path, child.Path, PathUtils.Comparison));
            if (specific.Entry is not null)
            {
                plan.Add(new AppPlan(specific.Entry, child, IsKnown: true));
                continue;
            }

            plan.Add(new AppPlan(
                container with { RelativePath = child.Name, DisplayName = child.Name },
                child,
                IsKnown: true,
                VendorOverride: container.Vendor));
        }
    }

    /// <summary>
    /// Assigns every aggregate to the nearest application root above it, in one pass.
    /// Replaces the previous per-application full scan of the aggregate list.
    /// </summary>
    private static Dictionary<string, List<DirectoryAggregate>> GroupByOwner(
        IEnumerable<DirectoryAggregate> aggregates,
        IReadOnlyCollection<string> ownerPaths)
    {
        var owners = new HashSet<string>(ownerPaths, PathUtils.Comparer);
        var result = new Dictionary<string, List<DirectoryAggregate>>(PathUtils.Comparer);
        var memo = new Dictionary<string, string?>(PathUtils.Comparer);

        foreach (var aggregate in aggregates)
        {
            var owner = FindOwner(aggregate.Path, owners, memo);
            if (owner is null)
            {
                continue;
            }

            if (!result.TryGetValue(owner, out var list))
            {
                list = [];
                result[owner] = list;
            }

            list.Add(aggregate);
        }

        return result;
    }

    private static string? FindOwner(string path, HashSet<string> owners, Dictionary<string, string?> memo)
    {
        if (memo.TryGetValue(path, out var cached))
        {
            return cached;
        }

        var current = path;
        while (!string.IsNullOrEmpty(current))
        {
            if (owners.Contains(current))
            {
                memo[path] = current;
                return current;
            }

            var parent = PathUtils.GetParent(current);
            if (parent is null || string.Equals(parent, current, PathUtils.Comparison))
            {
                break;
            }

            current = parent;
        }

        memo[path] = null;
        return null;
    }

    private static AppDataApplication BuildApplication(
        AppPlan plan,
        AppDataRoot kind,
        string profile,
        IReadOnlyList<DirectoryAggregate> slice)
    {
        var entry = plan.Entry;
        var aggregate = plan.Aggregate;

        return new AppDataApplication
        {
            Path = aggregate.Path,
            DisplayName = entry.DisplayName,
            Vendor = plan.VendorOverride ?? entry.Vendor,
            IsKnown = plan.IsKnown,
            Family = entry.Family,
            Root = kind,
            Profile = profile,
            Bytes = aggregate.SubtreeBytes,
            FileCount = aggregate.SubtreeFileCount,
            LastWriteUtc = aggregate.LastWriteUtc,
            Explanation = entry.Explanation,
            ExplanationKey = plan.IsKnown ? entry.ExplanationKey : null,
            Contents = ClassifyContents(entry.Family, aggregate.Path, aggregate.SubtreeBytes, slice),
            LargestDirectories = BuildTree(aggregate.Path, slice, aggregate.Depth, MaxTreeNodesPerApp),
        };
    }

    /// <summary>
    /// Applies the family's explicit rules to the application's own slice of the map.
    /// Nested matches are collapsed so the same byte is never counted twice.
    /// </summary>
    private static IReadOnlyList<AppDataContentGroup> ClassifyContents(
        string family,
        string applicationPath,
        long applicationBytes,
        IReadOnlyList<DirectoryAggregate> slice)
    {
        var rules = AppDataContentRules.For(family);
        if (rules.Count == 0)
        {
            return applicationBytes > 0
                ? [UnattributedGroup(family, applicationPath, applicationBytes)]
                : [];
        }

        var matched = new List<(DirectoryAggregate Aggregate, AppDataContentRule Rule)>();

        foreach (var candidate in slice)
        {
            if (candidate.SubtreeBytes <= 0)
            {
                continue;
            }

            var relative = AppDataContentRules.RelativeSegments(candidate.Path, applicationPath);
            var rule = rules.FirstOrDefault(r => AppDataContentRules.Matches(r.RelativePattern, relative));
            if (rule is not null)
            {
                matched.Add((candidate, rule));
            }
        }

        // Drop matches nested inside another match: the outer one already owns the bytes.
        var effective = new List<(DirectoryAggregate Aggregate, AppDataContentRule Rule)>();
        for (var i = 0; i < matched.Count; i++)
        {
            var candidate = matched[i];
            var nested = false;

            for (var j = 0; j < matched.Count && !nested; j++)
            {
                if (i == j)
                {
                    continue;
                }

                var other = matched[j];
                nested = other.Aggregate.Path.Length < candidate.Aggregate.Path.Length &&
                         PathUtils.IsUnder(candidate.Aggregate.Path, other.Aggregate.Path);
            }

            if (!nested)
            {
                effective.Add(candidate);
            }
        }

        var groups = effective
            .Select(m => new AppDataContentGroup
            {
                Kind = m.Rule.Kind,
                Path = m.Aggregate.Path,
                Name = RelativeDisplayName(m.Aggregate.Path, applicationPath),
                Bytes = m.Aggregate.SubtreeBytes,
                FileCount = m.Aggregate.SubtreeFileCount,
                LastWriteUtc = m.Aggregate.LastWriteUtc,
                Confidence = m.Rule.Confidence,
                Risk = m.Rule.Risk,
                Method = m.Rule.Method,
                IsReclaimable = m.Rule.Method != DeletionMethod.None && m.Rule.Confidence >= CleanupConfidence.Likely,
                ReasonKey = m.Rule.ReasonKey,
                Explanation = m.Rule.Explanation,
            })
            .ToList();

        var remainder = applicationBytes - groups.Sum(g => g.Bytes);
        if (remainder > 0)
        {
            groups.Add(UnattributedGroup(family, applicationPath, remainder));
        }

        return [.. groups.OrderByDescending(g => g.Bytes)];
    }

    /// <summary>
    /// The part of an application folder no rule described.
    /// Known data families get "application data"; unknown folders get "purpose not determined".
    /// </summary>
    private static AppDataContentGroup UnattributedGroup(string family, string applicationPath, long bytes)
    {
        var isVmDisk = family == KnownApplications.FamilyVmDisk;
        var isDataFamily = family == KnownApplications.FamilyData;

        return new AppDataContentGroup
        {
            Kind = isVmDisk || isDataFamily ? AppDataContentKind.Data : AppDataContentKind.Unknown,
            Path = applicationPath,
            Name = PathUtils.GetFileName(applicationPath),
            Bytes = bytes,
            FileCount = 0,
            Confidence = CleanupConfidence.NeedsReview,
            Risk = isVmDisk ? RiskLevel.Critical : RiskLevel.High,
            Method = DeletionMethod.None,
            IsReclaimable = false,
            ReasonKey = isVmDisk ? "appdata.vm-disk" : isDataFamily ? "appdata.data" : "appdata.unattributed",
            Explanation = isVmDisk
                ? "Virtual disk of a container or subsystem. Holds real filesystems and images; it is not a cache and is never offered for deletion."
                : isDataFamily
                    ? "Application data: profiles, databases, settings and indexes. Not junk — removing it resets or breaks the application."
                    : "Purpose could not be determined with confidence. Requires user review; never selected automatically.",
        };
    }

    private static string RelativeDisplayName(string path, string applicationPath)
    {
        var segments = AppDataContentRules.RelativeSegments(path, applicationPath);
        return segments.Count == 0 ? PathUtils.GetFileName(path) : string.Join(" \\ ", segments);
    }

    /// <summary>Builds a bounded directory tree for the expandable report view.</summary>
    private static IReadOnlyList<AppDataDirectoryNode> BuildTree(
        string rootPath,
        IReadOnlyList<DirectoryAggregate> slice,
        int applicationDepth,
        int budget)
    {
        // Exclude the application root itself: the tree is what is *inside* it.
        var nodes = slice
            .Where(a => !string.Equals(a.Path, rootPath, PathUtils.Comparison) && a.SubtreeBytes > 0)
            .OrderByDescending(a => a.SubtreeBytes)
            .Take(budget)
            .ToDictionary(
                a => a.Path,
                a => new AppDataDirectoryNode
                {
                    Path = a.Path,
                    Name = a.Name,
                    SubtreeBytes = a.SubtreeBytes,
                    OwnBytes = a.OwnBytes,
                    FileCount = a.SubtreeFileCount,
                    Depth = a.Depth - applicationDepth,
                    ParentPath = a.ParentPath,
                    LastWriteUtc = a.LastWriteUtc,
                },
                PathUtils.Comparer);

        var roots = new List<AppDataDirectoryNode>();
        foreach (var node in nodes.Values)
        {
            if (node.ParentPath is { } parent && nodes.TryGetValue(parent, out var parentNode))
            {
                parentNode.Children = [.. parentNode.Children.Append(node).OrderByDescending(c => c.SubtreeBytes)];
            }
            else
            {
                roots.Add(node);
            }
        }

        return [.. roots.OrderByDescending(n => n.SubtreeBytes)];
    }

    private static void EmitGroup(AnalyzerContext context, AppDataApplication application, AppDataContentGroup group)
    {
        var isFile = context.FileSystem.FileExists(group.Path);

        context.Emit(new ScanItem
        {
            Path = group.Path,
            Name = $"{application.DisplayName} — {group.Name}",
            Kind = isFile ? ScanItemKind.File : ScanItemKind.Directory,
            Size = group.Bytes,
            FileCount = Math.Max(1, group.FileCount),
            ModifiedAtUtc = group.LastWriteUtc,
            Category = group.Kind switch
            {
                AppDataContentKind.DeveloperCache => ScanCategory.DeveloperData,
                AppDataContentKind.Logs => ScanCategory.Logs,
                AppDataContentKind.Temp => ScanCategory.TemporaryFiles,
                AppDataContentKind.CrashDumps => ScanCategory.CrashDumps,
                _ => IsBrowserFamily(application.Family) ? ScanCategory.BrowserCache : ScanCategory.ApplicationCache,
            },
            Confidence = group.Confidence,
            RiskLevel = group.Risk,
            IsDeletable = group.Method != DeletionMethod.None,
            DeletionMethod = group.Method,
            Reason = group.ReasonKey,
            Explanation = group.Explanation,
            SourceAnalyzer = nameof(AppDataAnalyzer),
            OwnerApplication = application.DisplayName,
            DriveRoot = PathUtils.GetDriveRoot(group.Path),
        });
    }

    private static bool IsBrowserFamily(string? family) =>
        family is KnownApplications.FamilyChromium or KnownApplications.FamilyFirefox;

    private static AppDataReport BuildReport(
        IReadOnlyList<AppDataRootSummary> roots,
        IReadOnlyList<AppDataApplication> applications,
        bool incomplete)
    {
        var ordered = applications.OrderByDescending(a => a.Bytes).ToArray();
        var groups = ordered.SelectMany(a => a.Contents).ToArray();

        var byKind = groups
            .GroupBy(g => g.Kind)
            .Select(g => new AppDataContentTotals
            {
                Kind = g.Key,
                Bytes = g.Sum(x => x.Bytes),
                FileCount = g.Sum(x => x.FileCount),
                GroupCount = g.Count(),
                ReclaimableBytes = g.Where(x => x.IsReclaimable).Sum(x => x.Bytes),
            })
            .OrderByDescending(t => t.Bytes)
            .ToArray();

        return new AppDataReport
        {
            Roots = roots,
            Applications = ordered,
            TotalBytes = ordered.Sum(a => a.Bytes),
            TotalFiles = ordered.Sum(a => a.FileCount),
            KnownBytes = ordered.Where(a => a.IsKnown).Sum(a => a.Bytes),
            UnknownBytes = ordered.Where(a => !a.IsKnown).Sum(a => a.Bytes),
            ReclaimableBytes = groups.Where(g => g.IsReclaimable).Sum(g => g.Bytes),
            SafeReclaimableBytes = groups.Where(g => g.IsReclaimable && g.Confidence == CleanupConfidence.Safe).Sum(g => g.Bytes),
            IsComplete = !incomplete,
            ByContentKind = byKind,
        };
    }

    /// <summary>Internal plan entry: which catalog entry owns which aggregate.</summary>
    private sealed record AppPlan(
        KnownAppDataEntry Entry,
        DirectoryAggregate Aggregate,
        bool IsKnown,
        string? VendorOverride = null);
}
