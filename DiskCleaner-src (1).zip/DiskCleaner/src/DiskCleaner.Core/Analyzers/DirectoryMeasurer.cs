using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Core.Analyzers;

/// <summary>Result of sizing one folder.</summary>
public sealed record DirectoryMeasurement
{
    public required string Path { get; init; }

    public bool Exists { get; init; }

    /// <summary><c>true</c> when the measured target is a single file rather than a folder.</summary>
    public bool IsFile { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public int DirectoryCount { get; init; }

    public DateTime? NewestModificationUtc { get; init; }

    public DateTime? OldestModificationUtc { get; init; }

    /// <summary>Part of the tree could not be read: the size is a lower bound, not a fact.</summary>
    public bool IsComplete { get; init; } = true;

    public IReadOnlyList<ScanIssue> Issues { get; init; } = [];

    /// <summary>
    /// Files matching the requested pattern, when one was given. Bounded by
    /// <see cref="MaxMatchingFiles"/> so a pathological folder cannot exhaust memory.
    /// </summary>
    public IReadOnlyList<ScannedEntry> MatchingFiles { get; init; } = [];

    /// <summary>Cap on <see cref="MatchingFiles"/>; beyond it only the totals keep growing.</summary>
    public const int MaxMatchingFiles = 2_000;

    public static DirectoryMeasurement Missing(string path) => new() { Path = path, Exists = false };
}

/// <summary>Result of sizing a whole folder tree, with the per-directory map.</summary>
public sealed record TreeMeasurement
{
    public required string Path { get; init; }

    public bool Exists { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public int DirectoryCount { get; init; }

    public DateTime? NewestModificationUtc { get; init; }

    /// <summary><c>false</c> when part of the tree was unreadable: totals are a lower bound.</summary>
    public bool IsComplete { get; init; } = true;

    /// <summary>Per-directory own and subtree sizes. The basis of the AppData tree view.</summary>
    public IReadOnlyList<DirectoryAggregate> Aggregates { get; init; } = [];

    public IReadOnlyList<ScanIssue> Issues { get; init; } = [];

    public static TreeMeasurement Missing(string path) => new() { Path = path, Exists = false };
}

/// <summary>
/// Sizes a single folder on demand.
/// </summary>
/// <remarks>
/// Targeted analyzers (TEMP, browser caches, dumps) do not need a full-volume map: they
/// know exactly which folders they care about and measure just those. Reusing
/// <see cref="FileSystemScanner"/> keeps one enumeration implementation for the whole
/// product — the same long-path handling, the same reparse-point policy, the same
/// error reporting.
/// </remarks>
public interface IDirectoryMeasurer
{
    /// <param name="path">Folder to size.</param>
    /// <param name="fileNamePattern">
    /// Optional <c>*</c>/<c>?</c> filter. When given, totals and <see cref="DirectoryMeasurement.MatchingFiles"/>
    /// describe only matching files, so two rules over the same folder cannot double-count.
    /// </param>
    Task<DirectoryMeasurement> MeasureAsync(string path, string? fileNamePattern = null, CancellationToken cancellationToken = default);

    /// <summary>
    /// Sizes a folder tree and returns the per-directory map, which is what the AppData
    /// report is built from. One pass over the tree, no repeated IO per subfolder.
    /// </summary>
    Task<TreeMeasurement> MeasureTreeAsync(string path, int? maxDepth = null, CancellationToken cancellationToken = default);
}

public sealed class DirectoryMeasurer(FileSystemScanner scanner, IFileSystem fileSystem) : IDirectoryMeasurer
{
    private IFileSystem FileSystem { get; } = fileSystem;

    public async Task<DirectoryMeasurement> MeasureAsync(
        string path,
        string? fileNamePattern = null,
        CancellationToken cancellationToken = default)
    {
        var normalized = PathUtils.Normalize(path);

        if (normalized.Length == 0)
        {
            return DirectoryMeasurement.Missing(path);
        }

        // Some whitelist entries are single files (C:\Windows\MEMORY.DMP). They have no
        // children to enumerate, so reading the metadata is both correct and cheaper.
        var fileMetadata = FileSystem.TryGetFileMetadata(normalized);
        if (fileMetadata is { } file)
        {
            return new DirectoryMeasurement
            {
                Path = normalized,
                Exists = true,
                IsFile = true,
                Bytes = file.Size,
                FileCount = 1,
                DirectoryCount = 0,
                NewestModificationUtc = file.LastWriteUtc,
                OldestModificationUtc = file.CreatedUtc,
            };
        }

        var sink = new MeasuringSink(fileNamePattern);
        var options = new ScanOptions
        {
            Mode = ScanMode.Quick,
            Roots = [normalized],
            MaxDepth = null,
            FollowReparsePoints = false,
            // A single folder does not need four workers; keep the machine quiet.
            MaxDegreeOfParallelism = 2,
            ProgressInterval = TimeSpan.FromSeconds(30),
        };

        ScanStatistics statistics;
        try
        {
            statistics = await scanner.ScanAsync(options, sink, progress: null, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception)
        {
            return DirectoryMeasurement.Missing(normalized);
        }

        // A root that does not exist produces a NotFound issue and no entries at all.
        if (!sink.SawRoot)
        {
            return DirectoryMeasurement.Missing(normalized);
        }

        return new DirectoryMeasurement
        {
            Path = normalized,
            Exists = true,
            Bytes = sink.Bytes,
            FileCount = sink.FileCount,
            DirectoryCount = (int)Math.Min(int.MaxValue, statistics.DirectoriesScanned),
            NewestModificationUtc = sink.Newest,
            OldestModificationUtc = sink.Oldest,
            IsComplete = statistics.IssuesCount == 0,
            Issues = sink.Issues.ToArray(),
            MatchingFiles = sink.MatchingFiles,
        };
    }

    public async Task<TreeMeasurement> MeasureTreeAsync(string path, int? maxDepth = null, CancellationToken cancellationToken = default)
    {
        var normalized = PathUtils.Normalize(path);
        if (normalized.Length == 0 || !FileSystem.DirectoryExists(normalized))
        {
            return TreeMeasurement.Missing(normalized);
        }

        var collector = new ScanResultCollector(new ScanOptions
        {
            Mode = ScanMode.Deep,
            Roots = [normalized],
            MaxDepth = maxDepth,
            FollowReparsePoints = false,
            MaxDegreeOfParallelism = 2,
            // The tree view needs directories, not a file ranking.
            TopFilesCapacity = 10,
            ProgressInterval = TimeSpan.FromSeconds(30),
        });

        ScanStatistics statistics;
        try
        {
            statistics = await scanner.ScanAsync(collector.Options, collector, progress: null, cancellationToken).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception)
        {
            return TreeMeasurement.Missing(normalized);
        }

        return new TreeMeasurement
        {
            Path = normalized,
            Exists = true,
            Bytes = statistics.BytesScanned,
            FileCount = (int)Math.Min(int.MaxValue, statistics.FilesScanned),
            DirectoryCount = (int)Math.Min(int.MaxValue, statistics.DirectoriesScanned),
            IsComplete = statistics.IssuesCount == 0,
            Aggregates = collector.Aggregator.BuildAggregates(),
            Issues = collector.GetIssues(),
        };
    }

    private sealed class MeasuringSink(string? fileNamePattern) : IScanSink
    {
        private readonly object _gate = new();
        private readonly List<ScanIssue> _issues = [];
        private readonly List<ScannedEntry> _matching = [];

        private long _bytes;
        private int _files;
        private DateTime? _newest;
        private DateTime? _oldest;

        public bool SawRoot { get; private set; }

        public long Bytes => Interlocked.Read(ref _bytes);

        public int FileCount => Volatile.Read(ref _files);

        public DateTime? Newest { get { lock (_gate) { return _newest; } } }

        public DateTime? Oldest { get { lock (_gate) { return _oldest; } } }

        public IReadOnlyList<ScanIssue> Issues { get { lock (_gate) { return _issues.ToArray(); } } }

        public IReadOnlyList<ScannedEntry> MatchingFiles { get { lock (_gate) { return _matching.ToArray(); } } }

        public void OnDirectory(in ScannedEntry entry, int depth)
        {
            if (depth == 0)
            {
                SawRoot = true;
            }
        }

        public void OnFile(in ScannedEntry entry, int depth, string directory)
        {
            if (fileNamePattern is not null && !WildcardMatcher.IsMatch(entry.Name, fileNamePattern))
            {
                return;
            }

            Interlocked.Add(ref _bytes, entry.Size);
            Interlocked.Increment(ref _files);

            lock (_gate)
            {
                if (_matching.Count < DirectoryMeasurement.MaxMatchingFiles)
                {
                    _matching.Add(entry);
                }

                if (entry.LastWriteUtc is { } modified)
                {
                    if (_newest is null || modified > _newest)
                    {
                        _newest = modified;
                    }

                    if (_oldest is null || modified < _oldest)
                    {
                        _oldest = modified;
                    }
                }
            }
        }

        public void OnIssue(ScanIssue issue)
        {
            lock (_gate)
            {
                if (_issues.Count < 100)
                {
                    _issues.Add(issue);
                }
            }
        }
    }
}
