using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Core.Analyzers;

/// <summary>TEMP folders: current user, every other profile, and the Windows enclave.</summary>
public sealed class TempAnalyzer : LocationAnalyzerBase
{
    public override string Name => WellKnownAnalyzers.Temp;

    public override string Description => "Temporary folders that applications treat as scratch space.";

    public override int Order => 10;

    protected override IReadOnlyList<SafeLocation> Locations => SafeLocationCatalog.Temporary;
}

/// <summary>Cache directories of known browsers, listed explicitly per browser.</summary>
public sealed class BrowserCacheAnalyzer : LocationAnalyzerBase
{
    public override string Name => WellKnownAnalyzers.BrowserCache;

    public override string Description => "Cache of installed browsers. Sign-in state, bookmarks, history and passwords are stored elsewhere and are not touched.";

    public override int Order => 20;

    protected override IReadOnlyList<SafeLocation> Locations => SafeLocationCatalog.BrowserCaches;
}

/// <summary>Crash dumps and Windows Error Reporting queues.</summary>
public sealed class CrashDumpAnalyzer : LocationAnalyzerBase
{
    public override string Name => WellKnownAnalyzers.CrashDumps;

    public override string Description => "Crash dumps and error reports. Only needed to investigate a specific past failure.";

    public override int Order => 30;

    protected override IReadOnlyList<SafeLocation> Locations => SafeLocationCatalog.CrashDumps;
}

/// <summary>Explorer thumbnail and icon caches, reported per file.</summary>
public sealed class ThumbnailAnalyzer : LocationAnalyzerBase
{
    public override string Name => WellKnownAnalyzers.Thumbnails;

    public override string Description => "Explorer thumbnail and icon caches. Windows rebuilds them on demand.";

    public override int Order => 40;

    protected override IReadOnlyList<SafeLocation> Locations => SafeLocationCatalog.Thumbnails;
}

/// <summary>
/// The Recycle Bin of each volume.
/// </summary>
/// <remarks>
/// Reported as a <see cref="ScanItemKind.VirtualTarget"/> with
/// <see cref="DeletionMethod.SystemApi"/>: it is emptied through the shell API, never by
/// deleting files inside <c>$Recycle.Bin</c>. The safety policy keeps direct deletion of
/// that folder blocked; the exception it grants is specific to this shape of request.
/// </remarks>
public sealed class RecycleBinAnalyzer : IAnalyzer
{
    public string Name => WellKnownAnalyzers.RecycleBin;

    public string Description => "Content already deleted by the user but still occupying space on the volume.";

    public IReadOnlyCollection<ScanMode> SupportedModes { get; } =
        [ScanMode.Quick, ScanMode.Deep, ScanMode.Custom];

    public int Order => 5;

    public bool IsEnabled(AppSettings settings) => true;

    public async Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken)
    {
        foreach (var drive in context.Drives.Where(d => d.IsReady && d.TotalBytes > 0))
        {
            cancellationToken.ThrowIfCancellationRequested();

            var path = PathUtils.Combine(drive.RootPath, "$Recycle.Bin");
            if (!context.FileSystem.DirectoryExists(path))
            {
                continue;
            }

            var measurement = await context.Measurer.MeasureAsync(path, null, cancellationToken).ConfigureAwait(false);

            // Deliberately NOT forwarding measurement issues: $Recycle.Bin holds one
            // subfolder per user SID, and each is ACL'd to that SID plus SYSTEM. Even an
            // elevated administrator is denied on other users' bins, so those denials are
            // structural rather than actionable — reporting them would just be noise. The
            // item itself states that the size is a lower bound when reading was partial.
            if (!measurement.Exists || measurement.Bytes <= 0)
            {
                // Reading $Recycle.Bin usually needs elevation; a zero here means
                // "nothing visible to us", which must not be reported as "0 bytes to free".
                continue;
            }

            context.Emit(new ScanItem
            {
                Path = path,
                Name = $"{drive.DisplayName} — Recycle Bin",
                Kind = ScanItemKind.VirtualTarget,
                Size = measurement.Bytes,
                FileCount = Math.Max(1, measurement.FileCount),
                ModifiedAtUtc = measurement.NewestModificationUtc,
                Category = ScanCategory.RecycleBin,
                Confidence = CleanupConfidence.Safe,
                RiskLevel = RiskLevel.Medium,
                IsDeletable = true,
                DeletionMethod = DeletionMethod.SystemApi,
                Reason = "recycle-bin.volume",
                Explanation = measurement.IsComplete
                    ? "Items you already deleted, still occupying space on this volume. Emptying the Recycle Bin is final: they cannot be restored afterwards."
                    : "Items you already deleted. Part of the Recycle Bin could not be read without administrator rights, so the size shown is a lower bound.",
                SourceAnalyzer = Name,
                DriveRoot = drive.RootPath,
                RequiresElevation = !measurement.IsComplete,
            });
        }
    }
}
