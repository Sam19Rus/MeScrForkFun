using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.Core.Analyzers;

/// <summary>Inputs of one analyzer run. Services come from the pipeline itself.</summary>
public sealed record AnalyzerInput(
    ScanOptions Options,
    AppSettings Settings,
    IReadOnlyList<DriveSnapshot> Drives,
    IReadOnlyList<DirectoryAggregate> Directories,
    IReadOnlyList<ScanItem> LargestFiles)
{
    public static AnalyzerInput Empty(ScanOptions options, AppSettings settings, IReadOnlyList<DriveSnapshot> drives) =>
        new(options, settings, drives, [], []);
}

/// <summary>
/// Runs the analyzers that apply to a scan, in order, and collects what they emit.
/// </summary>
/// <remarks>
/// A failing analyzer is logged and skipped — one broken rule must never cost the user
/// the whole report.
/// </remarks>
public sealed class AnalyzerPipeline
{
    private readonly IReadOnlyList<IAnalyzer> _analyzers;
    private readonly Infrastructure.IEnvironmentInfo _environment;
    private readonly Infrastructure.IO.IFileSystem _fileSystem;
    private readonly IDirectoryMeasurer _measurer;
    private readonly Classification.ISafetyPolicy _safety;
    private readonly ILogger _logger;

    public AnalyzerPipeline(
        IEnumerable<IAnalyzer> analyzers,
        Infrastructure.IEnvironmentInfo environment,
        Infrastructure.IO.IFileSystem fileSystem,
        IDirectoryMeasurer measurer,
        Classification.ISafetyPolicy safety,
        ILogger<AnalyzerPipeline>? logger = null)
    {
        _analyzers = [.. analyzers.OrderBy(a => a.Order).ThenBy(a => a.Name, StringComparer.Ordinal)];
        _environment = environment;
        _fileSystem = fileSystem;
        _measurer = measurer;
        _safety = safety;
        _logger = logger ?? Microsoft.Extensions.Logging.Abstractions.NullLogger<AnalyzerPipeline>.Instance;
    }

    /// <summary>Registered analyzers, in execution order (diagnostics / Settings screen).</summary>
    public IReadOnlyList<IAnalyzer> Analyzers => _analyzers;

    public IReadOnlyList<IAnalyzer> SelectFor(ScanMode mode, AppSettings settings) =>
        [.. _analyzers.Where(a => a.SupportedModes.Contains(mode) && a.IsEnabled(settings))];

    public async Task<AnalyzerRunOutcome> RunAsync(AnalyzerInput input, ScanMode mode, CancellationToken cancellationToken)
    {
        var context = new AnalyzerContext(
            input.Options,
            input.Settings,
            input.Drives,
            input.Directories,
            input.LargestFiles,
            _environment,
            _fileSystem,
            _measurer,
            _safety,
            _logger)
        {
            CancellationToken = cancellationToken,
        };

        var selected = SelectFor(mode, input.Settings);
        var failed = new List<string>();

        foreach (var analyzer in selected)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                break;
            }

            try
            {
                await analyzer.AnalyzeAsync(context, cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                // Isolate the failure: the rest of the report stays valid.
                failed.Add(analyzer.Name);
                _logger.LogError(ex, "Analyzer {Analyzer} failed and was skipped", analyzer.Name);
            }
        }

        return new AnalyzerRunOutcome(
            [.. context.Items.OrderByDescending(i => i.Size)],
            context.EmittedCount,
            context.DuplicateCount,
            failed,
            [.. selected.Select(a => a.Name)],
            context.Issues,
            context.SupersededCount,
            context.Reports,
            context.MeasuredFiles,
            context.MeasuredBytes,
            context.MeasuredDirectories);
    }
}

/// <summary>What one analyzer run produced.</summary>
public sealed record AnalyzerRunOutcome(
    IReadOnlyList<ScanItem> Items,
    int EmittedCount,
    int DuplicateCount,
    IReadOnlyList<string> FailedAnalyzers,
    IReadOnlyList<string> ExecutedAnalyzers,
    IReadOnlyList<ScanIssue> Issues,
    int SupersededCount,
    IReadOnlyDictionary<string, object> Reports,
    long MeasuredFiles,
    long MeasuredBytes,
    long MeasuredDirectories);
