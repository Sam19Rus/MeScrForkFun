using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Core.Analyzers;

/// <summary>
/// Windows Update download cache and Delivery Optimization cache.
/// </summary>
/// <remarks>
/// Both are genuinely regenerable: Windows re-downloads whatever it still needs. Both
/// normally require administrator rights, which the safety policy reports through
/// <c>RequiresElevation</c> rather than by failing.
/// </remarks>
public sealed class WindowsUpdateAnalyzer : LocationAnalyzerBase
{
    private static readonly IReadOnlyList<SafeLocation> UpdateLocations =
    [
        new()
        {
            PathTemplate = @"{Windows}\SoftwareDistribution\Download",
            Category = ScanCategory.WindowsUpdateCache,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wu.download-cache",
            Explanation = "Downloaded Windows Update packages. Already-installed updates do not need them; pending ones are downloaded again.",
            OwnerApplication = "Windows Update",
        },
        new()
        {
            // Delivery Optimization keeps its cache under a service profile that is
            // usually readable only by SYSTEM. If it cannot be read, the measurement is
            // empty and nothing is reported — the app never claims bytes it did not see.
            PathTemplate = @"{Windows}\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache",
            Category = ScanCategory.WindowsUpdateCache,
            Confidence = CleanupConfidence.Likely,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "wu.delivery-optimization",
            Explanation = "Delivery Optimization cache: update fragments shared with other PCs on the network. Regenerated automatically; clearing it only means the next update is not served from a peer.",
            OwnerApplication = "Delivery Optimization",
        },
    ];

    public override string Name => WellKnownAnalyzers.WindowsUpdate;

    public override string Description => "Windows Update download cache and Delivery Optimization cache.";

    public override int Order => 25;

    protected override IReadOnlyList<SafeLocation> Locations => UpdateLocations;
}

/// <summary>
/// Log locations that are explicitly known and not already covered elsewhere.
/// </summary>
/// <remarks>
/// Deliberately narrow. Logs inside known application folders (VS Code, JetBrains,
/// Electron apps) are classified by the AppData content rules, and logs inside TEMP are
/// already part of the TEMP candidate — claiming them again would double-count. There is
/// no "*.log anywhere" rule: a log file is only junk when we know which tool wrote it and
/// that the tool regenerates or does not need it.
/// </remarks>
public sealed class LogAnalyzer : LocationAnalyzerBase
{
    private static readonly IReadOnlyList<SafeLocation> LogLocations =
    [
        new()
        {
            PathTemplate = @"{UserProfile}\.npm\_logs",
            Category = ScanCategory.Logs,
            Confidence = CleanupConfidence.Likely,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "logs.npm",
            Explanation = "npm debug logs. One file per npm invocation; they only accumulate and are never needed once an install succeeded.",
            OwnerApplication = "npm",
        },
        new()
        {
            PathTemplate = @"{LocalAppData}\npm-cache\_logs",
            Category = ScanCategory.Logs,
            Confidence = CleanupConfidence.Likely,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "logs.npm",
            Explanation = "npm debug logs written next to the npm cache.",
            OwnerApplication = "npm",
        },
        new()
        {
            PathTemplate = @"{RoamingAppData}\npm\_logs",
            Category = ScanCategory.Logs,
            Confidence = CleanupConfidence.Likely,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "logs.npm",
            Explanation = "npm debug logs in the roaming npm folder.",
            OwnerApplication = "npm",
        },
        new()
        {
            PathTemplate = @"{UserProfile}\.yarn\log",
            Category = ScanCategory.Logs,
            Confidence = CleanupConfidence.Likely,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "logs.yarn",
            Explanation = "Yarn debug logs.",
            OwnerApplication = "Yarn",
        },
    ];

    public override string Name => WellKnownAnalyzers.Log;

    public override string Description => "Debug logs of package managers, from explicitly known locations only.";

    public override int Order => 35;

    /// <summary>Developer-tool logs follow the developer-analysis switch.</summary>
    public override bool IsEnabled(AppSettings settings) => settings.EnableDeveloperAnalysis;

    protected override IReadOnlyList<SafeLocation> Locations => LogLocations;
}
