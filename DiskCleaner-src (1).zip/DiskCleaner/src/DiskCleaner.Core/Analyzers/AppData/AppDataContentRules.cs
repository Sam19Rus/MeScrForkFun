using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Analyzers.AppData;

/// <summary>
/// One explicit rule about what a subfolder of a known application is.
/// </summary>
/// <param name="RelativePattern">
/// Path relative to the application root, segment by segment. <c>*</c> matches exactly one
/// segment (browser profile names, JetBrains product versions, Store package names).
/// An empty pattern means the application root itself.
/// </param>
public sealed record AppDataContentRule(
    string Family,
    string RelativePattern,
    AppDataContentKind Kind,
    CleanupConfidence Confidence,
    RiskLevel Risk,
    DeletionMethod Method,
    string ReasonKey,
    string Explanation)
{
    /// <summary>Number of segments; more specific rules win.</summary>
    public int Specificity => RelativePattern.Length == 0 ? 0 : RelativePattern.Split('\\').Length;
}

/// <summary>
/// What inside a recognised application folder is cache, logs, temp — or real data.
/// </summary>
/// <remarks>
/// Every rule names a concrete relative path of a concrete application family. There is no
/// "folder called cache" heuristic: <c>User\History</c> and <c>Backups</c> inside VS Code are
/// user data and are deliberately absent from the reclaimable list, and Docker/WSL virtual
/// disks are listed only to be explained, never to be offered.
/// </remarks>
public static class AppDataContentRules
{
    private static readonly IReadOnlyList<AppDataContentRule> Rules = Build();

    public static IReadOnlyList<AppDataContentRule> For(string family) =>
        [.. Rules.Where(r => string.Equals(r.Family, family, StringComparison.Ordinal))
                 .OrderByDescending(r => r.Specificity)];

    /// <summary>Matches a relative path against a rule pattern, segment by segment.</summary>
    public static bool Matches(string relativePattern, IReadOnlyList<string> relativeSegments)
    {
        if (relativePattern.Length == 0)
        {
            return relativeSegments.Count == 0;
        }

        var pattern = relativePattern.Split('\\');
        if (pattern.Length != relativeSegments.Count)
        {
            return false;
        }

        for (var i = 0; i < pattern.Length; i++)
        {
            if (pattern[i] == "*")
            {
                continue;
            }

            if (!string.Equals(pattern[i], relativeSegments[i], StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>Splits a path into segments relative to an ancestor.</summary>
    public static IReadOnlyList<string> RelativeSegments(string path, string ancestor)
    {
        var normalized = PathUtils.Normalize(path);
        var root = PathUtils.EnsureTrailingSeparator(ancestor);

        if (!normalized.StartsWith(root, PathUtils.Comparison))
        {
            return [];
        }

        return normalized[root.Length..].Split(['\\', '/'], StringSplitOptions.RemoveEmptyEntries);
    }

    private static IReadOnlyList<AppDataContentRule> Build()
    {
        var rules = new List<AppDataContentRule>();

        void Add(string family, string pattern, AppDataContentKind kind, CleanupConfidence confidence,
            RiskLevel risk, DeletionMethod method, string reasonKey, string explanation) =>
            rules.Add(new AppDataContentRule(family, pattern, kind, confidence, risk, method, reasonKey, explanation));

        const string browserCacheExplanation =
            "Browser cache. The browser rebuilds it automatically; you stay signed in and bookmarks, " +
            "history, passwords and extensions are untouched.";
        const string logExplanation =
            "Application logs. Safe to remove, but they are the only evidence when something goes wrong, " +
            "so they are offered as a candidate rather than pre-selected.";

        // ---- Chromium -------------------------------------------------------
        foreach (var cache in new[] { "Cache", "Code Cache", "GPUCache", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "Application Cache" })
        {
            Add(KnownApplications.FamilyChromium, $@"User Data\*\{cache}", AppDataContentKind.Cache,
                CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
                "appdata.cache.chromium", browserCacheExplanation);
        }

        Add(KnownApplications.FamilyChromium, @"User Data\*\Service Worker\CacheStorage", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.service-worker", "Cached responses of service workers. Sites re-download what they need on the next visit.");
        Add(KnownApplications.FamilyChromium, @"User Data\*\Service Worker\ScriptStorage", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.service-worker.scripts", "Stored service worker scripts. Re-fetched from the site on the next run.");
        Add(KnownApplications.FamilyChromium, @"User Data\ShaderCache", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.shader", "Compiled shader cache shared by all profiles. Regenerated on demand.");
        Add(KnownApplications.FamilyChromium, @"User Data\GrShaderCache", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.shader", "Compiled Skia shader cache. Regenerated on demand.");

        // ---- Firefox --------------------------------------------------------
        Add(KnownApplications.FamilyFirefox, @"Profiles\*\cache2", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.firefox", browserCacheExplanation);
        Add(KnownApplications.FamilyFirefox, @"Profiles\*\startupCache", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.firefox.startup", "Firefox startup cache. Regenerated on the next launch.");
        Add(KnownApplications.FamilyFirefox, @"Profiles\*\shader-cache", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.shader", "Compiled shader cache. Regenerated on demand.");

        // ---- Electron -------------------------------------------------------
        foreach (var cache in new[] { "Cache", "Code Cache", "GPUCache", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "CacheStorage", "ShaderCache", "GrShaderCache" })
        {
            Add(KnownApplications.FamilyElectron, cache, AppDataContentKind.Cache,
                CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
                "appdata.cache.electron", "Electron web cache. The application rebuilds it; your account, settings and local data are stored elsewhere.");
        }

        Add(KnownApplications.FamilyElectron, "blob_storage", AppDataContentKind.Temp,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.temp.blob", "Temporary blob storage used for downloads and drag-and-drop. Leftovers only grow.");
        Add(KnownApplications.FamilyElectron, "logs", AppDataContentKind.Logs,
            CleanupConfidence.Likely, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.logs.electron", logExplanation);
        Add(KnownApplications.FamilyElectron, @"Service Worker\CacheStorage", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.service-worker", "Cached responses of service workers. Re-downloaded on the next visit.");
        Add(KnownApplications.FamilyElectron, @"Crashpad\completed", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.crashpad", "Crash reports that were prepared for sending. Only needed to diagnose a specific past crash.");

        // ---- VS Code --------------------------------------------------------
        foreach (var cache in new[] { "Cache", "Code Cache", "GPUCache", "CachedData", "CachedExtensionVSIXs", "CachedProfilesData", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "ShaderCache", "GrShaderCache", "blob_storage" })
        {
            Add(KnownApplications.FamilyVsCode, cache, AppDataContentKind.Cache,
                CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
                "appdata.cache.vscode", "VS Code cache. The editor rebuilds it; settings, snippets, keybindings and extensions are stored elsewhere.");
        }

        Add(KnownApplications.FamilyVsCode, "logs", AppDataContentKind.Logs,
            CleanupConfidence.Likely, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.logs.vscode", logExplanation);
        Add(KnownApplications.FamilyVsCode, @"Service Worker\CacheStorage", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.cache.service-worker", "Cached responses of service workers used by the web views.");
        Add(KnownApplications.FamilyVsCode, @"User\workspaceStorage", AppDataContentKind.Cache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.workspace-storage",
            "Per-workspace state: which files were open, undo history, extension workspace state. Source code is unaffected, " +
            "but every workspace reopens as if seen for the first time.");

        // Deliberately NOT listed: User\History (local file history), Backups (unsaved editors),
        // User\settings.json, User\snippets, User\globalStorage (extension databases).
        // Those are user data and must never be offered.

        // ---- JetBrains ------------------------------------------------------
        Add(KnownApplications.FamilyJetBrains, @"*\caches", AppDataContentKind.Cache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.cache.jetbrains",
            "IDE caches. Removing them forces a full re-index of every project on the next start, which can take many minutes.");
        Add(KnownApplications.FamilyJetBrains, @"*\index", AppDataContentKind.Cache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.index.jetbrains", "Code indexes. Rebuilt on the next start; projects keep working, the first open is slow.");
        Add(KnownApplications.FamilyJetBrains, @"*\log", AppDataContentKind.Logs,
            CleanupConfidence.Likely, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.logs.jetbrains", logExplanation);
        Add(KnownApplications.FamilyJetBrains, @"*\tmp", AppDataContentKind.Temp,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "appdata.temp.jetbrains", "IDE temporary files.");

        // ---- Windows components --------------------------------------------
        Add(KnownApplications.FamilyWer, "ReportQueue", AppDataContentKind.CrashDumps,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "wer.report-queue", "Error reports waiting to be sent. Windows recreates the folder.");
        Add(KnownApplications.FamilyWer, "ReportArchive", AppDataContentKind.CrashDumps,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "wer.report-archive", "Archive of already processed error reports.");
        // Method is deliberately None: ThumbnailAnalyzer already owns these caches and
        // offers the individual thumbcache_*.db / iconcache_*.db files. Claiming the whole
        // folder here as well would count the same bytes twice in the cleanup total.
        Add(KnownApplications.FamilyExplorer, "", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.None,
            "cache.thumbnails", "Explorer thumbnail and icon caches. Rebuilt on demand; offered per database file rather than as a whole folder.");
        Add(KnownApplications.FamilyWindows, "", AppDataContentKind.Cache,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "cache.windows.legacy", "Legacy WinINET cache. Still written by some desktop components; regenerated automatically.");
        Add(KnownApplications.FamilyTemp, "", AppDataContentKind.Temp,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "temp.user", "The user's TEMP folder. Applications treat it as scratch space.");
        Add(KnownApplications.FamilyCrashDumps, "", AppDataContentKind.CrashDumps,
            CleanupConfidence.Safe, RiskLevel.Low, DeletionMethod.Permanent,
            "dump.local-crashdumps", "User-mode crash dumps. Needed only to investigate a specific past crash.");

        // ---- developer caches ----------------------------------------------
        const string devCacheExplanation =
            "Package manager cache. Everything can be downloaded again, so this is reclaimable, " +
            "but the next restore will be slower and will use bandwidth. It is offered as a " +
            "candidate, never selected automatically.";

        Add(KnownApplications.FamilyDevCache, "", AppDataContentKind.DeveloperCache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "devcache.root", devCacheExplanation);
        Add(KnownApplications.FamilyDevCache, "http-cache", AppDataContentKind.DeveloperCache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "devcache.nuget.http", devCacheExplanation);
        Add(KnownApplications.FamilyDevCache, "plugins-cache", AppDataContentKind.DeveloperCache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "devcache.nuget.plugins", devCacheExplanation);
        Add(KnownApplications.FamilyDevCache, "v3-cache", AppDataContentKind.DeveloperCache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "devcache.nuget.v3", devCacheExplanation);

        // ---- GPU vendor shader caches --------------------------------------
        foreach (var cache in new[] { "DXCache", "DxCache", "GLCache", "NV_Cache", "OptixCache", "VulkanCache" })
        {
            Add(KnownApplications.FamilyShaderCache, cache, AppDataContentKind.Cache,
                CleanupConfidence.Likely, RiskLevel.Low, DeletionMethod.Permanent,
                "appdata.cache.shader.vendor",
                "Driver shader cache. Regenerated on the next run of each application; the first launch may be slower.");
        }

        // ---- Store packages -------------------------------------------------
        Add(KnownApplications.FamilyPackages, "LocalCache", AppDataContentKind.Cache,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.cache.uwp",
            "Cache of a Store application. Windows may rebuild it, but a poorly written app can lose local state, " +
            "so this stays a candidate rather than pre-selected.");
        Add(KnownApplications.FamilyPackages, "TempState", AppDataContentKind.Temp,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.temp.uwp", "Temporary state of a Store application.");
        Add(KnownApplications.FamilyPackages, @"AC\Temp", AppDataContentKind.Temp,
            CleanupConfidence.Likely, RiskLevel.Medium, DeletionMethod.Permanent,
            "appdata.temp.uwp.ac", "Temporary files inside a Store application container.");

        // ---- containers: described, never offered ---------------------------
        // No rules for FamilyVmDisk and FamilyData on purpose: absence of a rule is what
        // keeps Docker/WSL virtual disks and application data out of any cleanup plan.

        return rules;
    }
}
