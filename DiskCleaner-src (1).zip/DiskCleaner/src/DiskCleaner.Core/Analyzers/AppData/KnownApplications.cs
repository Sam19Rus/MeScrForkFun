using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Core.Analyzers.AppData;

/// <summary>
/// One recognised AppData folder.
/// </summary>
/// <param name="Root">Which AppData root the relative path lives under.</param>
/// <param name="RelativePath">One or two segments, e.g. <c>Google\Chrome</c>.</param>
/// <param name="DisplayName">Human name shown in the report.</param>
/// <param name="Vendor">Vendor shown when only the first segment matched.</param>
/// <param name="Family">Key into <see cref="AppDataContentRules"/> that decides what inside is reclaimable.</param>
/// <param name="Explanation">What is stored here and what happens if it is removed.</param>
/// <param name="TreatChildrenAsApplications">
/// The folder is a container: every direct child is one application instance
/// (<c>Packages</c> holds one folder per Store application). Children get this entry's
/// family unless a more specific catalog entry matches them.
/// </param>
public sealed record KnownAppDataEntry(
    AppDataRoot Root,
    string RelativePath,
    string DisplayName,
    string? Vendor,
    string Family,
    string Explanation,
    bool TreatChildrenAsApplications = false)
{
    /// <summary>
    /// Stable localisation key derived from the entry's identity, e.g.
    /// <c>local.google-chrome</c>. The presentation layer looks up
    /// <c>S.App.Expl.{key}</c> first, then the family default
    /// <c>S.App.Expl.family.{Family}</c>, and only then falls back to the English
    /// <see cref="Explanation"/> — so the catalog stays the single source of truth
    /// and translations can be added per app without touching this file.
    /// </summary>
    public string ExplanationKey => BuildExplanationKey(Root, RelativePath);

    private static string BuildExplanationKey(AppDataRoot root, string relativePath)
    {
        var builder = new System.Text.StringBuilder(root.ToString().ToLowerInvariant());
        builder.Append('.');

        var previousDash = false;
        foreach (var c in relativePath)
        {
            if (char.IsAsciiLetterOrDigit(c))
            {
                builder.Append(char.ToLowerInvariant(c));
                previousDash = false;
            }
            else if (!previousDash)
            {
                builder.Append('-');
                previousDash = true;
            }
        }

        return builder.ToString().TrimEnd('-');
    }
}

/// <summary>
/// Explicit catalog of AppData folders.
/// </summary>
/// <remarks>
/// This is the AppData counterpart of <see cref="SafeLocationCatalog"/>: a folder is
/// attributed to an application because it is <b>listed here</b>, never because its name
/// looks like a product name. Anything absent from the catalog is reported as unknown —
/// with its size, so the user can still see it, but without an invented explanation.
/// </remarks>
public static class KnownApplications
{
    public const string FamilyChromium = "Chromium";
    public const string FamilyFirefox = "Firefox";
    public const string FamilyElectron = "Electron";
    public const string FamilyVsCode = "VSCode";
    public const string FamilyJetBrains = "JetBrains";
    public const string FamilyWindows = "Windows";
    public const string FamilyWer = "Wer";
    public const string FamilyExplorer = "Explorer";
    public const string FamilyDevCache = "DevCache";
    public const string FamilyShaderCache = "ShaderCache";
    public const string FamilyPackages = "Packages";
    public const string FamilyTemp = "Temp";
    public const string FamilyCrashDumps = "CrashDumps";
    public const string FamilyVmDisk = "VmDisk";
    public const string FamilyData = "Data";

    /// <summary>Folder that matched nothing in the catalog.</summary>
    public const string FamilyUnknown = "Unknown";

    public static readonly IReadOnlyList<KnownAppDataEntry> All = Build();

    /// <summary>Exact match on a one-segment relative path.</summary>
    public static KnownAppDataEntry? Find(AppDataRoot root, string relativePath) =>
        All.FirstOrDefault(e =>
            e.Root == root &&
            string.Equals(e.RelativePath, relativePath, StringComparison.OrdinalIgnoreCase));

    /// <summary>Every catalog entry for one AppData root, deepest first.</summary>
    public static IReadOnlyList<KnownAppDataEntry> ForRoot(AppDataRoot root) =>
        [.. All.Where(e => e.Root == root)
               .OrderByDescending(e => e.RelativePath.Split('\\').Length)
               .ThenBy(e => e.RelativePath, StringComparer.OrdinalIgnoreCase)];

    /// <summary>
    /// Segment-wise match of a catalog path against a real relative path, so entries may
    /// use <c>*</c> where the machine decides the name — Store package family names such as
    /// <c>CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc</c> cannot be written literally.
    /// </summary>
    public static bool MatchesRelative(KnownAppDataEntry entry, IReadOnlyList<string> relativeSegments)
    {
        var pattern = entry.RelativePath.Split('\\');
        if (pattern.Length != relativeSegments.Count)
        {
            return false;
        }

        for (var i = 0; i < pattern.Length; i++)
        {
            if (!WildcardMatcher.IsMatch(relativeSegments[i], pattern[i]))
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>Vendor name when only the first segment of a path is known.</summary>
    public static string? FindVendor(AppDataRoot root, string firstSegment) =>
        All.FirstOrDefault(e =>
            e.Root == root &&
            e.Vendor is not null &&
            e.RelativePath.StartsWith(firstSegment + "\\", StringComparison.OrdinalIgnoreCase))?.Vendor;

    /// <summary>Two-segment entries that live under a vendor folder.</summary>
    public static IReadOnlyList<KnownAppDataEntry> ChildrenOf(AppDataRoot root, string firstSegment) =>
        [.. All.Where(e =>
            e.Root == root &&
            e.RelativePath.StartsWith(firstSegment + "\\", StringComparison.OrdinalIgnoreCase))];

    private static IReadOnlyList<KnownAppDataEntry> Build()
    {
        var entries = new List<KnownAppDataEntry>();

        void Add(AppDataRoot root, string relative, string name, string? vendor, string family, string explanation, bool treatChildrenAsApplications = false) =>
            entries.Add(new KnownAppDataEntry(root, relative, name, vendor, family, explanation, treatChildrenAsApplications));

        // ---------------------------------------------------------------- browsers
        const string browserExplanation =
            "Browser profile: settings, history, bookmarks, passwords, extensions and caches. " +
            "Only the cache subfolders listed below are reclaimable; the rest is user data.";

        Add(AppDataRoot.Local, @"Google\Chrome", "Google Chrome", "Google", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Google\Chrome SxS", "Google Chrome Canary", "Google", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Google\Update", "Google Update", "Google", FamilyData, "Google's updater binaries and logs. Small; removing it only makes the updater reinstall itself.");
        Add(AppDataRoot.Local, @"Microsoft\Edge", "Microsoft Edge", "Microsoft", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Microsoft\Edge SxS", "Microsoft Edge Canary", "Microsoft", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Microsoft\EdgeWebView", "Edge WebView2", "Microsoft", FamilyChromium, "WebView2 runtime data used by desktop applications that embed web content.");
        Add(AppDataRoot.Local, @"BraveSoftware\Brave-Browser", "Brave", "Brave Software", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, "Vivaldi", "Vivaldi", "Vivaldi", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, "Chromium", "Chromium", null, FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Opera Software\Opera Stable", "Opera", "Opera Software", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Opera Software\Opera GX Stable", "Opera GX", "Opera Software", FamilyChromium, browserExplanation);
        Add(AppDataRoot.Local, @"Mozilla\Firefox", "Firefox", "Mozilla", FamilyFirefox, "Firefox profiles and per-profile caches. The profile itself is user data; cache2 and startupCache are reclaimable.");

        // ---------------------------------------------------------------- editors / IDEs
        Add(AppDataRoot.Roaming, "Code", "Visual Studio Code", "Microsoft", FamilyVsCode, "VS Code user settings, snippets, workspace state, logs and caches.");
        Add(AppDataRoot.Roaming, "Code - Insiders", "Visual Studio Code Insiders", "Microsoft", FamilyVsCode, "VS Code Insiders user settings, workspace state, logs and caches.");
        Add(AppDataRoot.Roaming, "VSCodium", "VSCodium", null, FamilyVsCode, "VSCodium user settings, workspace state, logs and caches.");
        Add(AppDataRoot.Local, @"Programs\Microsoft VS Code", "Visual Studio Code (installation)", "Microsoft", FamilyData, "The per-user installation of VS Code itself. This is the program, not data — removing it uninstalls the editor.");
        Add(AppDataRoot.Local, "JetBrains", "JetBrains IDEs", "JetBrains", FamilyJetBrains, "Indexes, caches and logs of JetBrains IDEs (IntelliJ, Rider, PyCharm, WebStorm…). Removing caches forces a full re-index of every project.");

        // ---------------------------------------------------------------- Electron-based apps
        const string electronExplanation =
            "Electron-based application: profile, local databases and web caches. " +
            "Cache, GPU cache, blob storage and logs are reclaimable; the profile itself is user data.";

        Add(AppDataRoot.Roaming, "Slack", "Slack", "Slack", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Local, "Slack", "Slack (local data)", "Slack", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Discord", "Discord", "Discord", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "discord.ptb", "Discord PTB", "Discord", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Local, "Discord", "Discord (local data)", "Discord", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Notion", "Notion", "Notion Labs", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Postman", "Postman", "Postman", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Insomnia", "Insomnia", "Kong", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Figma", "Figma", "Figma", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Telegram Desktop", "Telegram Desktop", "Telegram", FamilyElectron, "Telegram Desktop profile and downloaded media cache. Removing the media cache keeps chats but re-downloads files on demand.");
        Add(AppDataRoot.Local, "Telegram Desktop", "Telegram Desktop (local data)", "Telegram", FamilyElectron, "Telegram Desktop local media and web caches.");
        Add(AppDataRoot.Roaming, "WhatsApp", "WhatsApp", "Meta", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Signal", "Signal", "Signal Foundation", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, "Spotify", "Spotify", "Spotify", FamilyElectron, "Spotify profile and offline cache. The offline cache can be large and is rebuilt when you make playlists available offline again.");
        Add(AppDataRoot.Local, "Spotify", "Spotify (local data)", "Spotify", FamilyElectron, "Spotify local storage and web caches.");
        Add(AppDataRoot.Local, @"Microsoft\Teams", "Microsoft Teams", "Microsoft", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Roaming, @"Microsoft\Teams", "Microsoft Teams (roaming)", "Microsoft", FamilyElectron, electronExplanation);
        Add(AppDataRoot.Local, "WhatsApp", "WhatsApp (local data)", "Meta", FamilyElectron, electronExplanation);

        // ---------------------------------------------------------------- developer caches
        const string devCacheExplanation =
            "Package manager cache. Everything in it can be downloaded again, so removing it is safe but " +
            "the next restore will be slower and will use bandwidth. Source code is never stored here.";

        Add(AppDataRoot.Local, "npm-cache", "npm cache", "npm", FamilyDevCache, devCacheExplanation);
        Add(AppDataRoot.Roaming, "npm-cache", "npm cache (roaming)", "npm", FamilyDevCache, devCacheExplanation);
        Add(AppDataRoot.Roaming, "npm", "npm global packages", "npm", FamilyData, "Globally installed npm packages. Removing this uninstalls your global CLI tools.");
        Add(AppDataRoot.Local, @"Yarn\Cache", "Yarn cache", "Yarn", FamilyDevCache, devCacheExplanation);
        // Not a cache: this is pnpm's home, holding the shims and the executable itself.
        // Removing it would uninstall the tool, so it is described but never offered.
        Add(AppDataRoot.Local, "pnpm", "pnpm (home and store)", "pnpm", FamilyData, "pnpm home: the executable, shims and the content-addressable store that projects link into. Removing it uninstalls pnpm and can break existing projects, so it is reported for explanation only.");
        Add(AppDataRoot.Local, "NuGet", "NuGet cache", "Microsoft", FamilyDevCache, "NuGet http and package caches. Restorable at any time; removing it only slows the next restore.");
        Add(AppDataRoot.Local, @"pip\Cache", "pip cache", "Python", FamilyDevCache, devCacheExplanation);
        Add(AppDataRoot.Local, @"pipx\Cache", "pipx cache", "Python", FamilyDevCache, devCacheExplanation);
        Add(AppDataRoot.Local, @"Android\Sdk", "Android SDK", "Google", FamilyData, "Android SDK, emulators and system images. Large, but it is an installation — removing it breaks Android builds until reinstalled.");
        Add(AppDataRoot.Local, "Temp", "Temporary files", null, FamilyTemp, "The user's TEMP folder. Applications treat it as scratch space and expect it may be empty.");
        Add(AppDataRoot.Local, "CrashDumps", "Application crash dumps", "Microsoft", FamilyCrashDumps, "User-mode crash dumps written by Windows Error Reporting. Needed only to investigate a specific past crash.");

        // ---------------------------------------------------------------- Windows itself
        Add(AppDataRoot.Local, "Packages", "Microsoft Store apps", "Microsoft", FamilyPackages,
            "Container of installed Store/UWP applications. Each subfolder is one application with its own settings, caches and temporary state.",
            treatChildrenAsApplications: true);
        Add(AppDataRoot.Local, @"Microsoft\Windows\WER", "Windows Error Reporting", "Microsoft", FamilyWer, "Queued and archived error reports. Safe to clear; Windows recreates the folders.");
        Add(AppDataRoot.Local, @"Microsoft\Windows\Explorer", "Explorer caches", "Microsoft", FamilyExplorer, "Thumbnail and icon caches. Windows rebuilds them on demand; icons may briefly appear generic.");
        Add(AppDataRoot.Local, @"Microsoft\Windows\INetCache", "Internet Explorer cache", "Microsoft", FamilyWindows, "Legacy IE/WinINET cache, still used by some desktop components.");
        Add(AppDataRoot.Local, @"Microsoft\Windows\WebCache", "WebCache", "Microsoft", FamilyWindows, "WinINET/Edge legacy URL and cookie cache database.");
        Add(AppDataRoot.Local, @"Microsoft\Windows\Caches", "Shell caches", "Microsoft", FamilyWindows, "Shell icon and thumbnail caches.");
        Add(AppDataRoot.Local, @"Microsoft\OneDrive", "OneDrive (local state)", "Microsoft", FamilyData, "OneDrive client state and setup logs. The synced files themselves live in your user folders, not here.");
        Add(AppDataRoot.Local, @"Microsoft\Windows\INetCookies", "Cookies", "Microsoft", FamilyData, "Legacy cookie store. Removing it signs you out of sites that still use WinINET.");
        Add(AppDataRoot.Local, @"Microsoft\Credentials", "Stored credentials", "Microsoft", FamilyData, "Credential Manager blobs, protected by DPAPI. Not readable without your account and never junk.");
        Add(AppDataRoot.Local, "ConnectedDevicesPlatform", "Connected Devices Platform", "Microsoft", FamilyData, "Windows cross-device state (timeline, clipboard, phone link).");
        Add(AppDataRoot.Local, "Comms", "Communications platform", "Microsoft", FamilyData, "Windows communication platform state.");
        Add(AppDataRoot.Local, "Programs", "Per-user installed programs", null, FamilyData, "Applications installed for this user only. This is program data, not cleanup material.");
        Add(AppDataRoot.Roaming, @"Microsoft\Windows\Start Menu", "Start Menu shortcuts", "Microsoft", FamilyData, "Shortcuts of the Start Menu. Tiny, and removing it empties your Start Menu.");

        // ---------------------------------------------------------------- GPU / vendor caches
        const string shaderExplanation = "Compiled shader cache. Drivers and applications regenerate it; the first launch after clearing may be slower.";
        Add(AppDataRoot.Local, "NVIDIA", "NVIDIA caches", "NVIDIA", FamilyShaderCache, shaderExplanation);
        Add(AppDataRoot.Local, @"NVIDIA Corporation", "NVIDIA Corporation caches", "NVIDIA", FamilyShaderCache, shaderExplanation);
        Add(AppDataRoot.Local, "AMD", "AMD caches", "AMD", FamilyShaderCache, shaderExplanation);
        Add(AppDataRoot.Local, "Intel", "Intel caches", "Intel", FamilyShaderCache, shaderExplanation);
        Add(AppDataRoot.Local, "D3DSCache", "DirectX shader cache", "Microsoft", FamilyShaderCache, shaderExplanation);

        // ---------------------------------------------------------------- containers: potentially critical
        const string vmExplanation =
            "Virtual disk of a container or subsystem (VHDX). This holds real filesystems and images — " +
            "it is NOT a cache. Compacting or resetting it is a deliberate administrative action, so the " +
            "application reports the size but never offers to delete it.";

        Add(AppDataRoot.Local, "Docker", "Docker Desktop", "Docker", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "Docker Desktop", "Docker Desktop (data)", "Docker", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "wsl", "WSL distributions", "Microsoft", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "Packages\\CanonicalGroupLimited*", "WSL (Ubuntu, Store package)", "Canonical", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "Packages\\*Ubuntu*", "WSL (Ubuntu, Store package)", "Canonical", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "Packages\\*Debian*", "WSL (Debian, Store package)", "Software in the Public Interest", FamilyVmDisk, vmExplanation);
        Add(AppDataRoot.Local, "Packages\\*Linux*", "WSL distribution (Store package)", null, FamilyVmDisk, vmExplanation);

        // ---------------------------------------------------------------- LocalLow
        Add(AppDataRoot.LocalLow, "Unity", "Unity (low integrity)", "Unity", FamilyData, "Unity editor and player data written at low integrity.");
        Add(AppDataRoot.LocalLow, "Adobe", "Adobe (low integrity)", "Adobe", FamilyData, "Adobe applications' low-integrity storage.");
        Add(AppDataRoot.LocalLow, @"Oracle\Java", "Java deployment cache", "Oracle", FamilyDevCache, "Java Web Start and applet cache. Fully regenerable.");
        Add(AppDataRoot.LocalLow, "Mozilla", "Mozilla (low integrity)", "Mozilla", FamilyData, "Low-integrity Mozilla data.");

        return entries;
    }
}
