using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Moving;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Core.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace DiskCleaner.Core;

/// <summary>
/// Registration of the platform-independent services.
/// </summary>
/// <remarks>
/// The WPF host calls this first and then adds its own Windows implementations
/// on top. Nothing here may depend on WPF, so the composition root stays testable.
/// </remarks>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDiskCleanerCore(this IServiceCollection services)
    {
        services.TryAddSingleton<IClock>(SystemClock.Instance);
        services.TryAddSingleton<IFileSystem, PhysicalFileSystem>();
        services.TryAddSingleton<IEnvironmentInfo>(sp => new SystemEnvironmentInfo(sp.GetService<IFileSystem>()));

        services.TryAddSingleton<ApplicationPaths>(sp =>
            new ApplicationPaths(sp.GetRequiredService<IEnvironmentInfo>(), sp.GetRequiredService<IFileSystem>()));

        services.TryAddSingleton<ISettingsService, JsonSettingsService>();
        services.TryAddSingleton<IHistoryService, JsonHistoryService>();
        services.TryAddSingleton<IDriveService, DriveService>();

        services.TryAddSingleton<FileSystemScanner>();
        services.TryAddTransient<DirectorySizeAggregator>();

        // Analyzers are registered as a set; adding one is a single line here and no
        // change to the scanner (that is the point of the IAnalyzer contract).
        services.TryAddSingleton<IDirectoryMeasurer>(sp =>
            new DirectoryMeasurer(
                sp.GetRequiredService<FileSystemScanner>(),
                sp.GetRequiredService<IFileSystem>()));
        services.AddSingleton<IAnalyzer, RecycleBinAnalyzer>();
        services.AddSingleton<IAnalyzer, TempAnalyzer>();
        services.AddSingleton<IAnalyzer, BrowserCacheAnalyzer>();
        services.AddSingleton<IAnalyzer, CrashDumpAnalyzer>();
        services.AddSingleton<IAnalyzer, ThumbnailAnalyzer>();
        services.AddSingleton<IAnalyzer, WindowsUpdateAnalyzer>();
        services.AddSingleton<IAnalyzer, LogAnalyzer>();
        services.AddSingleton<IAnalyzer, AppDataAnalyzer>();
        services.TryAddSingleton<AnalyzerPipeline>();

        // The plan the user builds, and the rows they dismissed from the report.
        services.TryAddSingleton<ICleanupPlanner, CleanupPlanner>();
        services.TryAddSingleton<ICleanupExecutor, CleanupExecutor>();
        services.TryAddSingleton<IReportExclusions, ReportExclusions>();

        // Session memory of what was actually deleted; report screens hide those rows.
        services.TryAddSingleton<ICleanupLedger>(sp =>
            new CleanupLedger(sp.GetRequiredService<ICleanupExecutor>(), sp.GetRequiredService<IScanService>()));

        services.TryAddSingleton<IScanService, ScanService>();

        // Safety policy: resolved from the real machine layout, cached for the process lifetime.
        services.TryAddSingleton<ProtectedRoots>(sp =>
        {
            var environment = sp.GetRequiredService<IEnvironmentInfo>();
            var drives = sp.GetRequiredService<IDriveService>().GetDrives();
            return ProtectedRootsResolver.Resolve(environment, [.. drives.Select(d => d.RootPath)]);
        });

        services.TryAddSingleton<ISafetyPolicy>(sp =>
            new SafetyPolicy(sp.GetRequiredService<ProtectedRoots>(), sp.GetService<IEnvironmentInfo>()));

        // Application mover. IJunctionService is platform-specific and must be supplied
        // by the host (WindowsJunctionService in the WPF shell, a fake in tests).
        services.TryAddSingleton<IAppMover, AppMover>();

        return services;
    }
}
