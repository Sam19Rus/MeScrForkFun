namespace DiskCleaner.Core.Models;

/// <summary>
/// Persisted user settings. Deliberately small: every entry here must be
/// something a real user would ever change.
/// </summary>
public sealed class AppSettings
{
    /// <summary>Bumped whenever the shape changes, so old files can be migrated or discarded.</summary>
    public int SchemaVersion { get; set; } = 1;

    // --- appearance ----------------------------------------------------------

    public AppTheme Theme { get; set; } = AppTheme.System;

    /// <summary>BCP-47 tag. Russian is the primary language, English the fallback.</summary>
    public string Language { get; set; } = "ru";

    // --- scanning ------------------------------------------------------------

    public ScanDepth ScanDepth { get; set; } = ScanDepth.Standard;

    /// <summary>Absolute paths never entered by the scanner.</summary>
    public List<string> ExcludedPaths { get; set; } = [];

    /// <summary>Extensions never reported as individual files (still counted in sizes).</summary>
    public List<string> ExcludedExtensions { get; set; } = [];

    /// <summary>Minimum size for the Large Files screen.</summary>
    public long LargeFileThresholdBytes { get; set; } = 256L * 1024 * 1024;

    /// <summary>Developer caches (node_modules, NuGet, Cargo, Gradle, shader caches, …).</summary>
    public bool EnableDeveloperAnalysis { get; set; } = true;

    /// <summary>
    /// Off by default. Turning it on can double-count data and, without the
    /// visited-set, loop on a self-referencing junction.
    /// </summary>
    public bool FollowReparsePoints { get; set; }

    /// <summary>0 = automatic (capped at <see cref="ScanOptions.MaxUsefulParallelism"/>).</summary>
    public int MaxDegreeOfParallelism { get; set; }

    // --- cleanup -------------------------------------------------------------

    public RecycleBinBehavior RecycleBinBehavior { get; set; } = RecycleBinBehavior.PreferForUserData;

    public bool SaveHistoryAutomatically { get; set; } = true;

    /// <summary>Keep at most this many history records.</summary>
    public int MaxHistoryRecords { get; set; } = 200;

    // --- diagnostics ---------------------------------------------------------

    /// <summary>Write a detailed rolling log file. Off in normal use.</summary>
    public bool EnableVerboseLogging { get; set; }

    public AppSettings Clone() => (AppSettings)MemberwiseClone();

    /// <summary>
    /// Clamps user-editable numbers into sane ranges. Called on load so a
    /// hand-edited settings.json cannot produce a broken scan.
    /// </summary>
    public AppSettings Sanitise()
    {
        LargeFileThresholdBytes = Math.Clamp(LargeFileThresholdBytes, 1L * 1024 * 1024, 1L * 1024 * 1024 * 1024 * 1024);
        MaxDegreeOfParallelism = Math.Clamp(MaxDegreeOfParallelism, 0, 64);
        MaxHistoryRecords = Math.Clamp(MaxHistoryRecords, 10, 5000);
        Language = string.IsNullOrWhiteSpace(Language) ? "ru" : Language.Trim();

        ExcludedPaths = [.. ExcludedPaths.Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).Distinct(StringComparer.OrdinalIgnoreCase)];
        ExcludedExtensions = [.. ExcludedExtensions.Where(e => !string.IsNullOrWhiteSpace(e)).Select(e => e.Trim()).Distinct(StringComparer.OrdinalIgnoreCase)];

        return this;
    }

    /// <summary>Projects the settings onto scan options.</summary>
    public ScanOptions ToScanOptions(ScanMode mode, IReadOnlyList<string> roots) => new()
    {
        Mode = mode,
        Roots = roots,
        Depth = ScanDepth,
        ExcludedPaths = ExcludedPaths,
        ExcludedExtensions = ExcludedExtensions,
        MinReportedFileSize = 0,
        LargeFileThresholdBytes = LargeFileThresholdBytes,
        IncludeHiddenAndSystem = true,
        EnableDeveloperAnalysis = EnableDeveloperAnalysis,
        FollowReparsePoints = FollowReparsePoints,
        MaxDegreeOfParallelism = MaxDegreeOfParallelism,
        MaxDepth = ScanDepth switch
        {
            ScanDepth.Fast => 24,
            ScanDepth.Exhaustive => null,
            _ => 48,
        },
    };
}
