namespace DiskCleaner.Core.Models;

/// <summary>
/// Anything the scanner could not read or process.
/// </summary>
/// <remarks>
/// A skipped file must never abort a scan and must never be silently dropped:
/// the report shows <c>Skipped: C:\Path — Access denied</c> so the user knows
/// the number is a lower bound, not a lie.
/// </remarks>
public sealed class ScanIssue
{
    public required string Path { get; init; }

    public required ScanIssueKind Kind { get; init; }

    /// <summary>Short user-facing reason. Localised by the presentation layer via <see cref="ReasonKey"/>.</summary>
    public required string Reason { get; init; }

    /// <summary>Stable, non-localised key for the reason (used by resources and by tests).</summary>
    public string ReasonKey { get; init; } = "issue.unknown";

    /// <summary>Exception type name, e.g. <c>UnauthorizedAccessException</c>. Never the full stack trace.</summary>
    public string? ExceptionType { get; init; }

    /// <summary>Underlying OS error code when available (e.g. 5 = ERROR_ACCESS_DENIED, 32 = ERROR_SHARING_VIOLATION).</summary>
    public int? ErrorCode { get; init; }

    /// <summary>Bytes we believe are hidden behind this issue, when known (0 otherwise).</summary>
    public long EstimatedSize { get; init; }

    public DateTime OccurredAtUtc { get; init; } = DateTime.UtcNow;

    /// <summary>
    /// <c>true</c> when re-running the same scope with administrator rights would probably help.
    /// Drives the "retry with elevation" affordance in the UI.
    /// </summary>
    public bool MayRequireElevation => Kind is ScanIssueKind.AccessDenied;

    public override string ToString() => $"{Kind}: {Path} ({Reason})";
}
