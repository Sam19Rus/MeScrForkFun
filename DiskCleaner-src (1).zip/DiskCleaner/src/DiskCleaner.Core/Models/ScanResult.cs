namespace DiskCleaner.Core.Models;

/// <summary>
/// The structured report produced by a scan: what was found, how much, how
/// confident we are, and what could not be read.
/// </summary>
public sealed class ScanResult
{
    public ScanMode Mode { get; init; }
    public ScanDepth Depth { get; init; }
    public IReadOnlyList<string> Roots { get; init; } = [];

    public DateTime StartedAtUtc { get; init; }
    public DateTime CompletedAtUtc { get; init; }
    public TimeSpan Duration => CompletedAtUtc - StartedAtUtc;

    public ScanStatistics Statistics { get; init; } = new();
    public bool WasCancelled => Statistics.WasCancelled;

    /// <summary>Classified candidates, grouped by the analyzer that produced them.</summary>
    public IReadOnlyList<ScanItem> Items { get; init; } = [];

    /// <summary>Space map: largest directories, deepest first when useful.</summary>
    public IReadOnlyList<DirectoryAggregate> LargestDirectories { get; init; } = [];

    /// <summary>Top-N largest files (bounded memory).</summary>
    public IReadOnlyList<ScanItem> LargestFiles { get; init; } = [];

    /// <summary>Everything that could not be read, with reasons.</summary>
    public IReadOnlyList<ScanIssue> Issues { get; init; } = [];

    /// <summary>Structured AppData breakdown, when the AppData analyzer ran.</summary>
    public AppDataReport? AppData { get; init; }

    /// <summary>Volume snapshots taken at scan start (used for "freed space" math).</summary>
    public IReadOnlyList<DriveSnapshot> Drives { get; init; } = [];

    // --- report summary ------------------------------------------------------

    /// <summary>Total bytes that could be reclaimed if every candidate were removed.</summary>
    public long PotentialCleanupBytes { get; init; }

    public long SafeBytes { get; init; }
    public long LikelyBytes { get; init; }
    public long NeedsReviewBytes { get; init; }

    public IReadOnlyDictionary<ScanCategory, long> BytesByCategory { get; init; }
        = new Dictionary<ScanCategory, long>();

    public IReadOnlyDictionary<ScanCategory, int> CountByCategory { get; init; }
        = new Dictionary<ScanCategory, int>();

    public IReadOnlyDictionary<CleanupConfidence, long> BytesByConfidence { get; init; }
        = new Dictionary<CleanupConfidence, long>();

    /// <summary>Identifier persisted with the history record so a run can be referenced later.</summary>
    public Guid Id { get; init; } = Guid.NewGuid();

    public IEnumerable<ScanItem> SelectableItems => Items.Where(i => i.IsDeletable && !i.IsProtected);
}
