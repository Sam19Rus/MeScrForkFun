namespace DiskCleaner.Core.Models;

/// <summary>
/// Immutable snapshot of scanner progress, published on a timer.
/// </summary>
/// <remarks>
/// <see cref="PercentComplete"/> is <c>null</c> whenever the total is not known.
/// The UI must render an indeterminate bar in that case — a made-up percentage
/// is worse than an honest "working…".
/// </remarks>
public sealed record ScanProgress
{
    public ScanPhase Phase { get; init; } = ScanPhase.Idle;

    /// <summary>Root currently being enumerated (drive or folder).</summary>
    public string? CurrentRoot { get; init; }

    /// <summary>Directory being enumerated right now. Best effort; may lag behind.</summary>
    public string? CurrentDirectory { get; init; }

    public long FilesScanned { get; init; }

    public long DirectoriesScanned { get; init; }

    /// <summary>Bytes walked through (sum of enumerated file sizes).</summary>
    public long BytesScanned { get; init; }

    /// <summary>Bytes attributed to found candidates so far.</summary>
    public long BytesFound { get; init; }

    public int ItemsFound { get; init; }

    public int IssuesCount { get; init; }

    /// <summary>Roots finished / total roots. Coarse but honest.</summary>
    public int RootsCompleted { get; init; }

    public int RootsTotal { get; init; }

    public TimeSpan Elapsed { get; init; }

    /// <summary>Enumerated entries per second over the last sampling window.</summary>
    public double EntriesPerSecond { get; init; }

    /// <summary>
    /// <c>null</c> when no trustworthy total is available. Only set when the
    /// work is genuinely bounded (e.g. a known list of roots being processed
    /// sequentially), never faked from a byte counter.
    /// </summary>
    public double? PercentComplete { get; init; }

    public bool IsIndeterminate => PercentComplete is null;

    public bool IsRunning => Phase is ScanPhase.Preparing or ScanPhase.Enumerating or ScanPhase.Analyzing or ScanPhase.Classifying;
}
