using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Models;

/// <summary>
/// The plan the user built. It exists as a separate object so that "what will be
/// deleted" can be shown, persisted and confirmed <em>before</em> anything runs.
/// </summary>
public sealed class CleanupPlan
{
    private readonly List<CleanupOperation> _operations = [];

    public Guid Id { get; } = Guid.NewGuid();

    public DateTime CreatedAtUtc { get; } = DateTime.UtcNow;

    /// <summary>Scan the plan was derived from (null when built ad-hoc).</summary>
    public Guid? SourceScanId { get; init; }

    public IReadOnlyList<CleanupOperation> Operations => _operations;

    public int Count => _operations.Count;

    public bool IsEmpty => _operations.Count == 0;

    public long TotalExpectedBytes => _operations.Sum(o => o.ExpectedBytes);

    public int TotalExpectedFileCount => _operations.Sum(o => o.ExpectedFileCount);

    public IEnumerable<IGrouping<ScanCategory, CleanupOperation>> ByCategory =>
        _operations.GroupBy(o => o.Category);

    public IEnumerable<CleanupOperation> HighRiskOperations =>
        _operations.Where(o => o.RiskLevel >= RiskLevel.High);

    /// <summary>
    /// Adds an operation. Refuses protected targets outright: a plan can never
    /// contain something the safety policy forbids, no matter who built it.
    /// </summary>
    /// <param name="explicitUserChoice">
    /// Pass <c>true</c> only when the user picked this exact item. It is what lets a
    /// user-data path (Documents, Desktop…) be acted on at all; hard-blocked paths stay
    /// refused either way.
    /// </param>
    /// <remarks>
    /// A rejection is returned as a <b>stable key</b> (<c>plan.*</c>, or the safety
    /// policy's rule name), not as prose: the presentation layer translates it, so the
    /// same refusal is readable in every language and greppable in logs.
    /// <para/>
    /// Nesting is collapsed in both directions. Adding a child of an already planned
    /// directory is refused (<c>plan.covered-by-parent</c>): the parent's deletion will
    /// remove it anyway, and a second operation would only produce a confusing
    /// "already gone" skip. Adding a directory whose children are already planned
    /// silently replaces them: one operation instead of many, same bytes, less noise.
    /// </remarks>
    public bool TryAdd(CleanupOperation operation, ISafetyPolicy safetyPolicy, out string? rejection, bool explicitUserChoice = false)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(safetyPolicy);

        if (_operations.Any(o => string.Equals(o.TargetPath, operation.TargetPath, PathUtils.Comparison)))
        {
            rejection = "plan.already-in-plan";
            return false;
        }

        if (operation.Method == DeletionMethod.None)
        {
            rejection = "plan.not-deletable";
            return false;
        }

        if (_operations.Any(o =>
                o.Kind == ScanItemKind.Directory &&
                PathUtils.IsUnder(operation.TargetPath, o.TargetPath)))
        {
            rejection = "plan.covered-by-parent";
            return false;
        }

        var verdict = safetyPolicy.Evaluate(operation.TargetPath, operation.Category, operation.Kind, explicitUserChoice);
        if (!verdict.IsAllowed)
        {
            rejection = verdict.RuleName ?? "policy.blocked";
            return false;
        }

        // The policy sets a ceiling on confidence and a floor on risk. An operation built
        // from a stale or optimistic ScanItem must not enter the plan understating either,
        // because these two fields are what the confirmation dialog shows.
        _operations.Add(operation with
        {
            Confidence = operation.Confidence > verdict.MaxConfidence ? verdict.MaxConfidence : operation.Confidence,
            RiskLevel = operation.RiskLevel < verdict.MinRisk ? verdict.MinRisk : operation.RiskLevel,
            RequiresElevation = operation.RequiresElevation || verdict.RequiresElevation,
        });

        // This directory supersedes any of its children that were planned individually.
        if (operation.Kind == ScanItemKind.Directory)
        {
            _operations.RemoveAll(o =>
                !string.Equals(o.TargetPath, operation.TargetPath, PathUtils.Comparison) &&
                PathUtils.IsUnder(o.TargetPath, operation.TargetPath));
        }

        rejection = null;
        return true;
    }

    public bool Remove(string targetPath) =>
        _operations.RemoveAll(o => string.Equals(o.TargetPath, targetPath, PathUtils.Comparison)) > 0;

    public void Clear() => _operations.Clear();
}
