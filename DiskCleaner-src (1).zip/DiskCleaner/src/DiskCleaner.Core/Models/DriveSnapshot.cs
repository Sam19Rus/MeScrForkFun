namespace DiskCleaner.Core.Models;

/// <summary>Snapshot of one volume, taken without touching the file system more than once.</summary>
public sealed record DriveSnapshot
{
    /// <summary>Root path, e.g. <c>C:\</c>.</summary>
    public required string RootPath { get; init; }

    /// <summary>Volume label, may be empty.</summary>
    public string Label { get; init; } = string.Empty;

    /// <summary><c>Fixed</c>, <c>Removable</c>, <c>Network</c>, <c>CdRom</c>, <c>Ram</c>.</summary>
    public required string DriveType { get; init; }

    public string FileSystemName { get; init; } = string.Empty;

    public long TotalBytes { get; init; }

    public long FreeBytes { get; init; }

    public long UsedBytes => TotalBytes - FreeBytes;

    /// <summary>0..1. <c>null</c> when the volume is not ready or reports no size.</summary>
    public double? UsedRatio => TotalBytes > 0 ? Math.Clamp((double)UsedBytes / TotalBytes, 0d, 1d) : null;

    public bool IsReady { get; init; }

    /// <summary>Fixed local volumes are the only ones scanned by default.</summary>
    public bool IsScannableByDefault { get; init; }

    /// <summary>Reading this volume needs an elevated process (rare, e.g. some recovery partitions).</summary>
    public bool RequiresElevation { get; init; }

    /// <summary>Volume serial, used to detect junctions that cross volume boundaries.</summary>
    public string? VolumeSerialNumber { get; init; }

    public DateTime CapturedAtUtc { get; init; } = DateTime.UtcNow;

    public string DisplayName => string.IsNullOrWhiteSpace(Label) ? RootPath : $"{Label} ({RootPath})";
}
