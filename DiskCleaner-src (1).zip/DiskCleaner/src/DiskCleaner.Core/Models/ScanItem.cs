using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Models;

/// <summary>
/// One row of the analysis report: a file, a directory or a virtual target
/// (Recycle Bin, package container) together with everything needed to explain
/// it to the user and to decide whether it may be removed.
/// </summary>
/// <remarks>
/// Deliberately a plain data object: it is produced by scanners and analyzers on
/// worker threads and must stay free of any UI dependency. The presentation layer
/// wraps it in an observable node for binding and tree display.
/// </remarks>
public sealed class ScanItem
{
    /// <summary>Absolute path. For <see cref="ScanItemKind.VirtualTarget"/> this may be a pseudo path.</summary>
    public required string Path { get; init; }

    /// <summary>Display name (leaf of <see cref="Path"/>, or a friendly label for virtual targets).</summary>
    public required string Name { get; init; }

    public ScanItemKind Kind { get; init; } = ScanItemKind.File;

    /// <summary>Bytes on disk. For directories: the whole subtree.</summary>
    public long Size { get; set; }

    /// <summary>Number of files contained in this item (1 for a file).</summary>
    public int FileCount { get; set; } = 1;

    public DateTime? CreatedAtUtc { get; init; }

    public DateTime? ModifiedAtUtc { get; init; }

    /// <summary>Lower-case extension including the dot, or <c>null</c> for directories.</summary>
    public string? Extension { get; init; }

    // --- classification ------------------------------------------------------

    public ScanCategory Category { get; set; } = ScanCategory.Unknown;

    /// <summary>How certain we are that this is reclaimable junk. See <see cref="CleanupConfidence"/>.</summary>
    public CleanupConfidence Confidence { get; set; } = CleanupConfidence.NeedsReview;

    /// <summary>Consequence of a wrong decision. Independent from <see cref="Confidence"/>.</summary>
    public RiskLevel RiskLevel { get; set; } = RiskLevel.High;

    /// <summary>
    /// <c>true</c> only when deletion is technically permitted AND allowed by the safety policy.
    /// A large user file is deletable in principle but must not be offered as cleanup.
    /// </summary>
    public bool IsDeletable { get; set; }

    public DeletionMethod DeletionMethod { get; set; } = DeletionMethod.None;

    /// <summary>Short, stable reason key, e.g. <c>temp.file</c> or <c>leftover.no-installed-app</c>.</summary>
    public string? Reason { get; set; }

    /// <summary>
    /// Human-readable explanation of <em>why</em> this item was found and what it is for.
    /// Must never be empty for items shown in the report.
    /// </summary>
    public string? Explanation { get; set; }

    /// <summary>Name of the analyzer that produced this item (diagnostics / trust).</summary>
    public required string SourceAnalyzer { get; init; }

    // --- context -------------------------------------------------------------

    /// <summary>Owning application, when it could be attributed (e.g. "Google Chrome").</summary>
    public string? OwnerApplication { get; set; }

    /// <summary>Volume root this item belongs to, e.g. <c>C:\</c>.</summary>
    public string? DriveRoot { get; init; }

    public bool IsReparsePoint { get; init; }

    /// <summary>Set when the path is inside a protected root (Windows, Program Files, user documents…).</summary>
    public bool IsProtected { get; set; }

    /// <summary>Set when reading or deleting this item needs an elevated process.</summary>
    public bool RequiresElevation { get; set; }

    /// <summary>Stable identity used to de-duplicate items produced by several analyzers.</summary>
    public string Id => Path;

    public override string ToString() =>
        $"{Kind} {Name} · {Size:N0} B · {Category}/{Confidence} · {Path}";

    /// <summary>Builds an item straight from a file system entry (no classification yet).</summary>
    public static ScanItem FromEntry(ScannedEntry entry, string sourceAnalyzer) => new()
    {
        Path = entry.FullPath,
        Name = entry.Name,
        Kind = entry.IsDirectory ? ScanItemKind.Directory : ScanItemKind.File,
        Size = entry.Size,
        CreatedAtUtc = entry.CreatedUtc,
        ModifiedAtUtc = entry.LastWriteUtc,
        Extension = entry.IsDirectory ? null : PathUtils.GetExtensionOrNull(entry.Name),
        IsReparsePoint = entry.IsReparsePoint,
        DriveRoot = entry.DriveRoot,
        SourceAnalyzer = sourceAnalyzer,
    };
}
