namespace DiskCleaner.Core.Models;

/// <summary>How much of the machine the user asked us to look at.</summary>
public enum ScanMode
{
    /// <summary>Only well-known, whitelisted locations (TEMP, browser caches, dumps, logs, Recycle Bin).</summary>
    Quick = 0,

    /// <summary>Full space map of the selected local drives plus AppData / leftover analysis.</summary>
    Deep = 1,

    /// <summary>The user picked exact drives and/or folders.</summary>
    Custom = 2,
}

/// <summary>
/// What a piece of disk usage actually is.
/// A category is a statement about <em>kind</em>, never about <em>value</em>:
/// a 40 GB <see cref="LargeFiles"/> entry is not junk just because it is large.
/// </summary>
public enum ScanCategory
{
    /// <summary>We could not attribute this data to any known category.</summary>
    Unknown = 0,

    TemporaryFiles,
    BrowserCache,
    ApplicationCache,
    Logs,
    CrashDumps,
    RecycleBin,
    Thumbnails,
    WindowsUpdateCache,
    AppLeftovers,
    LargeFiles,
    DeveloperData,
    InstallerPackages,

    /// <summary>Operating-system data. Reported for explanation, never proposed for deletion.</summary>
    SystemData,

    /// <summary>Documents, media and projects. Reported for explanation, never proposed for deletion.</summary>
    UserData,

    Other,
}

/// <summary>Which phase the scan engine is currently in. Surfaced verbatim in the progress UI.</summary>
public enum ScanPhase
{
    Idle = 0,
    Preparing,
    Enumerating,
    Analyzing,
    Classifying,
    Completed,
    Cancelled,
    Faulted,
}

/// <summary>Why a path/file could not be processed. Shown to the user in plain language.</summary>
public enum ScanIssueKind
{
    Unknown = 0,

    /// <summary>NTFS ACL denied access. Usually fixable by re-running that scope elevated.</summary>
    AccessDenied,

    /// <summary>Path exceeded the supported length for the operation.</summary>
    PathTooLong,

    /// <summary>Sharing violation: the file is open by another process.</summary>
    FileInUse,

    /// <summary>Entry disappeared between enumeration and inspection (normal on TEMP).</summary>
    NotFound,

    IoError,

    /// <summary>Junction / symlink / mount point that we deliberately did not follow.</summary>
    ReparsePointSkipped,

    /// <summary>Excluded by user settings or by the safety policy.</summary>
    Excluded,

    Cancelled,
}
