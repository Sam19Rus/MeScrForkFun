namespace DiskCleaner.Core.Models;

/// <summary>Which of the three AppData roots a directory belongs to.</summary>
public enum AppDataRoot
{
    /// <summary><c>%LOCALAPPDATA%</c> — machine-local, never roamed. Caches live here.</summary>
    Local = 0,

    /// <summary><c>%APPDATA%</c> — roams with the user in a domain. Settings and state live here.</summary>
    Roaming = 1,

    /// <summary><c>%USERPROFILE%\AppData\LocalLow</c> — low-integrity applications.</summary>
    LocalLow = 2,
}

/// <summary>What a piece of AppData content actually is.</summary>
public enum AppDataContentKind
{
    /// <summary>Regenerable cache. Reclaimed automatically by the owning app when needed.</summary>
    Cache = 0,

    Logs,

    /// <summary>Crash reports and dumps belonging to the application.</summary>
    CrashDumps,

    Temp,

    /// <summary>UWP/Store package containers.</summary>
    Packages,

    /// <summary>Developer package/build caches: regenerable, but re-downloading costs time and bandwidth.</summary>
    DeveloperCache,

    /// <summary>Real application data: profiles, databases, settings, indexes. Not junk.</summary>
    Data,

    /// <summary>Purpose could not be determined. Never offered for deletion.</summary>
    Unknown,
}

/// <summary>One directory node of the AppData tree shown in the report.</summary>
public sealed record AppDataDirectoryNode
{
    public required string Path { get; init; }

    public required string Name { get; init; }

    /// <summary>Bytes in the whole subtree.</summary>
    public long SubtreeBytes { get; init; }

    /// <summary>Bytes in files directly inside this directory.</summary>
    public long OwnBytes { get; init; }

    public int FileCount { get; init; }

    public int Depth { get; init; }

    public string? ParentPath { get; init; }

    public DateTime? LastWriteUtc { get; init; }

    /// <summary>Mutable because the tree is linked bottom-up after the nodes are created.</summary>
    public IReadOnlyList<AppDataDirectoryNode> Children { get; set; } = [];

    public bool IsLeaf => Children.Count == 0;
}

/// <summary>One classified group inside an application's AppData (e.g. its cache).</summary>
public sealed record AppDataContentGroup
{
    public required AppDataContentKind Kind { get; init; }

    /// <summary>Directory (or file) this group refers to.</summary>
    public required string Path { get; init; }

    public required string Name { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public DateTime? LastWriteUtc { get; init; }

    /// <summary>How confident we are that this group is reclaimable.</summary>
    public CleanupConfidence Confidence { get; init; } = CleanupConfidence.NeedsReview;

    public RiskLevel Risk { get; init; } = RiskLevel.High;

    public DeletionMethod Method { get; init; } = DeletionMethod.None;

    /// <summary><c>true</c> when the group may be offered as a cleanup candidate.</summary>
    public bool IsReclaimable { get; init; }

    /// <summary>Stable reason key for localisation, e.g. <c>appdata.cache.chromium</c>.</summary>
    public string? ReasonKey { get; init; }

    /// <summary>What this data is for and what happens if it is removed.</summary>
    public string? Explanation { get; init; }
}

/// <summary>One application (or vendor folder) inside AppData.</summary>
public sealed record AppDataApplication
{
    public required string Path { get; init; }

    /// <summary>Friendly name when the folder is recognised, otherwise the folder name.</summary>
    public required string DisplayName { get; init; }

    public string? Vendor { get; init; }

    /// <summary><c>true</c> when the folder matched the known-application catalog.</summary>
    public bool IsKnown { get; init; }

    /// <summary>
    /// Rule family that classified the contents (Chromium, VSCode, JetBrains…).
    /// Drives the reported category, e.g. a browser family makes its cache BrowserCache.
    /// </summary>
    public string? Family { get; init; }

    public required AppDataRoot Root { get; init; }

    /// <summary>Profile this entry belongs to, e.g. <c>C:\Users\alice</c>.</summary>
    public required string Profile { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public DateTime? LastWriteUtc { get; init; }

    /// <summary>What the application stores here. Empty for unknown folders.</summary>
    public string? Explanation { get; init; }

    /// <summary>
    /// Stable localisation key of <see cref="Explanation"/> (see
    /// <see cref="DiskCleaner.Core.Analyzers.AppData.KnownAppDataEntry.ExplanationKey"/>).
    /// Null for folders that matched nothing in the catalog.
    /// </summary>
    public string? ExplanationKey { get; init; }

    /// <summary>Classified content groups, largest first.</summary>
    public IReadOnlyList<AppDataContentGroup> Contents { get; init; } = [];

    /// <summary>Biggest subdirectories, for the expandable tree view.</summary>
    public IReadOnlyList<AppDataDirectoryNode> LargestDirectories { get; init; } = [];

    /// <summary>Bytes inside this application that may be reclaimed.</summary>
    public long ReclaimableBytes => Contents.Where(c => c.IsReclaimable).Sum(c => c.Bytes);
}

/// <summary>Totals for one AppData root of one profile.</summary>
public sealed record AppDataRootSummary
{
    public required AppDataRoot Root { get; init; }

    public required string Path { get; init; }

    public required string Profile { get; init; }

    public bool Exists { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public int ApplicationCount { get; init; }

    /// <summary><c>false</c> when part of the root could not be read: the total is a lower bound.</summary>
    public bool IsComplete { get; init; } = true;

    public IReadOnlyList<ScanIssue> Issues { get; init; } = [];
}

/// <summary>The whole AppData report attached to a <see cref="ScanResult"/>.</summary>
public sealed record AppDataReport
{
    public IReadOnlyList<AppDataRootSummary> Roots { get; init; } = [];

    /// <summary>All applications across profiles and roots, largest first.</summary>
    public IReadOnlyList<AppDataApplication> Applications { get; init; } = [];

    public long TotalBytes { get; init; }

    public int TotalFiles { get; init; }

    /// <summary>Bytes attributed to a recognised application.</summary>
    public long KnownBytes { get; init; }

    /// <summary>Bytes in folders that matched nothing in the catalog.</summary>
    public long UnknownBytes { get; init; }

    /// <summary>Bytes that may be reclaimed across every recognised group.</summary>
    public long ReclaimableBytes { get; init; }

    /// <summary>Reclaimable bytes limited to groups rated <see cref="CleanupConfidence.Safe"/>.</summary>
    public long SafeReclaimableBytes { get; init; }

    /// <summary>Whether any part of AppData could not be read.</summary>
    public bool IsComplete { get; init; } = true;

    /// <summary>Totals per content kind, largest first.</summary>
    public IReadOnlyList<AppDataContentTotals> ByContentKind { get; init; } = [];

    public static AppDataReport Empty { get; } = new();
}

/// <summary>One row of the "by content kind" summary.</summary>
public sealed record AppDataContentTotals
{
    public required AppDataContentKind Kind { get; init; }

    public long Bytes { get; init; }

    public int FileCount { get; init; }

    public int GroupCount { get; init; }

    public long ReclaimableBytes { get; init; }
}
