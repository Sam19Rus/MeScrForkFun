namespace DiskCleaner.Core.Models;

/// <summary>Aggregate counters for one scan run.</summary>
public sealed record ScanStatistics
{
    public long FilesScanned { get; init; }
    public long DirectoriesScanned { get; init; }
    public long BytesScanned { get; init; }
    public long IssuesCount { get; init; }
    public long ReparsePointsSkipped { get; init; }

    /// <summary>Directories that could not be read at all (access denied / IO error).</summary>
    public long InaccessibleDirectories { get; init; }

    public TimeSpan Elapsed { get; init; }
    public bool WasCancelled { get; init; }

    /// <summary>Peak number of directory entries held in memory by the aggregation structures.</summary>
    public int PeakTrackedDirectories { get; init; }
}

/// <summary>Aggregated size of one directory produced by the space-map pass.</summary>
public sealed record DirectoryAggregate
{
    public required string Path { get; init; }
    public required string Name { get; init; }

    /// <summary>Bytes in files directly inside this directory.</summary>
    public long OwnBytes { get; init; }

    /// <summary>Bytes in this directory and all of its subdirectories.</summary>
    public long SubtreeBytes { get; init; }

    public int OwnFileCount { get; init; }
    public int SubtreeFileCount { get; init; }

    /// <summary>0 for a scan root, 1 for its children, and so on.</summary>
    public int Depth { get; init; }

    public string? ParentPath { get; init; }

    public DateTime? LastWriteUtc { get; init; }
}
