namespace DiskCleaner.Core.Models;

/// <summary>Physical shape of a scan item.</summary>
public enum ScanItemKind
{
    File = 0,
    Directory,

    /// <summary>
    /// Something that is not a plain path but still occupies space, e.g. the
    /// Recycle Bin of a volume or a UWP package container.
    /// </summary>
    VirtualTarget,
}

/// <summary>
/// How sure the application is that the data is reclaimable junk.
/// </summary>
/// <remarks>
/// This is deliberately <b>not</b> the same axis as <see cref="RiskLevel"/> or
/// <see cref="DeletionMethod"/>. The product rule is:
/// <list type="bullet">
///   <item><description>"can be deleted" (technically possible) ≠ "is junk" (semantically certain);</description></item>
///   <item><description>only <see cref="Safe"/> items are pre-selected in the cleanup plan;</description></item>
///   <item><description><see cref="NeedsReview"/> items are never pre-selected, only explained.</description></item>
/// </list>
/// </remarks>
public enum CleanupConfidence
{
    /// <summary>
    /// Purpose could not be determined reliably. The honest answer is
    /// "requires user review" — the item is explained, never auto-selected.
    /// </summary>
    NeedsReview = 0,

    /// <summary>Strong evidence that the data is reclaimable, but the decision stays with the user.</summary>
    Likely = 1,

    /// <summary>
    /// Matched an explicit, hand-written rule for a well-known location
    /// (never "folder name contains cache").
    /// </summary>
    Safe = 2,
}

/// <summary>Consequence if the user deletes this and turns out to be wrong.</summary>
public enum RiskLevel
{
    None = 0,

    /// <summary>Regenerated automatically by the owning application (browser cache, thumbnails).</summary>
    Low = 1,

    /// <summary>Recoverable but with a cost: re-download, re-index, re-build.</summary>
    Medium = 2,

    /// <summary>Potential loss of user data or broken application state.</summary>
    High = 3,

    /// <summary>Can damage the OS or make the machine unbootable. Never offered.</summary>
    Critical = 4,
}

/// <summary>How an item is removed once the user has explicitly confirmed the plan.</summary>
public enum DeletionMethod
{
    /// <summary>Protected. This application will not delete it, even if asked.</summary>
    None = 0,

    /// <summary>Moved to the Recycle Bin so the user can undo the decision.</summary>
    RecycleBin = 1,

    /// <summary>Deleted permanently. Only for data whose retention is meaningless (TEMP, cache).</summary>
    Permanent = 2,

    /// <summary>Handled by a dedicated Windows API instead of file deletion (e.g. emptying the Recycle Bin).</summary>
    SystemApi = 3,
}

/// <summary>Lifecycle state of a single planned operation.</summary>
public enum CleanupOperationStatus
{
    Pending = 0,
    Succeeded,

    /// <summary>Not deleted, with a reason: in use, vanished, protected, denied.</summary>
    Skipped,

    Failed,
    Cancelled,
}
