namespace DiskCleaner.Core.Models;

/// <summary>Colour scheme requested by the user.</summary>
public enum AppTheme
{
    /// <summary>Follow the Windows setting (Apps use my Windows mode).</summary>
    System = 0,
    Light = 1,
    Dark = 2,
}

/// <summary>
/// Where deleted data goes. The default keeps user-looking data recoverable
/// while letting genuinely worthless cache be removed permanently.
/// </summary>
public enum RecycleBinBehavior
{
    /// <summary>Anything that might be user data goes to the Recycle Bin; temp/cache is deleted permanently.</summary>
    PreferForUserData = 0,

    /// <summary>Everything goes to the Recycle Bin when the volume supports it.</summary>
    Always = 1,

    /// <summary>Delete permanently (fastest, no undo).</summary>
    Never = 2,
}

/// <summary>How hard the scanner works. Trades time for completeness.</summary>
public enum ScanDepth
{
    /// <summary>Skip slow heuristics, cap directory aggregation depth.</summary>
    Fast = 0,

    Standard = 1,

    /// <summary>Full enumeration, no aggregation depth cap, all analyzers enabled.</summary>
    Exhaustive = 2,
}
