namespace DiskCleaner.Core.Models;

/// <summary>
/// One entry of the user-confirmed cleanup plan.
/// The planner creates these; the executor only ever acts on them.
/// </summary>
public sealed record CleanupOperation
{
    public Guid Id { get; init; } = Guid.NewGuid();

    public required string TargetPath { get; init; }

    public required string DisplayName { get; init; }

    public ScanItemKind Kind { get; init; } = ScanItemKind.File;

    public ScanCategory Category { get; init; }

    public CleanupConfidence Confidence { get; init; }

    public RiskLevel RiskLevel { get; init; }

    public DeletionMethod Method { get; init; } = DeletionMethod.None;

    /// <summary>Expected size, captured when the plan was built. Used for the confirmation dialog.</summary>
    public long ExpectedBytes { get; init; }

    public int ExpectedFileCount { get; init; } = 1;

    /// <summary>Why this is a candidate — carried over from the <see cref="ScanItem"/>.</summary>
    public string? Reason { get; init; }

    public string? Explanation { get; init; }

    public string SourceAnalyzer { get; init; } = string.Empty;

    // --- execution result ----------------------------------------------------

    public CleanupOperationStatus Status { get; set; } = CleanupOperationStatus.Pending;

    /// <summary>Bytes actually reclaimed.</summary>
    public long FreedBytes { get; set; }

    /// <summary>Files actually removed.</summary>
    public int RemovedFileCount { get; set; }

    /// <summary>Reason for <see cref="CleanupOperationStatus.Skipped"/> / <see cref="CleanupOperationStatus.Failed"/>.</summary>
    public string? ErrorMessage { get; set; }

    public ScanIssueKind? ErrorKind { get; set; }

    public DateTime? ExecutedAtUtc { get; set; }

    /// <summary>Set when the operation needed administrator rights that the process does not have.</summary>
    public bool RequiresElevation { get; set; }

    public static CleanupOperation FromItem(ScanItem item) => new()
    {
        TargetPath = item.Path,
        DisplayName = item.Name,
        Kind = item.Kind,
        Category = item.Category,
        Confidence = item.Confidence,
        RiskLevel = item.RiskLevel,
        Method = item.DeletionMethod,
        ExpectedBytes = item.Size,
        ExpectedFileCount = Math.Max(1, item.FileCount),
        Reason = item.Reason,
        Explanation = item.Explanation,
        SourceAnalyzer = item.SourceAnalyzer,
        RequiresElevation = item.RequiresElevation,
    };
}
