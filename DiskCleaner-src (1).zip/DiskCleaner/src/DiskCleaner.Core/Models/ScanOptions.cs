using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Core.Models;

/// <summary>
/// Everything a scan run is allowed to touch and how hard it should work.
/// Immutable and validated once, so worker threads never race on options.
/// </summary>
public sealed record ScanOptions
{
    public ScanMode Mode { get; init; } = ScanMode.Quick;

    /// <summary>Absolute roots: drive roots (<c>C:\</c>) or folders.</summary>
    public IReadOnlyList<string> Roots { get; init; } = [];

    public ScanDepth Depth { get; init; } = ScanDepth.Standard;

    // --- filtering -----------------------------------------------------------

    /// <summary>Absolute path prefixes that are never entered.</summary>
    public IReadOnlyList<string> ExcludedPaths { get; init; } = [];

    /// <summary>Extensions (with or without leading dot, case-insensitive) that are never reported.</summary>
    public IReadOnlyList<string> ExcludedExtensions { get; init; } = [];

    /// <summary>Files smaller than this are counted for sizes but never reported individually. 0 = report everything.</summary>
    public long MinReportedFileSize { get; init; }

    /// <summary>Threshold used by the large-files analyzer.</summary>
    public long LargeFileThresholdBytes { get; init; } = 256L * 1024 * 1024;

    /// <summary>Maximum directory depth below each root. <c>null</c> = unlimited.</summary>
    public int? MaxDepth { get; init; }

    /// <summary>Include hidden and system entries. Default <c>true</c>: caches are frequently hidden.</summary>
    public bool IncludeHiddenAndSystem { get; init; } = true;

    public bool EnableDeveloperAnalysis { get; init; } = true;

    // --- safety / traversal --------------------------------------------------

    /// <summary>
    /// Follow junctions, symlinks and mount points.
    /// Default <c>false</c>: following them double-counts data and can create
    /// cycles (a junction pointing at its own ancestor would loop forever).
    /// </summary>
    public bool FollowReparsePoints { get; init; }

    // --- performance ---------------------------------------------------------

    /// <summary>Worker threads used for enumeration. 0 = <see cref="Environment.ProcessorCount"/> capped by <see cref="MaxUsefulParallelism"/>.</summary>
    public int MaxDegreeOfParallelism { get; init; }

    /// <summary>
    /// Enumerating more than a handful of directories in parallel saturates a
    /// spinning disk and thrashes the NTFS MFT cache on SSDs. 4 is a good default.
    /// </summary>
    public const int MaxUsefulParallelism = 4;

    /// <summary>Capacity of the bounded directory work queue (back-pressure).</summary>
    public int DirectoryQueueCapacity { get; init; } = 4096;

    /// <summary>How often progress snapshots are published.</summary>
    public TimeSpan ProgressInterval { get; init; } = TimeSpan.FromMilliseconds(200);

    /// <summary>Number of entries kept in the "largest files" ranking. Fixed memory.</summary>
    public int TopFilesCapacity { get; init; } = 200;

    /// <summary>Number of entries kept in the "largest directories" ranking. Fixed memory.</summary>
    public int TopDirectoriesCapacity { get; init; } = 200;

    /// <summary>
    /// Total bytes that are expected to be walked, when known (sum of used space of
    /// the scanned volumes). Used only to derive an honest percentage; leave 0 for
    /// folder-scoped scans where no meaningful total exists and the UI shows an
    /// indeterminate bar instead of a fake number.
    /// </summary>
    public long ExpectedTotalBytes { get; init; }

    /// <summary>
    /// Directory aggregation keeps one counter per visited directory. Beyond this
    /// limit the deepest levels stop being tracked individually so memory stays
    /// bounded on pathological trees (millions of folders).
    /// </summary>
    public int MaxTrackedDirectories { get; init; } = 400_000;

    public int ResolveParallelism()
    {
        if (MaxDegreeOfParallelism > 0)
        {
            return Math.Clamp(MaxDegreeOfParallelism, 1, 64);
        }

        return Math.Clamp(Environment.ProcessorCount, 1, MaxUsefulParallelism);
    }

    public ScanOptions WithRoots(params string[] roots) => this with { Roots = roots };

    /// <summary>Validates the options and returns a normalised copy.</summary>
    public ScanOptions Normalise()
    {
        var roots = Roots
            .Where(r => !string.IsNullOrWhiteSpace(r))
            .Select(PathUtils.Normalize)
            .Distinct(PathUtils.Comparer)
            .ToArray();

        return this with
        {
            Roots = roots,
            ExcludedPaths = ExcludedPaths
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .Select(PathUtils.Normalize)
                .Distinct(PathUtils.Comparer)
                .ToArray(),
            ExcludedExtensions = ExcludedExtensions
                .Where(e => !string.IsNullOrWhiteSpace(e))
                .Select(e => e.StartsWith('.') ? e.ToLowerInvariant() : "." + e.ToLowerInvariant())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray(),
        };
    }
}
