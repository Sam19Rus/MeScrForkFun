using System.Text.Json.Serialization;

namespace DiskCleaner.Core.Models;

/// <summary>One skipped file inside a cleanup run.</summary>
public sealed record SkippedFile
{
    public required string Path { get; init; }

    public required ScanIssueKind Kind { get; init; }

    public required string Reason { get; init; }

    public long EstimatedBytes { get; init; }
}

/// <summary>
/// One path that was actually removed by a cleanup run.
/// </summary>
/// <remarks>
/// This is what lets the rest of the application answer "was this deleted?" without
/// re-scanning: the Results and Large Files screens drop these paths (and everything
/// under a deleted directory) from the stale report, and the History screen can show
/// what exactly was removed. Only <em>successful</em> operations are recorded.
/// </remarks>
public sealed record DeletedEntry
{
    public required string Path { get; init; }

    public ScanItemKind Kind { get; init; } = ScanItemKind.File;

    /// <summary>Bytes credited for this deletion (planned size; the shell API reports none).</summary>
    public long Bytes { get; init; }

    /// <summary><c>true</c> when the data went to the Recycle Bin and can be restored from there.</summary>
    public bool Recycled { get; init; }
}

/// <summary>
/// Persistent record of one executed cleanup. Kept forever (until the user clears
/// it) so the app can answer "what did I delete last week and how much did it free?".
/// </summary>
public sealed record CleanupRunRecord
{
    public Guid Id { get; init; } = Guid.NewGuid();

    public DateTime StartedAtUtc { get; init; }

    public DateTime CompletedAtUtc { get; init; }

    [JsonIgnore]
    public TimeSpan Duration => CompletedAtUtc - StartedAtUtc;

    public ScanMode Mode { get; init; }

    /// <summary>Bytes reported by the volumes before the run.</summary>
    public long FreeBytesBefore { get; init; }

    /// <summary>Bytes reported by the volumes after the run.</summary>
    public long FreeBytesAfter { get; init; }

    /// <summary>Sum of sizes of everything actually removed. This is the number we promise.</summary>
    public long FreedBytes { get; init; }

    public int DeletedFileCount { get; init; }

    public int DeletedDirectoryCount { get; init; }

    public int SkippedCount { get; init; }

    public int FailedCount { get; init; }

    public bool WasCancelled { get; init; }

    /// <summary>Whether the process was elevated while executing.</summary>
    public bool RanElevated { get; init; }

    /// <summary>Per-category totals. A list (not a dictionary) so it survives JSON round-trips cleanly.</summary>
    public IReadOnlyList<CategoryBreakdown> Categories { get; init; } = [];

    public IReadOnlyList<SkippedFile> Skipped { get; init; } = [];

    /// <summary>Everything actually removed by this run (successful operations only).</summary>
    public IReadOnlyList<DeletedEntry> Deleted { get; init; } = [];

    /// <summary>Free-text notes the user attached to the run (optional).</summary>
    public string? Note { get; init; }

    /// <summary>Version of the record schema, for forward-compatible migration.</summary>
    public int SchemaVersion { get; init; } = 2;
}

/// <summary>Per-category totals inside a <see cref="CleanupRunRecord"/>.</summary>
public sealed record CategoryBreakdown
{
    public required ScanCategory Category { get; init; }
    public long FreedBytes { get; init; }
    public int FileCount { get; init; }
    public int DirectoryCount { get; init; }
    public int SkippedCount { get; init; }
}
