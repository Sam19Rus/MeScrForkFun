using System.ComponentModel;
using System.Windows;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.ViewModels;

namespace DiskCleaner.App.Views;

/// <summary>
/// Shell window. The only logic here is the close guard: leaving while a scan is
/// running would throw away work the user is waiting for.
/// </summary>
public partial class MainWindow : Window
{
    private readonly IStringLocalizer _localizer;

    public MainWindow(MainViewModel viewModel, IStringLocalizer localizer)
    {
        InitializeComponent();
        DataContext = viewModel;
        _localizer = localizer;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (DataContext is MainViewModel { IsBusy: true })
        {
            var answer = MessageBox.Show(
                this,
                _localizer.Get("S.Shell.BusyClose"),
                _localizer.Get("S.Shell.BusyCloseTitle"),
                MessageBoxButton.YesNo,
                MessageBoxImage.Question,
                MessageBoxResult.No);

            if (answer != MessageBoxResult.Yes)
            {
                e.Cancel = true;
                return;
            }
        }

        base.OnClosing(e);
    }
}
