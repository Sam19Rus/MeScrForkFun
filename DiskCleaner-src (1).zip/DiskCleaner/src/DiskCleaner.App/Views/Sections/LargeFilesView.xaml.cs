using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

/// <summary>Phase 4: the Large Files screen. All logic lives in the view model.</summary>
public partial class LargeFilesView : UserControl
{
    public LargeFilesView() => InitializeComponent();
}
