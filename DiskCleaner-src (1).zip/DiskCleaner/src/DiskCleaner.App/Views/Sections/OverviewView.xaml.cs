using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class OverviewView : UserControl
{
    public OverviewView() => InitializeComponent();
}
