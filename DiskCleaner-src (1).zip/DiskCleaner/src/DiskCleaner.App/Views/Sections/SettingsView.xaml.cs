using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class SettingsView : UserControl
{
    public SettingsView() => InitializeComponent();
}
