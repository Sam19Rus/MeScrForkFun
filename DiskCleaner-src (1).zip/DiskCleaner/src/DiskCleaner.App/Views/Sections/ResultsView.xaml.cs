using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class ResultsView : UserControl
{
    public ResultsView() => InitializeComponent();
}
