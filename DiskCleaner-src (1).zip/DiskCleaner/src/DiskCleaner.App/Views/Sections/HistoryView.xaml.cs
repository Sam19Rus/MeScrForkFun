using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class HistoryView : UserControl
{
    public HistoryView() => InitializeComponent();
}
