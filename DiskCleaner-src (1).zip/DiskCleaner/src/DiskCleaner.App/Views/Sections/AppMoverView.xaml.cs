using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

/// <summary>
/// The application mover screen. All logic lives in <c>AppMoverViewModel</c>;
/// this is the pure view.
/// </summary>
public partial class AppMoverView : UserControl
{
    public AppMoverView()
    {
        InitializeComponent();
    }
}
