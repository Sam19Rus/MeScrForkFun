using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class ScanView : UserControl
{
    public ScanView() => InitializeComponent();
}
