using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class PendingSectionView : UserControl
{
    public PendingSectionView() => InitializeComponent();
}
