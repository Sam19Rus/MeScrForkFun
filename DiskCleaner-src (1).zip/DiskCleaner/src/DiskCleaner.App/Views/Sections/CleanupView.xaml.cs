using System.Windows.Controls;

namespace DiskCleaner.App.Views.Sections;

public partial class CleanupView : UserControl
{
    public CleanupView() => InitializeComponent();
}
