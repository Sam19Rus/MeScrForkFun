using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using DiskCleaner.App.Composition;
using DiskCleaner.App.Views;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.App;

/// <summary>
/// Application entry point: builds the container, loads settings, applies the theme
/// and shows the shell. No business logic lives here.
/// </summary>
public partial class App : System.Windows.Application
{
    /// <summary>
    /// A repeating UI fault (e.g. one raised on every progress tick) must not bury the
    /// user in modal dialogs. The first occurrence is shown, the rest are logged only.
    /// </summary>
    private const int MaxDialogsPerSession = 3;

    private AppHost? _host;
    private int _uiDialogsShown;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;
        TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;

        try
        {
            _host = AppHost.Create(e.Args);
        }
        catch (Exception ex)
        {
            // No container yet, so no localizer: this one message is bilingual by design.
            var localizer = new StringLocalizer(StringTable.Default);
            MessageBox.Show(
                localizer.Format("S.Shell.StartupFailed", ex.Message)
                    + "\n\n" + new StringLocalizer(StringTable.English).Format("S.Shell.StartupFailed", ex.Message),
                localizer.Get("S.Shell.StartupFailedTitle"),
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            Shutdown(-1);
            return;
        }

        var settings = _host.GetRequiredService<ISettingsService>();

        // Blocking is safe here: every await inside the service uses ConfigureAwait(false),
        // and the file is a few kilobytes.
        settings.LoadAsync().GetAwaiter().GetResult();

        _host.FileLogger.MinimumLevel = settings.Current.EnableVerboseLogging
            ? LogLevel.Information
            : LogLevel.Warning;

        var appearance = _host.GetRequiredService<IAppearanceService>();
        appearance.Apply(settings.Current.Theme, settings.Current.Language);

        var privileges = _host.GetRequiredService<IPrivilegeService>();
        var logger = _host.GetRequiredService<ILogger<App>>();
        logger.LogInformation(
            "DiskCleaner starting. Elevated={Elevated}, relaunchedElevated={Relaunched}, args={Args}",
            privileges.IsElevated, _host.LaunchedElevated, string.Join(' ', e.Args));

        var window = _host.GetRequiredService<MainWindow>();
        MainWindow = window;
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try
        {
            _host?.GetRequiredService<ILogger<App>>().LogInformation("DiskCleaner shutting down.");
        }
        catch (Exception)
        {
            // Shutdown must not throw.
        }

        _host?.Dispose();
        base.OnExit(e);
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        Log(e.Exception);

        // Keep the utility alive: a failed binding or a transient IO error should not
        // cost the user an in-progress scan. The detail goes to the log, not to the screen.
        if (Interlocked.Increment(ref _uiDialogsShown) <= MaxDialogsPerSession)
        {
            MessageBox.Show(
                MainWindow,
                Resolve("S.Shell.UiError"),
                Resolve("S.Shell.UiErrorTitle"),
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        e.Handled = true;
    }

    private void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception exception)
        {
            Log(exception);
        }
    }

    private void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
    {
        Log(e.Exception);
        e.SetObserved();
    }

    /// <summary>Resolves a UI string during a failure path, where the container may be gone.</summary>
    private string Resolve(string key)
    {
        try
        {
            return _host?.GetRequiredService<IStringLocalizer>().Get(key) ?? new StringLocalizer().Get(key);
        }
        catch (Exception)
        {
            return new StringLocalizer().Get(key);
        }
    }

    private void Log(Exception exception)
    {
        try
        {
            _host?.GetRequiredService<ILogger<App>>().LogError(exception, "Unhandled exception");
        }
        catch (Exception)
        {
            // Last resort: never throw from the exception handler.
            Debug.WriteLine(exception);
        }
    }
}
