using System.Runtime.InteropServices;
using System.Windows.Threading;
using DiskCleaner.Presentation.Application;

namespace DiskCleaner.App.Platform;

/// <summary>WPF implementation of <see cref="IUiDispatcher"/>.</summary>
public sealed class WpfUiDispatcher(Dispatcher dispatcher) : IUiDispatcher
{
    public bool CheckAccess() => dispatcher.CheckAccess();

    public void Post(Action action)
    {
        if (dispatcher.CheckAccess())
        {
            action();
            return;
        }

        dispatcher.BeginInvoke(action, DispatcherPriority.Background);
    }

    public Task InvokeAsync(Func<Task> action) =>
        dispatcher.CheckAccess() ? action() : dispatcher.InvokeAsync(action).Task.Unwrap();
}
