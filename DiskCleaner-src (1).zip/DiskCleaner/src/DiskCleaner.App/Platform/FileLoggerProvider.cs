using System.IO;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.App.Platform;

/// <summary>
/// Minimal rolling file logger.
/// </summary>
/// <remarks>
/// Written by hand instead of pulling in Serilog/NLog: the app is offline and
/// single-file, and all it needs is one line per event in a daily file. Full stack
/// traces go here (never to the UI); the release UI shows only short reasons.
/// </remarks>
public sealed class FileLoggerProvider(Func<string> pathFactory) : ILoggerProvider
{
    private readonly object _gate = new();
    private readonly Func<string> _pathFactory = pathFactory;

    /// <summary>Adjusted after settings load: Warning normally, Information when verbose logging is on.</summary>
    public LogLevel MinimumLevel { get; set; } = LogLevel.Warning;

    public ILogger CreateLogger(string categoryName) => new FileLogger(this, categoryName);

    public void Dispose()
    {
    }

    private void Write(LogLevel level, string category, string message, Exception? exception)
    {
        if (level < MinimumLevel)
        {
            return;
        }

        var line =
            $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{LevelToken(level)}] {ShortCategory(category)}: {message}" +
            (exception is null ? string.Empty : Environment.NewLine + exception);

        lock (_gate)
        {
            try
            {
                var path = _pathFactory();
                var directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                File.AppendAllText(path, line + Environment.NewLine);
            }
            catch (IOException)
            {
                // Logging must never break the application.
            }
            catch (UnauthorizedAccessException)
            {
            }
        }
    }

    private static string LevelToken(LogLevel level) => level switch
    {
        LogLevel.Trace => "TRC",
        LogLevel.Debug => "DBG",
        LogLevel.Information => "INF",
        LogLevel.Warning => "WRN",
        LogLevel.Error => "ERR",
        LogLevel.Critical => "CRT",
        _ => "???",
    };

    private static string ShortCategory(string category)
    {
        var index = category.LastIndexOf('.');
        return index >= 0 && index < category.Length - 1 ? category[(index + 1)..] : category;
    }

    private sealed class FileLogger(FileLoggerProvider provider, string category) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state)
            where TState : notnull
            => NullScope.Instance;

        public bool IsEnabled(LogLevel logLevel) => logLevel >= provider.MinimumLevel;

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }

            provider.Write(logLevel, category, formatter(state, exception), exception);
        }

        private sealed class NullScope : IDisposable
        {
            public static readonly NullScope Instance = new();

            public void Dispose()
            {
            }
        }
    }
}
