using System.Runtime.InteropServices;
using System.Windows;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;

namespace DiskCleaner.App.Platform;

/// <summary>
/// Publishes the active theme and the active string table into the application
/// resources, so every <c>DynamicResource</c> in XAML repaints without a restart.
/// </summary>
/// <remarks>
/// Slot layout of <c>App.xaml</c> → <c>MergedDictionaries</c>:
/// <list type="number">
///   <item><description>theme brushes (Light.xaml / Dark.xaml);</description></item>
///   <item><description>strings, rebuilt from <see cref="StringTable"/> — the C# table is the
///   single source of truth, XAML only consumes it;</description></item>
///   <item><description>control styles.</description></item>
/// </list>
/// Dictionaries are replaced wholesale rather than edited in place, which is what
/// makes WPF re-resolve every dynamic reference.
/// </remarks>
public sealed class WpfAppearanceService(IStringLocalizer localizer) : IAppearanceService
{
    private const string LightThemeUri = "pack://application:,,,/DiskCleaner;component/Resources/Themes/Light.xaml";
    private const string DarkThemeUri = "pack://application:,,,/DiskCleaner;component/Resources/Themes/Dark.xaml";

    private const int ThemeSlot = 0;
    private const int StringsSlot = 1;

    public AppTheme Current { get; private set; } = AppTheme.System;

    public string CurrentLanguage { get; private set; } = StringTable.Default;

    public void Apply(AppTheme theme, string language)
    {
        Current = theme;
        CurrentLanguage = StringTable.Normalise(language);

        // Order matters: strings first, because the theme swap can trigger a re-layout
        // that resolves resource keys.
        localizer.SetLanguage(CurrentLanguage);
        PublishStrings();
        PublishTheme(theme);
    }

    private void PublishStrings()
    {
        var dictionaries = System.Windows.Application.Current?.Resources.MergedDictionaries;
        if (dictionaries is null || dictionaries.Count <= StringsSlot)
        {
            return;
        }

        var table = new ResourceDictionary();
        foreach (var (key, value) in localizer.CurrentTable)
        {
            table[key] = value;
        }

        dictionaries[StringsSlot] = table;
    }

    private void PublishTheme(AppTheme theme)
    {
        var dictionaries = System.Windows.Application.Current?.Resources.MergedDictionaries;
        if (dictionaries is null || dictionaries.Count == 0)
        {
            return;
        }

        var useDark = theme switch
        {
            AppTheme.Dark => true,
            AppTheme.Light => false,
            _ => !WindowsThemeDetector.AppsUseLightTheme,
        };

        var replacement = new ResourceDictionary
        {
            Source = new Uri(useDark ? DarkThemeUri : LightThemeUri, UriKind.Absolute),
        };

        if (ThemeSlot < dictionaries.Count)
        {
            dictionaries[ThemeSlot] = replacement;
        }
        else
        {
            dictionaries.Insert(ThemeSlot, replacement);
        }
    }

    /// <summary>Reads <c>AppsUseLightTheme</c> from the current user's personalisation key.</summary>
    private static class WindowsThemeDetector
    {
        private static readonly Lazy<bool> Detected = new(Detect);

        public static bool AppsUseLightTheme => Detected.Value;

        private static bool Detect()
        {
            if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return true;
            }

            try
            {
                var data = Marshal.AllocHGlobal(sizeof(int));
                try
                {
                    var size = (uint)sizeof(int);
                    var status = RegGetValue(
                        HkeyCurrentUser,
                        @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
                        "AppsUseLightTheme",
                        RrfRtRegDword,
                        out _,
                        data,
                        ref size);

                    return status != 0 || Marshal.ReadInt32(data) != 0;
                }
                finally
                {
                    Marshal.FreeHGlobal(data);
                }
            }
            catch (Exception)
            {
                // Any failure falls back to light, which is always readable.
                return true;
            }
        }

        private static readonly nint HkeyCurrentUser = unchecked((nint)0x80000001);
        private const uint RrfRtRegDword = 0x00000010;

        // Classic DllImport: one call, no marshalling source generator, no unsafe block.
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, EntryPoint = "RegGetValueW", SetLastError = true)]
        private static extern int RegGetValue(
            nint hkey,
            string? subKey,
            string value,
            uint flags,
            out uint type,
            nint data,
            ref uint dataLength);
    }
}
