using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Presentation.Application;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.App.Platform;

/// <summary>
/// "Open in Explorer" and friends. Uses the shell, never a custom file manager,
/// so the user always lands in a familiar place.
/// </summary>
public sealed class WindowsShellService(ILogger<WindowsShellService> logger) : IShellService
{
    public bool OpenFolder(string path)
    {
        var target = PathUtils.FromExtendedLengthPath(path);
        if (string.IsNullOrWhiteSpace(target))
        {
            return false;
        }

        if (!Directory.Exists(target) && !File.Exists(target))
        {
            logger.LogWarning("Refusing to open a path that does not exist: {Path}", target);
            return false;
        }

        return Launch("explorer.exe", $"\"{target}\"");
    }

    public bool OpenFileLocation(string path)
    {
        var target = PathUtils.FromExtendedLengthPath(path);
        if (string.IsNullOrWhiteSpace(target))
        {
            return false;
        }

        var exists = File.Exists(target);
        var directory = exists ? Path.GetDirectoryName(target) : target;

        if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory))
        {
            return false;
        }

        // /select highlights the file itself, which is what the user asked for.
        return exists
            ? Launch("explorer.exe", $"/select,\"{target}\"")
            : Launch("explorer.exe", $"\"{directory}\"");
    }

    public bool OpenFile(string path)
    {
        var target = PathUtils.FromExtendedLengthPath(path);
        if (!File.Exists(target))
        {
            return false;
        }

        try
        {
            Process.Start(new ProcessStartInfo(target) { UseShellExecute = true });
            return true;
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            logger.LogWarning(ex, "Could not open {Path}", target);
            return false;
        }
    }

    public bool OpenRecycleBin() => Launch("explorer.exe", "shell:RecycleBinFolder");

    private bool Launch(string fileName, string arguments)
    {
        try
        {
            Process.Start(new ProcessStartInfo(fileName, arguments) { UseShellExecute = true });
            return true;
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            logger.LogWarning(ex, "Could not launch {FileName} {Arguments}", fileName, arguments);
            return false;
        }
    }
}
