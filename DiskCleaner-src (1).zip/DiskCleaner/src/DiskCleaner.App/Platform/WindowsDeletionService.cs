using System.IO;
using System.Runtime.InteropServices;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.App.Platform;

/// <summary>
/// Windows deletion backend.
/// </summary>
/// <remarks>
/// Recycle Bin removal goes through <c>SHFileOperationW</c> with <c>FOF_ALLOWUNDO</c>,
/// which is the documented way to recycle a path. Emptying the bin uses
/// <c>SHEmptyRecycleBinW</c>. Permanent removal uses the managed APIs so that long paths
/// (the <c>\\?\</c> prefix) work.
/// <para/>
/// Failures are translated into <see cref="DeletionOutcome"/> instead of exceptions:
/// a file locked by another process is reported as "in use" and left alone. Nothing here
/// ever terminates a process or forces a sharing violation.
/// </remarks>
internal sealed class WindowsDeletionService(ILogger<WindowsDeletionService>? logger = null) : IDeletionService
{
    private const int FO_DELETE = 0x0003;
    private const int FOF_SILENT = 0x0004;
    private const int FOF_NOCONFIRMATION = 0x0010;
    private const int FOF_ALLOWUNDO = 0x0040;
    private const int FOF_NOERRORUI = 0x0400;

    private const uint SHERB_NOCONFIRMATION = 0x1;
    private const uint SHERB_NOPROGRESSUI = 0x2;
    private const uint SHERB_NOSOUND = 0x4;

    /// <summary>
    /// SHFileOperation takes ANSI/MAX_PATH-style buffers; paths at or beyond this length
    /// are reported honestly rather than attempted with an unpredictable result.
    /// </summary>
    private const int MaxShellPathLength = 250;

    private readonly ILogger _logger = logger ?? NullLogger<WindowsDeletionService>.Instance;

    [StructLayout(LayoutKind.Sequential)]
    private struct SHFILEOPSTRUCTW
    {
        public IntPtr hwnd;
        public uint wFunc;

        /// <summary>Double-null terminated list of paths. Marshalled by hand.</summary>
        public IntPtr pFrom;

        public IntPtr pTo;
        public ushort fFlags;
        public int fAnyOperationsAborted;
        public IntPtr hNameMappings;
        public IntPtr lpszProgressTitle;
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHFileOperationW(ref SHFILEOPSTRUCTW lpFileOp);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHEmptyRecycleBinW(IntPtr hwnd, string? pszRootPath, uint dwFlags);

    public bool SupportsRecycleBin(string path)
    {
        // Network shares and some removable media have no bin. A conservative answer:
        // recycle local fixed volumes, delete permanently elsewhere.
        try
        {
            var root = Path.GetPathRoot(path);
            if (string.IsNullOrEmpty(root))
            {
                return false;
            }

            var drive = new DriveInfo(root);
            return drive.IsReady && drive.DriveType == DriveType.Fixed;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public DeletionOutcome Delete(string path, DeletionMethod method, bool isDirectory)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return DeletionOutcome.Fail(ScanIssueKind.Unknown, "cleanup.invalid-path");
        }

        return method == DeletionMethod.RecycleBin
            ? Recycle(path)
            : DeletePermanently(path, isDirectory);
    }

    public DeletionOutcome EmptyRecycleBin(string? volumeRoot)
    {
        var root = string.IsNullOrWhiteSpace(volumeRoot) ? null : volumeRoot;

        try
        {
            var code = SHEmptyRecycleBinW(IntPtr.Zero, root, SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);

            // E_UNEXPECTED / "already empty" is not a failure worth reporting as one.
            if (code == 0 || code == unchecked((int)0x8000FFFF))
            {
                _logger.LogInformation("Recycle Bin emptied for {Root} (code {Code})", root ?? "<all volumes>", code);
                return DeletionOutcome.Emptied(0, 0);
            }

            var issue = ScanIssueFactory.Create(root ?? string.Empty, ScanIssueKind.IoError, "cleanup.recyclebin-failed", string.Empty, 0);
            return DeletionOutcome.Fail(issue.Kind, issue.ReasonKey, code);
        }
        catch (Exception ex)
        {
            var issue = ScanIssueFactory.FromException(root ?? string.Empty, ex);
            _logger.LogWarning(ex, "Emptying the Recycle Bin failed");
            return DeletionOutcome.Fail(issue.Kind, issue.ReasonKey, issue.ErrorCode ?? 0);
        }
    }

    /// <summary>Moves a path to the Recycle Bin. Returns an honest outcome on any failure.</summary>
    private DeletionOutcome Recycle(string path)
    {
        var shellPath = Path.TrimEndingDirectorySeparator(path);

        if (shellPath.Length >= MaxShellPathLength)
        {
            return DeletionOutcome.Fail(ScanIssueKind.PathTooLong, "cleanup.recycle.path-too-long");
        }

        IntPtr buffer = IntPtr.Zero;
        try
        {
            // SHFileOperation wants "path\0\0". Marshal.StringToHGlobalUni stops at the
            // first NUL, so the buffer is filled by hand to guarantee the terminator pair.
            buffer = Marshal.AllocHGlobal((shellPath.Length + 2) * sizeof(char));
            for (var i = 0; i < shellPath.Length; i++)
            {
                Marshal.WriteInt16(buffer, i * sizeof(char), shellPath[i]);
            }

            Marshal.WriteInt16(buffer, shellPath.Length * sizeof(char), 0);
            Marshal.WriteInt16(buffer, (shellPath.Length + 1) * sizeof(char), 0);

            var operation = new SHFILEOPSTRUCTW
            {
                hwnd = IntPtr.Zero,
                wFunc = FO_DELETE,
                pFrom = buffer,
                pTo = IntPtr.Zero,
                fFlags = (ushort)(FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT),
                fAnyOperationsAborted = 0,
                hNameMappings = IntPtr.Zero,
                lpszProgressTitle = IntPtr.Zero,
            };

            var code = SHFileOperationW(ref operation);

            if (code == 0 && operation.fAnyOperationsAborted == 0)
            {
                return DeletionOutcome.Recycled(0, 1);
            }

            // DE_SAMEFILE (0x71) and friends are not permission problems; report the code.
            _logger.LogWarning("SHFileOperation failed for {Path}: code={Code}, aborted={Aborted}",
                shellPath, code, operation.fAnyOperationsAborted);

            return DeletionOutcome.Fail(
                ClassifyShellCode(code),
                ShellReasonKey(code),
                code);
        }
        catch (Exception ex)
        {
            var issue = ScanIssueFactory.FromException(shellPath, ex);
            return DeletionOutcome.Fail(issue.Kind, issue.ReasonKey, issue.ErrorCode ?? 0);
        }
        finally
        {
            if (buffer != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(buffer);
            }
        }
    }

    private DeletionOutcome DeletePermanently(string path, bool isDirectory)
    {
        try
        {
            if (isDirectory)
            {
                // A directory that is itself a junction/symlink is removed as a link,
                // non-recursively: the data at its target belongs to someone else and
                // must survive. For ordinary directories, .NET does not follow reparse
                // points while recursing, so a junction *inside* the tree is also
                // removed as a link, never as the target's contents.
                var recursive = !IsReparsePoint(path);
                Directory.Delete(path, recursive);
            }
            else
            {
                File.Delete(path);
            }

            return DeletionOutcome.Deleted(0, 1);
        }
        catch (Exception ex)
        {
            var issue = ScanIssueFactory.FromException(path, ex);
            _logger.LogDebug(ex, "Permanent deletion failed for {Path}: {Reason}", path, issue.ReasonKey);
            return DeletionOutcome.Fail(issue.Kind, issue.ReasonKey, issue.ErrorCode ?? 0);
        }
    }

    /// <summary>Attribute probe that never throws: an unreadable path is treated as a normal directory.</summary>
    private static bool IsReparsePoint(string path)
    {
        try
        {
            var attributes = File.GetAttributes(PathUtils.ToExtendedLengthPathIfWindows(path));
            return (attributes & FileAttributes.ReparsePoint) != 0;
        }
        catch (Exception)
        {
            return false;
        }
    }

    private static ScanIssueKind ClassifyShellCode(int code) => code switch
    {
        0x71 => ScanIssueKind.Unknown,            // DE_SAMEFILE
        0x73 => ScanIssueKind.PathTooLong,        // DE_INVALIDFILES
        0x02 or 0x03 => ScanIssueKind.NotFound,   // ERROR_FILE/PATH_NOT_FOUND
        0x05 => ScanIssueKind.AccessDenied,       // ERROR_ACCESS_DENIED
        0x20 => ScanIssueKind.FileInUse,          // ERROR_SHARING_VIOLATION
        _ => ScanIssueKind.Unknown,
    };

    private static string ShellReasonKey(int code) => code switch
    {
        0x02 or 0x03 => "cleanup.already-gone",
        0x05 => "cleanup.access-denied",
        0x20 => "cleanup.file-in-use",
        0x71 => "cleanup.recycle.same-file",
        0x73 => "cleanup.recycle.invalid-path",
        _ => "cleanup.recycle.failed",
    };
}
