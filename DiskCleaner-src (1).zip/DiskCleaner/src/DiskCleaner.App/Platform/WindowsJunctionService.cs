using System.IO;
using System.Runtime.InteropServices;
using DiskCleaner.Core.Moving;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DiskCleaner.App.Platform;

/// <summary>
/// Directory junctions (NTFS mount points) through <c>DeviceIoControl</c>.
/// </summary>
/// <remarks>
/// Junctions are used instead of symbolic links for one reason: creating a symlink
/// needs <c>SeCreateSymbolicLinkPrivilege</c> (administrator or Developer Mode), while
/// a mount-point junction needs only write access to the parent directory — exactly
/// what a standard user has over <c>%LOCALAPPDATA%\Programs</c>. The reparse buffer
/// follows the documented <c>MOUNT_POINT_REPARSE_BUFFER</c> layout: the substitute
/// name is the NT form <c>\??\D:\Apps\Ollama</c>, the print name the Win32 form.
/// </remarks>
internal sealed class WindowsJunctionService(ILogger<WindowsJunctionService>? logger = null) : IJunctionService
{
    private const uint FSCTL_SET_REPARSE_POINT = 0x000900A4;
    private const uint IO_REPARSE_TAG_MOUNT_POINT = 0xA0000003;

    private const uint GENERIC_WRITE = 0x40000000;
    private const uint FILE_SHARE_READ = 0x1;
    private const uint FILE_SHARE_WRITE = 0x2;
    private const uint FILE_SHARE_DELETE = 0x4;
    private const uint OPEN_EXISTING = 3;
    private const uint FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;
    private const uint FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000;

    private static readonly IntPtr InvalidHandleValue = new(-1);

    private readonly ILogger _logger = logger ?? NullLogger<WindowsJunctionService>.Instance;

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateFileW(
        string lpFileName,
        uint dwDesiredAccess,
        uint dwShareMode,
        IntPtr lpSecurityAttributes,
        uint dwCreationDisposition,
        uint dwFlagsAndAttributes,
        IntPtr hTemplateFile);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeviceIoControl(
        IntPtr hDevice,
        uint dwIoControlCode,
        IntPtr lpInBuffer,
        uint nInBufferSize,
        IntPtr lpOutBuffer,
        uint nOutBufferSize,
        out uint lpBytesReturned,
        IntPtr lpOverlapped);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr hObject);

    public bool IsLink(string path)
    {
        try
        {
            var attributes = File.GetAttributes(path);
            return (attributes & FileAttributes.ReparsePoint) != 0;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public string? TryGetLinkTarget(string path)
    {
        try
        {
            var target = File.ResolveLinkTarget(path, returnFinalTarget: false)?.FullName;
            return string.IsNullOrEmpty(target) ? null : target;
        }
        catch (Exception)
        {
            return null;
        }
    }

    public bool TryCreateJunction(string linkPath, string targetPath, out string? error)
    {
        error = null;

        try
        {
            if (!Directory.Exists(targetPath))
            {
                error = $"The target does not exist: {targetPath}";
                return false;
            }

            if (Directory.Exists(linkPath) || File.Exists(linkPath))
            {
                if (!IsLink(linkPath))
                {
                    error = $"The location is already occupied: {linkPath}";
                    return false;
                }

                // Replacing an existing junction: remove the link only, never the target.
                Directory.Delete(linkPath, recursive: false);
            }

            Directory.CreateDirectory(linkPath);

            // The NT object-manager form of the target. A trailing separator marks it a directory.
            var fullTarget = Path.GetFullPath(targetPath);
            var substitute = @"\\??\" + EnsureTrailingSlash(fullTarget);
            var print = EnsureTrailingSlash(fullTarget);

            var handle = CreateFileW(
                linkPath,
                GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                IntPtr.Zero,
                OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT,
                IntPtr.Zero);

            if (handle == InvalidHandleValue)
            {
                error = $"CreateFile failed with Win32 error {Marshal.GetLastWin32Error()}";
                return false;
            }

            var buffer = IntPtr.Zero;
            try
            {
                var substituteBytes = (substitute.Length + 1) * sizeof(char);
                var printBytes = (print.Length + 1) * sizeof(char);

                // ReparseTag(4) + ReparseDataLength(2) + Reserved(2) + 4 USHORTs(8) + path buffer.
                const int headerSize = 8;
                const int mountPointSize = 8;
                var totalSize = headerSize + mountPointSize + substituteBytes + printBytes;

                buffer = Marshal.AllocHGlobal(totalSize);
                for (var i = 0; i < totalSize; i++)
                {
                    Marshal.WriteByte(buffer, i, 0);
                }

                Marshal.WriteInt32(buffer, 0, unchecked((int)IO_REPARSE_TAG_MOUNT_POINT));
                Marshal.WriteInt16(buffer, 4, (short)(totalSize - headerSize));
                Marshal.WriteInt16(buffer, 6, 0);

                // SubstituteNameOffset, SubstituteNameLength, PrintNameOffset, PrintNameLength —
                // offsets are relative to the end of these four fields (the path buffer).
                Marshal.WriteInt16(buffer, 8, 0);
                Marshal.WriteInt16(buffer, 10, (short)(substitute.Length * sizeof(char)));
                Marshal.WriteInt16(buffer, 12, (short)substituteBytes);
                Marshal.WriteInt16(buffer, 14, (short)(print.Length * sizeof(char)));

                var pathBuffer = buffer + headerSize + mountPointSize;
                Marshal.Copy(substitute.ToCharArray(), 0, pathBuffer, substitute.Length);
                Marshal.WriteInt16(pathBuffer, substitute.Length * sizeof(char), 0);
                Marshal.Copy(print.ToCharArray(), 0, pathBuffer + substituteBytes, print.Length);
                Marshal.WriteInt16(pathBuffer + substituteBytes, print.Length * sizeof(char), 0);

                if (!DeviceIoControl(handle, FSCTL_SET_REPARSE_POINT, buffer, (uint)totalSize, IntPtr.Zero, 0, out _, IntPtr.Zero))
                {
                    var win32 = Marshal.GetLastWin32Error();
                    error = $"FSCTL_SET_REPARSE_POINT failed with Win32 error {win32}";
                    _logger.LogWarning("Junction creation failed for {Link} → {Target}: Win32 {Code}", linkPath, targetPath, win32);

                    // Leave no half-made folder behind.
                    TryRemoveEmpty(linkPath);
                    return false;
                }

                return true;
            }
            finally
            {
                if (buffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(buffer);
                }

                CloseHandle(handle);
            }
        }
        catch (Exception ex)
        {
            error = ex.Message;
            _logger.LogWarning(ex, "Junction creation threw for {Link} → {Target}", linkPath, targetPath);
            return false;
        }
    }

    public bool TryDeleteJunction(string linkPath, out string? error)
    {
        try
        {
            if (!IsLink(linkPath))
            {
                error = $"Not a junction: {linkPath}";
                return false;
            }

            // Non-recursive: removes the link and only the link.
            Directory.Delete(linkPath, recursive: false);
            error = null;
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    private void TryRemoveEmpty(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: false);
            }
        }
        catch (Exception)
        {
            // Best effort: an empty leftover folder is reported by the next validation.
        }
    }

    private static string EnsureTrailingSlash(string path) =>
        path.EndsWith('\\') ? path : path + "\\";
}
