using System.Diagnostics;
using System.Security.Principal;
using DiskCleaner.Core.Application;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.App.Platform;

/// <summary>
/// Elevation awareness. The process starts as a standard user (see app.manifest);
/// this service only reports the current state and offers to relaunch elevated.
/// </summary>
public sealed class WindowsPrivilegeService(ILogger<WindowsPrivilegeService> logger) : IPrivilegeService
{
    public bool IsElevated { get; } = ComputeIsElevated();

    public string UserName => Environment.UserDomainName + "\\" + Environment.UserName;

    public Task<bool> RequestElevationAsync(string? reason = null, CancellationToken cancellationToken = default)
    {
        var executable = Environment.ProcessPath;
        if (string.IsNullOrWhiteSpace(executable))
        {
            logger.LogWarning("Cannot elevate: the executable path is unknown.");
            return Task.FromResult(false);
        }

        if (IsElevated)
        {
            return Task.FromResult(true);
        }

        var arguments = reason is null
            ? "--elevated"
            : $"--elevated --reason \"{reason.Replace("\"", "'")}\"";

        try
        {
            var process = Process.Start(new ProcessStartInfo(executable, arguments)
            {
                UseShellExecute = true,
                Verb = "runas",       // triggers the UAC prompt
                WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            });

            return Task.FromResult(process is not null);
        }
        catch (System.ComponentModel.Win32Exception ex)
        {
            // 1223 = ERROR_CANCELLED: the user said no to UAC. That is a normal outcome.
            logger.LogInformation("Elevation was not granted ({Message}).", ex.Message);
            return Task.FromResult(false);
        }
        catch (InvalidOperationException ex)
        {
            logger.LogWarning(ex, "Could not start an elevated process.");
            return Task.FromResult(false);
        }
    }

    private static bool ComputeIsElevated()
    {
        try
        {
            using var identity = WindowsIdentity.GetCurrent();
            return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
        }
        catch (Exception ex) when (ex is PlatformNotSupportedException or System.Security.SecurityException)
        {
            return false;
        }
    }
}
