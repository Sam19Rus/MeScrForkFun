using System.Windows;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;
using Microsoft.Win32;

namespace DiskCleaner.App.Platform;

/// <summary>WPF dialogs. Kept deliberately small: confirmations, folder picking and messages.</summary>
public sealed class WpfDialogService(IStringLocalizer localizer) : IDialogService
{
    public Task<bool> ConfirmAsync(string title, string message, string confirmLabel = "Continue", string cancelLabel = "Cancel")
    {
        // WPF has no native "custom button text" dialog; the labels are shown in the
        // message so the user still sees what each button means — in the UI language.
        var text = message + "\n\n" + localizer.Format("S.Dialog.Confirm.Hint", confirmLabel, cancelLabel);
        var result = MessageBox.Show(
            Application.Current?.MainWindow,
            text,
            title,
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning,
            MessageBoxResult.No);

        return Task.FromResult(result == MessageBoxResult.Yes);
    }

    public Task<string?> PickFolderAsync(string? initialDirectory = null)
    {
        // OpenFolderDialog is part of WPF since .NET 8 — no WinForms, no shell hacks.
        var dialog = new OpenFolderDialog
        {
            Title = localizer.Get("S.Dialog.PickFolder"),
        };

        if (!string.IsNullOrWhiteSpace(initialDirectory) && System.IO.Directory.Exists(initialDirectory))
        {
            dialog.InitialDirectory = initialDirectory;
        }

        var owner = Application.Current?.MainWindow;
        var ok = owner is null ? dialog.ShowDialog() : dialog.ShowDialog(owner);

        return Task.FromResult<string?>(ok == true ? dialog.FolderName : null);
    }

    public void ShowInfo(string title, string message) =>
        MessageBox.Show(Application.Current?.MainWindow, message, title, MessageBoxButton.OK, MessageBoxImage.Information);

    public void ShowWarning(string title, string message) =>
        MessageBox.Show(Application.Current?.MainWindow, message, title, MessageBoxButton.OK, MessageBoxImage.Warning);
}
