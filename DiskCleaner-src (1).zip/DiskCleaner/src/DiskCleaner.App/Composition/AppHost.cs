using DiskCleaner.App.Platform;
using DiskCleaner.App.Views;
using DiskCleaner.Core;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation;
using DiskCleaner.Presentation.Application;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace DiskCleaner.App.Composition;

/// <summary>
/// The composition root. Everything the WPF shell needs is registered here; views
/// and view models never call <c>new</c> on a service.
/// </summary>
public sealed class AppHost : IDisposable
{
    private readonly ServiceProvider _provider;
    private bool _disposed;

    private AppHost(ServiceProvider provider, ApplicationPaths paths, FileLoggerProvider fileLogger, IReadOnlyList<string> arguments)
    {
        _provider = provider;
        Paths = paths;
        FileLogger = fileLogger;
        Arguments = arguments;
    }

    public ApplicationPaths Paths { get; }

    public FileLoggerProvider FileLogger { get; }

    public IReadOnlyList<string> Arguments { get; }

    /// <summary><c>true</c> when this instance was started by an elevation request.</summary>
    public bool LaunchedElevated => Arguments.Contains("--elevated", StringComparer.OrdinalIgnoreCase);

    public static AppHost Create(string[] args)
    {
        var paths = new ApplicationPaths();
        paths.EnsureCreated();

        var fileLogger = new FileLoggerProvider(() => paths.LogFileFor(DateTime.UtcNow));

        var services = new ServiceCollection();

        // Layers, in dependency order. Core never sees WPF; Presentation never sees the disk.
        services.AddSingleton(paths);
        services.AddDiskCleanerCore();
        services.AddDiskCleanerPresentation();

        services.AddLogging(builder =>
        {
            builder.SetMinimumLevel(LogLevel.Debug);
            builder.AddProvider(fileLogger);
#if DEBUG
            builder.AddDebug();
#endif
        });

        // Platform implementations of the presentation contracts.
        services.AddSingleton<IUiDispatcher>(_ =>
            new WpfUiDispatcher(System.Windows.Application.Current.Dispatcher));
        services.AddSingleton<IShellService, WindowsShellService>();
        services.AddSingleton<IDialogService, WpfDialogService>();
        services.AddSingleton<IAppearanceService, WpfAppearanceService>();
        services.AddSingleton<IPrivilegeService, WindowsPrivilegeService>();

        // The only component allowed to remove data. Core talks to the interface, so the
        // whole executor stays testable without a filesystem.
        services.AddSingleton<DiskCleaner.Core.Cleanup.IDeletionService, WindowsDeletionService>();

        // Junctions for the application mover (mount points, no elevation needed).
        services.AddSingleton<DiskCleaner.Core.Moving.IJunctionService, WindowsJunctionService>();

        // Shell.
        services.AddSingleton<MainWindow>();

        var provider = services.BuildServiceProvider(new ServiceProviderOptions
        {
            // Fail at startup rather than when the user clicks something three minutes in.
            ValidateOnBuild = true,
            ValidateScopes = false,
        });

        return new AppHost(provider, paths, fileLogger, args ?? []);
    }

    public T GetRequiredService<T>()
        where T : notnull => _provider.GetRequiredService<T>();

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _provider.Dispose();
    }
}
