using System.Globalization;
using System.Windows.Data;

namespace DiskCleaner.App.Converters;

/// <summary>
/// Two-way string ↔ radio-button binding (used for the UI language).
/// <c>ConverterParameter</c> is the string this option represents.
/// </summary>
public sealed class StringToBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        string.Equals(value as string, parameter as string, StringComparison.OrdinalIgnoreCase);

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is true && parameter is string text ? text : Binding.DoNothing;
}
