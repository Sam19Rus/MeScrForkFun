#Requires -Version 5.1
<#
.SYNOPSIS
  Runs every unit test project. These run on any OS: Core and Presentation target
  plain net10.0, only the WPF shell is Windows-bound (and it has no logic in it).
.EXAMPLE
  ./scripts/test.ps1
#>
[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string] $Configuration = 'Debug',
    [string] $Filter
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

Push-Location $root
try {
    $args = @('test', '-c', $Configuration, '--nologo')
    if ($Filter) { $args += @('--filter', $Filter) }

    Write-Host "==> dotnet $($args -join ' ')" -ForegroundColor Cyan
    & dotnet @args
    if ($LASTEXITCODE -ne 0) { throw "Tests failed with exit code $LASTEXITCODE" }
    Write-Host "==> tests OK" -ForegroundColor Green
}
finally {
    Pop-Location
}
