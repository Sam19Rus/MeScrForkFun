#Requires -Version 5.1
<#
.SYNOPSIS
  Builds the whole solution in Release and fails on any warning.
.EXAMPLE
  ./scripts/build.ps1
  ./scripts/build.ps1 -Configuration Debug
#>
[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string] $Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

Push-Location $root
try {
    Write-Host "==> restore + build ($Configuration)" -ForegroundColor Cyan
    dotnet build -c $Configuration --nologo -warnaserror
    if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE" }
    Write-Host "==> build OK" -ForegroundColor Green
}
finally {
    Pop-Location
}
