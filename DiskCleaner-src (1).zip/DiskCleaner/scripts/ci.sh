#!/usr/bin/env bash
# Build + test + single-file publish + artefact verification on Linux/macOS.
#
# The WPF shell cannot be *executed* off Windows, but it can be compiled and
# published: `EnableWindowsTargeting` restores the Windows reference packs from
# NuGet. Everything with real logic (Core, Presentation) is unit-tested here.
#
# Usage: ./scripts/ci.sh [--no-compression]
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$(pwd)"
CONFIG="Release"
COMPRESS="true"
OUT="$ROOT/publish/win-x64-single-file"

for arg in "$@"; do
  case "$arg" in
    --no-compression) COMPRESS="false" ;;
    --debug) CONFIG="Debug" ;;
    *) echo "unknown argument: $arg" >&2; exit 2 ;;
  esac
done

echo "==> build ($CONFIG)"
dotnet build -c "$CONFIG" --nologo -warnaserror

echo "==> tests"
dotnet test -c Debug --nologo

echo "==> single-file publish (win-x64, self-contained, compression=$COMPRESS)"
rm -rf "$OUT"
dotnet publish "$ROOT/src/DiskCleaner.App/DiskCleaner.App.csproj" \
  -c "$CONFIG" -r win-x64 --self-contained true \
  -p:PublishSingleFile=true \
  -p:IncludeNativeLibrariesForSelfExtract=true \
  -p:EnableCompressionInSingleFile="$COMPRESS" \
  -p:PublishTrimmed=false \
  -p:PublishReadyToRun=false \
  -p:SatelliteResourceLanguages=en \
  -p:DebugType=none -p:DebugSymbols=false \
  -o "$OUT" --nologo

echo "==> verifying the artefact"
mapfile -t FILES < <(find "$OUT" -type f -printf '%f\n' | sort)
COUNT=${#FILES[@]}
for f in "${FILES[@]}"; do
  size=$(du -m "$OUT/$f" | cut -f1)
  printf '   %-28s %6s MB\n' "$f" "$size"
done

fail=0
if [ "$COUNT" -ne 1 ]; then
  echo "   FAIL: expected exactly 1 file, found $COUNT"; fail=1
fi
if [ ! -f "$OUT/DiskCleaner.exe" ]; then
  echo "   FAIL: DiskCleaner.exe is missing"; fail=1
fi
for f in "${FILES[@]}"; do
  case "$f" in
    DiskCleaner.exe) ;;
    *) echo "   FAIL: stray file next to the executable: $f"; fail=1 ;;
  esac
done

if [ -f "$OUT/DiskCleaner.exe" ]; then
  python3 - "$OUT/DiskCleaner.exe" <<'PY'
import struct, sys
data = open(sys.argv[1], "rb").read()
assert data[:2] == b"MZ", "not a PE image"
off = struct.unpack_from("<I", data, 0x3C)[0]
assert data[off:off + 4] == b"PE\0\0", "missing PE signature"
machine = struct.unpack_from("<H", data, off + 4)[0]
subsystem = struct.unpack_from("<H", data, off + 0x5C)[0]
print(f"   machine=0x{machine:04X} ({'x64' if machine == 0x8664 else 'UNEXPECTED'}), "
      f"subsystem={subsystem} ({'Windows GUI' if subsystem == 2 else 'UNEXPECTED'}), "
      f"size={len(data) / 1e6:.1f} MB")
if machine != 0x8664 or subsystem != 2:
    sys.exit(1)
PY
  [ $? -eq 0 ] || fail=1
fi

if [ "$fail" -ne 0 ]; then
  echo "==> single-file verification FAILED"; exit 1
fi
echo "==> OK: one self-contained x64 GUI executable"
