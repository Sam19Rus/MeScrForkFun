#Requires -Version 5.1
<#
.SYNOPSIS
  Publishes the release build: ONE self-contained DiskCleaner.exe for win-x64.
.DESCRIPTION
  The user must be able to copy DiskCleaner.exe anywhere and run it with no .NET
  installed and no DLLs next to it. This script publishes that artefact and then
  VERIFIES the output directory, failing the build if anything other than the
  executable was emitted.
.EXAMPLE
  ./scripts/publish.ps1
  ./scripts/publish.ps1 -NoCompression    # ~165 MB, fastest cold start
  ./scripts/publish.ps1 -Output D:\out
#>
[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string] $Configuration = 'Release',

    # Compression: ~68 MB with, ~165 MB without (but faster startup).
    [switch] $NoCompression,

    [string] $Output,

    [switch] $SkipVerify
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$compress = if ($NoCompression) { 'false' } else { 'true' }
$outDir = if ($Output) { $Output } else { Join-Path $root 'publish\win-x64-single-file' }

if (Test-Path $outDir) { Remove-Item -Recurse -Force $outDir }

$publishArgs = @(
    'publish', (Join-Path $root 'src\DiskCleaner.App\DiskCleaner.App.csproj'),
    '-c', $Configuration,
    '-r', 'win-x64',
    '--self-contained', 'true',
    '-p:PublishSingleFile=true',
    '-p:IncludeNativeLibrariesForSelfExtract=true',
    "-p:EnableCompressionInSingleFile=$compress",
    '-p:PublishTrimmed=false',          # WPF is not trimmable
    '-p:PublishReadyToRun=false',
    '-p:SatelliteResourceLanguages=en',
    '-p:DebugType=none',
    '-p:DebugSymbols=false',
    '-o', $outDir
)

Push-Location $root
try {
    Write-Host "==> dotnet $($publishArgs -join ' ')" -ForegroundColor Cyan
    & dotnet @publishArgs
    if ($LASTEXITCODE -ne 0) { throw "Publish failed with exit code $LASTEXITCODE" }

    if ($SkipVerify) { return }

    Write-Host "`n==> verifying the artefact" -ForegroundColor Cyan
    $files = Get-ChildItem -Path $outDir -File -Recurse
    $files | ForEach-Object { Write-Host ("   {0,-28} {1,10:N1} MB" -f $_.Name, ($_.Length / 1MB)) }

    $problems = @()
    if ($files.Count -ne 1) { $problems += "expected exactly 1 file, found $($files.Count)" }

    $exe = $files | Where-Object { $_.Name -eq 'DiskCleaner.exe' }
    if (-not $exe) { $problems += 'DiskCleaner.exe is missing' }

    # Any application DLL / json / pdb next to the exe breaks the "copy one file" promise.
    $stray = $files | Where-Object { $_.Extension -in '.dll', '.pdb', '.json', '.xml', '.config', '.exe' -and $_.Name -ne 'DiskCleaner.exe' }
    if ($stray) { $problems += "stray files next to the executable: $($stray.Name -join ', ')" }

    if ($exe) {
        $bytes = [System.IO.File]::ReadAllBytes($exe.FullName)
        if ($bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) { $problems += 'not a valid PE image (missing MZ header)' }
        $peOffset = [BitConverter]::ToInt32($bytes, 0x3C)
        $machine = [BitConverter]::ToUInt16($bytes, $peOffset + 4)
        if ($machine -ne 0x8664) { $problems += ("unexpected machine type 0x{0:X4} (expected 0x8664 = x64)" -f $machine) }
        $subsystem = [BitConverter]::ToUInt16($bytes, $peOffset + 0x5C)
        if ($subsystem -ne 2) { $problems += "subsystem is $subsystem (expected 2 = Windows GUI)" }
    }

    if ($problems.Count -gt 0) {
        $problems | ForEach-Object { Write-Host "   FAIL: $_" -ForegroundColor Red }
        throw 'Single-file verification failed.'
    }

    Write-Host ("   OK: single self-contained x64 GUI executable, {0:N1} MB" -f ($exe.Length / 1MB)) -ForegroundColor Green
    Write-Host "   Native dependencies are extracted to %TEMP%\.net\DiskCleaner\<hash> on first run." -ForegroundColor DarkGray
}
finally {
    Pop-Location
}
