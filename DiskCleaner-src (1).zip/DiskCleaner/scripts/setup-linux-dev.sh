#!/usr/bin/env bash
#
# Restores the Linux/macOS development toolchain for this repository.
#
# Needed because the workspace sandbox does not persist the toolchain: ~/.cache and
# ~/.dotnet are outside the snapshot, and system libraries are reset with the sandbox.
# Running this script brings the environment back to a state where ./scripts/ci.sh works.
#
# The SDK is deliberately installed OUTSIDE the repository (~/.cache): anything under
# the repo counts towards the workspace snapshot limit.
#
#   ./scripts/setup-linux-dev.sh            # install SDK 10.0.401 into ~/.cache/dotnet
#   ./scripts/setup-linux-dev.sh --check    # only report what is missing
#
# On Windows you do not need this: install the .NET 10 SDK normally and use
# ./scripts/build.ps1, ./scripts/test.ps1, ./scripts/publish.ps1.
#
set -euo pipefail

SDK_VERSION="10.0.401"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CACHE="${DOTNET_INSTALL_DIR:-$HOME/.cache}"
DOTNET_DIR="$CACHE/dotnet"
ENV_FILE="$CACHE/env.sh"

CHECK_ONLY=0
[ "${1:-}" = "--check" ] && CHECK_ONLY=1

report() { printf '%s\n' "$*"; }

have_dotnet() {
    [ -x "$DOTNET_DIR/dotnet" ] || command -v dotnet >/dev/null 2>&1
}

if have_dotnet; then
    report "==> dotnet already available: $("$DOTNET_DIR/dotnet" --version 2>/dev/null || dotnet --version)"
    exit 0
fi

report "==> dotnet missing"
if [ "$CHECK_ONLY" = 1 ]; then
    exit 1
fi

# --- ICU (globalisation). Without it the CLI aborts with "Couldn't find a valid ICU package".
if ! ldconfig -p 2>/dev/null | grep -q libicu; then
    report "==> installing libicu"
    if command -v apt-get >/dev/null 2>&1; then
        apt-get update -qq
        apt-get install -y --no-install-recommends libicu72 || apt-get install -y --no-install-recommends libicu-dev || true
    else
        report "    (no apt-get; install ICU manually or set DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1)"
    fi
fi

# --- .NET SDK
if [ ! -x "$DOTNET_DIR/dotnet" ]; then
    mkdir -p "$CACHE/dl" "$DOTNET_DIR"
    TARBALL="$CACHE/dl/dotnet-sdk-$SDK_VERSION-linux-x64.tar.gz"
    URL="https://builds.dotnet.microsoft.com/dotnet/Sdk/$SDK_VERSION/dotnet-sdk-$SDK_VERSION-linux-x64.tar.gz"

    report "==> downloading $URL"
    python3 - "$URL" "$TARBALL" <<'PY'
import sys, urllib.request
url, dst = sys.argv[1], sys.argv[2]
urllib.request.urlretrieve(url, dst)
PY
    report "==> extracting into $DOTNET_DIR"
    tar -xzf "$TARBALL" -C "$DOTNET_DIR"
    rm -f "$TARBALL"
fi

# --- environment for subsequent shells
cat > "$ENV_FILE" <<EOF
export DOTNET_ROOT=$DOTNET_DIR
export PATH="$DOTNET_DIR:\$PATH"
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_CLI_HOME=$CACHE/dotnethome
export NUGET_PACKAGES=$CACHE/nuget
EOF
mkdir -p "$CACHE/dotnethome" "$CACHE/nuget"

report "==> ready. In every new shell run:  . $ENV_FILE"
report "    then:  ./scripts/ci.sh"
