# Модель данных

Все типы — в `DiskCleaner.Core.Models`. Это чистые данные без зависимости от UI:
обёртки для биндинга (`ScanItemNode` и т. п.) появятся в `Presentation` вместе с
экранами результатов.

## 1. `ScanItem` — единица отчёта

| Поле | Тип | Смысл |
| --- | --- | --- |
| `Path` | `string` | Абсолютный путь (для `VirtualTarget` — псевдопуть). |
| `Name` | `string` | Отображаемое имя. |
| `Kind` | `ScanItemKind` | `File` / `Directory` / `VirtualTarget` (Корзина, контейнер UWP). |
| `Size` | `long` | Байты; для каталога — всё поддерево. |
| `FileCount` | `int` | Сколько файлов внутри. |
| `CreatedAtUtc` / `ModifiedAtUtc` | `DateTime?` | Метки времени (`null`, если прочитать не удалось). |
| `Extension` | `string?` | В нижнем регистре, с точкой; `null` для каталогов. |
| `Category` | `ScanCategory` | Что это по природе (см. §2). |
| `Confidence` | `CleanupConfidence` | Насколько мы уверены, что это мусор. |
| `RiskLevel` | `RiskLevel` | Цена ошибки при удалении. |
| `IsDeletable` | `bool` | **Технически** допустимо удаление (с учётом safety policy). |
| `DeletionMethod` | `DeletionMethod` | Как удалять: `None` / `RecycleBin` / `Permanent` / `SystemApi`. |
| `Reason` | `string?` | Короткий стабильный ключ причины (`temp.file`, `leftover.no-installed-app`). |
| `Explanation` | `string?` | Человекочитаемое объяснение, что это и почему найдено. |
| `SourceAnalyzer` | `string` | Кто создал элемент (см. `WellKnownAnalyzers`). |
| `OwnerApplication` | `string?` | Приложение-владелец, если удалось атрибутировать. |
| `DriveRoot` | `string?` | Том, к которому относится элемент. |
| `IsReparsePoint` | `bool` | Junction / symlink / mount point. |
| `IsProtected` | `bool` | Путь в защищённой зоне. |
| `RequiresElevation` | `bool` | Нужны права администратора. |

### Главное разделение

> **«Можно удалить» ≠ «можно уверенно определить, что это мусор».**

* `IsDeletable` — про допустимость операции (safety policy, атрибуты, занятость).
* `Confidence` — про семантическую уверенность.

Крупный `.vhdx` в папке пользователя: `IsDeletable = true` (по явному выбору),
`Confidence = NeedsReview`, `RiskLevel = High`. В автоматическую выборку он не попадёт
никогда.

## 2. Перечисления

### `ScanCategory`
`Unknown`, `TemporaryFiles`, `BrowserCache`, `ApplicationCache`, `Logs`, `CrashDumps`,
`RecycleBin`, `Thumbnails`, `WindowsUpdateCache`, `AppLeftovers`, `LargeFiles`,
`DeveloperData`, `InstallerPackages`, `SystemData`, `UserData`, `Other`.

`SystemData` и `UserData` — объяснительные категории: они попадают в отчёт, но
`SafetyPolicy` отказывает в их удалении независимо от пути.

### `CleanupConfidence`
| Значение | Поведение в UI |
| --- | --- |
| `NeedsReview` (0) | Никогда не выбирается автоматически. Текст: «Не удалось уверенно определить назначение. Требуется проверка пользователя». |
| `Likely` (1) | Показывается как кандидат, решение за пользователем. |
| `Safe` (2) | Единственный уровень, который предлагается заранее выбранным. Требует явного правила на известное расположение. |

### `RiskLevel`
`None` → `Low` (пересоздаётся приложением) → `Medium` (нужно заново
скачать/пересобрать) → `High` (возможна потеря данных пользователя) → `Critical`
(повреждение ОС; не предлагается никогда).

### `DeletionMethod`
`None` (защищено), `RecycleBin` (можно отменить), `Permanent` (только TEMP/кэш),
`SystemApi` (например, очистка Корзины системным вызовом, а не удалением файлов).

### `ScanMode`, `ScanPhase`, `ScanItemKind`, `ScanIssueKind`, `CleanupOperationStatus`
`ScanIssueKind`: `AccessDenied`, `PathTooLong`, `FileInUse`, `NotFound`, `IoError`,
`ReparsePointSkipped`, `Excluded`, `Cancelled`, `Unknown`. `MayRequireElevation`
истинно только для `AccessDenied` — именно это включает кнопку «повторить с
повышением».

## 3. Сканирование

### `ScanOptions`
Режим, корни, глубина, исключения (пути и расширения), пороги размеров, `MaxDepth`,
`IncludeHiddenAndSystem`, `EnableDeveloperAnalysis`, `FollowReparsePoints` (по
умолчанию `false`), параллелизм (`MaxUsefulParallelism = 4`), ёмкость очереди
каталогов, интервал прогресса, ёмкости top-N и `MaxTrackedDirectories` (защита памяти),
`ExpectedTotalBytes` (основа честного процента).

`Normalise()` приводит корни и исключения к каноническому виду один раз, до старта.

### `ScannedEntry` (`readonly record struct`)
`FullPath`, `Name`, `IsDirectory`, `Size`, `Attributes`, `CreatedUtc`, `LastWriteUtc`,
`IsReparsePoint`, `DriveRoot` + вычисляемые `IsHidden`, `IsSystem`, `IsSparseFile`,
`IsCloudPlaceholder`, `IsOfflineOrRecall`.

> `IsCloudPlaceholder` важен для корректности: OneDrive-файл «только онлайн»
> сообщает логический размер, но на диске места почти не занимает.

### `ScanProgress`
`Phase`, `CurrentRoot`, `CurrentDirectory`, счётчики файлов/каталогов/байт,
`IssuesCount`, `RootsCompleted/RootsTotal`, `Elapsed`, `EntriesPerSecond`,
`PercentComplete` (**nullable** — `null` означает «честный indeterminate»).

### `ScanStatistics` / `ScanResult`
`ScanStatistics`: сколько просмотрено, сколько пропущено, сколько каталогов недоступно,
сколько reparse points не пройдено, длительность, признак отмены, пик отслеженных
каталогов.

`ScanResult`: элементы, крупнейшие каталоги (`DirectoryAggregate` с `OwnBytes` и
`SubtreeBytes`), крупнейшие файлы, issues, снимки томов, итоговые суммы
`PotentialCleanupBytes`, `SafeBytes`, `LikelyBytes`, `NeedsReviewBytes` и словари
`BytesByCategory` / `CountByCategory` / `BytesByConfidence`.

### `ScanIssue`
`Path`, `Kind`, `Reason`, `ReasonKey` (нелокализованный ключ), `ExceptionType`,
`ErrorCode` (Win32-код: 5 = access denied, 32 = sharing violation), `EstimatedSize`,
`OccurredAtUtc`, `MayRequireElevation`. **Stack trace в модель не попадает** — он
остаётся в логе.

## 3a. Отчёт по AppData

`ScanResult.AppData` — структурированный разбор, который не сводится к плоскому списку:

* `AppDataRootSummary` — корень (`Local` / `Roaming` / `LocalLow`), профиль, объём,
  число приложений, признак неполного чтения.
* `AppDataApplication` — приложение или папка: путь, отображаемое имя, производитель,
  `IsKnown` (совпало ли с каталогом), `Family` (какое семейство правил классифицировало
  содержимое), корень, профиль, объём, число файлов, объяснение, группы содержимого и
  дерево крупнейших каталогов. `ReclaimableBytes` — сумма групп-кандидатов.
* `AppDataContentGroup` — классифицированная часть приложения: `Kind`
  (`Cache` / `Logs` / `Temp` / `Packages` / `DeveloperCache` / `CrashDumps` / `Data` /
  `Unknown`), объём, `Confidence`, `Risk`, `Method`, `IsReclaimable`, `ReasonKey`,
  объяснение.
* `AppDataDirectoryNode` — узел дерева: `SubtreeBytes`, `OwnBytes`, `FileCount`, `Depth`,
  `ParentPath`, дочерние узлы. Узлами являются только каталоги; файлы дают вклад в
  `OwnBytes` родителя.
* `AppDataReport` — итоги: `TotalBytes`, `KnownBytes`, `UnknownBytes`, `ReclaimableBytes`,
  `SafeReclaimableBytes`, `IsComplete`, `ByContentKind`.

Ключевое правило: совокупный размер приложения — это объяснение, а не кандидат. Кандидатом
может быть только группа, у которой есть явное правило семейства.

## 4. `DirectoryAggregate`
`Path`, `Name`, `OwnBytes` (файлы прямо в каталоге), `SubtreeBytes` (всё поддерево),
`OwnFileCount`, `SubtreeFileCount`, `Depth`, `ParentPath`, `LastWriteUtc`. Из этих
полей строится дерево каталогов в UI без повторного обращения к диску.

## 5. Очистка

### `CleanupOperation`
Целевой путь, отображаемое имя, `Kind`, `Category`, `Confidence`, `RiskLevel`,
`Method`, ожидаемые `ExpectedBytes`/`ExpectedFileCount`, `Reason`, `Explanation`,
`SourceAnalyzer`, `RequiresElevation`; после выполнения — `Status`,
`FreedBytes`, `RemovedFileCount`, `ErrorMessage`, `ErrorKind`, `ExecutedAtUtc`.

### `CleanupPlan`
Список операций + агрегаты (`TotalExpectedBytes`, `TotalExpectedFileCount`,
`ByCategory`, `HighRiskOperations`). Метод `TryAdd(operation, safetyPolicy, out rejection)`
**физически не может** положить в план защищённый путь: проверка выполняется при
добавлении, а не при выполнении. Дубликаты пути отклоняются.

### `CleanupRunRecord` (история)
`Id`, `StartedAtUtc`, `CompletedAtUtc`, `Mode`, `FreeBytesBefore/After`,
`FreedBytes`, `DeletedFileCount`, `DeletedDirectoryCount`, `SkippedCount`,
`FailedCount`, `WasCancelled`, `RanElevated`, `Categories` (список
`CategoryBreakdown`), `Skipped` (список `SkippedFile` с причиной), `Note`,
`SchemaVersion`.

## 6. Настройки (`AppSettings`)
`SchemaVersion`, `Theme`, `Language`, `ScanDepth`, `ExcludedPaths`,
`ExcludedExtensions`, `LargeFileThresholdBytes`, `EnableDeveloperAnalysis`,
`FollowReparsePoints`, `MaxDegreeOfParallelism`, `RecycleBinBehavior`,
`SaveHistoryAutomatically`, `MaxHistoryRecords`, `EnableVerboseLogging`.

`Sanitise()` зажимает значения в безопасные диапазоны при загрузке (ручная правка
`settings.json` не может привести к нерабочему сканированию), `ToScanOptions(mode, roots)`
проецирует настройки в параметры сканирования, включая `MaxDepth` по глубине:
Fast → 24, Standard → 48, Exhaustive → без ограничения.

Пример `settings.json`:

```json
{
  "schemaVersion": 1,
  "theme": "Dark",
  "language": "en",
  "scanDepth": "Standard",
  "excludedPaths": ["C:\\Projects"],
  "excludedExtensions": ["iso"],
  "largeFileThresholdBytes": 268435456,
  "enableDeveloperAnalysis": true,
  "followReparsePoints": false,
  "maxDegreeOfParallelism": 0,
  "recycleBinBehavior": "PreferForUserData",
  "saveHistoryAutomatically": true,
  "maxHistoryRecords": 200,
  "enableVerboseLogging": false
}
```

## 7. Контракт анализатора

```csharp
public interface IAnalyzer
{
    string Name { get; }                        // стабильный идентификатор
    string Description { get; }                 // для подсказки «почему найдено»
    IReadOnlyCollection<ScanMode> SupportedModes { get; }
    int Order { get; }                          // порядок выполнения
    bool IsEnabled(AppSettings settings);
    Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken);
}
```

`AnalyzerContext` даёт анализатору: `Options`, `Drives`, `Directories` (вся карта
пространства), `LargestFiles`, `Environment`, `Safety`, `Logger`, `CancellationToken`
и метод `Emit(ScanItem)`.

`Emit` централизованно применяет safety policy:

* запрещённый путь → элемент не публикуется, `IsDeletable = false`,
  `Confidence = NeedsReview`, `RiskLevel = Critical`, в `Explanation` попадает причина
  отказа;
* разрешённый путь → `Confidence` **не может превысить** `verdict.MaxConfidence`,
  `RiskLevel` **не может быть ниже** `verdict.MinRisk`, проставляется
  `RequiresElevation`.

Таким образом анализатор может быть сколь угодно смелым в гипотезах, но переоценить
уверенность поверх политики безопасности он не способен.

### Планируемые анализаторы
`DriveAnalyzer`, `LargeFilesAnalyzer`, `AppDataAnalyzer`, `TempAnalyzer`,
`BrowserCacheAnalyzer`, `LogAnalyzer`, `CrashDumpAnalyzer`, `RecycleBinAnalyzer`,
`DeveloperCacheAnalyzer`, `LeftoverApplicationsAnalyzer`. Список открыт: добавление
нового не затрагивает `FileSystemScanner`.
