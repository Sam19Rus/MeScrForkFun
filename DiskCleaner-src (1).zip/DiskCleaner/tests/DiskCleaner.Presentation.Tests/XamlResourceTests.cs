using System.Text.RegularExpressions;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

/// <summary>
/// A <c>StaticResource</c> that does not resolve is a load-time crash, and the WPF shell
/// cannot run in CI on Linux — unit tests never instantiate the views. These tests parse
/// the XAML instead, so a style referenced from the wrong dictionary is caught here
/// rather than the first time a user opens that section.
/// </summary>
public class XamlResourceTests
{
    private static readonly string[] GlobalDictionaries =
    [
        "src/DiskCleaner.App/Resources/Styles.xaml",
        "src/DiskCleaner.App/Resources/Themes/Light.xaml",
        "src/DiskCleaner.App/Resources/Themes/Dark.xaml",
        "src/DiskCleaner.App/App.xaml",
    ];

    private static string Root()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null && !File.Exists(Path.Combine(directory.FullName, "DiskCleaner.slnx")))
        {
            directory = directory.Parent;
        }

        return directory?.FullName ?? throw new InvalidOperationException("repository root not found");
    }

    private static HashSet<string> KeysOf(string relativePath)
    {
        var text = File.ReadAllText(Path.Combine(Root(), relativePath));
        return [.. Regex.Matches(text, "x:Key=\"([^\"]+)\"").Select(m => m.Groups[1].Value)];
    }

    [Fact]
    public void Every_StaticResource_referenced_from_XAML_resolves()
    {
        var globalKeys = new HashSet<string>(StringComparer.Ordinal);
        foreach (var dictionary in GlobalDictionaries)
        {
            globalKeys.UnionWith(KeysOf(dictionary));
        }

        var unresolved = new List<string>();

        foreach (var file in Directory.EnumerateFiles(Path.Combine(Root(), "src"), "*.xaml", SearchOption.AllDirectories))
        {
            // Comments may legitimately mention resource syntax; only markup resolves keys.
            var text = Regex.Replace(File.ReadAllText(file), "<!--.*?-->", string.Empty, RegexOptions.Singleline);
            var localKeys = new HashSet<string>(
                Regex.Matches(text, "x:Key=\"([^\"]+)\"").Select(m => m.Groups[1].Value),
                StringComparer.Ordinal);

            foreach (Match match in Regex.Matches(text, @"StaticResource\s+(\{x:Type [^}]+\}|[A-Za-z0-9_.]+)"))
            {
                var key = match.Groups[1].Value;

                // Implicit styles keyed by type ({x:Type Button}) are a different lookup;
                // the shared dictionary defines them and they cannot be misspelled silently.
                if (key.StartsWith('{'))
                {
                    continue;
                }

                if (!localKeys.Contains(key) && !globalKeys.Contains(key))
                {
                    unresolved.Add($"{Path.GetRelativePath(Root(), file)}: {key}");
                }
            }
        }

        Assert.True(unresolved.Count == 0, "unresolvable StaticResource references:\n" + string.Join("\n", unresolved));
    }

    [Fact]
    public void Light_and_dark_themes_define_the_same_keys()
    {
        var light = KeysOf(GlobalDictionaries[1]);
        var dark = KeysOf(GlobalDictionaries[2]);

        // The appearance service swaps the whole dictionary: a brush missing from Dark
        // renders as an invisible or default-coloured element only in the dark theme.
        var onlyLight = light.Except(dark).OrderBy(k => k, StringComparer.Ordinal).ToArray();
        var onlyDark = dark.Except(light).OrderBy(k => k, StringComparer.Ordinal).ToArray();

        Assert.True(onlyLight.Length == 0, "keys missing from Dark.xaml: " + string.Join(", ", onlyLight));
        Assert.True(onlyDark.Length == 0, "keys missing from Light.xaml: " + string.Join(", ", onlyDark));
        Assert.True(light.Count > 10, $"expected a substantial theme dictionary, found {light.Count} keys");
    }
}
