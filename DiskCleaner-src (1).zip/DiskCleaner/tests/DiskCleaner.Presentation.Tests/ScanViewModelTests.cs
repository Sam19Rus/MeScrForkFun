using System.Diagnostics;
using System.Globalization;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class ScanViewModelTests
{
    private static readonly IValueFormatter Formatter = new ValueFormatter(CultureInfo.InvariantCulture);

    private sealed class Context(TempDirectory temp) : IDisposable
    {
        public TempDirectory Temp { get; } = temp;

        public void Dispose() => Temp.Dispose();
    }

    private static (ScanViewModel Vm, FakeScanService Scan, FakeDriveService Drives, FakeDialogService Dialogs, FakeUiDispatcher Dispatcher, NavigationService Nav, RecordingLogger<ScanViewModel> Logger, FakeShellService Shell, Core.Services.ApplicationPaths Paths, FakePrivilegeService Privileges, IDisposable Cleanup) Create(bool elevated = false)
    {
        var temp = new TempDirectory("dc-scan-vm");
        var environment = new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root });
        var paths = new Core.Services.ApplicationPaths(environment, new Core.Infrastructure.IO.PhysicalFileSystem());
        var settings = new Core.Services.JsonSettingsService(paths);
        settings.LoadAsync().GetAwaiter().GetResult();

        var drives = new FakeDriveService();
        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100, "System"));
        drives.Drives.Add(FakeDriveService.Fixed(@"D:\", 1024, 700, "Data"));

        var scan = new FakeScanService();
        var dialogs = new FakeDialogService();
        var dispatcher = new FakeUiDispatcher();
        var navigation = new NavigationService();
        var shell = new FakeShellService();
        var logger = new RecordingLogger<ScanViewModel>();
        var privileges = new FakePrivilegeService { IsElevated = elevated };

        var vm = new ScanViewModel(scan, drives, settings, dialogs, Formatter, navigation, dispatcher, shell, paths, privileges, Loc.En, logger);
        return (vm, scan, drives, dialogs, dispatcher, navigation, logger, shell, paths, privileges, new Context(temp));
    }

    [Fact]
    public async Task Deep_scan_hands_scope_resolution_to_the_service()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.SelectedMode = ScanMode.Deep;

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.Single(scan.Calls);
            Assert.Equal(ScanMode.Deep, scan.Calls[0].Mode);
            Assert.Empty(scan.Calls[0].Roots);      // the service picks the fixed volumes
            Assert.False(vm.IsRunning);
        }
    }

    [Fact]
    public async Task Custom_scan_without_a_selection_warns_and_does_not_start()
    {
        var (vm, scan, _, dialogs, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.SelectedMode = ScanMode.Custom;
            foreach (var drive in vm.Drives)
            {
                drive.IsSelectedForScan = false;
            }

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.Empty(scan.Calls);
            Assert.Single(dialogs.Warnings);
            Assert.Contains("Nothing selected", dialogs.Warnings[0], StringComparison.Ordinal);
            Assert.Contains("Select at least one", vm.StatusText, StringComparison.Ordinal);
        }
    }

    [Fact]
    public async Task Custom_scan_passes_the_selected_volumes_and_folders()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.SelectedMode = ScanMode.Custom;
            foreach (var drive in vm.Drives)
            {
                drive.IsSelectedForScan = drive.RootPath == @"D:\";
            }

            vm.CustomFolders.Add(@"C:\Users\alice\AppData");

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.Single(scan.Calls);
            Assert.Equal(ScanMode.Custom, scan.Calls[0].Mode);
            Assert.Equal([@"D:\", @"C:\Users\alice\AppData"], scan.Calls[0].Roots);
        }
    }

    [Fact]
    public async Task Progress_is_marshalled_through_the_dispatcher_and_rendered()
    {
        var (vm, scan, _, _, dispatcher, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            var livePhases = new List<string>();

            scan.BeforeReturn = progress =>
            {
                progress?.Report(new ScanProgress
                {
                    Phase = ScanPhase.Enumerating,
                    CurrentRoot = @"C:\",
                    CurrentDirectory = @"C:\Users\alice\AppData\Local\Google\Chrome\User Data",
                    FilesScanned = 1_234_567,
                    DirectoriesScanned = 56_789,
                    BytesScanned = 1024L * 1024 * 1024 * 40,
                    Elapsed = TimeSpan.FromSeconds(95),
                    EntriesPerSecond = 14_000,
                    PercentComplete = null,      // folder scan: no trustworthy total
                    IssuesCount = 3,
                });

                // Captured while the scan is still running; the final report
                // legitimately moves the phase on to "Completed".
                livePhases.Add(vm.PhaseText);
            };

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.True(dispatcher.PostedCount > 0, "progress must hop through the dispatcher");
            Assert.Equal(["Scanning"], livePhases);
            Assert.Equal("1,234,567", vm.FilesText);
            Assert.Equal("56,789", vm.DirectoriesText);
            Assert.Equal("40.0 GB", vm.ScannedBytesText);
            Assert.Equal("Completed", vm.PhaseText);
            Assert.Contains("Chrome", vm.CurrentDirectoryText, StringComparison.Ordinal);
        }
    }

    [Fact]
    public async Task A_known_total_produces_a_percentage_and_an_unknown_one_stays_indeterminate()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.BeforeReturn = progress =>
            {
                progress?.Report(new ScanProgress { PercentComplete = null, FilesScanned = 1 });
                Assert.True(vm.IsIndeterminate);

                progress?.Report(new ScanProgress { PercentComplete = 0.42, FilesScanned = 2 });
                Assert.False(vm.IsIndeterminate);
                Assert.Equal(0.42, vm.ProgressValue, 3);
                Assert.Equal("42.0%", vm.ProgressText);
            };

            await vm.StartScanCommand.ExecuteAsync(null);
        }
    }

    [Fact]
    public async Task Result_summary_reports_counts_bytes_and_skips()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.Result = new ScanResult
            {
                Mode = ScanMode.Deep,
                StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
                CompletedAtUtc = new DateTime(2026, 5, 1, 10, 2, 0, DateTimeKind.Utc),
                Statistics = new ScanStatistics
                {
                    FilesScanned = 900_000,
                    DirectoriesScanned = 40_000,
                    BytesScanned = 300L * 1024 * 1024 * 1024,
                    IssuesCount = 7,
                    InaccessibleDirectories = 5,
                    ReparsePointsSkipped = 2,
                    Elapsed = TimeSpan.FromMinutes(2),
                },
                Issues =
                [
                    new ScanIssue
                    {
                        Path = @"C:\Windows\System32\config\SYSTEM",
                        Kind = ScanIssueKind.AccessDenied,
                        Reason = "Access denied",
                        ReasonKey = "issue.access-denied",
                        ExceptionType = "UnauthorizedAccessException",
                        ErrorCode = 5,
                    },
                ],
            };

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.True(vm.HasResult);
            Assert.Contains("900,000 files", vm.ResultSummaryText, StringComparison.Ordinal);
            Assert.Contains("300.0 GB", vm.ResultSummaryText, StringComparison.Ordinal);
            Assert.Contains("2m 00s", vm.ResultSummaryText, StringComparison.Ordinal);
            Assert.Contains("7 item(s) skipped", vm.SkippedSummaryText, StringComparison.Ordinal);

            var issue = Assert.Single(vm.Issues);
            Assert.Equal("Access denied", issue.KindText);
            Assert.Contains("config", issue.ShortPath, StringComparison.Ordinal);
            Assert.True(issue.MayRequireElevation);
            Assert.Contains("administrator", issue.Tooltip, StringComparison.OrdinalIgnoreCase);
        }
    }

    [Fact]
    public async Task The_classification_summary_is_shown_after_a_scan()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.Result = new ScanResult
            {
                Mode = ScanMode.Quick,
                StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
                CompletedAtUtc = new DateTime(2026, 5, 1, 10, 0, 9, DateTimeKind.Utc),
                Statistics = new ScanStatistics { FilesScanned = 500, DirectoriesScanned = 12, BytesScanned = 30L * 1024 * 1024 * 1024 },
                PotentialCleanupBytes = (long)(28.6 * 1024 * 1024 * 1024),
                SafeBytes = (long)(12.4 * 1024 * 1024 * 1024),
                LikelyBytes = (long)(7.8 * 1024 * 1024 * 1024),
                NeedsReviewBytes = (long)(8.4 * 1024 * 1024 * 1024),
                BytesByCategory = new Dictionary<ScanCategory, long>
                {
                    [ScanCategory.BrowserCache] = 11L * 1024 * 1024 * 1024,
                    [ScanCategory.TemporaryFiles] = 6L * 1024 * 1024 * 1024,
                },
                CountByCategory = new Dictionary<ScanCategory, int>
                {
                    [ScanCategory.BrowserCache] = 4,
                    [ScanCategory.TemporaryFiles] = 3,
                },
            };

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.True(vm.HasCleanupCandidates);
            Assert.Equal("28.6 GB", vm.PotentialCleanupText);
            Assert.Equal("12.4 GB", vm.SafeText);
            Assert.Equal("7.8 GB", vm.LikelyText);
            Assert.Equal("8.4 GB", vm.NeedsReviewText);

            Assert.Equal(2, vm.Categories.Count);
            Assert.Equal(ScanCategory.BrowserCache, vm.Categories[0].Category);
            Assert.Equal("11.0 GB", vm.Categories[0].SizeText);
            Assert.Equal("4", vm.Categories[0].CountText);
        }
    }

    [Fact]
    public async Task An_empty_result_says_so_instead_of_showing_zeros_as_achievements()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.Result = new ScanResult
            {
                StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
                CompletedAtUtc = new DateTime(2026, 5, 1, 10, 0, 1, DateTimeKind.Utc),
            };

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.False(vm.HasCleanupCandidates);
            Assert.Empty(vm.Categories);
            // The scan ran and genuinely found nothing: report a real zero, not a dash.
            Assert.Equal("0 B", vm.PotentialCleanupText);
            Assert.Equal("0 B", vm.SafeText);
        }
    }

    [Fact]
    public async Task Cancel_signals_the_token_and_the_ui_says_it_was_cancelled()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            var tcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            scan.RunOverride = async (_, _, _, cancellationToken) =>
            {
                await tcs.Task.WaitAsync(cancellationToken);
                return new ScanResult();
            };

            var run = vm.StartScanCommand.ExecuteAsync(null);
            WaitUntil(() => vm.IsRunning);

            Assert.True(vm.IsBusy);
            Assert.True(vm.CancelScanCommand.CanExecute(null));

            vm.CancelScanCommand.Execute(null);

            await run;

            Assert.False(vm.IsRunning);
            Assert.False(vm.IsBusy);
            Assert.Equal("Scan cancelled.", vm.StatusText);
            Assert.Equal("Cancelled", vm.PhaseText);
        }
    }

    [Fact]
    public async Task Start_is_disabled_while_a_scan_is_running()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            var gate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            scan.RunOverride = async (_, _, _, cancellationToken) =>
            {
                await gate.Task.WaitAsync(cancellationToken);
                return new ScanResult();
            };

            var run = vm.StartScanCommand.ExecuteAsync(null);
            WaitUntil(() => vm.IsRunning);

            Assert.False(vm.StartScanCommand.CanExecute(null));

            vm.CancelScanCommand.Execute(null);
            await run;

            Assert.True(vm.StartScanCommand.CanExecute(null));
        }
    }

    [Fact]
    public async Task The_folder_dialog_appends_unique_entries()
    {
        var (vm, _, _, dialogs, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            dialogs.FolderToReturn = @"D:\Projects";

            await vm.AddFolderCommand.ExecuteAsync(null);
            await vm.AddFolderCommand.ExecuteAsync(null);

            Assert.Equal([@"D:\Projects"], vm.CustomFolders);
        }
    }

    [Fact]
    public void Typed_paths_can_be_added_and_removed()
    {
        var (vm, _, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.NewFolderPath = @"C:\Temp";
            vm.AddPathFromTextBoxCommand.Execute(null);

            Assert.Equal([@"C:\Temp"], vm.CustomFolders);
            Assert.Equal(string.Empty, vm.NewFolderPath);

            vm.RemoveFolderCommand.Execute(@"C:\Temp");
            Assert.Empty(vm.CustomFolders);
        }
    }

    [Fact]
    public void Reload_picks_up_volume_changes_and_keeps_the_user_selection()
    {
        var (vm, _, drives, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.Drives.First(d => d.RootPath == @"D:\").IsSelectedForScan = false;

            drives.Drives.Add(FakeDriveService.Fixed(@"E:\", 256, 200, "USB"));
            vm.ReloadDrivesCommand.Execute(null);

            Assert.Equal(3, vm.Drives.Count);
            Assert.False(vm.Drives.First(d => d.RootPath == @"D:\").IsSelectedForScan);
            Assert.True(vm.Drives.First(d => d.RootPath == @"E:\").IsSelectedForScan);
        }
    }

    [Fact]
    public async Task Open_results_navigates_to_the_results_section()
    {
        var (vm, _, _, _, _, navigation, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            vm.OpenResultsCommand.Execute(null);

            Assert.Equal(Section.Results, navigation.Current);
            await Task.CompletedTask;
        }
    }

    [Fact]
    public async Task A_failing_scan_surfaces_the_reason_instead_of_swallowing_it()
    {
        var (vm, scan, _, _, _, _, logger, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.RunOverride = (_, _, _, _) =>
                throw new InvalidOperationException("The scanner could not open C:\\Users\\alice.");

            await vm.StartScanCommand.ExecuteAsync(null);

            // The user sees a short, safe reason: type + message, never a stack trace.
            Assert.True(vm.HasFailure);
            Assert.Contains("InvalidOperationException", vm.FailureText, StringComparison.Ordinal);
            Assert.Contains("could not open", vm.FailureText, StringComparison.Ordinal);
            Assert.DoesNotContain("StackTrace", vm.FailureText, StringComparison.Ordinal);

            Assert.Equal("Stopped", vm.PhaseText);
            Assert.False(vm.IsIndeterminate);
            Assert.False(vm.IsRunning);

            // And the log keeps the full detail, so the failure is diagnosable.
            Assert.True(logger.HasErrors);
            Assert.IsType<InvalidOperationException>(logger.LastException);
        }
    }

    [Fact]
    public async Task A_new_scan_clears_the_previous_failure()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            scan.RunOverride = (_, _, _, _) => throw new IOException("device not ready");
            await vm.StartScanCommand.ExecuteAsync(null);
            Assert.True(vm.HasFailure);

            scan.RunOverride = null;
            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.False(vm.HasFailure);
            Assert.Null(vm.FailureText);
        }
    }

    [Fact]
    public async Task The_failure_banner_can_be_dismissed_and_leads_to_the_log()
    {
        var (vm, scan, _, _, _, _, _, shell, paths, _, cleanup) = Create();
        using (cleanup)
        {
            scan.RunOverride = (_, _, _, _) => throw new UnauthorizedAccessException("denied");
            await vm.StartScanCommand.ExecuteAsync(null);

            vm.OpenLogFolderCommand.Execute(null);
            Assert.Contains("folder:" + paths.LogsDirectory, shell.Opened);

            vm.DismissFailureCommand.Execute(null);
            Assert.False(vm.HasFailure);
        }
    }

    [Fact]
    public async Task HasIssues_tracks_the_skipped_list_so_the_panel_actually_shows()
    {
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create();
        using (cleanup)
        {
            Assert.False(vm.HasIssues);

            scan.Result = new ScanResult
            {
                Statistics = new ScanStatistics { FilesScanned = 10, IssuesCount = 1 },
                Issues =
                [
                    new ScanIssue
                    {
                        Path = @"C:\Windows\System32\config\SYSTEM",
                        Kind = ScanIssueKind.AccessDenied,
                        Reason = "Access denied",
                        ReasonKey = "issue.access-denied",
                    },
                ],
            };

            await vm.StartScanCommand.ExecuteAsync(null);

            Assert.True(vm.HasIssues);
            var issue = Assert.Single(vm.Issues);
            Assert.Equal("Access denied", issue.KindText);
            Assert.Equal("Access denied", issue.Reason);
            Assert.Contains("administrator", issue.Tooltip, StringComparison.OrdinalIgnoreCase);
        }
    }

    [Fact]
    public async Task Access_denied_advice_depends_on_whether_the_process_is_already_elevated()
    {
        static ScanResult DeniedResult() => new()
        {
            StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
            CompletedAtUtc = new DateTime(2026, 5, 1, 10, 0, 1, DateTimeKind.Utc),
            Issues =
            [
                new ScanIssue
                {
                    Path = @"C:\Users\bob\AppData\Local\Microsoft\Credentials",
                    Kind = ScanIssueKind.AccessDenied,
                    Reason = "Access denied",
                    ReasonKey = "issue.access-denied",
                    ErrorCode = 5,
                },
            ],
        };

        // A standard user can act on the advice.
        var (vm, scan, _, _, _, _, _, _, _, _, cleanup) = Create(elevated: false);
        using (cleanup)
        {
            scan.Result = DeniedResult();
            await vm.StartScanCommand.ExecuteAsync(null);

            var issue = Assert.Single(vm.Issues);
            Assert.True(issue.CanBeFixedByElevation);
            Assert.False(issue.IsSystemOnly);
            Assert.Contains("administrator", issue.Tooltip, StringComparison.OrdinalIgnoreCase);
        }

        // An administrator cannot: telling them to elevate again would be a lie.
        var (elevatedVm, elevatedScan, _, _, _, _, _, _, _, privileges, cleanup2) = Create(elevated: true);
        using (cleanup2)
        {
            Assert.True(privileges.IsElevated);
            elevatedScan.Result = DeniedResult();
            await elevatedVm.StartScanCommand.ExecuteAsync(null);

            var issue = Assert.Single(elevatedVm.Issues);
            Assert.False(issue.CanBeFixedByElevation);
            Assert.True(issue.IsSystemOnly);
            Assert.Contains("SYSTEM", issue.Tooltip, StringComparison.Ordinal);
            Assert.DoesNotContain("may help", issue.Tooltip, StringComparison.OrdinalIgnoreCase);
        }
    }

    private static void WaitUntil(Func<bool> condition, int timeoutMs = 5_000)
    {
        var watch = Stopwatch.StartNew();
        while (!condition())
        {
            if (watch.ElapsedMilliseconds > timeoutMs)
            {
                throw new TimeoutException("Condition was not met in time.");
            }

            Thread.Sleep(5);
        }
    }
}
