using System.Globalization;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class ResultsViewModelTests
{
    private static readonly IValueFormatter Formatter = new ValueFormatter(CultureInfo.InvariantCulture);

    private static AppDataReport SampleReport() => new()
    {
        TotalBytes = 30L * 1024 * 1024 * 1024,
        TotalFiles = 250_000,
        KnownBytes = 26L * 1024 * 1024 * 1024,
        UnknownBytes = 4L * 1024 * 1024 * 1024,
        ReclaimableBytes = 6L * 1024 * 1024 * 1024,
        SafeReclaimableBytes = 3L * 1024 * 1024 * 1024,
        IsComplete = true,
        Roots =
        [
            new AppDataRootSummary
            {
                Root = AppDataRoot.Local,
                Path = @"C:\Users\alice\AppData\Local",
                Profile = @"C:\Users\alice",
                Exists = true,
                Bytes = 22L * 1024 * 1024 * 1024,
                ApplicationCount = 40,
            },
            new AppDataRootSummary
            {
                Root = AppDataRoot.Roaming,
                Path = @"C:\Users\alice\AppData\Roaming",
                Profile = @"C:\Users\alice",
                Exists = true,
                Bytes = 8L * 1024 * 1024 * 1024,
                ApplicationCount = 25,
            },
            new AppDataRootSummary
            {
                Root = AppDataRoot.LocalLow,
                Path = @"C:\Users\alice\AppData\LocalLow",
                Profile = @"C:\Users\alice",
                Exists = false,
            },
        ],
        ByContentKind =
        [
            new AppDataContentTotals { Kind = AppDataContentKind.Cache, Bytes = 5L * 1024 * 1024 * 1024, GroupCount = 12, ReclaimableBytes = 5L * 1024 * 1024 * 1024 },
            new AppDataContentTotals { Kind = AppDataContentKind.Data, Bytes = 24L * 1024 * 1024 * 1024, GroupCount = 30 },
        ],
        Applications =
        [
            new AppDataApplication
            {
                Path = @"C:\Users\alice\AppData\Local\Google\Chrome",
                DisplayName = "Google Chrome",
                Vendor = "Google",
                IsKnown = true,
                Family = "Chromium",
                Root = AppDataRoot.Local,
                Profile = @"C:\Users\alice",
                Bytes = 11L * 1024 * 1024 * 1024,
                FileCount = 90_000,
                Explanation = "Browser profile: settings, history, bookmarks, passwords, extensions and caches.",
                Contents =
                [
                    new AppDataContentGroup
                    {
                        Kind = AppDataContentKind.Cache,
                        Path = @"C:\Users\alice\AppData\Local\Google\Chrome\User Data\Default\Cache",
                        Name = @"User Data \ Default \ Cache",
                        Bytes = 2L * 1024 * 1024 * 1024,
                        Confidence = CleanupConfidence.Safe,
                        Risk = RiskLevel.Low,
                        Method = DeletionMethod.Permanent,
                        IsReclaimable = true,
                        ReasonKey = "appdata.cache.chromium",
                        Explanation = "Browser cache. The browser rebuilds it automatically.",
                    },
                    new AppDataContentGroup
                    {
                        Kind = AppDataContentKind.Data,
                        Path = @"C:\Users\alice\AppData\Local\Google\Chrome",
                        Name = "Chrome",
                        Bytes = 9L * 1024 * 1024 * 1024,
                        Confidence = CleanupConfidence.NeedsReview,
                        Risk = RiskLevel.High,
                        IsReclaimable = false,
                        Explanation = "Application data: profiles, databases, settings and indexes.",
                    },
                ],
                LargestDirectories =
                [
                    new AppDataDirectoryNode
                    {
                        Path = @"C:\Users\alice\AppData\Local\Google\Chrome\User Data",
                        Name = "User Data",
                        SubtreeBytes = 11L * 1024 * 1024 * 1024,
                        Depth = 1,
                        Children =
                        [
                            new AppDataDirectoryNode
                            {
                                Path = @"C:\Users\alice\AppData\Local\Google\Chrome\User Data\Default",
                                Name = "Default",
                                SubtreeBytes = 8L * 1024 * 1024 * 1024,
                                Depth = 2,
                            },
                        ],
                    },
                ],
            },
            new AppDataApplication
            {
                Path = @"C:\Users\alice\AppData\Local\SomeMysteryApp",
                DisplayName = "SomeMysteryApp",
                IsKnown = false,
                Family = "Unknown",
                Root = AppDataRoot.Local,
                Profile = @"C:\Users\alice",
                Bytes = 4L * 1024 * 1024 * 1024,
                FileCount = 1_200,
            },
        ],
    };

    private static ScanResult ResultWith(AppDataReport report) => new()
    {
        Mode = ScanMode.Deep,
        StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
        CompletedAtUtc = new DateTime(2026, 5, 1, 10, 6, 0, DateTimeKind.Utc),
        Statistics = new ScanStatistics { FilesScanned = 1_500_000, DirectoriesScanned = 120_000 },
        AppData = report,
    };

    private sealed class Harness : IDisposable
    {
        public Harness(ScanResult? initialResult = null)
        {
            Environment = FakeEnvironmentInfo.DefaultWindows();
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Environment, [@"C:\", @"D:\"]), Environment);
            Planner = new CleanupPlanner(Policy);
            Exclusions = new ReportExclusions();
            Ledger = new CleanupLedger();
            Scan = new FakeScanService();
            Dispatcher = new ManualUiDispatcher();
            Shell = new FakeShellService();

            if (initialResult is not null)
            {
                Scan.Result = initialResult;
            }

            Vm = new ResultsViewModel(Scan, Formatter, Dispatcher, Shell, new NavigationService(), Planner, Exclusions, Ledger, Loc.En);
        }

        public FakeEnvironmentInfo Environment { get; }
        public SafetyPolicy Policy { get; }
        public CleanupPlanner Planner { get; }
        public ReportExclusions Exclusions { get; }
        public CleanupLedger Ledger { get; }
        public FakeScanService Scan { get; }
        public ManualUiDispatcher Dispatcher { get; }
        public FakeShellService Shell { get; }
        public ResultsViewModel Vm { get; }

        public void Dispose()
        {
        }
    }

    private static (ResultsViewModel Vm, FakeScanService Scan, ManualUiDispatcher Dispatcher, FakeShellService Shell) Create()
    {
        var harness = new Harness();
        return (harness.Vm, harness.Scan, harness.Dispatcher, harness.Shell);
    }

    private static ScanItem Candidate(
        string path,
        long size,
        CleanupConfidence confidence,
        ScanCategory category = ScanCategory.TemporaryFiles,
        bool deletable = true) => new()
        {
            Path = path,
            Name = System.IO.Path.GetFileName(path),
            Kind = ScanItemKind.Directory,
            Size = size,
            FileCount = 5,
            Category = category,
            Confidence = confidence,
            RiskLevel = confidence == CleanupConfidence.Safe ? RiskLevel.Low : RiskLevel.High,
            IsDeletable = deletable,
            DeletionMethod = deletable ? DeletionMethod.Permanent : DeletionMethod.None,
            Reason = "temp.user",
            Explanation = "Temporary files.",
            SourceAnalyzer = "TempAnalyzer",
        };

    private static ScanResult Candidates(params ScanItem[] items) => new()
    {
        Mode = ScanMode.Quick,
        StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
        CompletedAtUtc = new DateTime(2026, 5, 1, 10, 0, 5, DateTimeKind.Utc),
        Statistics = new ScanStatistics { FilesScanned = 100, DirectoriesScanned = 10 },
        Items = items,
        AppData = SampleReport(),
    };

    [Fact]
    public async Task Candidates_are_split_into_the_three_confidence_tiers()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(
            Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe),
            Candidate(@"C:\Users\alice\.npm\_logs", 2_000, CleanupConfidence.Likely, ScanCategory.Logs),
            Candidate(@"C:\Users\alice\AppData\Local\Mystery", 3_000, CleanupConfidence.NeedsReview, ScanCategory.Unknown, deletable: false));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        Assert.True(h.Vm.HasCandidates);
        Assert.Single(h.Vm.SafeItems);
        Assert.Single(h.Vm.LikelyItems);
        Assert.Single(h.Vm.ReviewItems);
        Assert.Contains("3 items", h.Vm.CandidateSummaryText, StringComparison.Ordinal);
        Assert.Contains("5.9 KB", h.Vm.CandidateSummaryText, StringComparison.Ordinal);   // 6000 B
    }

    [Fact]
    public async Task Bulk_add_takes_only_the_safe_tier()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(
            Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe),
            Candidate(@"C:\Windows\Temp", 2_000, CleanupConfidence.Safe),
            Candidate(@"C:\Users\alice\.npm\_logs", 4_000, CleanupConfidence.Likely, ScanCategory.Logs),
            Candidate(@"C:\Users\alice\AppData\Local\Mystery", 8_000, CleanupConfidence.NeedsReview, deletable: false));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        h.Vm.AddAllSafeToPlanCommand.Execute(null);

        Assert.Equal(2, h.Planner.Count);
        Assert.Equal(3_000, h.Planner.TotalBytes);
        Assert.True(h.Vm.HasPlan);
        Assert.Equal(2, h.Vm.PlanRows.Count);
        Assert.Contains("2 operation(s)", h.Vm.PlanSummaryText, StringComparison.Ordinal);

        // "Likely" and "Requires review" are never added in bulk.
        Assert.False(h.Planner.Contains(@"C:\Users\alice\.npm\_logs"));
        Assert.False(h.Planner.Contains(@"C:\Users\alice\AppData\Local\Mystery"));
    }

    [Fact]
    public async Task Per_item_toggle_moves_it_in_and_out_of_the_plan()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        var row = h.Vm.SafeItems[0];
        Assert.False(row.IsInPlan);

        row.TogglePlanCommand.Execute(null);
        Assert.True(row.IsInPlan);
        Assert.Equal(1, h.Planner.Count);
        Assert.Equal("Remove", row.PlanToggleText);

        row.TogglePlanCommand.Execute(null);
        Assert.False(row.IsInPlan);
        Assert.Equal(0, h.Planner.Count);
    }

    [Fact]
    public async Task A_protected_item_cannot_enter_the_plan_and_the_refusal_is_shown()
    {
        using var h = new Harness();
        var protectedItem = Candidate(@"C:\Users\alice\AppData\Local\Mystery", 3_000, CleanupConfidence.NeedsReview, deletable: false);
        h.Scan.Result = Candidates(protectedItem);

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        var row = h.Vm.ReviewItems[0];
        row.TogglePlanCommand.Execute(null);

        Assert.Equal(0, h.Planner.Count);
        Assert.NotNull(row.RejectionText);
        Assert.Contains("not marked as deletable", row.RejectionText, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Excluding_a_row_removes_it_from_the_tiers_and_from_the_plan()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(
            Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe),
            Candidate(@"C:\Windows\Temp", 2_000, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        h.Vm.AddAllSafeToPlanCommand.Execute(null);
        Assert.Equal(2, h.Planner.Count);

        var row = h.Vm.SafeItems[0];
        var path = row.Path;
        row.ToggleExcludedCommand.Execute(null);
        h.Dispatcher.Pump();

        Assert.True(h.Exclusions.IsExcluded(path));
        Assert.False(h.Planner.Contains(path));        // an excluded row must not stay planned
        Assert.Single(h.Vm.SafeItems);
        Assert.Single(h.Vm.ExcludedItems);
        Assert.Contains("1 row(s) excluded", h.Vm.ExcludedCountText, StringComparison.Ordinal);

        h.Vm.RestoreAllExcludedCommand.Execute(null);
        h.Dispatcher.Pump();
        Assert.Equal(2, h.Vm.SafeItems.Count);
        Assert.Empty(h.Vm.ExcludedItems);
    }

    [Fact]
    public async Task Clearing_the_plan_empties_it_and_updates_the_summary()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        h.Vm.AddAllSafeToPlanCommand.Execute(null);
        Assert.True(h.Vm.HasPlan);

        h.Vm.ClearPlanCommand.Execute(null);
        h.Dispatcher.Pump();

        Assert.False(h.Vm.HasPlan);
        Assert.Empty(h.Vm.PlanRows);
        Assert.Equal("The plan is empty. Add items from the candidate list: deletion is possible only after the plan is explicitly confirmed.", h.Vm.PlanSummaryText);
    }

    [Fact]
    public async Task Explanations_are_localised_by_reason_key()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(Candidate(@"C:\Users\alice\AppData\Local\Temp", 1_000, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        var row = h.Vm.SafeItems[0];
        Assert.Equal("temp.user", row.ReasonKey);
        Assert.Contains("TEMP folder", row.Explanation, StringComparison.OrdinalIgnoreCase);
        Assert.Equal("Temporary files", row.CategoryText);
        Assert.Equal("Safe", row.ConfidenceText);
    }

    [Fact]
    public void Before_any_scan_the_screen_says_so_instead_of_showing_zeros()
    {
        var (vm, _, _, _) = Create();

        Assert.False(vm.HasReport);
        Assert.Empty(vm.Applications);
        Assert.Equal("No analysis has been run yet. Start a scan — a deep scan covers AppData of every profile, a quick scan only the current user.", vm.SummaryText);
    }

    [Fact]
    public async Task A_completed_scan_from_a_background_thread_populates_the_report()
    {
        var (vm, scan, dispatcher, _) = Create();

        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));

        // Marshalling: nothing touches the bound collections until the UI thread runs it.
        Assert.False(vm.HasReport);
        Assert.Equal(1, dispatcher.PendingCount);

        dispatcher.Pump();

        Assert.True(vm.HasReport);
        Assert.Equal("30.0 GB", vm.TotalText);
        Assert.Equal("26.0 GB", vm.KnownText);
        Assert.Equal("4.0 GB", vm.UnknownText);
        Assert.Equal("6.0 GB", vm.ReclaimableText);
        Assert.Equal("3.0 GB", vm.SafeReclaimableText);
        Assert.False(vm.IsIncomplete);

        Assert.Equal(2, vm.Applications.Count);
        Assert.Equal(2, vm.Roots.Count);                       // LocalLow does not exist
        Assert.Equal(2, vm.ContentKinds.Count);

        Assert.Contains("applications and folders: 2", vm.SummaryText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task The_largest_application_is_selected_and_explained()
    {
        var (vm, scan, dispatcher, _) = Create();
        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));
        dispatcher.Pump();

        var selected = vm.SelectedApplication;
        Assert.NotNull(selected);
        Assert.Equal("Google Chrome", selected!.DisplayName);
        Assert.Equal("11.0 GB", selected.SizeText);
        Assert.Equal("Local", selected.RootText);
        Assert.True(selected.IsKnown);
        Assert.Contains("Browser profile", selected.Explanation, StringComparison.Ordinal);

        var cache = Assert.Single(selected.Contents, c => c.IsReclaimable);
        Assert.Equal("Cache", cache.KindText);
        Assert.Equal("Safe", cache.ConfidenceText);
        Assert.Equal("2.0 GB", cache.SizeText);

        var data = Assert.Single(selected.Contents, c => !c.IsReclaimable);
        Assert.Equal("Application data", data.KindText);
        Assert.Equal("Requires review", data.ConfidenceText);
    }

    [Fact]
    public async Task An_unknown_folder_is_flagged_and_gets_no_invented_purpose()
    {
        var (vm, scan, dispatcher, _) = Create();
        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));
        dispatcher.Pump();

        var unknown = vm.Applications.Single(a => a.DisplayName == "SomeMysteryApp");
        Assert.False(unknown.IsKnown);
        Assert.Contains("not in the known-application catalog", unknown.Explanation, StringComparison.Ordinal);
        Assert.Empty(unknown.Contents);
    }

    [Fact]
    public async Task The_directory_tree_is_exposed_for_the_selected_application()
    {
        var (vm, scan, dispatcher, _) = Create();
        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));
        dispatcher.Pump();

        var root = Assert.Single(vm.SelectedApplication!.Tree);
        Assert.Equal("User Data", root.Name);
        Assert.Equal("11.0 GB", root.SizeText);
        Assert.True(root.HasChildren);

        var child = Assert.Single(root.Children);
        Assert.Equal("Default", child.Name);
        Assert.Equal("8.0 GB", child.SizeText);
    }

    [Fact]
    public async Task Filtering_narrows_the_list_and_keeps_a_valid_selection()
    {
        var (vm, scan, dispatcher, _) = Create();
        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));
        dispatcher.Pump();

        vm.FilterText = "mystery";

        var only = Assert.Single(vm.Applications);
        Assert.Equal("SomeMysteryApp", only.DisplayName);
        Assert.Equal(only, vm.SelectedApplication);      // selection follows the filter

        vm.FilterText = string.Empty;
        Assert.Equal(2, vm.Applications.Count);
    }

    [Fact]
    public async Task Open_folder_uses_the_shell_service()
    {
        var (vm, scan, dispatcher, shell) = Create();
        await Task.Run(() => scan.RaiseCompleted(ResultWith(SampleReport())));
        dispatcher.Pump();

        vm.OpenSelectedFolderCommand.Execute(null);

        Assert.Contains(@"folder:C:\Users\alice\AppData\Local\Google\Chrome", shell.Opened);
    }

    [Fact]
    public async Task A_scan_without_the_appdata_analyzer_leaves_the_screen_honest()
    {
        var (vm, scan, dispatcher, _) = Create();

        await Task.Run(() => scan.RaiseCompleted(new ScanResult
        {
            Mode = ScanMode.Custom,
            StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
            CompletedAtUtc = new DateTime(2026, 5, 1, 10, 1, 0, DateTimeKind.Utc),
        }));
        dispatcher.Pump();

        Assert.False(vm.HasReport);
        Assert.Empty(vm.Applications);
        Assert.NotEmpty(vm.ScanSummaryText);
    }

    // ------------------------------------------------------------ deleted rows disappear

    private static CleanupRunRecord DeletionRecord(params DeletedEntry[] deleted) => new()
    {
        StartedAtUtc = new DateTime(2026, 5, 1, 12, 0, 0, DateTimeKind.Utc),
        CompletedAtUtc = new DateTime(2026, 5, 1, 12, 0, 10, DateTimeKind.Utc),
        Deleted = deleted,
    };

    [Fact]
    public async Task A_deleted_candidate_disappears_and_the_screen_says_why()
    {
        using var h = new Harness();
        var temp = @"C:\Users\alice\AppData\Local\Temp";
        h.Scan.Result = Candidates(
            Candidate(temp, 1_000, CleanupConfidence.Safe),
            Candidate(@"C:\Users\alice\.npm\_logs", 2_000, CleanupConfidence.Likely, ScanCategory.Logs));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();
        Assert.Single(h.Vm.SafeItems);

        h.Ledger.Register(DeletionRecord(new DeletedEntry
        {
            Path = temp,
            Kind = ScanItemKind.Directory,
            Bytes = 1_000,
        }));
        h.Dispatcher.Pump();

        Assert.Empty(h.Vm.SafeItems);
        Assert.Single(h.Vm.LikelyItems);
        Assert.True(h.Vm.HasDeletedNote);
        Assert.Contains("Deleted this session", h.Vm.DeletedNoteText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task Children_of_a_deleted_directory_disappear_too()
    {
        using var h = new Harness();
        h.Scan.Result = Candidates(
            Candidate(@"C:\Users\alice\AppData\Local\Temp\big", 1_000, CleanupConfidence.Safe),
            Candidate(@"C:\Users\alice\AppData\Local\Temp\big\inner.tmp", 400, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();
        Assert.Equal(2, h.Vm.SafeItems.Count);

        h.Ledger.Register(DeletionRecord(new DeletedEntry
        {
            Path = @"C:\Users\alice\AppData\Local\Temp\big",
            Kind = ScanItemKind.Directory,
            Bytes = 1_400,
        }));
        h.Dispatcher.Pump();

        Assert.Empty(h.Vm.SafeItems);
    }

    [Fact]
    public async Task A_reset_ledger_brings_rows_back_after_a_new_scan()
    {
        using var h = new Harness();
        var temp = @"C:\Users\alice\AppData\Local\Temp";
        h.Scan.Result = Candidates(Candidate(temp, 1_000, CleanupConfidence.Safe));

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        h.Ledger.Register(DeletionRecord(new DeletedEntry { Path = temp, Kind = ScanItemKind.Directory, Bytes = 1_000 }));
        h.Dispatcher.Pump();
        Assert.Empty(h.Vm.SafeItems);

        // TEMP regenerates: a new scan proves the path exists again, the ledger resets
        // (in production the ledger is wired to ScanCompleted), and the row returns.
        h.Ledger.Reset();
        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        Assert.Single(h.Vm.SafeItems);
        Assert.False(h.Vm.HasDeletedNote);
    }

    [Fact]
    public async Task Deleted_content_groups_and_whole_applications_leave_the_report()
    {
        using var h = new Harness();
        h.Scan.Result = ResultWith(SampleReport());

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        var chrome = h.Vm.Applications.Single(a => a.DisplayName == "Google Chrome");
        Assert.Equal(2, chrome.Contents.Count);

        // The cache group was deleted by a cleanup run…
        h.Ledger.Register(DeletionRecord(new DeletedEntry
        {
            Path = @"C:\Users\alice\AppData\Local\Google\Chrome\User Data\Default\Cache",
            Kind = ScanItemKind.Directory,
            Bytes = 2L * 1024 * 1024 * 1024,
        }));
        h.Dispatcher.Pump();

        chrome = h.Vm.Applications.Single(a => a.DisplayName == "Google Chrome");
        var remaining = Assert.Single(chrome.Contents);
        Assert.Equal(AppDataContentKind.Data, remaining.Kind);

        // …and when the whole application folder goes, the application row goes with it.
        h.Ledger.Register(DeletionRecord(new DeletedEntry
        {
            Path = @"C:\Users\alice\AppData\Local\Google\Chrome",
            Kind = ScanItemKind.Directory,
            Bytes = 11L * 1024 * 1024 * 1024,
        }));
        h.Dispatcher.Pump();

        Assert.DoesNotContain(h.Vm.Applications, a => a.DisplayName == "Google Chrome");
        Assert.Single(h.Vm.Applications);
    }

    [Fact]
    public async Task Localised_explanations_reach_the_application_details()
    {
        using var h = new Harness();
        h.Scan.Result = ResultWith(SampleReport());

        await Task.Run(() => h.Scan.RaiseCompleted(h.Scan.Result));
        h.Dispatcher.Pump();

        var chrome = h.Vm.Applications.Single(a => a.DisplayName == "Google Chrome");

        // The sample report has no ExplanationKey, so the family fallback cannot fire;
        // the catalog-driven key is exercised end to end in the coverage tests instead.
        Assert.NotEmpty(chrome.Explanation);
    }
}
