using System.Globalization;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class OverviewViewModelTests
{
    private static readonly IValueFormatter Formatter = new ValueFormatter(CultureInfo.InvariantCulture);

    private static OverviewViewModel Create(
        FakeDriveService drives,
        FakeScanService scan,
        out NavigationService navigation,
        IUiDispatcher? dispatcher = null)
    {
        navigation = new NavigationService();
        return new OverviewViewModel(drives, scan, navigation, Formatter, dispatcher ?? new FakeUiDispatcher(), Loc.En);
    }

    private static ScanResult SampleResult() => new()
    {
        Mode = ScanMode.Deep,
        StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
        CompletedAtUtc = new DateTime(2026, 5, 1, 10, 4, 30, DateTimeKind.Utc),
        Statistics = new ScanStatistics
        {
            FilesScanned = 1_234_567,
            DirectoriesScanned = 98_765,
            BytesScanned = 412L * 1024 * 1024 * 1024,
            IssuesCount = 42,
        },
        PotentialCleanupBytes = (long)(28.6 * 1024 * 1024 * 1024),
        SafeBytes = (long)(12.4 * 1024 * 1024 * 1024),
        LargestDirectories =
        [
            new DirectoryAggregate { Path = @"C:\Users\alice\AppData\Local", Name = "Local", SubtreeBytes = 80L * 1024 * 1024 * 1024 },
        ],
        BytesByCategory = new Dictionary<ScanCategory, long>
        {
            [ScanCategory.TemporaryFiles] = 6L * 1024 * 1024 * 1024,
            [ScanCategory.BrowserCache] = 3L * 1024 * 1024 * 1024,
        },
        CountByCategory = new Dictionary<ScanCategory, int>
        {
            [ScanCategory.TemporaryFiles] = 1200,
            [ScanCategory.BrowserCache] = 300,
        },
    };

    [Fact]
    public void Lists_volumes_with_their_real_numbers()
    {
        var drives = new FakeDriveService();
        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100, "System"));
        drives.Drives.Add(FakeDriveService.Fixed(@"D:\", 1024, 700, "Data"));

        var vm = Create(drives, new FakeScanService(), out _);

        Assert.Equal(2, vm.Drives.Count);
        Assert.Equal("100.0 GB", vm.Drives[0].FreeText);
        Assert.Equal("512.0 GB", vm.Drives[0].TotalText);
        Assert.Equal("700.0 GB", vm.Drives[1].FreeText);

        // 800 GB free of 1536 GB total.
        Assert.Equal("800.0 GB", vm.CombinedFreeText);
        Assert.Contains("2 ready volume(s)", vm.DrivesSummaryText, StringComparison.Ordinal);
    }

    [Fact]
    public void Not_ready_volumes_are_shown_but_excluded_from_totals()
    {
        var drives = new FakeDriveService();
        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100));
        drives.Drives.Add(new DriveSnapshot { RootPath = @"E:\", DriveType = "Removable", IsReady = false });

        var vm = Create(drives, new FakeScanService(), out _);

        Assert.Equal(2, vm.Drives.Count);
        Assert.Equal("100.0 GB", vm.CombinedFreeText);
        Assert.False(vm.Drives[1].IsReady);
        Assert.Contains("1 ready volume(s)", vm.DrivesSummaryText, StringComparison.Ordinal);
    }

    [Fact]
    public void A_full_volume_is_flagged_as_critical()
    {
        var drives = new FakeDriveService();
        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 500, 10));   // 98% used

        var vm = Create(drives, new FakeScanService(), out _);

        Assert.True(vm.Drives[0].IsCritical);
        Assert.False(vm.Drives[0].IsWarning);
    }

    [Fact]
    public void Before_any_scan_the_dashboard_says_so()
    {
        var vm = Create(new FakeDriveService(), new FakeScanService(), out _);

        Assert.False(vm.HasLastScan);
        Assert.Equal("—", vm.PotentialCleanupText);
        Assert.Equal("No analysis has been run yet.", vm.LastScanSummaryText);
        Assert.Empty(vm.Categories);
    }

    [Fact]
    public void Completing_a_scan_updates_the_headline_numbers()
    {
        var scan = new FakeScanService();
        var vm = Create(new FakeDriveService(), scan, out _);

        scan.RaiseCompleted(SampleResult());

        Assert.True(vm.HasLastScan);
        Assert.Equal("28.6 GB", vm.PotentialCleanupText);
        Assert.Equal("12.4 GB", vm.SafeToCleanText);
        Assert.Contains(@"C:\Users\alice\AppData\Local", vm.BiggestDirectoryText, StringComparison.Ordinal);
        Assert.Contains("4m 30s", vm.LastScanSummaryText, StringComparison.Ordinal);
        Assert.Contains("1,234,567 files", vm.LastScanSummaryText, StringComparison.Ordinal);

        // Categories are ordered by size.
        Assert.Equal(2, vm.Categories.Count);
        Assert.Equal(ScanCategory.TemporaryFiles, vm.Categories[0].Category);
        Assert.Equal("6.0 GB", vm.Categories[0].SizeText);
        Assert.Equal("1,200", vm.Categories[0].CountText);
    }

    [Fact]
    public void A_cancelled_scan_is_labelled_as_partial()
    {
        var scan = new FakeScanService();
        var vm = Create(new FakeDriveService(), scan, out _);

        var sample = SampleResult();
        var result = new ScanResult
        {
            Mode = sample.Mode,
            StartedAtUtc = sample.StartedAtUtc,
            CompletedAtUtc = sample.CompletedAtUtc,
            Statistics = sample.Statistics with { WasCancelled = true },
            PotentialCleanupBytes = sample.PotentialCleanupBytes,
            SafeBytes = sample.SafeBytes,
            BytesByCategory = sample.BytesByCategory,
            CountByCategory = sample.CountByCategory,
        };
        scan.RaiseCompleted(result);

        Assert.Contains("Cancelled", vm.LastScanSummaryText, StringComparison.Ordinal);
        Assert.Contains("partial", vm.LastScanSummaryText, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task A_scan_completed_off_the_ui_thread_is_marshalled_before_touching_collections()
    {
        // Regression: ScanCompleted is raised on a thread-pool thread. Mutating the bound
        // ObservableCollection there makes WPF throw NotSupportedException and used to
        // surface as an unexplained "scan failed" dialog with nothing in the log.
        var dispatcher = new ManualUiDispatcher();
        var scan = new FakeScanService();
        var vm = Create(new FakeDriveService(), scan, out _, dispatcher);

        await Task.Run(() => scan.RaiseCompleted(SampleResult()));

        Assert.False(vm.HasLastScan);
        Assert.Empty(vm.Categories);
        Assert.Equal(1, dispatcher.PendingCount);

        dispatcher.Pump();

        Assert.True(vm.HasLastScan);
        Assert.Equal("28.6 GB", vm.PotentialCleanupText);
        Assert.Equal(2, vm.Categories.Count);
        Assert.Equal(0, dispatcher.PendingCount);
    }

    [Fact]
    public void Refresh_requeries_the_volume_list()
    {
        var drives = new FakeDriveService();
        var vm = Create(drives, new FakeScanService(), out _);
        Assert.Empty(vm.Drives);

        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100));
        vm.RefreshCommand.Execute(null);

        Assert.Single(vm.Drives);
    }

    [Fact]
    public void Dashboard_buttons_navigate_instead_of_duplicating_the_scan_page()
    {
        var vm = Create(new FakeDriveService(), new FakeScanService(), out var navigation);

        vm.GoToScanCommand.Execute(null);
        Assert.Equal(Section.Scan, navigation.Current);

        vm.GoToResultsCommand.Execute(null);
        Assert.Equal(Section.Results, navigation.Current);
    }
}
