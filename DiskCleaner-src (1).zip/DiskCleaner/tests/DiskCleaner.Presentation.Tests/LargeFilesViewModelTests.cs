using System.Globalization;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

/// <summary>
/// Phase 4 from the user's side: the Large Files screen explains where the space went
/// and lets the user open files and folders. It filters honestly (an unknown age never
/// matches an age filter), says what the chosen scan mode could not see, and never
/// offers anything for deletion.
/// </summary>
public class LargeFilesViewModelTests
{
    private const long Mb = 1024 * 1024;
    private const long Gb = 1024 * Mb;

    private static readonly DateTime Now = new(2026, 9, 30, 12, 0, 0, DateTimeKind.Utc);

    /// <summary>A shell where nothing can be opened: the screen must report it, not stay silent.</summary>
    private sealed class FailingShell : IShellService
    {
        public bool OpenFolder(string path) => false;

        public bool OpenFileLocation(string path) => false;

        public bool OpenFile(string path) => false;

        public bool OpenRecycleBin() => false;
    }

    private sealed class Fixture
    {
        public FakeScanService Scan { get; } = new();

        public AppSettings Settings { get; } = new() { LargeFileThresholdBytes = 100 * Mb };

        public FakeSettingsService SettingsService { get; }

        public FakeUiDispatcher Dispatcher { get; } = new();

        public FakeShellService Shell { get; } = new();

        public NavigationService Navigation { get; } = new(Section.LargeFiles);

        public ManualClock Clock { get; } = new(Now);

        public CleanupLedger Ledger { get; } = new();

        public StringLocalizer Localizer { get; } = new("ru");

        public IValueFormatter Formatter { get; } = new ValueFormatter(CultureInfo.InvariantCulture);

        public Fixture() => SettingsService = new FakeSettingsService(Settings);

        public LargeFilesViewModel CreateViewModel(IShellService? shell = null) => new(
            Scan,
            SettingsService,
            Formatter,
            Dispatcher,
            shell ?? Shell,
            Navigation,
            Clock,
            Ledger,
            Localizer);
    }

    private static ScanItem File(
        string path,
        long size,
        string? drive = @"C:\",
        DateTime? modified = null,
        ScanCategory category = ScanCategory.Unknown)
    {
        var name = path[(path.LastIndexOfAny(['\\', '/']) + 1)..];
        var dot = name.LastIndexOf('.');
        return new ScanItem
        {
            Path = path,
            Name = name,
            Kind = ScanItemKind.File,
            Size = size,
            Extension = dot > 0 ? name[dot..].ToLowerInvariant() : null,
            DriveRoot = drive,
            ModifiedAtUtc = modified,
            Category = category,
            SourceAnalyzer = "Test",
        };
    }

    private static ScanResult Result(
        ScanMode mode = ScanMode.Deep,
        ScanItem[]? files = null,
        DirectoryAggregate[]? directories = null,
        bool cancelled = false) => new()
        {
            Mode = mode,
            LargestFiles = files ?? [],
            LargestDirectories = directories ?? [],
            Statistics = new ScanStatistics { WasCancelled = cancelled },
        };

    private static DirectoryAggregate Agg(string path, long subtree, long own, string? parent, int files = 5)
    {
        var name = path.TrimEnd('\\') is { Length: > 0 } trimmed
            ? trimmed[(trimmed.LastIndexOf('\\') + 1)..]
            : path;
        return new DirectoryAggregate
        {
            Path = path,
            Name = name.Length > 0 ? name : path,
            SubtreeBytes = subtree,
            OwnBytes = own,
            SubtreeFileCount = files,
            OwnFileCount = files,
            Depth = parent is null ? 0 : 1,
            ParentPath = parent,
        };
    }

    // --------------------------------------------------------------- empty state

    [Fact]
    public void Before_any_scan_the_screen_is_an_honest_empty_state()
    {
        var vm = new Fixture().CreateViewModel();

        Assert.False(vm.HasData);
        Assert.Empty(vm.Files);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.Empty"), vm.EmptyText);
        Assert.False(string.IsNullOrWhiteSpace(vm.EmptyHintText));
    }

    [Fact]
    public void The_empty_state_sends_the_user_to_the_scan_section()
    {
        var fixture = new Fixture();
        var vm = fixture.CreateViewModel();

        vm.GoToScanCommand.Execute(null);

        Assert.Equal(Section.Scan, fixture.Navigation.Current);
    }

    [Fact]
    public void The_section_is_real_not_a_placeholder()
    {
        var vm = new Fixture().CreateViewModel();

        Assert.True(vm.IsImplemented);
        Assert.Null(vm.ImplementationPhase);
        Assert.Null(vm.PlannedContent);
    }

    // --------------------------------------------------------------- data flow

    [Fact]
    public void An_existing_scan_result_is_picked_up_on_construction_largest_first()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\a.iso", 500 * Mb),
            File(@"C:\data\b.vhdx", 900 * Mb),
            File(@"C:\data\c.log", 120 * Mb),
        ]));

        var vm = fixture.CreateViewModel();

        Assert.True(vm.HasData);
        Assert.Equal(["b.vhdx", "a.iso", "c.log"], [.. vm.Files.Select(f => f.Name)]);
    }

    [Fact]
    public void A_scan_finishing_later_repopulates_the_screen_through_the_dispatcher()
    {
        var fixture = new Fixture();
        var vm = fixture.CreateViewModel();
        Assert.False(vm.HasData);

        fixture.Scan.RaiseCompleted(Result(files: [File(@"C:\data\big.iso", 2 * Gb)]));

        Assert.True(vm.HasData);
        Assert.Single(vm.Files);
        Assert.True(fixture.Dispatcher.PostedCount >= 1);
    }

    // --------------------------------------------------------------- filters

    [Fact]
    public void Minimum_size_defaults_to_the_settings_threshold()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\big.iso", 500 * Mb),
            File(@"C:\Temp\small.tmp", 50 * Mb),   // below the 100 MB threshold
        ]));

        var vm = fixture.CreateViewModel();

        Assert.Equal(100 * Mb, vm.SelectedMinSize!.Value);
        Assert.Single(vm.Files);
        Assert.Equal("big.iso", vm.Files[0].Name);
    }

    [Fact]
    public void Choosing_any_size_shows_smaller_candidates_too()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\big.iso", 500 * Mb),
            File(@"C:\Temp\small.tmp", 50 * Mb),
        ]));
        var vm = fixture.CreateViewModel();

        vm.SelectedMinSize = vm.MinSizeOptions.First(o => o.Value == 0);

        Assert.Equal(2, vm.Files.Count);
    }

    [Fact]
    public void Size_options_are_ordered_and_label_the_settings_threshold()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result());
        var vm = fixture.CreateViewModel();

        Assert.Equal(
            [0L, 100 * Mb, Gb, 4 * Gb],
            vm.MinSizeOptions.Select(o => o.Value).ToArray());

        var thresholdOption = vm.MinSizeOptions.First(o => o.Value == 100 * Mb);
        Assert.Equal(
            fixture.Localizer.Format("S.LargeFiles.Filter.SettingsThreshold", fixture.Formatter.Bytes(100 * Mb)),
            thresholdOption.Display);
    }

    [Fact]
    public void Changing_the_threshold_in_settings_retunes_the_screen()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\big.iso", 500 * Mb),
            File(@"C:\data\mid.bin", 300 * Mb),
        ]));
        var vm = fixture.CreateViewModel();
        Assert.Equal(2, vm.Files.Count);

        fixture.SettingsService.Update(s => s.LargeFileThresholdBytes = 400 * Mb);

        Assert.Equal(400 * Mb, vm.SelectedMinSize!.Value);
        Assert.Single(vm.Files);
        Assert.Equal("big.iso", vm.Files[0].Name);
    }

    [Fact]
    public void Volume_filter_keeps_only_the_chosen_volume()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\one.iso", 500 * Mb, drive: @"C:\"),
            File(@"D:\data\two.iso", 600 * Mb, drive: @"D:\"),
            File(@"C:\data\novolume.iso", 700 * Mb, drive: null),
        ]));
        var vm = fixture.CreateViewModel();

        Assert.Equal(
            ["*", @"C:\", @"D:\"],
            vm.VolumeOptions.Select(o => o.Value ?? "*").ToArray());
        Assert.Equal(3, vm.Files.Count);

        vm.SelectedVolume = vm.VolumeOptions.First(o => o.Value == @"D:\");

        Assert.Single(vm.Files);
        Assert.Equal("two.iso", vm.Files[0].Name);
    }

    [Theory]
    [InlineData("iso")]
    [InlineData("ISO")]
    [InlineData(".iso")]
    [InlineData("*.iso")]
    public void Extension_filter_is_forgiving_about_format(string typed)
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\movie.ISO", 2 * Gb),
            File(@"C:\data\notes.txt", 300 * Mb),
        ]));
        var vm = fixture.CreateViewModel();

        vm.ExtensionFilterText = typed;

        Assert.Single(vm.Files);
        Assert.Equal("movie.ISO", vm.Files[0].Name);

        vm.ExtensionFilterText = string.Empty;
        Assert.Equal(2, vm.Files.Count);
    }

    [Fact]
    public void Category_filter_lists_only_categories_that_are_present()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\Temp\one.tmp", 500 * Mb, category: ScanCategory.TemporaryFiles),
            File(@"C:\logs\two.log", 400 * Mb, category: ScanCategory.Logs),
            File(@"C:\data\three.bin", 300 * Mb, category: ScanCategory.Logs),
        ]));
        var vm = fixture.CreateViewModel();

        // "All categories" + Logs + TemporaryFiles, in enum order.
        Assert.Equal(
            ["*", "TemporaryFiles", "Logs"],
            vm.CategoryOptions.Select(o => o.Value?.ToString() ?? "*").ToArray());

        vm.SelectedCategory = vm.CategoryOptions.First(o => o.Value == ScanCategory.Logs);

        Assert.Equal(2, vm.Files.Count);
        Assert.All(vm.Files, f => Assert.Equal(ScanCategory.Logs, f.Category));
    }

    [Fact]
    public void Age_filter_never_matches_a_file_with_an_unknown_date()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\recent.iso", 500 * Mb, modified: Now.AddDays(-5)),
            File(@"C:\data\old.iso", 400 * Mb, modified: Now.AddDays(-40)),
            File(@"C:\data\unknown.iso", 300 * Mb, modified: null),
        ]));
        var vm = fixture.CreateViewModel();

        vm.SelectedAge = vm.AgeOptions.First(o => o.Value == LargeFileAgeFilter.Last30Days);
        Assert.Equal(["recent.iso"], [.. vm.Files.Select(f => f.Name)]);

        vm.SelectedAge = vm.AgeOptions.First(o => o.Value == LargeFileAgeFilter.OlderThanYear);
        Assert.Empty(vm.Files);

        vm.SelectedAge = vm.AgeOptions.First(o => o.Value == LargeFileAgeFilter.LastYear);
        Assert.Equal(["recent.iso", "old.iso"], [.. vm.Files.Select(f => f.Name)]);
    }

    [Fact]
    public void Reset_filters_restores_the_defaults()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\movie.iso", 2 * Gb, drive: @"C:\", modified: Now.AddDays(-1)),
            File(@"D:\data\backup.vhdx", 3 * Gb, drive: @"D:\", modified: Now.AddDays(-400), category: ScanCategory.Logs),
        ]));
        var vm = fixture.CreateViewModel();

        vm.SelectedVolume = vm.VolumeOptions.First(o => o.Value == @"D:\");
        vm.SelectedMinSize = vm.MinSizeOptions.First(o => o.Value == 0);
        vm.SelectedAge = vm.AgeOptions.First(o => o.Value == LargeFileAgeFilter.Last7Days);
        vm.SelectedCategory = vm.CategoryOptions.First(o => o.Value == ScanCategory.Logs);
        vm.ExtensionFilterText = "iso";
        Assert.Empty(vm.Files);

        vm.ResetFiltersCommand.Execute(null);

        Assert.Null(vm.SelectedVolume!.Value);
        Assert.Equal(100 * Mb, vm.SelectedMinSize!.Value);
        Assert.Equal(LargeFileAgeFilter.Any, vm.SelectedAge!.Value);
        Assert.Null(vm.SelectedCategory!.Value);
        Assert.Equal(string.Empty, vm.ExtensionFilterText);
        Assert.Equal(2, vm.Files.Count);
    }

    // --------------------------------------------------------------- honest texts

    [Fact]
    public void Summary_reports_shown_total_and_bytes()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\a.iso", 500 * Mb),
            File(@"C:\data\b.iso", 300 * Mb),
            File(@"C:\data\tiny.tmp", 10 * Mb),   // below threshold, counted in the total
        ]));
        var vm = fixture.CreateViewModel();

        var expected = fixture.Localizer.Format(
            "S.LargeFiles.Summary",
            fixture.Formatter.Count(2),
            fixture.Formatter.Count(3),
            fixture.Formatter.Bytes(800 * Mb));

        Assert.Equal(expected, vm.FileSummaryText);
        Assert.Equal(expected, vm.StatusText);
    }

    [Fact]
    public void The_scan_mode_note_says_what_could_not_be_seen()
    {
        var quick = new Fixture();
        quick.Scan.RaiseCompleted(Result(ScanMode.Quick));
        var quickVm = quick.CreateViewModel();
        Assert.True(quickVm.HasScanNote);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.Note.Quick"), quickVm.ScanNoteText);

        var deep = new Fixture();
        deep.Scan.RaiseCompleted(Result(ScanMode.Deep));
        var deepVm = deep.CreateViewModel();
        Assert.False(deepVm.HasScanNote);

        var stopped = new Fixture();
        stopped.Scan.RaiseCompleted(Result(ScanMode.Deep, cancelled: true));
        var stoppedVm = stopped.CreateViewModel();
        Assert.True(stoppedVm.HasScanNote);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.Note.Cancelled"), stoppedVm.ScanNoteText);
    }

    [Fact]
    public void Empty_list_distinguishes_bad_filters_from_an_empty_scan()
    {
        var filtered = new Fixture();
        filtered.Scan.RaiseCompleted(Result(files: [File(@"C:\data\a.iso", 500 * Mb)]));
        var filteredVm = filtered.CreateViewModel();
        filteredVm.SelectedMinSize = filteredVm.MinSizeOptions.First(o => o.Value == 4 * Gb);
        Assert.True(filteredVm.FilesEmptyAfterFilter);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.NoMatches"), filteredVm.NoMatchesText);

        var empty = new Fixture();
        empty.Scan.RaiseCompleted(Result(files: []));
        var emptyVm = empty.CreateViewModel();
        Assert.True(emptyVm.FilesEmptyAfterFilter);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.NoFiles"), emptyVm.NoMatchesText);
    }

    [Fact]
    public void Age_text_is_bucketed_and_unknown_stays_unknown()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\data\today.iso", 600 * Mb, modified: Now.AddHours(-3)),
            File(@"C:\data\days.iso", 500 * Mb, modified: Now.AddDays(-10)),
            File(@"C:\data\months.iso", 400 * Mb, modified: Now.AddDays(-100)),
            File(@"C:\data\years.iso", 300 * Mb, modified: Now.AddDays(-800)),
            File(@"C:\data\unknown.iso", 200 * Mb, modified: null),
        ]));
        var vm = fixture.CreateViewModel();

        var ru = fixture.Localizer;
        var byName = vm.Files.ToDictionary(f => f.Name);
        Assert.Equal(ru.Get("S.LargeFiles.Age.Today"), byName["today.iso"].AgeText);
        Assert.Equal(ru.Format("S.LargeFiles.Age.DaysAgo", 10), byName["days.iso"].AgeText);
        Assert.Equal(ru.Format("S.LargeFiles.Age.MonthsAgo", 3), byName["months.iso"].AgeText);
        Assert.Equal(ru.Format("S.LargeFiles.Age.YearsAgo", 2), byName["years.iso"].AgeText);
        Assert.Equal(ru.Get("S.LargeFiles.Age.Unknown"), byName["unknown.iso"].AgeText);
    }

    // --------------------------------------------------------------- actions

    [Fact]
    public void Open_actions_go_through_the_shell_service()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(
            files: [File(@"C:\data\movie.iso", 2 * Gb)],
            directories: [Agg(@"C:\data", 2 * Gb, 2 * Gb, null)]));
        var vm = fixture.CreateViewModel();

        vm.OpenFileCommand.Execute(vm.Files[0]);
        vm.OpenLocationCommand.Execute(vm.Files[0]);
        vm.OpenDirectoryCommand.Execute(vm.DirectoryRoots[0]);

        Assert.Equal(
            ["file:C:\\data\\movie.iso", "location:C:\\data\\movie.iso", "folder:C:\\data"],
            fixture.Shell.Opened);
    }

    [Fact]
    public void A_failed_open_is_reported_instead_of_swallowed()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files: [File(@"C:\data\gone.iso", 2 * Gb)]));
        var vm = fixture.CreateViewModel(new FailingShell());

        vm.OpenFileCommand.Execute(vm.Files[0]);

        Assert.Equal(Loc.Ru.Get("S.LargeFiles.OpenFailed"), vm.StatusText);
    }

    [Fact]
    public void Null_parameters_do_not_crash_the_open_commands()
    {
        var fixture = new Fixture();
        var vm = fixture.CreateViewModel();

        vm.OpenFileCommand.Execute(null);
        vm.OpenLocationCommand.Execute(null);
        vm.OpenDirectoryCommand.Execute(null);

        Assert.Empty(fixture.Shell.Opened);
    }

    // --------------------------------------------------------------- directory map

    [Fact]
    public void The_directory_tree_links_parents_and_promotes_orphans_to_roots()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(directories:
        [
            Agg(@"C:\Users\alice", 30 * Gb, 10 * Gb, @"C:\Users"),
            Agg(@"C:\Windows", 60 * Gb, 20 * Gb, @"C:\"),
            Agg(@"C:\", 100 * Gb, 1 * Gb, null),
            Agg(@"D:\Data", 200 * Gb, 200 * Gb, null),
            Agg(@"C:\deep\leaf", 50 * Gb, 50 * Gb, @"C:\deep"),   // parent outside the top-N cut
            Agg(@"C:\Users", 40 * Gb, 5 * Gb, @"C:\"),
        ]));
        var vm = fixture.CreateViewModel();

        Assert.True(vm.HasDirectories);

        // Roots: subtree size descending; the orphan is a root of its own subtree.
        Assert.Equal([@"D:\Data", @"C:\", @"C:\deep\leaf"], [.. vm.DirectoryRoots.Select(n => n.Path)]);

        var c = vm.DirectoryRoots[1];
        Assert.Equal([@"C:\Windows", @"C:\Users"], [.. c.Children.Select(n => n.Path)]);
        Assert.Single(c.Children[1].Children);
        Assert.Equal(@"C:\Users\alice", c.Children[1].Children[0].Path);

        // Subtree vs own bytes stay visibly different — the whole point of the map.
        Assert.Equal(fixture.Formatter.Bytes(100 * Gb), c.SubtreeSizeText);
        Assert.Equal(
            fixture.Localizer.Format("S.LargeFiles.Tree.Own", fixture.Formatter.Bytes(1 * Gb)),
            c.OwnSizeText);
    }

    [Fact]
    public void A_quick_scan_explains_why_there_is_no_directory_map()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(ScanMode.Quick, directories: []));
        var vm = fixture.CreateViewModel();

        Assert.False(vm.HasDirectories);
        Assert.Empty(vm.DirectoryRoots);
        Assert.Equal(Loc.Ru.Get("S.LargeFiles.Tree.Empty"), vm.DirectoryNoteText);
    }

    // --------------------------------------------------------------- localisation

    [Fact]
    public void Switching_language_rebuilds_labels_and_keeps_the_filters()
    {
        var fixture = new Fixture();
        fixture.Scan.RaiseCompleted(Result(files:
        [
            File(@"C:\Temp\one.tmp", 500 * Mb, category: ScanCategory.TemporaryFiles),
            File(@"D:\data\two.iso", 2 * Gb, drive: @"D:\"),
        ]));
        var vm = fixture.CreateViewModel();

        vm.SelectedVolume = vm.VolumeOptions.First(o => o.Value == @"D:\");
        vm.SelectedMinSize = vm.MinSizeOptions.First(o => o.Value == 0);

        fixture.Localizer.SetLanguage("en");

        Assert.Equal("All volumes", vm.VolumeOptions[0].Display);
        Assert.Equal(@"D:\", vm.SelectedVolume!.Value);          // selection survived
        Assert.Equal(0L, vm.SelectedMinSize!.Value);
        Assert.Equal("Any size", vm.MinSizeOptions[0].Display);
        Assert.Equal(Loc.En.Get("S.LargeFiles.Empty"), vm.EmptyText);
        Assert.Equal(
            Loc.En.Get(ScanItemViewModel.CategoryKey(ScanCategory.TemporaryFiles)),
            vm.CategoryOptions.First(o => o.Value == ScanCategory.TemporaryFiles).Display);
    }
}
