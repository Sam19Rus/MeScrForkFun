using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class MainViewModelTests
{
    private static (MainViewModel Vm, NavigationService Nav, TestSectionViewModel[] Sections) CreateShell()
    {
        var sections = new[]
        {
            new TestSectionViewModel(Section.Settings, "S.Nav.Settings"),
            new TestSectionViewModel(Section.Overview, "S.Nav.Overview"),
            new TestSectionViewModel(Section.Scan, "S.Nav.Scan", busy: true),
        };

        var navigation = new NavigationService();
        var vm = new MainViewModel(
            sections,
            navigation,
            new FakeUiDispatcher(),
            new FakePrivilegeService(),
            new FakeScanService(),
            Loc.En);

        return (vm, navigation, sections);
    }

    [Fact]
    public void Sections_are_ordered_by_their_enum_value()
    {
        var (vm, _, _) = CreateShell();

        Assert.Equal(
            [Section.Overview, Section.Scan, Section.Settings],
            vm.Sections.Select(s => s.Section).ToArray());
    }

    [Fact]
    public void Starts_on_overview_and_marks_it_active()
    {
        var (vm, _, sections) = CreateShell();

        Assert.Equal(Section.Overview, vm.CurrentSection!.Section);
        Assert.True(vm.CurrentSection.IsActive);
        Assert.Equal("Overview", vm.CurrentSectionTitle);
        Assert.Equal(1, sections[1].NavigatedToCount);
    }

    [Fact]
    public void Selecting_a_section_updates_the_navigation_service()
    {
        var (vm, navigation, sections) = CreateShell();

        vm.CurrentSection = sections[0];      // Settings

        Assert.Equal(Section.Settings, navigation.Current);
        Assert.Equal(1, sections[0].NavigatedToCount);
        Assert.Equal(1, sections[1].NavigatedFromCount);
        Assert.False(sections[1].IsActive);
    }

    [Fact]
    public void Programmatic_navigation_reflects_in_the_rail()
    {
        var (vm, navigation, _) = CreateShell();

        navigation.Navigate(Section.Scan);

        Assert.Equal(Section.Scan, vm.CurrentSection!.Section);
        Assert.Equal("Scan", vm.CurrentSectionTitle);
    }

    [Fact]
    public void IsBusy_is_true_while_any_section_is_working()
    {
        var (vm, _, sections) = CreateShell();

        Assert.True(vm.IsBusy);                       // the Scan section reports busy
        Assert.False(sections[1].IsBusy);             // Overview does not
    }

    [Fact]
    public void Elevation_state_is_surfaced_to_the_shell()
    {
        var privileges = new FakePrivilegeService { IsElevated = true };
        var vm = new MainViewModel(
            [new TestSectionViewModel(Section.Overview)],
            new NavigationService(),
            new FakeUiDispatcher(),
            privileges,
            new FakeScanService(),
            Loc.En);

        Assert.True(vm.IsElevated);
        Assert.Contains("administrator", vm.ElevationText, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Status_bar_reports_a_pending_section_honestly()
    {
        // Large Files graduated in phase 4; App Leftovers is the remaining placeholder.
        var pending = new AppLeftoversViewModel(Loc.En);
        var vm = new MainViewModel(
            [pending],
            new NavigationService(Section.Overview),
            new FakeUiDispatcher(),
            new FakePrivilegeService(),
            new FakeScanService(),
            Loc.En);

        vm.CurrentSection = pending;

        Assert.True(vm.CurrentSectionIsPending);
        Assert.Contains("phase 7", vm.StatusText, StringComparison.OrdinalIgnoreCase);
        Assert.False(string.IsNullOrWhiteSpace(pending.PlannedContent));
    }
}
