using System.Globalization;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Moving;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

/// <summary>
/// The mover screen from the user's side: discovery, an explicit confirmation with the
/// real numbers, translated refusals, and a result that never claims more than happened.
/// </summary>
public class AppMoverViewModelTests
{
    private const string Programs = @"C:\Users\alice\AppData\Local\Programs";
    private const string Ollama = Programs + @"\Ollama";

    private sealed class FakeAppMover : IAppMover
    {
        public string? DefaultRoot => Programs;

        public List<MovableApplication> Apps { get; set; } = [];

        public AppMoveValidation Validation { get; set; } =
            AppMoveValidation.Ok(2_000, 500_000, @"D:\MovedApps\Ollama");

        public AppMoveRecord MoveResult { get; set; } = new()
        {
            SourcePath = Ollama,
            DestinationPath = @"D:\MovedApps\Ollama",
            Succeeded = true,
            Bytes = 2_000,
            Files = 12,
            StartedAtUtc = DateTime.UtcNow,
            CompletedAtUtc = DateTime.UtcNow.AddSeconds(3),
            FinalPhase = AppMovePhase.Completed,
            LinkCreated = true,
        };

        public AppMoveRecord MoveBackResult { get; set; } = new()
        {
            SourcePath = @"D:\MovedApps\Ollama",
            DestinationPath = Ollama,
            Succeeded = true,
            Bytes = 2_000,
            Files = 12,
            StartedAtUtc = DateTime.UtcNow,
            CompletedAtUtc = DateTime.UtcNow.AddSeconds(2),
            FinalPhase = AppMovePhase.Completed,
        };

        public List<(string Source, string Destination)> MoveCalls { get; } = [];

        public List<string> MoveBackCalls { get; } = [];

        public int DiscoveryCalls { get; private set; }

        /// <summary>When set, <see cref="MoveAsync"/> blocks on it — for busy-state tests.</summary>
        public TaskCompletionSource? Gate { get; set; }

        public Task<IReadOnlyList<MovableApplication>> DiscoverAsync(string? rootDirectory = null, CancellationToken cancellationToken = default)
        {
            DiscoveryCalls++;
            return Task.FromResult<IReadOnlyList<MovableApplication>>(Apps);
        }

        public Task<AppMoveValidation> ValidateMoveAsync(string sourcePath, string destinationDirectory, CancellationToken cancellationToken = default) =>
            Task.FromResult(Validation);

        public async Task<AppMoveRecord> MoveAsync(string sourcePath, string destinationDirectory, IProgress<AppMoveProgress>? progress = null, CancellationToken cancellationToken = default)
        {
            MoveCalls.Add((sourcePath, destinationDirectory));
            progress?.Report(new AppMoveProgress { Phase = AppMovePhase.Copying, BytesCopied = 1_000, TotalBytes = 2_000, FilesCopied = 6, TotalFiles = 12 });

            if (Gate is { } gate)
            {
                await gate.Task.ConfigureAwait(false);
            }

            return MoveResult;
        }

        public Task<AppMoveRecord> MoveBackAsync(string linkPath, IProgress<AppMoveProgress>? progress = null, CancellationToken cancellationToken = default)
        {
            MoveBackCalls.Add(linkPath);
            return Task.FromResult(MoveBackResult);
        }
    }

    private sealed class Harness
    {
        public Harness(IStringLocalizer? localizer = null)
        {
            Mover = new FakeAppMover
            {
                Apps =
                [
                    new MovableApplication { Name = "Ollama", Path = Ollama, Bytes = 2_000, FileCount = 12 },
                    new MovableApplication
                    {
                        Name = "VSCode",
                        Path = Programs + @"\Microsoft VS Code",
                        Bytes = 900,
                        FileCount = 40,
                        IsAlreadyMoved = true,
                        LinkTarget = @"D:\MovedApps\Microsoft VS Code",
                    },
                ],
            };
            Drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 40));
            Drives.Drives.Add(FakeDriveService.Fixed(@"D:\", 1024, 700));
            Localizer = localizer ?? Loc.En;
            Vm = new AppMoverViewModel(Mover, Drives, Dialogs, Shell, Formatter, Localizer);
        }

        public FakeAppMover Mover { get; }
        public FakeDriveService Drives { get; } = new();
        public FakeDialogService Dialogs { get; } = new();
        public FakeShellService Shell { get; } = new();
        public IStringLocalizer Localizer { get; }
        public AppMoverViewModel Vm { get; }

        public static IValueFormatter Formatter { get; } = new ValueFormatter(CultureInfo.InvariantCulture);
    }

    [Fact]
    public async Task Navigating_to_the_section_discovers_applications_once()
    {
        var h = new Harness();

        await h.Vm.OnNavigatedToAsync();

        Assert.Equal(1, h.Mover.DiscoveryCalls);
        Assert.Equal(2, h.Vm.Apps.Count);
        Assert.True(h.Vm.HasApps);

        var moved = h.Vm.Apps.Single(a => a.Name == "VSCode");
        Assert.True(moved.IsAlreadyMoved);
        Assert.Contains(@"D:\MovedApps", moved.StateText, StringComparison.Ordinal);

        // A second navigation must not rescan the disk.
        await h.Vm.OnNavigatedToAsync();
        Assert.Equal(1, h.Mover.DiscoveryCalls);
    }

    [Fact]
    public void The_destination_defaults_to_a_folder_on_the_non_system_volume()
    {
        var h = new Harness();

        Assert.Equal(@"D:\", h.Vm.SelectedVolume?.RootPath);
        Assert.Equal(@"D:\MovedApps", h.Vm.DestinationDirectory);
    }

    [Fact]
    public async Task Moving_asks_once_and_shows_the_real_numbers()
    {
        var h = new Harness();
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        var prompt = Assert.Single(h.Dialogs.ConfirmPrompts);
        Assert.Contains("Ollama", prompt, StringComparison.Ordinal);
        Assert.Contains(@"D:\MovedApps\Ollama", prompt, StringComparison.Ordinal);
        Assert.Contains("Close the application", prompt, StringComparison.Ordinal);

        Assert.Equal((Ollama, @"D:\MovedApps"), h.Mover.MoveCalls.Single());
        Assert.True(h.Vm.HasResult);
        Assert.False(h.Vm.ResultIsError);
        Assert.Contains("Move completed", h.Vm.ResultText, StringComparison.Ordinal);
        Assert.Contains("2.0 KB", h.Vm.ResultText, StringComparison.Ordinal);
        Assert.False(h.Vm.IsWorking);
        Assert.False(h.Vm.IsBusy);
    }

    [Fact]
    public async Task Declining_the_confirmation_moves_nothing()
    {
        var h = new Harness();
        h.Dialogs.ConfirmResult = false;
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        Assert.Empty(h.Mover.MoveCalls);
        Assert.False(h.Vm.HasResult);
    }

    [Fact]
    public async Task A_refused_move_shows_the_translated_reason_and_touches_nothing()
    {
        var h = new Harness();
        h.Mover.Validation = AppMoveValidation.Fail("move.same-volume");
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        Assert.Empty(h.Mover.MoveCalls);
        Assert.True(h.Vm.ResultIsError);
        Assert.Contains("different drives", h.Vm.ResultText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task Russian_ui_shows_russian_refusals()
    {
        var h = new Harness(Loc.Ru);
        h.Mover.Validation = new AppMoveValidation
        {
            IsValid = false,
            ReasonKey = "move.not-enough-space",
            RequiredBytes = 5_000,
            AvailableBytes = 1_000,
        };
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        Assert.Contains("не хватает места", h.Vm.ResultText, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Нужно", h.Vm.ResultText, StringComparison.Ordinal);
        Assert.DoesNotContain("move.not-enough-space", h.Vm.ResultText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task An_already_moved_app_can_be_moved_back_and_nothing_else()
    {
        var h = new Harness();
        await h.Vm.OnNavigatedToAsync();

        var moved = h.Vm.Apps.First(a => a.Name == "VSCode");
        h.Vm.SelectedApp = moved;

        Assert.False(h.Vm.MoveCommand.CanExecute(null));
        Assert.True(h.Vm.MoveBackCommand.CanExecute(null));

        await h.Vm.MoveBackCommand.ExecuteAsync(null);

        Assert.Equal(moved.Path, Assert.Single(h.Mover.MoveBackCalls));
        Assert.True(h.Vm.HasResult);
        Assert.False(h.Vm.ResultIsError);
    }

    [Fact]
    public async Task A_failed_move_that_rolled_back_says_that_nothing_changed()
    {
        var h = new Harness();
        h.Mover.MoveResult = h.Mover.MoveResult with
        {
            Succeeded = false,
            FinalPhase = AppMovePhase.Failed,
            FailureReasonKey = "move.copy-failed",
            FailureDetails = @"C:\...\ollama.exe: sharing violation",
            RolledBack = true,
        };
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        Assert.True(h.Vm.ResultIsError);
        Assert.Contains("Nothing changed", h.Vm.ResultText, StringComparison.Ordinal);
        Assert.Contains("ollama.exe", h.Vm.ResultText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task When_only_the_destination_copy_survives_the_result_points_at_it()
    {
        var h = new Harness();
        h.Mover.MoveResult = h.Mover.MoveResult with
        {
            Succeeded = false,
            FinalPhase = AppMovePhase.Failed,
            FailureReasonKey = "move.link-failed-data-safe",
            DataAtDestinationOnly = true,
        };
        await h.Vm.OnNavigatedToAsync();

        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");
        await h.Vm.MoveCommand.ExecuteAsync(null);

        Assert.True(h.Vm.ResultIsError);
        Assert.Contains("ATTENTION", h.Vm.ResultText, StringComparison.Ordinal);
        Assert.Contains(@"D:\MovedApps\Ollama", h.Vm.ResultText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task The_section_reports_busy_while_a_move_runs_so_the_shell_asks_before_closing()
    {
        var h = new Harness();
        await h.Vm.OnNavigatedToAsync();
        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");

        // Block inside the mover so "busy" can be observed deterministically.
        h.Mover.Gate = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

        var running = h.Vm.MoveCommand.ExecuteAsync(null);

        var spins = 0;
        while (!h.Vm.IsBusy && spins++ < 10_000)
        {
            await Task.Yield();
        }

        Assert.True(h.Vm.IsBusy);
        Assert.False(h.Vm.MoveCommand.CanExecute(null), "controls must be disabled while a move runs");

        h.Mover.Gate.SetResult();
        await running;

        Assert.False(h.Vm.IsBusy);
        Assert.True(h.Vm.MoveCommand.CanExecute(null));
    }

    [Fact]
    public async Task Refresh_rediscovers_and_keeps_the_selection()
    {
        var h = new Harness();
        await h.Vm.OnNavigatedToAsync();
        h.Vm.SelectedApp = h.Vm.Apps.First(a => a.Name == "Ollama");

        await h.Vm.RefreshCommand.ExecuteAsync(null);

        Assert.Equal(2, h.Mover.DiscoveryCalls);
        Assert.Equal("Ollama", h.Vm.SelectedApp?.Name);
    }
}
