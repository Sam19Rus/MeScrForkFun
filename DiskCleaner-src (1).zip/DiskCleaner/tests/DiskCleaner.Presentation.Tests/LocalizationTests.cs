using System.Text.RegularExpressions;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

/// <summary>
/// Localisation is user-visible surface area: a missing key renders as an empty label,
/// which is exactly the kind of defect that survives code review and shows up only on
/// a screen nobody looked at. These tests make that impossible.
/// </summary>
public class LocalizationTests
{
    [Fact]
    public void Russian_and_english_tables_have_exactly_the_same_keys()
    {
        var ru = StringTable.Ru.Keys.ToHashSet(StringComparer.Ordinal);
        var en = StringTable.En.Keys.ToHashSet(StringComparer.Ordinal);

        var onlyRu = ru.Except(en).OrderBy(k => k).ToArray();
        var onlyEn = en.Except(ru).OrderBy(k => k).ToArray();

        Assert.True(onlyRu.Length == 0, "keys present only in ru: " + string.Join(", ", onlyRu));
        Assert.True(onlyEn.Length == 0, "keys present only in en: " + string.Join(", ", onlyEn));
        Assert.True(ru.Count > 100, $"expected a substantial string table, found {ru.Count} keys");
    }

    [Fact]
    public void Every_key_is_namespaced_and_every_value_is_non_empty()
    {
        foreach (var (key, value) in StringTable.Ru.Concat(StringTable.En))
        {
            Assert.StartsWith("S.", key, StringComparison.Ordinal);
            Assert.False(string.IsNullOrWhiteSpace(value), $"empty value for {key}");
            Assert.DoesNotContain("{DynamicResource", value, StringComparison.Ordinal);
        }
    }

    [Fact]
    public void Format_placeholders_match_between_languages()
    {
        foreach (var (key, ruValue) in StringTable.Ru)
        {
            var enValue = StringTable.En[key];
            var ruPlaceholders = Placeholders(ruValue);
            var enPlaceholders = Placeholders(enValue);

            Assert.True(
                ruPlaceholders.SequenceEqual(enPlaceholders),
                $"{key}: ru placeholders [{string.Join(",", ruPlaceholders)}] != en [{string.Join(",", enPlaceholders)}]");
        }
    }

    [Fact]
    public void Every_resource_key_referenced_from_xaml_exists_in_the_table()
    {
        var root = FindRepositoryRoot();
        var used = new SortedSet<string>(StringComparer.Ordinal);

        foreach (var file in Directory.EnumerateFiles(Path.Combine(root, "src"), "*.xaml", SearchOption.AllDirectories))
        {
            foreach (Match match in Regex.Matches(File.ReadAllText(file), @"(?:DynamicResource|StaticResource)\s+(S\.[A-Za-z0-9_.]+)"))
            {
                var key = match.Groups[1].Value;

                // A trailing dot means the key is built by concatenation at runtime
                // (S.Reason.<reasonKey>, resolved from Core data), not a literal key.
                if (key.EndsWith('.'))
                {
                    continue;
                }

                used.Add(key);
            }
        }

        Assert.True(used.Count > 50, $"expected the views to reference many strings, found {used.Count}");

        var missingRu = used.Where(k => !StringTable.Ru.ContainsKey(k)).ToArray();
        var missingEn = used.Where(k => !StringTable.En.ContainsKey(k)).ToArray();

        Assert.True(missingRu.Length == 0, "missing in ru: " + string.Join(", ", missingRu));
        Assert.True(missingEn.Length == 0, "missing in en: " + string.Join(", ", missingEn));
    }

    [Fact]
    public void Every_key_used_by_view_models_exists_in_the_table()
    {
        var root = FindRepositoryRoot();
        var used = new SortedSet<string>(StringComparer.Ordinal);

        var sources = Directory
            .EnumerateFiles(Path.Combine(root, "src", "DiskCleaner.Presentation"), "*.cs", SearchOption.AllDirectories)
            .Concat(Directory.EnumerateFiles(Path.Combine(root, "src", "DiskCleaner.App"), "*.cs", SearchOption.AllDirectories));

        foreach (var file in sources)
        {
            foreach (Match match in Regex.Matches(File.ReadAllText(file), @"(?:Get|Format)\(\s*""(S\.[A-Za-z0-9_.]+)"""))
            {
                var key = match.Groups[1].Value;

                // A trailing dot means the key is composed at runtime from Core data
                // (S.Reason.<reasonKey>), so it is not a literal key to look up.
                if (key.EndsWith('.'))
                {
                    continue;
                }

                used.Add(key);
            }
        }

        Assert.True(used.Count > 10, $"expected view models to resolve string keys, found {used.Count}");

        var missing = used.Where(k => !StringTable.Ru.ContainsKey(k) || !StringTable.En.ContainsKey(k)).ToArray();
        Assert.True(missing.Length == 0, "missing keys: " + string.Join(", ", missing));
    }

    [Fact]
    public void No_hardcoded_ui_text_remains_in_the_views()
    {
        var root = FindRepositoryRoot();
        var offenders = new List<string>();

        foreach (var file in Directory.EnumerateFiles(Path.Combine(root, "src", "DiskCleaner.App", "Views"), "*.xaml", SearchOption.AllDirectories))
        {
            var lines = File.ReadAllLines(file);
            for (var i = 0; i < lines.Length; i++)
            {
                foreach (Match match in Regex.Matches(lines[i], @"(?:Text|Content|ToolTip|Header)=""([^""]{2,})"""))
                {
                    var value = match.Groups[1].Value;
                    var isDynamic = value.Contains("DynamicResource") || value.Contains("Binding") || value.StartsWith("&#");
                    // The brand name is intentionally not translated.
                    var isBrand = value == "DiskCleaner";

                    if (!isDynamic && !isBrand)
                    {
                        offenders.Add($"{Path.GetFileName(file)}:{i + 1} \"{value}\"");
                    }
                }
            }
        }

        Assert.True(offenders.Count == 0, "hardcoded UI text: " + string.Join("; ", offenders));
    }

    [Fact]
    public void Switching_language_replaces_every_string_and_raises_the_event()
    {
        var localizer = new StringLocalizer(StringTable.Russian);
        var raised = 0;
        localizer.LanguageChanged += (_, _) => raised++;

        Assert.Equal("Настройки", localizer.Get("S.Nav.Settings"));
        Assert.Equal("Сканирование", localizer.Get("S.Nav.Scan"));
        Assert.Equal("Обзор", localizer.Get("S.Nav.Overview"));

        localizer.SetLanguage("en");

        Assert.Equal(1, raised);
        Assert.Equal("Settings", localizer.Get("S.Nav.Settings"));
        Assert.Equal("en", localizer.Language);

        // Setting the same language again must not churn the UI.
        localizer.SetLanguage("en-US");
        Assert.Equal(1, raised);
    }

    [Fact]
    public void Unknown_and_unsupported_languages_fall_back_safely()
    {
        var localizer = new StringLocalizer("de-DE");

        Assert.Equal("ru", localizer.Language);                    // unsupported → primary language
        Assert.Equal("Настройки", localizer.Get("S.Nav.Settings"));

        Assert.Equal("S.NoSuch.Key", localizer.Get("S.NoSuch.Key"));   // missing key is visible, not blank
        Assert.Equal(string.Empty, localizer.Get(string.Empty));
    }

    [Fact]
    public void Format_tolerates_missing_arguments_and_malformed_templates()
    {
        var localizer = Loc.En;

        Assert.Equal("Status: X", localizer.Format("S.Scan.StatusFormat", "X"));
        Assert.Contains("{0}", localizer.Format("S.Scan.StatusFormat"));       // no args → template untouched
        Assert.Equal("S.NoSuch.Key", localizer.Format("S.NoSuch.Key"));        // unknown key → key itself
    }

    [Fact]
    public void Russian_scan_summary_reads_naturally()
    {
        var localizer = Loc.Ru;

        var text = localizer.Format("S.Scan.ResultSummary", "1 234", "56", "2.0 ГБ", "3m 20s");

        Assert.Equal("Просканировано файлов: 1 234 в папках: 56 (2.0 ГБ) за 3m 20s.", text);
    }


    // ------------------------------------------------------------ Core-produced keys
    //
    // The keys below are not literals in the UI layer: Core emits stable codes and the
    // view models compose the table keys from them. A missing entry would surface as a
    // raw key or an English fallback in the Russian UI, so the coverage is audited here.

    [Fact]
    public void Every_known_application_explanation_is_translated()
    {
        var missing = new List<string>();

        foreach (var entry in DiskCleaner.Core.Analyzers.AppData.KnownApplications.All)
        {
            var perApp = "S.App.Expl." + entry.ExplanationKey;
            var perFamily = "S.App.Expl.family." + entry.Family;

            var covered =
                (StringTable.Ru.ContainsKey(perApp) && StringTable.En.ContainsKey(perApp)) ||
                (StringTable.Ru.ContainsKey(perFamily) && StringTable.En.ContainsKey(perFamily));

            if (!covered)
            {
                missing.Add($"{entry.Root}:{entry.RelativePath} ({perApp} | {perFamily})");
            }
        }

        Assert.True(missing.Count == 0, "untranslated application explanations:\n" + string.Join("\n", missing));
    }

    [Fact]
    public void Every_mover_reason_key_is_translated()
    {
        var root = FindRepositoryRoot();
        var source = File.ReadAllText(Path.Combine(root, "src", "DiskCleaner.Core", "Moving", "AppMover.cs"));

        var keys = Regex.Matches(source, @"""(move\.[a-z0-9.\-]+)""")
            .Select(m => m.Groups[1].Value)
            .Distinct(StringComparer.Ordinal)
            .ToArray();

        Assert.True(keys.Length >= 15, $"expected the mover to emit many reason keys, found {keys.Length}");

        var missing = keys
            .Where(k => !StringTable.Ru.ContainsKey("S.AppMover.Reason." + k) || !StringTable.En.ContainsKey("S.AppMover.Reason." + k))
            .ToArray();

        Assert.True(missing.Length == 0, "untranslated move reasons: " + string.Join(", ", missing));
    }

    [Fact]
    public void Every_cleanup_reason_key_is_translated()
    {
        var root = FindRepositoryRoot();
        var sources = new[]
        {
            Path.Combine(root, "src", "DiskCleaner.Core", "Cleanup", "CleanupExecutor.cs"),
            Path.Combine(root, "src", "DiskCleaner.App", "Platform", "WindowsDeletionService.cs"),
        };

        var keys = new SortedSet<string>(StringComparer.Ordinal);
        foreach (var file in sources)
        {
            foreach (Match match in Regex.Matches(File.ReadAllText(file), @"""(cleanup\.[a-z0-9.\-]+)"""))
            {
                keys.Add(match.Groups[1].Value);
            }
        }

        Assert.True(keys.Count >= 8, $"expected cleanup reason keys, found {keys.Count}");

        var missing = keys
            .Where(k => !StringTable.Ru.ContainsKey("S.Cleanup.Reason." + k) || !StringTable.En.ContainsKey("S.Cleanup.Reason." + k))
            .ToArray();

        Assert.True(missing.Length == 0, "untranslated cleanup reasons: " + string.Join(", ", missing));
    }

    [Fact]
    public void Every_plan_and_policy_refusal_key_is_translated()
    {
        var root = FindRepositoryRoot();

        var keys = new SortedSet<string>(StringComparer.Ordinal) { "policy.blocked" };

        var plan = File.ReadAllText(Path.Combine(root, "src", "DiskCleaner.Core", "Models", "CleanupPlan.cs"));
        foreach (Match match in Regex.Matches(plan, @"rejection = ""([a-z0-9.\-]+)"""))
        {
            keys.Add(match.Groups[1].Value);
        }

        var policy = File.ReadAllText(Path.Combine(root, "src", "DiskCleaner.Core", "Classification", "SafetyPolicy.cs"));
        foreach (Match match in Regex.Matches(policy, @"Deny\(\s*""([a-z0-9.\-]+)"""))
        {
            keys.Add(match.Groups[1].Value);
        }

        Assert.True(keys.Count >= 8, $"expected refusal keys, found {keys.Count}");

        var missing = keys
            .Where(k => !StringTable.Ru.ContainsKey("S.Reject." + k) || !StringTable.En.ContainsKey("S.Reject." + k))
            .ToArray();

        Assert.True(missing.Length == 0, "untranslated refusals: " + string.Join(", ", missing));
    }

    [Fact]
    public void Every_move_phase_has_a_label_in_both_languages()
    {
        foreach (var phase in Enum.GetNames<DiskCleaner.Core.Moving.AppMovePhase>())
        {
            var key = "S.AppMover.Phase." + phase;
            Assert.True(StringTable.Ru.ContainsKey(key), "missing in ru: " + key);
            Assert.True(StringTable.En.ContainsKey(key), "missing in en: " + key);
        }
    }

    [Fact]
    public void Every_scan_issue_reason_key_is_translated()
    {
        var root = FindRepositoryRoot();
        var sources = Directory.EnumerateFiles(Path.Combine(root, "src", "DiskCleaner.Core"), "*.cs", SearchOption.AllDirectories);

        var keys = new SortedSet<string>(StringComparer.Ordinal);
        foreach (var file in sources)
        {
            foreach (Match match in Regex.Matches(File.ReadAllText(file), @"""(issue\.[a-z0-9\-]+)"""))
            {
                keys.Add(match.Groups[1].Value);
            }
        }

        Assert.True(keys.Count >= 5, $"expected issue reason keys, found {keys.Count}");

        var missing = keys
            .Where(k => !StringTable.Ru.ContainsKey("S.IssueReason." + k["issue.".Length..]) ||
                        !StringTable.En.ContainsKey("S.IssueReason." + k["issue.".Length..]))
            .ToArray();

        Assert.True(missing.Length == 0, "untranslated issue reasons: " + string.Join(", ", missing));
    }

    private static IEnumerable<int> Placeholders(string template) =>
        Regex.Matches(template, @"\{(\d+)\}")
            .Select(m => int.Parse(m.Groups[1].Value))
            .OrderBy(i => i)
            .ToArray();

    /// <summary>Walks up from the test assembly until it finds the repository root.</summary>
    private static string FindRepositoryRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null)
        {
            if (File.Exists(Path.Combine(directory.FullName, "DiskCleaner.slnx")) &&
                Directory.Exists(Path.Combine(directory.FullName, "src")))
            {
                return directory.FullName;
            }

            directory = directory.Parent;
        }

        throw new DirectoryNotFoundException("Could not locate the repository root from " + AppContext.BaseDirectory);
    }
}
