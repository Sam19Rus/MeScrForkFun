using System.Globalization;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Models;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.Services;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

/// <summary>
/// Phase 8 from the user's side: the screen shows the plan, asks once, and then reports
/// what really happened. Nothing is deleted without that single explicit confirmation.
/// </summary>
public class CleanupViewModelTests
{
    private const string Local = @"C:\Users\alice\AppData\Local";

    private sealed class RecordingExecutor : ICleanupExecutor
    {
        public List<CleanupPlan> Plans { get; } = [];

        public CleanupRunRecord Result { get; set; } = new();

        /// <summary>When set, the run stays open so "busy" state can be asserted.</summary>
        public TaskCompletionSource? BlockUntil { get; set; }

        public bool IsRunning { get; private set; }

        public event EventHandler<CleanupRunRecord>? RunCompleted;

        public async Task<CleanupRunRecord> ExecuteAsync(
            CleanupPlan plan,
            ScanMode mode,
            IProgress<CleanupProgress>? progress = null,
            CancellationToken cancellationToken = default)
        {
            Plans.Add(plan);
            IsRunning = true;

            try
            {
                if (BlockUntil is not null)
                {
                    await BlockUntil.Task.ConfigureAwait(false);
                }

                progress?.Report(new CleanupProgress
                {
                    CompletedOperations = plan.Count,
                    TotalOperations = plan.Count,
                    FreedBytes = Result.FreedBytes,
                    CurrentPath = plan.Operations.FirstOrDefault()?.TargetPath,
                });

                RunCompleted?.Invoke(this, Result);
                return Result;
            }
            finally
            {
                IsRunning = false;
            }
        }
    }

    private sealed class Fixture
    {
        public FakeEnvironmentInfo Env { get; } = FakeEnvironmentInfo.DefaultWindows();
        public FakeDialogService Dialogs { get; } = new();
        public FakeUiDispatcher Dispatcher { get; } = new();
        public FakePrivilegeService Privileges { get; } = new();
        public AppSettings Settings { get; } = new();
        public RecordingExecutor Executor { get; } = new();
        public StringLocalizer Localizer { get; } = new("ru");
        public IValueFormatter Formatter { get; } = new ValueFormatter(CultureInfo.InvariantCulture);

        public ICleanupPlanner Planner { get; }

        public Fixture()
        {
            var policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, ["C:\\"]), Env);
            Planner = new CleanupPlanner(policy);
        }

        public CleanupViewModel CreateViewModel() => new(
            Planner,
            Executor,
            Formatter,
            Dispatcher,
            Dialogs,
            Privileges,
            new FakeSettingsService(Settings),
            new NavigationService(Section.Cleanup),
            Localizer);

        public ScanItem Item(
            string path,
            ScanCategory category = ScanCategory.TemporaryFiles,
            long size = 1_000_000,
            DeletionMethod method = DeletionMethod.Permanent,
            RiskLevel risk = RiskLevel.Low,
            CleanupConfidence confidence = CleanupConfidence.Safe,
            bool requiresElevation = false) => new()
        {
            Path = path,
            Name = System.IO.Path.GetFileName(path),
            SourceAnalyzer = "Test",
            Kind = ScanItemKind.Directory,
            Category = category,
            Size = size,
            DeletionMethod = method,
            RiskLevel = risk,
            Confidence = confidence,
            RequiresElevation = requiresElevation,
            Explanation = "test explanation",
        };

        public bool Add(ScanItem item) => Planner.TryAdd(item, out _);
    }

    // --------------------------------------------------------------- the plan

    [Fact]
    public void The_plan_is_mirrored_into_rows_with_translated_labels()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp", size: 1_000_000)));
        Assert.True(fixture.Add(fixture.Item(Local + @"\CrashDumps", ScanCategory.CrashDumps, 2_000_000)));

        var vm = fixture.CreateViewModel();

        Assert.Equal(2, vm.Operations.Count);
        Assert.Equal(2, vm.OperationCount);

        // Largest first, so the user sees what matters most at the top.
        Assert.Equal(Local + @"\CrashDumps", vm.Operations[0].Path);
        Assert.Equal(fixture.Formatter.Bytes(2_000_000), vm.Operations[0].SizeText);

        Assert.All(vm.Operations, o =>
        {
            Assert.False(o.CategoryText.StartsWith("S.", StringComparison.Ordinal));
            Assert.False(o.RiskText.StartsWith("S.", StringComparison.Ordinal));
            Assert.False(o.MethodText.StartsWith("S.", StringComparison.Ordinal));
        });

        Assert.False(vm.SummaryText.StartsWith("S.", StringComparison.Ordinal));
        Assert.Contains(fixture.Formatter.Bytes(3_000_000), vm.SummaryText, StringComparison.Ordinal);
        Assert.True(vm.HasPlan);
    }

    [Fact]
    public void An_empty_plan_says_so_instead_of_offering_a_button_that_does_nothing()
    {
        var vm = new Fixture().CreateViewModel();

        Assert.True(vm.IsEmpty);
        Assert.False(vm.HasPlan);
        Assert.Empty(vm.Operations);
        Assert.False(vm.ExecuteCommand.CanExecute(null));
    }

    // --------------------------------------------------------- the one dialog

    [Fact]
    public async Task Declining_the_confirmation_deletes_nothing()
    {
        var fixture = new Fixture();
        fixture.Dialogs.ConfirmResult = false;
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        var vm = fixture.CreateViewModel();
        await vm.ExecuteCommand.ExecuteAsync(null);

        Assert.Empty(fixture.Executor.Plans);
        Assert.False(vm.HasResult);
        Assert.Equal(1, vm.OperationCount); // the plan survives a declined confirmation
        Assert.Single(fixture.Dialogs.ConfirmPrompts);
    }

    [Fact]
    public async Task The_confirmation_dialog_shows_the_numbers_being_accepted()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp", size: 1_500_000)));

        var vm = fixture.CreateViewModel();
        await vm.ExecuteCommand.ExecuteAsync(null);

        var prompt = Assert.Single(fixture.Dialogs.ConfirmPrompts);
        Assert.Contains(fixture.Formatter.Bytes(1_500_000), prompt, StringComparison.Ordinal);
        Assert.Contains(fixture.Localizer.Get("S.Results.Category.TemporaryFiles"), prompt, StringComparison.Ordinal);
        Assert.Contains(fixture.Localizer.Get("S.Cleanup.Confirm.Question"), prompt, StringComparison.Ordinal);
    }

    [Fact]
    public async Task Confirming_runs_the_plan_and_reports_the_result()
    {
        var fixture = new Fixture();
        fixture.Executor.Result = new CleanupRunRecord
        {
            FreedBytes = 1_000_000,
            DeletedDirectoryCount = 1,
            StartedAtUtc = new DateTime(2026, 6, 1, 12, 0, 0, DateTimeKind.Utc),
            CompletedAtUtc = new DateTime(2026, 6, 1, 12, 0, 4, DateTimeKind.Utc),
            Categories =
            [
                new CategoryBreakdown { Category = ScanCategory.TemporaryFiles, FreedBytes = 1_000_000, DirectoryCount = 1 },
            ],
        };
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        var vm = fixture.CreateViewModel();
        await vm.ExecuteCommand.ExecuteAsync(null);

        Assert.Single(fixture.Executor.Plans);
        Assert.True(vm.HasResult);
        Assert.Contains(fixture.Formatter.Bytes(1_000_000), vm.ResultHeadline, StringComparison.Ordinal);
        Assert.Single(vm.ResultCategories);
        Assert.Equal(
            fixture.Localizer.Get("S.Results.Category.TemporaryFiles"),
            vm.ResultCategories[0].Name);

        // The plan is spent: leaving it in place would invite a second, unintended run.
        Assert.Empty(vm.Operations);
        Assert.Equal(0, vm.OperationCount);
        Assert.False(vm.IsExecuting);
    }

    [Fact]
    public async Task An_executor_failure_is_shown_as_a_message_not_as_a_crash()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        // A throwing executor must still leave the screen usable.
        var throwing = new ThrowingExecutor();
        var subject = new CleanupViewModel(
            fixture.Planner,
            throwing,
            fixture.Formatter,
            fixture.Dispatcher,
            fixture.Dialogs,
            fixture.Privileges,
            new FakeSettingsService(fixture.Settings),
            new NavigationService(Section.Cleanup),
            fixture.Localizer);

        await subject.ExecuteCommand.ExecuteAsync(null);

        Assert.True(subject.HasResult);
        Assert.False(subject.IsExecuting);
        Assert.False(string.IsNullOrEmpty(subject.ResultError));
        Assert.False(subject.ResultError!.StartsWith("S.", StringComparison.Ordinal));
    }

    private sealed class ThrowingExecutor : ICleanupExecutor
    {
        public bool IsRunning => false;

        public event EventHandler<CleanupRunRecord>? RunCompleted
        {
            add { }
            remove { }
        }

        public Task<CleanupRunRecord> ExecuteAsync(
            CleanupPlan plan,
            ScanMode mode,
            IProgress<CleanupProgress>? progress = null,
            CancellationToken cancellationToken = default) =>
            throw new InvalidOperationException("disk exploded");
    }

    // ------------------------------------------------------ while it is running

    [Fact]
    public async Task Everything_that_could_change_the_plan_is_locked_during_a_run()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));
        fixture.Executor.BlockUntil = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

        var vm = fixture.CreateViewModel();
        var running = vm.ExecuteCommand.ExecuteAsync(null);

        // Let the command reach the executor.
        while (!vm.IsExecuting)
        {
            await Task.Delay(5);
        }

        Assert.False(vm.ExecuteCommand.CanExecute(null));
        Assert.False(vm.ClearPlanCommand.CanExecute(null));
        Assert.True(vm.CancelRunCommand.CanExecute(null));
        Assert.False(vm.HasPlan);

        fixture.Executor.BlockUntil.SetResult();
        await running;

        Assert.False(vm.IsExecuting);
        Assert.False(vm.CancelRunCommand.CanExecute(null));
        // The plan was cleared by the run, so there is nothing left to execute.
        Assert.False(vm.ExecuteCommand.CanExecute(null));
    }

    [Fact]
    public async Task Stopping_a_run_cancels_the_token_the_executor_received()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));
        var blocker = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Executor.BlockUntil = blocker;

        var vm = fixture.CreateViewModel();
        var running = vm.ExecuteCommand.ExecuteAsync(null);
        while (!vm.IsExecuting)
        {
            await Task.Delay(5);
        }

        vm.CancelRunCommand.Execute(null);

        // The command only signals cancellation; the executor owns the actual stop.
        Assert.True(vm.IsExecuting);

        blocker.SetResult();
        await running;

        Assert.False(vm.IsExecuting);
    }

    // ------------------------------------------------------------ safety hints

    [Fact]
    public async Task Elevation_is_offered_only_when_something_needs_it()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(
            @"C:\Windows\SoftwareDistribution\Download",
            ScanCategory.WindowsUpdateCache,
            requiresElevation: true)));

        var vm = fixture.CreateViewModel();
        Assert.True(vm.NeedsElevation);

        // The app never elevates silently: the user asks, the process relaunches (here the
        // stub flips the flag), and the screen re-evaluates.
        fixture.Privileges.IsElevated = true;
        await vm.RequestElevationCommand.ExecuteAsync(null);

        Assert.False(vm.NeedsElevation);
        Assert.Equal(1, fixture.Privileges.ElevationRequests);
    }

    [Fact]
    public void A_high_risk_item_produces_a_warning()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp", risk: RiskLevel.High)));

        var vm = fixture.CreateViewModel();

        Assert.True(vm.HasHighRiskOperation);
    }

    // ------------------------------------------------------- skipped reporting

    [Fact]
    public async Task Skipped_items_are_shown_with_a_translated_reason_never_a_raw_key()
    {
        var fixture = new Fixture();
        fixture.Executor.Result = new CleanupRunRecord
        {
            FreedBytes = 0,
            SkippedCount = 1,
            Skipped =
            [
                new SkippedFile
                {
                    Path = Local + @"\Temp\locked.tmp",
                    Kind = ScanIssueKind.FileInUse,
                    Reason = "cleanup.file-in-use",
                    EstimatedBytes = 4_096,
                },
            ],
        };
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        var vm = fixture.CreateViewModel();
        await vm.ExecuteCommand.ExecuteAsync(null);

        var skipped = Assert.Single(vm.ResultSkipped);
        Assert.Equal("locked.tmp", skipped.Name);
        Assert.Equal(fixture.Localizer.Get("S.Cleanup.Reason.cleanup.file-in-use"), skipped.ReasonText);
        Assert.Equal(fixture.Localizer.Get("S.Issue.FileInUse"), skipped.KindText);
        Assert.False(skipped.NeedsElevation);
    }

    [Fact]
    public async Task A_reason_key_the_app_does_not_know_falls_back_to_the_issue_label()
    {
        var fixture = new Fixture();
        fixture.Executor.Result = new CleanupRunRecord
        {
            SkippedCount = 1,
            Skipped =
            [
                new SkippedFile
                {
                    Path = Local + @"\Temp\odd.tmp",
                    Kind = ScanIssueKind.AccessDenied,
                    Reason = "cleanup.some-key-added-in-a-later-version",
                    EstimatedBytes = 10,
                },
            ],
        };
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        var vm = fixture.CreateViewModel();
        await vm.ExecuteCommand.ExecuteAsync(null);

        var skipped = Assert.Single(vm.ResultSkipped);
        Assert.Equal(fixture.Localizer.Get("S.Issue.AccessDenied"), skipped.ReasonText);
        Assert.True(skipped.NeedsElevation);
    }

    [Fact]
    public void Switching_language_re_renders_the_plan_and_the_last_result()
    {
        var fixture = new Fixture();
        Assert.True(fixture.Add(fixture.Item(Local + @"\Temp")));

        var vm = fixture.CreateViewModel();
        var russian = vm.Operations[0].CategoryText;

        fixture.Localizer.SetLanguage("en");

        Assert.NotEqual(russian, vm.Operations[0].CategoryText);
        Assert.Equal(
            fixture.Localizer.Get("S.Results.Category.TemporaryFiles"),
            vm.Operations[0].CategoryText);
    }
}
