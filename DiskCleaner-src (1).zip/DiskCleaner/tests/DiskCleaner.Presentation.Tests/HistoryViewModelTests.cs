using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class HistoryViewModelTests
{
    private static (HistoryViewModel Vm, JsonHistoryService History, ManualUiDispatcher Dispatcher, TempDirectory Temp) Create()
    {
        var temp = new TempDirectory("dc-history-vm");
        var environment = new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root });
        var paths = new ApplicationPaths(environment, new PhysicalFileSystem());
        var settings = new JsonSettingsService(paths);
        settings.LoadAsync().GetAwaiter().GetResult();

        var history = new JsonHistoryService(paths, settings);
        var dispatcher = new ManualUiDispatcher();

        var vm = new HistoryViewModel(
            history,
            new FakeDialogService(),
            new FakeShellService(),
            new ValueFormatter(System.Globalization.CultureInfo.InvariantCulture),
            paths,
            dispatcher,
            Loc.En);

        return (vm, history, dispatcher, temp);
    }

    private static CleanupRunRecord Record(long freed, int minutesOffset) => new()
    {
        StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc).AddMinutes(minutesOffset),
        CompletedAtUtc = new DateTime(2026, 5, 1, 10, 2, 0, DateTimeKind.Utc).AddMinutes(minutesOffset),
        FreedBytes = freed,
        DeletedFileCount = 12,
        SkippedCount = 1,
        Categories = [new CategoryBreakdown { Category = ScanCategory.TemporaryFiles, FreedBytes = freed, FileCount = 12 }],
        Skipped = [new SkippedFile { Path = @"C:\Temp\locked.dat", Kind = ScanIssueKind.FileInUse, Reason = "In use" }],
    };

    [Fact]
    public async Task A_history_change_from_a_background_thread_is_marshalled_to_the_ui()
    {
        // Regression: JsonHistoryService raises HistoryChanged after ConfigureAwait(false).
        // Refresh() mutates the bound Runs collection, which WPF forbids off-thread.
        var (vm, history, dispatcher, temp) = Create();
        using (temp)
        {
            await Task.Run(async () => await history.AppendAsync(Record(2048, 0)));

            Assert.Empty(vm.Runs);
            Assert.Equal(1, dispatcher.PendingCount);

            dispatcher.Pump();

            var run = Assert.Single(vm.Runs);
            Assert.True(vm.HasRuns);
            Assert.Equal("2.0 KB", run.FreedText);
            Assert.Equal("Completed", run.StateText);
            Assert.Equal("1", run.SkippedText);
            Assert.Contains("locked.dat", run.SkippedDetail, StringComparison.Ordinal);
            // Categories are localised now: the English table renders the enum as prose.
            Assert.Contains("Temporary files", run.CategoriesText, StringComparison.Ordinal);
        }
    }

    [Fact]
    public async Task Totals_and_summary_reflect_the_stored_runs()
    {
        var (vm, history, dispatcher, temp) = Create();
        using (temp)
        {
            await history.AppendAsync(Record(1_000, 0));
            await history.AppendAsync(Record(2_500, 10));
            dispatcher.Pump();

            Assert.Equal(2, vm.Runs.Count);
            Assert.Equal("3.4 KB", vm.TotalFreedText);
            Assert.Contains("2 run(s)", vm.SummaryText, StringComparison.Ordinal);

            // Newest first.
            Assert.Equal("2.4 KB", vm.Runs[0].FreedText);
        }
    }

    [Fact]
    public async Task Clearing_history_asks_first_and_respects_the_answer()
    {
        var (vm, history, dispatcher, temp) = Create();
        using (temp)
        {
            var dialogs = new FakeDialogService { ConfirmResult = false };
            var paths = new ApplicationPaths(
                new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root }),
                new PhysicalFileSystem());
            var settings = new JsonSettingsService(paths);
            await settings.LoadAsync();
            var guarded = new JsonHistoryService(paths, settings);
            await guarded.AppendAsync(Record(10, 0));

            var guardedVm = new HistoryViewModel(
                guarded, dialogs, new FakeShellService(),
                new ValueFormatter(System.Globalization.CultureInfo.InvariantCulture),
                paths, dispatcher, Loc.En);

            await guardedVm.ClearCommand.ExecuteAsync(null);
            Assert.Single(guardedVm.Runs);          // declined → nothing removed
            Assert.Single(dialogs.ConfirmPrompts);

            dialogs.ConfirmResult = true;
            await guardedVm.ClearCommand.ExecuteAsync(null);
            Assert.Empty(guardedVm.Runs);
            _ = history;
        }
    }
}
