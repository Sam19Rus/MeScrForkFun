using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Formatting;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.ViewModels;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Presentation.Tests;

public class SettingsViewModelTests
{
    private static (SettingsViewModel Vm, JsonSettingsService Settings, ApplicationPaths Paths, FakeAppearanceService Appearance, FakeDialogService Dialogs, FakeShellService Shell, FakeScanService Scan, RecordingLogger<SettingsViewModel> Logger, TempDirectory Temp) Create()
    {
        var temp = new TempDirectory("dc-settings-vm");
        var environment = new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root });
        var paths = new ApplicationPaths(environment, new Core.Infrastructure.IO.PhysicalFileSystem());
        var settings = new JsonSettingsService(paths);
        settings.LoadAsync().GetAwaiter().GetResult();

        var appearance = new FakeAppearanceService();
        var dialogs = new FakeDialogService();
        var shell = new FakeShellService();

        var scan = new FakeScanService();
        var logger = new RecordingLogger<SettingsViewModel>();

        var vm = new SettingsViewModel(
            settings, appearance, shell, dialogs, paths, scan,
            new ValueFormatter(System.Globalization.CultureInfo.InvariantCulture), Loc.En, logger);

        return (vm, settings, paths, appearance, dialogs, shell, scan, logger, temp);
    }

    [Fact]
    public void Initial_state_reflects_the_loaded_settings_and_applies_the_theme_once()
    {
        var (vm, _, _, appearance, _, _, _, _, temp) = Create();
        using (temp)
        {
            Assert.Equal(AppTheme.System, vm.Theme);
            Assert.Equal("ru", vm.Language);   // Russian is the primary language
            Assert.Equal(ScanDepth.Standard, vm.Depth);
            Assert.Equal(RecycleBinBehavior.PreferForUserData, vm.RecycleBinBehavior);
            Assert.Equal("256.0 MB", vm.LargeFileThresholdText);
            Assert.True(vm.EnableDeveloperAnalysis);
            Assert.False(vm.FollowReparsePoints);
            Assert.False(vm.HasUnsavedChanges);

            Assert.Single(appearance.Applied);
            Assert.Equal((AppTheme.System, "ru"), appearance.Applied[0]);
        }
    }

    [Fact]
    public void Changing_the_theme_applies_immediately_and_marks_the_page_dirty()
    {
        var (vm, settings, _, appearance, _, _, _, _, temp) = Create();
        using (temp)
        {
            vm.Theme = AppTheme.Dark;

            Assert.Equal((AppTheme.Dark, "ru"), appearance.Applied[^1]);
            Assert.True(vm.HasUnsavedChanges);

            // Live preview must not write to disk behind the user's back.
            Assert.Equal(AppTheme.System, settings.Current.Theme);
        }
    }

    [Fact]
    public async Task Save_persists_every_choice_and_clears_the_dirty_flag()
    {
        var (vm, settings, paths, _, _, _, _, _, temp) = Create();
        using (temp)
        {
            vm.Theme = AppTheme.Dark;
            vm.Language = "en";
            vm.Depth = ScanDepth.Exhaustive;
            vm.RecycleBinBehavior = RecycleBinBehavior.Never;
            vm.LargeFileThresholdText = "1.5 GB";
            vm.EnableDeveloperAnalysis = false;
            vm.FollowReparsePoints = true;
            vm.SaveHistoryAutomatically = false;
            vm.MaxDegreeOfParallelism = 2;
            vm.NewExcludedPath = @"C:\Projects";
            vm.AddExcludedPathCommand.Execute(null);
            vm.NewExcludedExtension = ".iso";
            vm.AddExcludedExtensionCommand.Execute(null);

            await vm.SaveCommand.ExecuteAsync(null);

            Assert.False(vm.HasUnsavedChanges);
            Assert.Null(vm.ValidationMessage);

            var reloaded = new JsonSettingsService(paths);
            var saved = await reloaded.LoadAsync();

            Assert.Equal(AppTheme.Dark, saved.Theme);
            Assert.Equal("en", saved.Language);
            Assert.Equal(ScanDepth.Exhaustive, saved.ScanDepth);
            Assert.Equal(RecycleBinBehavior.Never, saved.RecycleBinBehavior);
            Assert.Equal(1610612736L, saved.LargeFileThresholdBytes);
            Assert.False(saved.EnableDeveloperAnalysis);
            Assert.True(saved.FollowReparsePoints);
            Assert.False(saved.SaveHistoryAutomatically);
            Assert.Equal(2, saved.MaxDegreeOfParallelism);
            Assert.Equal([@"C:\Projects"], saved.ExcludedPaths);
            Assert.Equal(["iso"], saved.ExcludedExtensions);   // leading dot is normalised away
        }
    }

    [Fact]
    public async Task An_invalid_size_blocks_the_save_and_explains_why()
    {
        var (vm, settings, _, _, dialogs, _, _, _, temp) = Create();
        using (temp)
        {
            vm.LargeFileThresholdText = "banana";

            await vm.SaveCommand.ExecuteAsync(null);

            Assert.NotNull(vm.ValidationMessage);
            Assert.Contains("not a valid size", vm.ValidationMessage, StringComparison.Ordinal);
            Assert.Single(dialogs.Warnings);
            Assert.True(vm.HasUnsavedChanges);
            Assert.Equal(256L * 1024 * 1024, settings.Current.LargeFileThresholdBytes);   // unchanged
        }
    }

    [Fact]
    public void Revert_restores_the_persisted_values()
    {
        var (vm, _, _, _, _, _, _, _, temp) = Create();
        using (temp)
        {
            vm.Theme = AppTheme.Dark;
            vm.LargeFileThresholdText = "99 GB";
            vm.NewExcludedPath = @"C:\Projects";
            vm.AddExcludedPathCommand.Execute(null);
            Assert.True(vm.HasUnsavedChanges);

            vm.RevertCommand.Execute(null);

            Assert.Equal(AppTheme.System, vm.Theme);
            Assert.Equal("256.0 MB", vm.LargeFileThresholdText);
            Assert.Empty(vm.ExcludedPaths);
            Assert.False(vm.HasUnsavedChanges);
        }
    }

    [Fact]
    public void Excluded_paths_are_unique_and_removable()
    {
        var (vm, _, _, _, _, _, _, _, temp) = Create();
        using (temp)
        {
            vm.NewExcludedPath = @"C:\Projects";
            vm.AddExcludedPathCommand.Execute(null);
            vm.NewExcludedPath = @"C:\Projects";
            vm.AddExcludedPathCommand.Execute(null);
            vm.NewExcludedPath = @"D:\Backups";
            vm.AddExcludedPathCommand.Execute(null);

            Assert.Equal(2, vm.ExcludedPaths.Count);

            vm.RemoveExcludedPathCommand.Execute(@"C:\Projects");

            Assert.Equal([@"D:\Backups"], vm.ExcludedPaths);
        }
    }

    [Fact]
    public async Task The_folder_dialog_can_fill_the_exclusion_box()
    {
        var (vm, _, _, _, dialogs, _, _, _, temp) = Create();
        using (temp)
        {
            dialogs.FolderToReturn = @"D:\VMs";

            await vm.BrowseExcludedPathCommand.ExecuteAsync(null);

            Assert.Equal([@"D:\VMs"], vm.ExcludedPaths);
            Assert.Equal(string.Empty, vm.NewExcludedPath);
        }
    }

    [Fact]
    public void Shell_commands_open_the_application_folders()
    {
        var (vm, _, paths, _, _, shell, _, _, temp) = Create();
        using (temp)
        {
            vm.OpenDataFolderCommand.Execute(null);
            vm.OpenLogsFolderCommand.Execute(null);

            Assert.Equal(
                ["folder:" + paths.RootDirectory, "folder:" + paths.LogsDirectory],
                shell.Opened);
        }
    }

    [Fact]
    public async Task The_engine_self_test_reports_real_numbers()
    {
        var (vm, _, _, _, _, _, scan, _, temp) = Create();
        using (temp)
        {
            scan.Result = new ScanResult
            {
                Mode = ScanMode.Custom,
                StartedAtUtc = new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc),
                CompletedAtUtc = new DateTime(2026, 5, 1, 10, 0, 1, DateTimeKind.Utc),
                Statistics = new ScanStatistics { FilesScanned = 7, DirectoriesScanned = 3, IssuesCount = 1 },
            };

            await vm.RunDiagnosticsCommand.ExecuteAsync(null);

            Assert.False(vm.DiagnosticsFailed);
            Assert.Contains("7 files", vm.DiagnosticsText, StringComparison.Ordinal);
            Assert.Contains("3 folders", vm.DiagnosticsText, StringComparison.Ordinal);
            Assert.Contains("1", vm.DiagnosticsText, StringComparison.Ordinal);

            // It must exercise the real pipeline over the app data folder, not a mock path.
            var call = Assert.Single(scan.Calls);
            Assert.Equal(ScanMode.Custom, call.Mode);
            Assert.Single(call.Roots);
        }
    }

    [Fact]
    public async Task The_engine_self_test_surfaces_the_exact_exception()
    {
        var (vm, _, _, _, _, _, scan, logger, temp) = Create();
        using (temp)
        {
            scan.RunOverride = (_, _, _, _) => throw new UnauthorizedAccessException("C:\\Users\\alice is denied");

            await vm.RunDiagnosticsCommand.ExecuteAsync(null);

            Assert.True(vm.DiagnosticsFailed);
            Assert.Contains("UnauthorizedAccessException", vm.DiagnosticsText, StringComparison.Ordinal);
            Assert.Contains("is denied", vm.DiagnosticsText, StringComparison.Ordinal);
            Assert.True(logger.HasErrors);
        }
    }

    [Fact]
    public void The_storage_location_is_shown_so_the_user_knows_where_data_lives()
    {
        var (vm, _, paths, _, _, _, _, _, temp) = Create();
        using (temp)
        {
            Assert.Equal(paths.RootDirectory, vm.StorageLocationText);
            Assert.Contains("DiskCleaner", vm.StorageLocationText, StringComparison.Ordinal);
        }
    }
}
