using DiskCleaner.Core.Application;
using DiskCleaner.Core.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Services;
using DiskCleaner.Presentation.Application;
using DiskCleaner.Presentation.Localization;
using DiskCleaner.Presentation.ViewModels;

namespace DiskCleaner.Testing;

/// <summary>Runs posted work inline so view-model tests are deterministic.</summary>
public sealed class FakeUiDispatcher : IUiDispatcher
{
    public int PostedCount { get; private set; }

    public bool CheckAccess() => true;

    public void Post(Action action)
    {
        PostedCount++;
        action();
    }

    public Task InvokeAsync(Func<Task> action) => action();
}

public sealed class FakeDialogService : IDialogService
{
    public bool ConfirmResult { get; set; } = true;

    public string? FolderToReturn { get; set; }

    public List<string> ConfirmPrompts { get; } = [];

    public List<string> Warnings { get; } = [];

    public List<string> Infos { get; } = [];

    public Task<bool> ConfirmAsync(string title, string message, string confirmLabel = "Continue", string cancelLabel = "Cancel")
    {
        ConfirmPrompts.Add($"{title}: {message}");
        return Task.FromResult(ConfirmResult);
    }

    public Task<string?> PickFolderAsync(string? initialDirectory = null) => Task.FromResult(FolderToReturn);

    public void ShowInfo(string title, string message) => Infos.Add($"{title}: {message}");

    public void ShowWarning(string title, string message) => Warnings.Add($"{title}: {message}");
}

public sealed class FakeShellService : IShellService
{
    public List<string> Opened { get; } = [];

    public bool OpenFolder(string path)
    {
        Opened.Add("folder:" + path);
        return true;
    }

    public bool OpenFileLocation(string path)
    {
        Opened.Add("location:" + path);
        return true;
    }

    public bool OpenFile(string path)
    {
        Opened.Add("file:" + path);
        return true;
    }

    public bool OpenRecycleBin()
    {
        Opened.Add("recyclebin");
        return true;
    }
}

public sealed class FakeAppearanceService : IAppearanceService
{
    public List<(AppTheme Theme, string Language)> Applied { get; } = [];

    public void Apply(AppTheme theme, string language) => Applied.Add((theme, language));
}

public sealed class FakePrivilegeService : IPrivilegeService
{
    public bool IsElevated { get; set; }

    public string UserName { get; set; } = "TEST-PC\\alice";

    public int ElevationRequests { get; private set; }

    public Task<bool> RequestElevationAsync(string? reason = null, CancellationToken cancellationToken = default)
    {
        ElevationRequests++;
        return Task.FromResult(true);
    }
}

public sealed class FakeDriveService : IDriveService
{
    public List<DriveSnapshot> Drives { get; } = [];

    public IReadOnlyList<DriveSnapshot> GetDrives() => Drives;

    public IReadOnlyList<DriveSnapshot> GetScannableDrives() => [.. Drives.Where(d => d.IsScannableByDefault)];

    public DriveSnapshot? GetDrive(string rootPath) =>
        Drives.FirstOrDefault(d => string.Equals(d.RootPath, rootPath, PathUtils.Comparison));

    public long? GetFreeBytes(string rootPath) => GetDrive(rootPath)?.FreeBytes;

    public static DriveSnapshot Fixed(string root, long totalGb, long freeGb, string label = "") => new()
    {
        RootPath = root,
        Label = label,
        DriveType = "Fixed",
        FileSystemName = "NTFS",
        TotalBytes = totalGb * 1024 * 1024 * 1024,
        FreeBytes = freeGb * 1024 * 1024 * 1024,
        IsReady = true,
        IsScannableByDefault = true,
    };
}

/// <summary>Stands in for the real scan pipeline so view models can be tested without touching a disk.</summary>
public sealed class FakeScanService : IScanService
{
    public List<(ScanMode Mode, IReadOnlyList<string> Roots)> Calls { get; } = [];

    public ScanResult Result { get; set; } = new();

    /// <summary>Replaces the default behaviour, e.g. to block until cancelled.</summary>
    public Func<ScanMode, IReadOnlyList<string>, IProgress<ScanProgress>?, CancellationToken, Task<ScanResult>>? RunOverride { get; set; }

    /// <summary>Invoked after the call is recorded, before the result is returned.</summary>
    public Action<IProgress<ScanProgress>?>? BeforeReturn { get; set; }

    public bool IsRunning { get; private set; }

    public ScanResult? LastResult { get; private set; }

    public event EventHandler<ScanResult>? ScanCompleted;

    public async Task<ScanResult> RunAsync(
        ScanMode mode,
        IReadOnlyList<string> roots,
        IProgress<ScanProgress>? progress = null,
        CancellationToken cancellationToken = default)
    {
        Calls.Add((mode, roots));
        IsRunning = true;
        try
        {
            if (RunOverride is not null)
            {
                return await RunOverride(mode, roots, progress, cancellationToken);
            }

            BeforeReturn?.Invoke(progress);
            LastResult = Result;
            return Result;
        }
        finally
        {
            IsRunning = false;
        }
    }

    public void RaiseCompleted(ScanResult result)
    {
        LastResult = result;
        ScanCompleted?.Invoke(this, result);
    }
}

/// <summary>Convenient access to a real localizer in either language.</summary>
public static class Loc
{
    public static IStringLocalizer En => new StringLocalizer(StringTable.English);

    public static IStringLocalizer Ru => new StringLocalizer(StringTable.Russian);
}

/// <summary>Minimal concrete section used to test the shell in isolation.</summary>
public sealed class TestSectionViewModel(
    Section section,
    string titleKey = "S.Nav.Scan",
    bool busy = false,
    IStringLocalizer? localizer = null)
    : SectionViewModel(section, titleKey, "\uE700", localizer ?? Loc.En)
{
    public int NavigatedToCount { get; private set; }

    public int NavigatedFromCount { get; private set; }

    public override bool IsBusy => busy;

    public override Task OnNavigatedToAsync()
    {
        NavigatedToCount++;
        return Task.CompletedTask;
    }

    public override Task OnNavigatedFromAsync()
    {
        NavigatedFromCount++;
        return Task.CompletedTask;
    }
}

/// <summary>Settings service backed by a real file in a temp directory.</summary>
public static class SettingsFactory
{
    public static (JsonSettingsService Service, ApplicationPaths Paths, TempDirectory Temp) CreateTemp()
    {
        var temp = new TempDirectory("dc-presentation");
        var environment = new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root });
        var paths = new ApplicationPaths(environment, new PhysicalFileSystem());
        var service = new JsonSettingsService(paths);
        service.LoadAsync().GetAwaiter().GetResult();
        return (service, paths, temp);
    }
}


/// <summary>Captures log records so tests can assert that failures are actually reported.</summary>
public sealed class RecordingLogger<T> : ILogger<T>
{
    private readonly List<(LogLevel Level, string Message, Exception? Exception)> _entries = [];

    public IReadOnlyList<(LogLevel Level, string Message, Exception? Exception)> Entries
    {
        get { lock (_entries) { return _entries.ToArray(); } }
    }

    public bool HasErrors => Entries.Any(e => e.Level >= LogLevel.Error);

    public string? LastErrorMessage => Entries.LastOrDefault(e => e.Level >= LogLevel.Error).Message;

    public Exception? LastException => Entries.LastOrDefault(e => e.Level >= LogLevel.Error).Exception;

    public IDisposable? BeginScope<TState>(TState state)
        where TState : notnull
        => NullScope.Instance;

    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        lock (_entries)
        {
            _entries.Add((logLevel, formatter(state, exception), exception));
        }
    }

    private sealed class NullScope : IDisposable
    {
        public static readonly NullScope Instance = new();

        public void Dispose()
        {
        }
    }
}


/// <summary>
/// Dispatcher that queues work and only executes it when <see cref="Pump"/> is called.
/// </summary>
/// <remarks>
/// This is what makes cross-thread bugs testable: code that mutates bound collections
/// from a background thread leaves the queue unpumped, and the test can assert that
/// nothing was applied until the UI thread ran it.
/// </remarks>
public sealed class ManualUiDispatcher : IUiDispatcher
{
    private readonly Queue<Action> _queue = new();
    private readonly object _gate = new();

    public int PostedCount { get; private set; }

    public int ExecutedCount { get; private set; }

    public int PendingCount { get { lock (_gate) { return _queue.Count; } } }

    public bool CheckAccess() => false;

    public void Post(Action action)
    {
        PostedCount++;
        lock (_gate)
        {
            _queue.Enqueue(action);
        }
    }

    public Task InvokeAsync(Func<Task> action) => action();

    /// <summary>Runs everything queued so far, in order, on the calling thread.</summary>
    public void Pump()
    {
        while (true)
        {
            Action action;
            lock (_gate)
            {
                if (_queue.Count == 0)
                {
                    return;
                }

                action = _queue.Dequeue();
            }

            ExecutedCount++;
            action();
        }
    }
}

/// <summary>In-memory settings service for view-model and service tests.</summary>
public sealed class FakeSettingsService(AppSettings? initial = null) : ISettingsService
{
    private readonly object _gate = new();

    public AppSettings Current { get; private set; } = initial ?? new AppSettings();

    public string? LastError { get; set; }

    public int SaveCount { get; private set; }

    public event EventHandler<AppSettings>? SettingsChanged;

    public Task<AppSettings> LoadAsync(CancellationToken cancellationToken = default) => Task.FromResult(Current);

    public Task SaveAsync(CancellationToken cancellationToken = default)
    {
        SaveCount++;
        return Task.CompletedTask;
    }

    public AppSettings Update(Action<AppSettings> mutate)
    {
        lock (_gate)
        {
            mutate(Current);
        }

        SettingsChanged?.Invoke(this, Current);
        return Current;
    }
}
