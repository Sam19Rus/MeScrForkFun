using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Moving;

namespace DiskCleaner.Testing;

/// <summary>
/// In-memory junctions for mover tests.
/// </summary>
/// <remarks>
/// When constructed with an <see cref="InMemoryFileSystem"/>, created links are
/// materialised inside it (as reparse-point nodes), so enumeration, metadata and
/// link resolution behave like the real thing without touching Windows.
/// </remarks>
public sealed class FakeJunctionService(InMemoryFileSystem? fileSystem = null) : IJunctionService
{
    private readonly Dictionary<string, string> _links = new(PathUtils.Comparer);

    /// <summary>Link paths whose creation must fail.</summary>
    public HashSet<string> FailCreate { get; } = new(PathUtils.Comparer);

    /// <summary>Link paths whose deletion must fail.</summary>
    public HashSet<string> FailDelete { get; } = new(PathUtils.Comparer);

    /// <summary>Every created junction: (link, target).</summary>
    public List<(string Link, string Target)> Created { get; } = [];

    public IReadOnlyDictionary<string, string> Links => _links;

    public bool IsLink(string path)
    {
        var normalized = PathUtils.Normalize(path);
        return _links.ContainsKey(normalized) ||
               (fileSystem?.TryGetDirectoryMetadata(normalized)?.IsReparsePoint ?? false);
    }

    public string? TryGetLinkTarget(string path)
    {
        var normalized = PathUtils.Normalize(path);
        if (_links.TryGetValue(normalized, out var target))
        {
            return target;
        }

        return fileSystem?.TryResolveLinkTarget(normalized);
    }

    public bool TryCreateJunction(string linkPath, string targetPath, out string? error)
    {
        var link = PathUtils.Normalize(linkPath);
        var target = PathUtils.Normalize(targetPath);

        if (FailCreate.Contains(link))
        {
            error = "Junction creation blocked by the test fixture";
            return false;
        }

        if (fileSystem is not null)
        {
            if (!fileSystem.DirectoryExists(target))
            {
                error = $"The target does not exist: {target}";
                return false;
            }

            if ((fileSystem.DirectoryExists(link) || fileSystem.FileExists(link)) && !IsLink(link))
            {
                error = $"The location is already occupied: {link}";
                return false;
            }
        }

        fileSystem?.AddLink(link, target);
        _links[link] = target;
        Created.Add((link, target));
        error = null;
        return true;
    }

    public bool TryDeleteJunction(string linkPath, out string? error)
    {
        var link = PathUtils.Normalize(linkPath);

        if (FailDelete.Contains(link))
        {
            error = "Junction deletion blocked by the test fixture";
            return false;
        }

        if (!IsLink(link))
        {
            error = $"Not a junction: {link}";
            return false;
        }

        fileSystem?.TryDeleteDirectory(link, recursive: false, out _);
        _links.Remove(link);
        error = null;
        return true;
    }
}
