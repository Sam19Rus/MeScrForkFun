using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Testing;

/// <summary>
/// In-memory deletion backend for executor tests: records every request and can be told
/// which paths are locked, denied, or vanished.
/// </summary>
public sealed class FakeDeletionService : IDeletionService
{
    private readonly HashSet<string> _deleted = new(PathUtils.Comparer);

    /// <summary>Paths whose deletion fails with a sharing violation (locked by a process).</summary>
    public HashSet<string> InUse { get; } = new(PathUtils.Comparer);

    /// <summary>Paths whose deletion fails with access denied (would need elevation).</summary>
    public HashSet<string> Denied { get; } = new(PathUtils.Comparer);

    /// <summary>Paths that no longer exist.</summary>
    public HashSet<string> Missing { get; } = new(PathUtils.Comparer);

    /// <summary>Paths for which the Recycle Bin is unavailable.</summary>
    public HashSet<string> NoRecycleBin { get; } = new(PathUtils.Comparer);

    /// <summary>Every delete request, in order: (path, method, isDirectory).</summary>
    public List<(string Path, DeletionMethod Method, bool IsDirectory)> Requests { get; } = [];

    public int EmptyRecycleBinCalls { get; private set; }

    public string? LastEmptyRecycleBinVolume { get; private set; }

    public IReadOnlyCollection<string> Deleted => _deleted;

    public bool WasDeleted(string path) => _deleted.Contains(path);

    public bool SupportsRecycleBin(string path) => !NoRecycleBin.Contains(path);

    /// <summary>
    /// When set, every delete blocks until it completes. Makes "no two runs at once"
    /// tests deterministic instead of racy.
    /// </summary>
    public TaskCompletionSource? BlockUntil { get; set; }

    public DeletionOutcome Delete(string path, DeletionMethod method, bool isDirectory)
    {
        Requests.Add((path, method, isDirectory));

        BlockUntil?.Task.GetAwaiter().GetResult();

        if (Missing.Contains(path))
        {
            return DeletionOutcome.Fail(ScanIssueKind.NotFound, "cleanup.already-gone");
        }

        if (InUse.Contains(path))
        {
            return DeletionOutcome.Fail(ScanIssueKind.FileInUse, "cleanup.file-in-use", 32);
        }

        if (Denied.Contains(path))
        {
            return DeletionOutcome.Fail(ScanIssueKind.AccessDenied, "cleanup.access-denied", 5);
        }

        _deleted.Add(path);

        return method == DeletionMethod.RecycleBin
            ? DeletionOutcome.Recycled(0, 1)
            : DeletionOutcome.Deleted(0, 1);
    }

    public DeletionOutcome EmptyRecycleBin(string? volumeRoot)
    {
        EmptyRecycleBinCalls++;
        LastEmptyRecycleBinVolume = volumeRoot;
        return DeletionOutcome.Emptied(0, 0);
    }
}
