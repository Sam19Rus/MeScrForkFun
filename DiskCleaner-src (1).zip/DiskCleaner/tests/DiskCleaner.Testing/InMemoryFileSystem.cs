using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Testing;

/// <summary>
/// Deterministic in-memory file system.
/// </summary>
/// <remarks>
/// Used to exercise the failure paths that are impossible to provoke reliably on
/// a real volume: access-denied directories, sharing violations, paths that
/// disappear mid-scan, and junctions that point at their own ancestor.
/// </remarks>
public sealed class InMemoryFileSystem : IFileSystem
{
    private sealed record Node(bool IsDirectory, long Size, FileAttributes Attributes, DateTime CreatedUtc, DateTime ModifiedUtc);

    private readonly Dictionary<string, Node> _nodes = new(PathUtils.Comparer);
    private readonly Dictionary<string, string> _contents = new(PathUtils.Comparer);

    /// <summary>Directories whose enumeration throws <see cref="UnauthorizedAccessException"/>.</summary>
    public HashSet<string> DeniedDirectories { get; } = new(PathUtils.Comparer);

    /// <summary>Directories whose enumeration throws <see cref="IOException"/> (sharing violation).</summary>
    public HashSet<string> InUseDirectories { get; } = new(PathUtils.Comparer);

    /// <summary>Directories that do not exist at enumeration time.</summary>
    public HashSet<string> MissingDirectories { get; } = new(PathUtils.Comparer);

    /// <summary>Directories whose name is too long for the API.</summary>
    public HashSet<string> TooLongPathDirectories { get; } = new(PathUtils.Comparer);

    /// <summary>Paths whose deletion fails (locked, denied…) — for rollback tests.</summary>
    public HashSet<string> DeleteFailures { get; } = new(PathUtils.Comparer);

    /// <summary>Source files whose copy fails — simulates a running application.</summary>
    public HashSet<string> CopyFailures { get; } = new(PathUtils.Comparer);

    /// <summary>Every successful copy: (source, destination).</summary>
    public List<(string Source, string Destination)> CopiedFiles { get; } = [];

    /// <summary>link path → resolved target.</summary>
    public Dictionary<string, string> LinkTargets { get; } = new(PathUtils.Comparer);

    public List<string> DeletedFiles { get; } = [];

    public List<string> DeletedDirectories { get; } = [];

    public int EnumerateCallCount { get; private set; }

    public InMemoryFileSystem AddDirectory(string path, DateTime? modifiedUtc = null)
    {
        var normalized = PathUtils.Normalize(path);
        EnsureAncestors(normalized);
        _nodes[normalized] = new Node(true, 0, FileAttributes.Directory, DateTime.UtcNow, modifiedUtc ?? DateTime.UtcNow);
        return this;
    }

    public InMemoryFileSystem AddFile(
        string path,
        long size,
        FileAttributes attributes = FileAttributes.Normal,
        DateTime? createdUtc = null,
        DateTime? modifiedUtc = null,
        string? content = null)
    {
        var normalized = PathUtils.Normalize(path);
        var parent = PathUtils.GetParent(normalized);
        if (parent is not null)
        {
            AddDirectory(parent);
        }

        _nodes[normalized] = new Node(
            false,
            size,
            attributes,
            createdUtc ?? DateTime.UtcNow,
            modifiedUtc ?? DateTime.UtcNow);

        if (content is not null)
        {
            _contents[normalized] = content;
        }

        return this;
    }

    /// <summary>Adds a junction/symlink that behaves like a directory pointing at <paramref name="target"/>.</summary>
    public InMemoryFileSystem AddLink(string linkPath, string target)
    {
        var normalized = PathUtils.Normalize(linkPath);
        var parent = PathUtils.GetParent(normalized);
        if (parent is not null)
        {
            AddDirectory(parent);
        }

        _nodes[normalized] = new Node(
            true,
            0,
            FileAttributes.Directory | FileAttributes.ReparsePoint,
            DateTime.UtcNow,
            DateTime.UtcNow);

        LinkTargets[normalized] = PathUtils.Normalize(target);
        return this;
    }

    private void EnsureAncestors(string path)
    {
        var parent = PathUtils.GetParent(path);
        while (!string.IsNullOrEmpty(parent) && !_nodes.ContainsKey(parent))
        {
            _nodes[parent] = new Node(true, 0, FileAttributes.Directory, DateTime.UtcNow, DateTime.UtcNow);
            parent = PathUtils.GetParent(parent);
        }
    }

    public bool DirectoryExists(string path)
    {
        var normalized = PathUtils.Normalize(path);
        return _nodes.TryGetValue(normalized, out var node) && node.IsDirectory;
    }

    public bool FileExists(string path)
    {
        var normalized = PathUtils.Normalize(path);
        return _nodes.TryGetValue(normalized, out var node) && !node.IsDirectory;
    }

    public IEnumerable<ScannedEntry> EnumerateEntries(string directory)
    {
        var normalized = PathUtils.Normalize(directory);
        EnumerateCallCount++;

        if (DeniedDirectories.Contains(normalized))
        {
            throw new UnauthorizedAccessException($"Access to the path '{normalized}' is denied.");
        }

        if (InUseDirectories.Contains(normalized))
        {
            throw new IOException("The process cannot access the file because it is being used by another process.")
            {
                HResult = unchecked((int)0x80070020),
            };
        }

        if (MissingDirectories.Contains(normalized))
        {
            throw new DirectoryNotFoundException($"Could not find a part of the path '{normalized}'.");
        }

        if (TooLongPathDirectories.Contains(normalized))
        {
            throw new PathTooLongException($"The path '{normalized}' is too long.");
        }

        var prefix = PathUtils.EnsureTrailingSeparator(normalized);

        // Behave like a real junction: enumerate the target's contents but present
        // them under the link path. Without this a fake link would look empty and
        // the cycle guard could never be exercised.
        var effective = normalized;
        var hops = 0;
        while (LinkTargets.TryGetValue(effective, out var target) && hops++ < 16)
        {
            effective = target;
        }

        if (hops >= 16)
        {
            throw new IOException("The link could not be resolved: too many levels.");
        }

        var targetPrefix = PathUtils.EnsureTrailingSeparator(effective);

        // Snapshot before yielding: a real directory enumeration is stable even while
        // the caller creates files elsewhere (the mover copies into the fake while
        // walking it), and a live dictionary would throw "collection was modified".
        var children = _nodes
            .Where(kv => kv.Key.StartsWith(targetPrefix, PathUtils.Comparison))
            .Select(kv => (Path: kv.Key, Node: kv.Value))
            .Where(x =>
            {
                var remainder = x.Path[targetPrefix.Length..];
                return remainder.Length > 0 && !remainder.Contains('\\') && !remainder.Contains('/');
            })
            .ToArray();

        foreach (var (path, node) in children)
        {
            var remainder = path[targetPrefix.Length..];

            yield return new ScannedEntry(
                fullPath: prefix + remainder,
                name: remainder,
                isDirectory: node.IsDirectory,
                size: node.Size,
                attributes: node.Attributes | (node.IsDirectory ? FileAttributes.Directory : 0),
                createdUtc: node.CreatedUtc,
                lastWriteUtc: node.ModifiedUtc,
                isReparsePoint: (node.Attributes & FileAttributes.ReparsePoint) != 0,
                driveRoot: PathUtils.GetDriveRoot(path));
        }
    }

    public DirectoryMetadata? TryGetDirectoryMetadata(string path)
    {
        var normalized = PathUtils.Normalize(path);
        if (!_nodes.TryGetValue(normalized, out var node) || !node.IsDirectory)
        {
            return null;
        }

        return new DirectoryMetadata(
            normalized,
            node.Attributes | FileAttributes.Directory,
            node.CreatedUtc,
            node.ModifiedUtc,
            (node.Attributes & FileAttributes.ReparsePoint) != 0);
    }

    public FileMetadata? TryGetFileMetadata(string path)
    {
        var normalized = PathUtils.Normalize(path);
        if (!_nodes.TryGetValue(normalized, out var node) || node.IsDirectory)
        {
            return null;
        }

        return new FileMetadata(normalized, node.Size, node.Attributes, node.CreatedUtc, node.ModifiedUtc);
    }

    public string? TryResolveLinkTarget(string path)
    {
        var normalized = PathUtils.Normalize(path);
        return LinkTargets.TryGetValue(normalized, out var target) ? target : null;
    }

    public bool TryCreateDirectory(string path)
    {
        AddDirectory(path);
        return true;
    }

    public string? TryReadAllText(string path) =>
        _contents.TryGetValue(PathUtils.Normalize(path), out var value) ? value : null;

    public void WriteAllTextAtomic(string path, string contents)
    {
        var normalized = PathUtils.Normalize(path);
        _contents[normalized] = contents;
        AddFile(normalized, contents.Length, content: contents);
    }

    public bool TryDeleteFile(string path, out string? error)
    {
        var normalized = PathUtils.Normalize(path);
        if (DeniedDirectories.Contains(normalized))
        {
            error = "Access denied";
            return false;
        }

        DeletedFiles.Add(normalized);
        _nodes.Remove(normalized);
        error = null;
        return true;
    }

    public bool TryDeleteDirectory(string path, bool recursive, out string? error)
    {
        var normalized = PathUtils.Normalize(path);

        if (DeleteFailures.Contains(normalized))
        {
            error = "Deletion blocked by the test fixture";
            return false;
        }

        DeletedDirectories.Add(normalized);
        if (recursive)
        {
            var prefix = PathUtils.EnsureTrailingSeparator(normalized);
            foreach (var key in _nodes.Keys.Where(k => k.StartsWith(prefix, PathUtils.Comparison)).ToArray())
            {
                _nodes.Remove(key);
            }
        }

        _nodes.Remove(normalized);
        error = null;
        return true;
    }

    public bool TryCopyFile(string sourcePath, string destinationPath, out string? error)
    {
        var source = PathUtils.Normalize(sourcePath);
        var destination = PathUtils.Normalize(destinationPath);

        if (CopyFailures.Contains(source))
        {
            error = "Copy blocked by the test fixture";
            return false;
        }

        if (!_nodes.TryGetValue(source, out var node) || node.IsDirectory)
        {
            error = "Source file not found";
            return false;
        }

        if (_nodes.ContainsKey(destination))
        {
            error = "Destination already exists";
            return false;
        }

        AddFile(destination, node.Size, node.Attributes, node.CreatedUtc, node.ModifiedUtc);
        if (_contents.TryGetValue(source, out var content))
        {
            _contents[destination] = content;
        }

        CopiedFiles.Add((source, destination));
        error = null;
        return true;
    }
}
