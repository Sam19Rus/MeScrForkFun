using System.Collections.Concurrent;
using DiskCleaner.Core.Models;

namespace DiskCleaner.Testing;

/// <summary>
/// Synchronous, thread-safe <see cref="IProgress{T}"/> collector.
/// </summary>
/// <remarks>
/// <see cref="Progress{T}"/> posts to a synchronization context, which makes
/// assertions about published snapshots racy. This one records inline.
/// </remarks>
public sealed class CollectingProgress : IProgress<ScanProgress>
{
    private readonly ConcurrentQueue<ScanProgress> _snapshots = new();

    public void Report(ScanProgress value) => _snapshots.Enqueue(value);

    public IReadOnlyList<ScanProgress> Snapshots => _snapshots.ToArray();

    public int Count => _snapshots.Count;
}
