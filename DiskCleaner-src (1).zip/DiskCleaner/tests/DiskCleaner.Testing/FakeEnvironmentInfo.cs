using DiskCleaner.Core.Infrastructure;

namespace DiskCleaner.Testing;

/// <summary>Fabricated machine layout so classification rules can be tested off Windows.</summary>
public sealed class FakeEnvironmentInfo : IEnvironmentInfo
{
    public FakeEnvironmentInfo(SpecialFolders? folders = null, IReadOnlyList<string>? profiles = null)
    {
        Folders = folders ?? Windows();
        Profiles = profiles ?? [];
    }

    public bool IsWindows { get; init; } = true;

    public string MachineName { get; init; } = "TEST-PC";

    public Version? OsVersion { get; init; } = new Version(10, 0, 19045, 0);

    public SpecialFolders Folders { get; init; }

    public IReadOnlyList<string> Profiles { get; init; }

    public IReadOnlyList<string> EnumerateUserProfiles() => Profiles;

    /// <summary>A typical Windows 10 machine with one user, <c>alice</c>.</summary>
    public static SpecialFolders Windows(string user = "alice", string systemDrive = @"C:\")
    {
        var profile = $@"{systemDrive}Users\{user}";
        return new SpecialFolders
        {
            Windows = $@"{systemDrive}Windows",
            System32 = $@"{systemDrive}Windows\System32",
            ProgramFiles = $@"{systemDrive}Program Files",
            ProgramFilesX86 = $@"{systemDrive}Program Files (x86)",
            ProgramData = $@"{systemDrive}ProgramData",
            UsersRoot = $@"{systemDrive}Users",
            UserProfile = profile,
            RoamingAppData = $@"{profile}\AppData\Roaming",
            LocalAppData = $@"{profile}\AppData\Local",
            LocalAppDataLow = $@"{profile}\AppData\LocalLow",
            UserTemp = $@"{profile}\AppData\Local\Temp",
            WindowsTemp = $@"{systemDrive}Windows\Temp",
            StartMenuPrograms = $@"{profile}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs",
            CommonStartMenuPrograms = $@"{systemDrive}ProgramData\Microsoft\Windows\Start Menu\Programs",
        };
    }

    public static FakeEnvironmentInfo DefaultWindows() =>
        new(Windows(), [$@"C:\Users\alice"]);
}
