using DiskCleaner.Core.Infrastructure.IO;

namespace DiskCleaner.Testing;

/// <summary>Disposable temporary directory tree for tests that need a real file system.</summary>
public sealed class TempDirectory : IDisposable
{
    public TempDirectory(string prefix = "diskcleaner-tests")
    {
        Root = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"{prefix}-{Guid.NewGuid():N}");
        Directory.CreateDirectory(Root);
    }

    public string Root { get; }

    /// <summary>Absolute path for a relative path inside the tree (platform separators applied).</summary>
    public string PathOf(string relativePath)
    {
        var normalized = relativePath.Replace('\\', System.IO.Path.DirectorySeparatorChar).Replace('/', System.IO.Path.DirectorySeparatorChar);
        return PathUtils.Combine(Root, normalized);
    }

    /// <summary>Creates a file of exactly <paramref name="size"/> bytes without allocating a buffer.</summary>
    public string WriteFile(string relativePath, long size)
    {
        var full = PathOf(relativePath);
        var parent = System.IO.Path.GetDirectoryName(full);
        if (!string.IsNullOrEmpty(parent))
        {
            Directory.CreateDirectory(parent);
        }

        using var stream = new FileStream(full, FileMode.Create, FileAccess.Write, FileShare.None);
        stream.SetLength(size);
        return full;
    }

    public string CreateDir(string relativePath)
    {
        var full = PathOf(relativePath);
        Directory.CreateDirectory(full);
        return full;
    }

    /// <summary>Creates many small files quickly; returns the number created.</summary>
    public int WriteFiles(string relativeDirectory, int count, long sizeEach = 128)
    {
        var directory = CreateDir(relativeDirectory);
        for (var i = 0; i < count; i++)
        {
            var full = System.IO.Path.Combine(directory, $"file_{i:00000}.bin");
            using var stream = new FileStream(full, FileMode.Create, FileAccess.Write, FileShare.None);
            stream.SetLength(sizeEach);
        }

        return count;
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(Root))
            {
                Directory.Delete(Root, recursive: true);
            }
        }
        catch (IOException)
        {
            // Best effort: a leaked temp directory must not fail the test run.
        }
        catch (UnauthorizedAccessException)
        {
        }
    }
}
