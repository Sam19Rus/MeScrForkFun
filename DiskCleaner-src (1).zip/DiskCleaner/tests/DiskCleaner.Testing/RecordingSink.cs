using System.Collections.Concurrent;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;

namespace DiskCleaner.Testing;

/// <summary>Records everything the scanner reports. Thread-safe: workers call it concurrently.</summary>
public sealed class RecordingSink : IScanSink
{
    private readonly ConcurrentQueue<ScannedEntry> _files = new();
    private readonly ConcurrentQueue<(string Path, int Depth)> _directories = new();
    private readonly ConcurrentQueue<ScanIssue> _issues = new();

    /// <summary>When set, the sink cancels the scan after this many files.</summary>
    public int CancelAfterFiles { get; set; } = int.MaxValue;

    public CancellationTokenSource? Cancellation { get; set; }

    public IReadOnlyCollection<ScannedEntry> Files => _files;

    public IReadOnlyCollection<(string Path, int Depth)> Directories => _directories;

    public IReadOnlyCollection<ScanIssue> Issues => _issues;

    public long FileCount => _files.Count;

    public long TotalBytes => _files.Sum(f => f.Size);

    public void OnDirectory(in ScannedEntry entry, int depth) => _directories.Enqueue((entry.FullPath, depth));

    public void OnFile(in ScannedEntry entry, int depth, string directory)
    {
        _files.Enqueue(entry);

        if (_files.Count >= CancelAfterFiles)
        {
            Cancellation?.Cancel();
        }
    }

    public void OnIssue(ScanIssue issue) => _issues.Enqueue(issue);

    public bool ContainsFile(string path) =>
        _files.Any(f => string.Equals(f.FullPath, path, PathUtils.Comparison));

    public bool VisitedDirectory(string path) =>
        _directories.Any(d => string.Equals(d.Path, path, PathUtils.Comparison));

    public ScanIssue? FirstIssueOfKind(ScanIssueKind kind) => _issues.FirstOrDefault(i => i.Kind == kind);
}
