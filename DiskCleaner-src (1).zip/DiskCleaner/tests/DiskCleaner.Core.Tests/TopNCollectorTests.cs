using DiskCleaner.Core.Infrastructure.Collections;
using Xunit;

namespace DiskCleaner.Core.Tests;

public class TopNCollectorTests
{
    private static TopNCollector<(string Name, long Size)> Create(int capacity) =>
        new(capacity, item => item.Size);

    [Fact]
    public void Keeps_only_the_best_n_in_descending_order()
    {
        var collector = Create(3);

        for (var i = 1; i <= 10; i++)
        {
            collector.TryAdd(($"f{i}", i));
        }

        var top = collector.ToDescendingList();

        Assert.Equal(3, top.Count);
        Assert.Equal([10, 9, 8], top.Select(t => t.Size).ToArray());
        Assert.Equal(10, collector.TotalSeen);
        Assert.Equal(55, collector.TotalBytes);
    }

    [Fact]
    public void Threshold_rejects_smaller_items_without_locking()
    {
        var collector = Create(2);
        collector.TryAdd(("a", 100));
        collector.TryAdd(("b", 200));

        Assert.Equal(100, collector.Threshold);
        Assert.False(collector.TryAdd(("c", 50)));
        Assert.True(collector.TryAdd(("d", 150)));

        Assert.Equal([200, 150], collector.ToDescendingList().Select(t => t.Size).ToArray());
        Assert.Equal(150, collector.Threshold);
    }

    [Fact]
    public void Capacity_is_never_exceeded_under_concurrency()
    {
        var collector = Create(10);
        const int total = 200_000;

        Parallel.For(0, total, i => collector.TryAdd(($"f{i}", i)));

        var top = collector.ToDescendingList();

        Assert.Equal(10, top.Count);
        Assert.Equal(total, collector.TotalSeen);
        Assert.Equal(Enumerable.Range(total - 10, 10).Reverse().Select(i => (long)i).ToArray(), top.Select(t => t.Size).ToArray());
    }

    [Fact]
    public void Zero_capacity_is_clamped_to_one()
    {
        var collector = Create(0);
        collector.TryAdd(("a", 5));
        collector.TryAdd(("b", 9));

        Assert.Equal(1, collector.Capacity);
        Assert.Single(collector.ToDescendingList());
        Assert.Equal(9, collector.ToDescendingList()[0].Size);
    }

    [Fact]
    public void Clear_resets_ranking_but_keeps_cumulative_counters()
    {
        var collector = Create(5);
        collector.TryAdd(("a", 10));
        collector.Clear();

        Assert.Equal(0, collector.Count);
        Assert.Equal(0, collector.Threshold);
        Assert.Equal(1, collector.TotalSeen);
    }

    [Fact]
    public void Snapshot_is_a_copy_not_a_live_view()
    {
        var collector = Create(5);
        collector.TryAdd(("a", 10));

        var snapshot = collector.ToDescendingList();
        collector.TryAdd(("b", 20));

        Assert.Single(snapshot);
        Assert.Equal(2, collector.Count);
    }
}
