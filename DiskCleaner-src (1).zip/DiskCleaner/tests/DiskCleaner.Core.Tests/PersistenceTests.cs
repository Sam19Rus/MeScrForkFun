using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// Settings and history must survive a restart, must not be corrupted by a crash
/// mid-write, and must fall back to safe defaults instead of throwing at startup.
/// </summary>
public class PersistenceTests
{
    private static (ApplicationPaths Paths, JsonSettingsService Settings, TempDirectory Temp) CreateEnvironment()
    {
        var temp = new TempDirectory("dc-persistence");
        var environment = new FakeEnvironmentInfo(
            FakeEnvironmentInfo.Windows() with { LocalAppData = temp.Root },
            []);

        var paths = new ApplicationPaths(environment, new PhysicalFileSystem());
        return (paths, new JsonSettingsService(paths), temp);
    }

    [Fact]
    public void Application_data_stays_inside_the_user_profile()
    {
        var (paths, _, temp) = CreateEnvironment();
        using (temp)
        {
            Assert.Equal(PathUtils.Combine(temp.Root, "DiskCleaner"), paths.RootDirectory);
            Assert.EndsWith("settings.json", paths.SettingsFile, StringComparison.Ordinal);
            Assert.EndsWith("history.json", paths.HistoryFile, StringComparison.Ordinal);
            Assert.Equal("diskcleaner-2026-01-02.log", Path.GetFileName(paths.LogFileFor(new DateTime(2026, 1, 2, 13, 0, 0, DateTimeKind.Utc))));
        }
    }

    [Fact]
    public async Task Missing_settings_file_yields_defaults_without_error()
    {
        var (_, settings, temp) = CreateEnvironment();
        using (temp)
        {
            var loaded = await settings.LoadAsync();

            Assert.Null(settings.LastError);
            Assert.Equal(AppTheme.System, loaded.Theme);
            Assert.True(loaded.EnableDeveloperAnalysis);
            Assert.Equal(RecycleBinBehavior.PreferForUserData, loaded.RecycleBinBehavior);
            Assert.False(loaded.FollowReparsePoints);
        }
    }

    [Fact]
    public async Task Settings_round_trip_preserves_every_user_choice()
    {
        var (paths, settings, temp) = CreateEnvironment();
        using (temp)
        {
            settings.Update(s =>
            {
                s.Theme = AppTheme.Dark;
                s.Language = "ru";
                s.LargeFileThresholdBytes = 512L * 1024 * 1024;
                s.EnableDeveloperAnalysis = false;
                s.FollowReparsePoints = true;
                s.RecycleBinBehavior = RecycleBinBehavior.Always;
                s.ScanDepth = ScanDepth.Exhaustive;
                s.MaxDegreeOfParallelism = 3;
                s.SaveHistoryAutomatically = false;
                s.ExcludedPaths.Add(@"C:\Projects");
                s.ExcludedExtensions.Add("vhd");
                s.EnableVerboseLogging = true;
            });

            await settings.SaveAsync();
            Assert.Null(settings.LastError);

            var reloaded = new JsonSettingsService(paths);
            var loaded = await reloaded.LoadAsync();

            Assert.Equal(AppTheme.Dark, loaded.Theme);
            Assert.Equal("ru", loaded.Language);
            Assert.Equal(512L * 1024 * 1024, loaded.LargeFileThresholdBytes);
            Assert.False(loaded.EnableDeveloperAnalysis);
            Assert.True(loaded.FollowReparsePoints);
            Assert.Equal(RecycleBinBehavior.Always, loaded.RecycleBinBehavior);
            Assert.Equal(ScanDepth.Exhaustive, loaded.ScanDepth);
            Assert.Equal(3, loaded.MaxDegreeOfParallelism);
            Assert.False(loaded.SaveHistoryAutomatically);
            Assert.Equal([@"C:\Projects"], loaded.ExcludedPaths);
            Assert.Equal(["vhd"], loaded.ExcludedExtensions);
            Assert.True(loaded.EnableVerboseLogging);
        }
    }

    [Fact]
    public async Task Settings_are_serialised_as_readable_text_not_numbers()
    {
        var (paths, settings, temp) = CreateEnvironment();
        using (temp)
        {
            settings.Update(s => s.Theme = AppTheme.Dark);
            await settings.SaveAsync();

            var json = File.ReadAllText(paths.SettingsFile);

            Assert.Contains("\"Dark\"", json, StringComparison.Ordinal);
            Assert.Contains("\"largeFileThresholdBytes\"", json, StringComparison.Ordinal);
        }
    }

    [Fact]
    public async Task Corrupt_settings_fall_back_to_defaults_and_report_a_reason()
    {
        var (paths, settings, temp) = CreateEnvironment();
        using (temp)
        {
            Directory.CreateDirectory(paths.RootDirectory);
            await File.WriteAllTextAsync(paths.SettingsFile, "{ this is not json ");

            var loaded = await settings.LoadAsync();

            Assert.NotNull(settings.LastError);
            Assert.Equal(AppTheme.System, loaded.Theme);
        }
    }

    [Fact]
    public async Task Hand_edited_nonsense_is_clamped_on_load()
    {
        var (paths, settings, temp) = CreateEnvironment();
        using (temp)
        {
            Directory.CreateDirectory(paths.RootDirectory);
            await File.WriteAllTextAsync(paths.SettingsFile, """{"maxHistoryRecords":-5,"maxDegreeOfParallelism":9999,"largeFileThresholdBytes":1}""");

            var loaded = await settings.LoadAsync();

            Assert.InRange(loaded.MaxHistoryRecords, 10, 5000);
            Assert.InRange(loaded.MaxDegreeOfParallelism, 0, 64);
            Assert.True(loaded.LargeFileThresholdBytes >= 1024 * 1024);
        }
    }

    [Fact]
    public async Task History_is_persisted_newest_first()
    {
        var (paths, _, temp) = CreateEnvironment();
        using (temp)
        {
            var settings = new JsonSettingsService(paths);
            await settings.LoadAsync();

            var history = new JsonHistoryService(paths, settings);
            await history.LoadAsync();
            Assert.Empty(history.Records);

            var started = new DateTime(2026, 3, 1, 10, 0, 0, DateTimeKind.Utc);
            for (var i = 0; i < 3; i++)
            {
                await history.AppendAsync(new CleanupRunRecord
                {
                    StartedAtUtc = started.AddHours(i),
                    CompletedAtUtc = started.AddHours(i).AddMinutes(2),
                    Mode = ScanMode.Quick,
                    FreedBytes = (i + 1) * 1_000,
                    DeletedFileCount = 10 * (i + 1),
                    Categories =
                    [
                        new CategoryBreakdown { Category = ScanCategory.TemporaryFiles, FreedBytes = (i + 1) * 1_000, FileCount = 10 * (i + 1) },
                    ],
                    Skipped =
                    [
                        new SkippedFile { Path = @"C:\Temp\locked.dat", Kind = ScanIssueKind.FileInUse, Reason = "The file is being used by another process" },
                    ],
                });
            }

            Assert.Equal(3, history.Records.Count);
            Assert.Equal(6_000, history.TotalFreedBytes);
            Assert.Equal(started.AddHours(2), history.Records[0].StartedAtUtc);
            Assert.Equal(TimeSpan.FromMinutes(2), history.Records[0].Duration);
            Assert.Single(history.Records[0].Skipped);
            Assert.Equal(ScanIssueKind.FileInUse, history.Records[0].Skipped[0].Kind);

            // Survives a restart.
            var reloaded = new JsonHistoryService(paths, settings);
            var records = await reloaded.LoadAsync();

            Assert.Equal(3, records.Count);
            Assert.Equal(6_000, reloaded.TotalFreedBytes);
            Assert.Equal(ScanCategory.TemporaryFiles, records[0].Categories[0].Category);
        }
    }

    [Fact]
    public async Task History_is_trimmed_to_the_configured_limit()
    {
        var (paths, _, temp) = CreateEnvironment();
        using (temp)
        {
            var settings = new JsonSettingsService(paths);
            await settings.LoadAsync();
            settings.Update(s => s.MaxHistoryRecords = 10);

            var history = new JsonHistoryService(paths, settings);
            for (var i = 0; i < 25; i++)
            {
                await history.AppendAsync(new CleanupRunRecord
                {
                    StartedAtUtc = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMinutes(i),
                    CompletedAtUtc = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddMinutes(i),
                    FreedBytes = i,
                });
            }

            Assert.Equal(10, history.Records.Count);
            Assert.Equal(24, history.Records[0].FreedBytes);   // newest kept
        }
    }

    [Fact]
    public async Task History_can_be_cleared_and_single_records_removed()
    {
        var (paths, _, temp) = CreateEnvironment();
        using (temp)
        {
            var settings = new JsonSettingsService(paths);
            await settings.LoadAsync();
            var history = new JsonHistoryService(paths, settings);

            var first = new CleanupRunRecord { StartedAtUtc = DateTime.UtcNow, FreedBytes = 1 };
            var second = new CleanupRunRecord { StartedAtUtc = DateTime.UtcNow, FreedBytes = 2 };
            await history.AppendAsync(first);
            await history.AppendAsync(second);

            await history.RemoveAsync(second.Id);
            Assert.Single(history.Records);
            Assert.Equal(1, history.Records[0].FreedBytes);

            await history.ClearAsync();
            Assert.Empty(history.Records);

            var reloaded = new JsonHistoryService(paths, settings);
            Assert.Empty(await reloaded.LoadAsync());
        }
    }

    [Fact]
    public async Task History_is_not_written_when_the_user_disabled_it()
    {
        var (paths, _, temp) = CreateEnvironment();
        using (temp)
        {
            var settings = new JsonSettingsService(paths);
            await settings.LoadAsync();
            settings.Update(s => s.SaveHistoryAutomatically = false);

            var history = new JsonHistoryService(paths, settings);
            await history.AppendAsync(new CleanupRunRecord { StartedAtUtc = DateTime.UtcNow, FreedBytes = 5 });

            Assert.Single(history.Records);          // kept in memory
            Assert.False(File.Exists(paths.HistoryFile));   // but not persisted
        }
    }
}
