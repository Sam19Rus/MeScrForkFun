using DiskCleaner.Core.Scanning;
using Xunit;

namespace DiskCleaner.Core.Tests;

public class DirectorySizeAggregatorTests
{
    private static DirectorySizeAggregator BuildSampleTree()
    {
        var aggregator = new DirectorySizeAggregator();

        aggregator.TryRegisterDirectory("/root", 0, null, "root", null);
        aggregator.TryRegisterDirectory("/root/a", 1, "/root", "a", null);
        aggregator.TryRegisterDirectory("/root/a/b", 2, "/root/a", "b", null);
        aggregator.TryRegisterDirectory("/root/c", 1, "/root", "c", null);

        aggregator.AddFile("/root", 10);
        aggregator.AddFile("/root/a", 20);
        aggregator.AddFile("/root/a", 15);
        aggregator.AddFile("/root/a/b", 5);
        aggregator.AddFile("/root/c", 100);

        return aggregator;
    }

    [Fact]
    public void Subtree_sizes_fold_children_into_parents_exactly_once()
    {
        var aggregates = BuildSampleTree().BuildAggregates().ToDictionary(a => a.Path, StringComparer.Ordinal);

        Assert.Equal(150, aggregates["/root"].SubtreeBytes);
        Assert.Equal(40, aggregates["/root/a"].SubtreeBytes);
        Assert.Equal(5, aggregates["/root/a/b"].SubtreeBytes);
        Assert.Equal(100, aggregates["/root/c"].SubtreeBytes);

        Assert.Equal(10, aggregates["/root"].OwnBytes);
        Assert.Equal(35, aggregates["/root/a"].OwnBytes);

        Assert.Equal(5, aggregates["/root"].SubtreeFileCount);
        Assert.Equal(3, aggregates["/root/a"].SubtreeFileCount);
    }

    [Fact]
    public void Depth_and_parent_are_preserved_for_tree_building()
    {
        var aggregates = BuildSampleTree().BuildAggregates().ToDictionary(a => a.Path, StringComparer.Ordinal);

        Assert.Equal(0, aggregates["/root"].Depth);
        Assert.Equal(2, aggregates["/root/a/b"].Depth);
        Assert.Equal("/root/a", aggregates["/root/a/b"].ParentPath);
        Assert.Equal("b", aggregates["/root/a/b"].Name);
    }

    [Fact]
    public void TopDirectories_orders_by_subtree_size()
    {
        var top = BuildSampleTree().TopDirectories(2);

        Assert.Equal(2, top.Count);
        Assert.Equal("/root", top[0].Path);
        Assert.Equal("/root/c", top[1].Path);
    }

    [Fact]
    public void Tracking_cap_keeps_memory_bounded_without_losing_bytes()
    {
        var aggregator = new DirectorySizeAggregator(maxTrackedDirectories: 1024);
        aggregator.TryRegisterDirectory("/root", 0, null, "root", null);

        for (var i = 0; i < 1_200; i++)
        {
            aggregator.TryRegisterDirectory($"/root/d{i:0000}", 1, "/root", $"d{i:0000}", null);
        }

        Assert.Equal(1024, aggregator.TrackedCount);

        // d1023..d1199 could not be registered; their bytes fall back to the nearest
        // tracked ancestor instead of disappearing from the totals.
        aggregator.AddFile("/root/d1199", 100);
        aggregator.AddFile("/root/d1100", 50);

        Assert.Equal(150, aggregator.TotalBytes);
        Assert.Equal(0, aggregator.UntrackedBytes);

        var root = aggregator.BuildAggregates().Single(a => a.Path == "/root");
        Assert.Equal(150, root.OwnBytes);
        Assert.Equal(150, root.SubtreeBytes);
    }

    [Fact]
    public void Bytes_with_no_tracked_ancestor_are_still_accounted_for()
    {
        var aggregator = new DirectorySizeAggregator();

        aggregator.AddFile("/nowhere/at/all/file.bin", 42);

        Assert.Equal(42, aggregator.TotalBytes);
        Assert.Equal(42, aggregator.UntrackedBytes);
        Assert.Empty(aggregator.BuildAggregates());
    }

    [Fact]
    public void Concurrent_accumulation_is_exact()
    {
        var aggregator = new DirectorySizeAggregator();
        aggregator.TryRegisterDirectory("/root", 0, null, "root", null);
        for (var i = 0; i < 8; i++)
        {
            aggregator.TryRegisterDirectory($"/root/d{i}", 1, "/root", $"d{i}", null);
        }

        const int perDirectory = 5_000;
        Parallel.For(0, 8, d =>
        {
            for (var i = 0; i < perDirectory; i++)
            {
                aggregator.AddFile($"/root/d{d}", 3);
            }
        });

        Assert.Equal(8L * perDirectory * 3, aggregator.TotalBytes);
        var root = aggregator.BuildAggregates().Single(a => a.Path == "/root");
        Assert.Equal(8 * perDirectory, root.SubtreeFileCount);
    }

    [Fact]
    public void Clear_resets_everything()
    {
        var aggregator = BuildSampleTree();
        aggregator.Clear();

        Assert.Equal(0, aggregator.TrackedCount);
        Assert.Equal(0, aggregator.TotalBytes);
        Assert.Empty(aggregator.BuildAggregates());
    }
}
