using DiskCleaner.Core.Application;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The ledger is what keeps the report honest between a cleanup run and the next
/// scan: deleted rows disappear, everything else stays, and a new scan wipes the
/// memory so regenerated paths (TEMP!) can be shown again.
/// </summary>
public class CleanupLedgerTests
{
    private static CleanupRunRecord Record(params DeletedEntry[] deleted) => new()
    {
        StartedAtUtc = DateTime.UtcNow,
        CompletedAtUtc = DateTime.UtcNow,
        Deleted = deleted,
    };

    private static DeletedEntry File(string path, long bytes = 100, bool recycled = false) => new()
    {
        Path = path,
        Kind = ScanItemKind.File,
        Bytes = bytes,
        Recycled = recycled,
    };

    private static DeletedEntry Dir(string path, long bytes = 1_000) => new()
    {
        Path = path,
        Kind = ScanItemKind.Directory,
        Bytes = bytes,
    };

    [Fact]
    public void A_deleted_file_hides_exactly_itself()
    {
        var ledger = new CleanupLedger();

        ledger.Register(Record(File(@"C:\Users\alice\AppData\Local\Temp\a.tmp")));

        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\a.tmp"));
        Assert.False(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\b.tmp"));
        Assert.False(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp"));
    }

    [Fact]
    public void A_deleted_directory_hides_everything_under_it()
    {
        var ledger = new CleanupLedger();

        ledger.Register(Record(Dir(@"C:\Users\alice\AppData\Local\Temp\session")));

        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\session"));
        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\session\deep\nested\file.dat"));
        Assert.False(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\session2"));
        Assert.False(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp"));
    }

    [Fact]
    public void Trailing_separators_and_query_depth_do_not_matter()
    {
        var ledger = new CleanupLedger();

        // Registered with a trailing separator, queried with a deep child path.
        ledger.Register(Record(Dir(@"C:\Users\alice\AppData\Local\Temp\session\")));

        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\session"));
        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\session\FILE.DAT"));

        // Case handling follows PathUtils.Comparer, which is case-insensitive on the
        // product's only runtime platform (Windows); asserting it here would make the
        // suite platform-dependent.
        if (PathUtils.Comparison == StringComparison.OrdinalIgnoreCase)
        {
            Assert.True(ledger.IsDeleted(@"c:\users\alice\appdata\local\temp\session\file.dat"));
        }
    }

    [Fact]
    public void Totals_count_every_deletion_once()
    {
        var ledger = new CleanupLedger();

        ledger.Register(Record(File(@"C:\a.tmp", 100), Dir(@"C:\d", 900)));
        // A second run over an overlapping plan must not double-credit.
        ledger.Register(Record(File(@"C:\a.tmp", 100), File(@"C:\b.tmp", 50, recycled: true)));

        Assert.Equal(3, ledger.DeletedCount);
        Assert.Equal(1_050, ledger.DeletedBytes);
        Assert.True(ledger.AnyRecycled);
    }

    [Fact]
    public void An_empty_record_changes_nothing_and_raises_nothing()
    {
        var ledger = new CleanupLedger();
        var raised = 0;
        ledger.Changed += (_, _) => raised++;

        ledger.Register(Record());

        Assert.Equal(0, raised);
        Assert.Equal(0, ledger.DeletedCount);
    }

    [Fact]
    public void Reset_forgets_everything()
    {
        var ledger = new CleanupLedger();
        ledger.Register(Record(Dir(@"C:\gone")));

        ledger.Reset();

        Assert.False(ledger.IsDeleted(@"C:\gone\x"));
        Assert.Equal(0, ledger.DeletedCount);
        Assert.Equal(0, ledger.DeletedBytes);
        Assert.False(ledger.AnyRecycled);
    }

    [Fact]
    public void Garbage_input_is_never_reported_as_deleted()
    {
        var ledger = new CleanupLedger();
        ledger.Register(Record(Dir(@"C:\gone")));

        Assert.False(ledger.IsDeleted(string.Empty));
        Assert.False(ledger.IsDeleted("   "));
    }

    [Fact]
    public void The_ledger_feeds_from_executor_runs_and_resets_on_a_new_scan()
    {
        // Wiring test: the DI-registered ledger listens to the executor and the scanner
        // without any view model in between.
        var executor = new FakeRunCompletedExecutor();
        var scan = new FakeScanService();
        var ledger = new CleanupLedger(executor, scan);

        executor.Raise(Record(Dir(@"C:\Users\alice\AppData\Local\Temp\old")));
        Assert.True(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\old\x.dat"));

        scan.RaiseCompleted(new ScanResult());
        Assert.False(ledger.IsDeleted(@"C:\Users\alice\AppData\Local\Temp\old\x.dat"));
    }

    private sealed class FakeRunCompletedExecutor : ICleanupExecutor
    {
        public bool IsRunning => false;

        public event EventHandler<CleanupRunRecord>? RunCompleted;

        public Task<CleanupRunRecord> ExecuteAsync(
            CleanupPlan plan,
            ScanMode mode,
            IProgress<CleanupProgress>? progress = null,
            CancellationToken cancellationToken = default) =>
            throw new NotSupportedException();

        public void Raise(CleanupRunRecord record) => RunCompleted?.Invoke(this, record);
    }
}
