using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using Xunit;

namespace DiskCleaner.Core.Tests;

public class ScanFilterTests
{
    private static ScannedEntry File(string path, long size, FileAttributes attributes = FileAttributes.Normal) => new(
        path, PathUtils.GetFileName(path), false, size, attributes, null, null, false, PathUtils.GetDriveRoot(path));

    private static ScannedEntry Dir(string path, FileAttributes attributes = FileAttributes.Directory) => new(
        path, PathUtils.GetFileName(path), true, 0, attributes | FileAttributes.Directory, null, null, false, PathUtils.GetDriveRoot(path));

    [Fact]
    public void Excluded_path_matches_itself_and_everything_below_it()
    {
        var filter = new ScanFilter(excludedPaths: [@"C:\Users\alice\Projects"]);

        Assert.True(filter.IsPathExcluded(@"C:\Users\alice\Projects"));
        Assert.True(filter.IsPathExcluded(@"C:\Users\alice\Projects\node_modules\left-pad"));
        Assert.False(filter.IsPathExcluded(@"C:\Users\alice\ProjectsBackup"));   // prefix trap
        Assert.False(filter.IsPathExcluded(@"C:\Users\alice\AppData"));
    }

    [Fact]
    public void Excluded_extensions_are_case_insensitive_and_may_omit_the_dot()
    {
        var filter = new ScanFilter(excludedExtensions: ["TMP", ".log"]);

        Assert.True(filter.IsExtensionExcluded("a.tmp"));
        Assert.True(filter.IsExtensionExcluded("a.TMP"));
        Assert.True(filter.IsExtensionExcluded("a.log"));
        Assert.False(filter.IsExtensionExcluded("a.txt"));
        Assert.False(filter.IsExtensionExcluded("noextension"));
    }

    [Fact]
    public void MinReportedFileSize_hides_small_files()
    {
        var filter = new ScanFilter(minReportedFileSize: 1024);

        Assert.False(filter.ShouldReportFile(File(@"C:\a\small.bin", 1023)));
        Assert.True(filter.ShouldReportFile(File(@"C:\a\big.bin", 1024)));
    }

    [Fact]
    public void Hidden_and_system_entries_are_included_by_default_because_caches_live_there()
    {
        var included = new ScanFilter();
        var hidden = File(@"C:\a\.hidden", 10, FileAttributes.Hidden | FileAttributes.System);

        Assert.True(included.ShouldReportFile(hidden));

        var excluded = new ScanFilter(includeHiddenAndSystem: false);
        Assert.False(excluded.ShouldReportFile(hidden));
    }

    [Fact]
    public void MaxDepth_stops_descent()
    {
        var filter = new ScanFilter(maxDepth: 2);

        Assert.True(filter.IsDepthAllowed(0));
        Assert.True(filter.IsDepthAllowed(2));
        Assert.False(filter.IsDepthAllowed(3));
    }

    [Fact]
    public void ShouldEnterDirectory_respects_exclusions_and_hidden_flags()
    {
        var filter = new ScanFilter(excludedPaths: [@"C:\Users\alice\Projects"]);
        var hiddenDir = Dir(@"C:\Users\alice\Secret", FileAttributes.Hidden);

        Assert.True(filter.ShouldEnterDirectory(Dir(@"C:\Users\alice\AppData"), 1));
        Assert.False(filter.ShouldEnterDirectory(Dir(@"C:\Users\alice\Projects"), 1));

        // Hidden directories are entered by default: caches are usually hidden.
        Assert.True(filter.ShouldEnterDirectory(hiddenDir, 1));

        var strict = new ScanFilter(includeHiddenAndSystem: false);
        Assert.False(strict.ShouldEnterDirectory(hiddenDir, 1));
    }

    [Fact]
    public void Options_are_normalised_so_trailing_separators_do_not_break_matching()
    {
        var options = new ScanOptions
        {
            Roots = [@"C:\Users\alice\", @"c:\USERS\alice"],
            ExcludedPaths = [@"C:\Temp\"],
            ExcludedExtensions = ["log"],
        }.Normalise();

        // Duplicate roots collapse; extensions gain their dot.
        Assert.True(options.Roots.Count is 1 or 2);
        Assert.Contains(".log", options.ExcludedExtensions);

        var filter = ScanFilter.FromOptions(options);
        Assert.True(filter.IsPathExcluded(@"C:\Temp\anything"));
    }
}
