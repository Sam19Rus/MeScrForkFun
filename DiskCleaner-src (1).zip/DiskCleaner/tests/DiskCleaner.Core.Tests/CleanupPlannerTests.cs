using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Models;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The plan is the last thing standing between analysis and deletion, so its refusal
/// behaviour is tested as strictly as the safety policy itself.
/// </summary>
public class CleanupPlannerTests
{
    private static readonly FakeEnvironmentInfo Env = FakeEnvironmentInfo.DefaultWindows();

    private static CleanupPlanner CreatePlanner() =>
        new(new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]), Env));

    private static ScanItem Item(string path, long size = 1_000, CleanupConfidence confidence = CleanupConfidence.Safe) => new()
    {
        Path = path,
        Name = System.IO.Path.GetFileName(path),
        Kind = ScanItemKind.Directory,
        Size = size,
        FileCount = 12,
        Category = ScanCategory.TemporaryFiles,
        Confidence = confidence,
        RiskLevel = RiskLevel.Low,
        IsDeletable = true,
        DeletionMethod = DeletionMethod.Permanent,
        Reason = "temp.user",
        Explanation = "Temporary files.",
        SourceAnalyzer = "TempAnalyzer",
    };

    [Fact]
    public void Adding_an_item_updates_totals_and_raises_the_event()
    {
        var planner = CreatePlanner();
        var raised = 0;
        planner.PlanChanged += (_, _) => raised++;

        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp", 1_000), out var rejection));
        Assert.Null(rejection);
        Assert.Equal(1, raised);
        Assert.Equal(1, planner.Count);
        Assert.Equal(1_000, planner.TotalBytes);
        Assert.Equal(12, planner.TotalFileCount);
        Assert.True(planner.Contains(@"C:\Users\alice\AppData\Local\Temp"));
    }

    [Fact]
    public void The_same_path_cannot_enter_the_plan_twice()
    {
        var planner = CreatePlanner();

        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out _));
        Assert.False(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp", 9_999), out var rejection));

        Assert.NotNull(rejection);
        Assert.Equal(1, planner.Count);
        Assert.Equal(1_000, planner.TotalBytes);
    }

    [Fact]
    public void Hard_blocked_paths_are_refused_even_though_the_user_picked_them()
    {
        var planner = CreatePlanner();

        string[] forbidden =
        [
            @"C:\Windows\System32\drivers\etc\hosts",
            @"C:\Windows\WinSxS\amd64_x",
            @"C:\Program Files\App\app.exe",
            @"C:\Windows",
            @"C:\pagefile.sys",
            @"C:\",
            @"C:\Users",
        ];

        foreach (var path in forbidden)
        {
            Assert.False(planner.TryAdd(Item(path), out var rejection), $"expected refusal for {path}");
            Assert.False(string.IsNullOrWhiteSpace(rejection));
        }

        Assert.Equal(0, planner.Count);
    }

    [Fact]
    public void User_data_enters_only_as_an_explicit_choice_and_keeps_its_risk()
    {
        var planner = CreatePlanner();
        var document = Item(@"C:\Users\alice\Documents\report.docx", 5_000, CleanupConfidence.NeedsReview);

        // The planner always acts on an explicit user choice, so it is accepted…
        Assert.True(planner.TryAdd(document, out _));

        // …but the operation carries the honest risk and can never be marked "safe".
        var operation = Assert.Single(planner.Current.Operations);
        Assert.Equal(RiskLevel.High, operation.RiskLevel);
        Assert.Equal(CleanupConfidence.NeedsReview, operation.Confidence);
    }

    [Fact]
    public void Items_that_are_not_deletable_cannot_be_planned()
    {
        var planner = CreatePlanner();
        var item = Item(@"C:\Users\alice\AppData\Local\Docker\wsl\data\ext4.vhdx", 40_000_000_000);

        // A virtual-disk style entry arrives from the analyzer as non-deletable.
        var notDeletable = new ScanItem
        {
            Path = item.Path,
            Name = "ext4.vhdx",
            Size = item.Size,
            Category = ScanCategory.DeveloperData,
            Confidence = CleanupConfidence.NeedsReview,
            RiskLevel = RiskLevel.Critical,
            IsDeletable = false,
            DeletionMethod = DeletionMethod.None,
            SourceAnalyzer = "AppDataAnalyzer",
        };

        Assert.False(planner.TryAdd(notDeletable, out var rejection));
        Assert.Equal("plan.not-deletable", rejection);
        Assert.Equal(0, planner.Count);
        _ = item;
    }

    [Fact]
    public void Removing_and_clearing_raise_events_only_when_something_changed()
    {
        var planner = CreatePlanner();
        var raised = 0;
        planner.PlanChanged += (_, _) => raised++;

        planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out _);
        planner.TryAdd(Item(@"C:\Windows\Temp", 2_000), out _);
        Assert.Equal(2, raised);

        Assert.True(planner.Remove(@"C:\Windows\Temp"));
        Assert.False(planner.Remove(@"C:\Windows\Temp"));     // already gone: no event
        Assert.Equal(3, raised);

        planner.Clear();
        Assert.Equal(4, raised);

        planner.Clear();                                        // already empty: no event
        Assert.Equal(4, raised);
        Assert.Equal(0, planner.Count);
    }

    [Fact]
    public void The_plan_groups_by_category_and_flags_high_risk_operations()
    {
        var planner = CreatePlanner();
        planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp", 1_000), out _);

        var document = Item(@"C:\Users\alice\Documents\report.docx", 5_000, CleanupConfidence.NeedsReview);
        document.Category = ScanCategory.LargeFiles;
        planner.TryAdd(document, out _);

        var plan = planner.Current;
        Assert.Equal(6_000, plan.TotalExpectedBytes);
        Assert.Single(plan.ByCategory.Single(g => g.Key == ScanCategory.TemporaryFiles));
        Assert.Single(plan.ByCategory.Single(g => g.Key == ScanCategory.LargeFiles));

        var risky = Assert.Single(plan.HighRiskOperations);
        Assert.Equal(@"C:\Users\alice\Documents\report.docx", risky.TargetPath);
        Assert.False(plan.IsEmpty);
    }

    [Fact]
    public void Exclusions_are_session_state_and_do_not_touch_the_plan()
    {
        var exclusions = new ReportExclusions();
        var raised = 0;
        exclusions.Changed += (_, _) => raised++;

        Assert.True(exclusions.Exclude(@"C:\Users\alice\AppData\Local\Temp"));
        Assert.False(exclusions.Exclude(@"C:\Users\alice\AppData\Local\Temp"));   // idempotent
        Assert.Equal(1, raised);
        // Windows paths are case-insensitive; on other platforms the comparer is ordinal.
        var caseInsensitive = System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(
            System.Runtime.InteropServices.OSPlatform.Windows);
        Assert.Equal(
            caseInsensitive,
            exclusions.IsExcluded(@"c:\users\alice\appdata\local\temp"));
        Assert.True(exclusions.IsExcluded(@"C:\Users\alice\AppData\Local\Temp"));

        Assert.True(exclusions.Include(@"C:\Users\alice\AppData\Local\Temp"));
        Assert.False(exclusions.IsExcluded(@"C:\Users\alice\AppData\Local\Temp"));

        exclusions.Clear();
        exclusions.Clear();                                                        // no event when empty
        Assert.Equal(2, raised);
    }

    [Fact]
    public void A_child_of_a_planned_directory_is_refused_as_covered()
    {
        var planner = CreatePlanner();

        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out _));
        Assert.False(
            planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp\sub\file.log"), out var rejection),
            "a file inside a planned directory must not become a second operation");
        Assert.Equal("plan.covered-by-parent", rejection);
        Assert.Equal(1, planner.Count);
    }

    [Fact]
    public void Adding_a_parent_directory_supersedes_its_planned_children()
    {
        var planner = CreatePlanner();

        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp\a"), out _));
        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp\b"), out _));
        Assert.Equal(2, planner.Count);

        // One operation for the whole folder replaces the two child operations:
        // the same bytes, no confusing "already gone" skips during the run.
        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out _));

        Assert.Equal(1, planner.Count);
        Assert.True(planner.Contains(@"C:\Users\alice\AppData\Local\Temp"));
    }

    [Fact]
    public void Refusals_return_stable_keys_not_prose()
    {
        var planner = CreatePlanner();

        Assert.True(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out _));
        Assert.False(planner.TryAdd(Item(@"C:\Users\alice\AppData\Local\Temp"), out var duplicate));
        Assert.Equal("plan.already-in-plan", duplicate);

        Assert.False(planner.TryAdd(Item(@"C:\Windows\System32"), out var blocked));
        Assert.Equal("hard-blocked.self", blocked);

        // A volume root is refused for everyone, even on an explicit choice.
        Assert.False(planner.TryAdd(Item(@"C:\"), out var root));
        Assert.Equal("volume-root", root);
    }
}
