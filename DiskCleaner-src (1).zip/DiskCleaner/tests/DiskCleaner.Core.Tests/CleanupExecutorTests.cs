using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Cleanup;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Services;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The executor is the only component that removes data, so its guarantees are tested
/// directly: it deletes exactly what the user confirmed, it skips what it cannot take,
/// and it never forces its way past a lock or the safety policy.
/// </summary>
public class CleanupExecutorTests
{
    private const string Local = @"C:\Users\alice\AppData\Local";

    private sealed class Fixture
    {
        public InMemoryFileSystem Fs { get; } = new();
        public FakeEnvironmentInfo Env { get; } = FakeEnvironmentInfo.DefaultWindows();
        public FakeDeletionService Deletion { get; } = new();
        public ManualClock Clock { get; } = new(new DateTime(2026, 6, 1, 12, 0, 0, DateTimeKind.Utc));
        public FakeDriveService Drives { get; } = new();
        public FakePrivilegeService Privileges { get; } = new();
        public RecordingHistoryService History { get; } = new();
        public AppSettings Settings { get; } = new();
        public FakeSettingsService SettingsService { get; }

        public SafetyPolicy Policy { get; }

        public Fixture()
        {
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, ["C:\\"]), Env);
            SettingsService = new FakeSettingsService(Settings);
            Drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100));
        }

        public CleanupExecutor CreateExecutor(ISafetyPolicy? executorPolicy = null) => new(
            Deletion,
            executorPolicy ?? Policy,
            Fs,
            Drives,
            History,
            SettingsService,
            Privileges,
            Clock);

        /// <summary>Builds a plan the way the planner would: validated against the policy.</summary>
        public CleanupPlan Plan(ISafetyPolicy? buildPolicy = null, params CleanupOperation[] operations)
        {
            var policy = buildPolicy ?? Policy;
            var plan = new CleanupPlan();

            foreach (var operation in operations)
            {
                var added = plan.TryAdd(operation, policy, out _, explicitUserChoice: true);
                Assert.True(added, $"fixture could not add {operation.TargetPath} to the plan");
            }

            return plan;
        }

        public CleanupOperation Op(
            string path,
            ScanCategory category,
            long bytes,
            DeletionMethod method = DeletionMethod.Permanent,
            ScanItemKind kind = ScanItemKind.Directory)
        {
            // A plan is built from a scan, so the path existed when it was added.
            if (kind == ScanItemKind.File)
            {
                Fs.AddFile(path, bytes);
            }
            else if (kind == ScanItemKind.Directory)
            {
                Fs.AddDirectory(path);
            }

            return new()
            {
                TargetPath = path,
            DisplayName = System.IO.Path.GetFileName(path),
            Category = category,
            Kind = kind,
            Method = method,
                RiskLevel = RiskLevel.Medium,
                Confidence = CleanupConfidence.Likely,
                ExpectedBytes = bytes,
            };
        }
    }

    /// <summary>History double: records what the executor persisted.</summary>
    private sealed class RecordingHistoryService : IHistoryService
    {
        private readonly List<CleanupRunRecord> _records = [];

        public IReadOnlyList<CleanupRunRecord> Records => _records;

        public long TotalFreedBytes => _records.Sum(r => r.FreedBytes);

        public string? LastError => null;

        public event EventHandler? HistoryChanged;

        public Task<IReadOnlyList<CleanupRunRecord>> LoadAsync(CancellationToken cancellationToken = default) =>
            Task.FromResult<IReadOnlyList<CleanupRunRecord>>(_records);

        public Task AppendAsync(CleanupRunRecord record, CancellationToken cancellationToken = default)
        {
            _records.Add(record);
            HistoryChanged?.Invoke(this, EventArgs.Empty);
            return Task.CompletedTask;
        }

        public Task RemoveAsync(Guid id, CancellationToken cancellationToken = default)
        {
            _records.RemoveAll(r => r.Id == id);
            return Task.CompletedTask;
        }

        public Task ClearAsync(CancellationToken cancellationToken = default)
        {
            _records.Clear();
            return Task.CompletedTask;
        }
    }

    /// <summary>
    /// A policy that allows everything, used to prove the executor does not simply trust
    /// the plan it was handed.
    /// </summary>
    private sealed class PermissivePolicy : ISafetyPolicy
    {
        public ProtectedRoots Roots => new();

        public SafetyVerdict Evaluate(
            string path,
            ScanCategory category = ScanCategory.Unknown,
            ScanItemKind kind = ScanItemKind.File,
            bool explicitUserChoice = false) => new() { IsAllowed = true };

        public bool IsProtected(string path) => false;

        public bool RequiresElevation(string path) => false;
    }

    /// <summary><see cref="Progress{T}"/> posts asynchronously; tests need deterministic delivery.</summary>
    private sealed class SynchronousProgress(List<CleanupProgress> sink) : IProgress<CleanupProgress>
    {
        public void Report(CleanupProgress value) => sink.Add(value);
    }

    // ------------------------------------------------------------ happy path

    [Fact]
    public async Task A_confirmed_plan_is_executed_and_the_freed_space_is_credited()
    {
        var fixture = new Fixture();
        var plan = fixture.Plan(operations:
        [
            fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000_000),
            fixture.Op(Local + @"\Microsoft\Windows\Explorer", ScanCategory.Thumbnails, 250_000),
        ]);

        var record = await fixture.CreateExecutor().ExecuteAsync(plan, ScanMode.Quick);

        Assert.Equal(1_250_000, record.FreedBytes);
        Assert.Equal(2, record.DeletedDirectoryCount);
        Assert.Equal(0, record.SkippedCount);
        Assert.Equal(0, record.FailedCount);
        Assert.Equal(2, record.Categories.Count);
        Assert.True(fixture.Deletion.WasDeleted(Local + @"\Temp"));
        Assert.True(fixture.Deletion.WasDeleted(Local + @"\Microsoft\Windows\Explorer"));
        Assert.All(plan.Operations, o => Assert.Equal(CleanupOperationStatus.Succeeded, o.Status));
    }

    [Fact]
    public async Task Only_paths_that_are_in_the_plan_are_touched()
    {
        var fixture = new Fixture();

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000)]),
            ScanMode.Quick);

        var requested = Assert.Single(fixture.Deletion.Requests);
        Assert.Equal(Local + @"\Temp", requested.Path);
        Assert.True(requested.IsDirectory);
    }

    [Fact]
    public async Task Progress_is_reported_once_per_operation_plus_a_final_report()
    {
        var fixture = new Fixture();
        var reports = new List<CleanupProgress>();

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations:
            [
                fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000),
                fixture.Op(Local + @"\CrashDumps", ScanCategory.CrashDumps, 2_000),
            ]),
            ScanMode.Quick,
            new SynchronousProgress(reports));

        Assert.Equal(3, reports.Count);
        Assert.Equal(2, reports[^1].CompletedOperations);
        Assert.Equal(3_000, reports[^1].FreedBytes);
        Assert.Equal(1.0, reports[^1].PercentComplete);
    }

    // ------------------------------------------------------------ safe skips

    [Fact]
    public async Task A_locked_file_is_skipped_with_a_reason_and_the_run_continues()
    {
        var fixture = new Fixture();
        var locked = Local + @"\Temp\locked.tmp";
        fixture.Deletion.InUse.Add(locked);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations:
            [
                fixture.Op(locked, ScanCategory.TemporaryFiles, 1_000, kind: ScanItemKind.File),
                fixture.Op(Local + @"\Temp\other", ScanCategory.TemporaryFiles, 2_000),
            ]),
            ScanMode.Quick);

        Assert.Equal(1, record.SkippedCount);
        Assert.Equal(2_000, record.FreedBytes);

        var skipped = Assert.Single(record.Skipped);
        Assert.Equal(locked, skipped.Path);
        Assert.Equal(ScanIssueKind.FileInUse, skipped.Kind);
        Assert.Equal("cleanup.file-in-use", skipped.Reason);
    }

    [Fact]
    public async Task An_access_denied_path_is_skipped_and_recorded_under_its_category()
    {
        var fixture = new Fixture();
        var denied = @"C:\Windows\SoftwareDistribution\Download";
        fixture.Deletion.Denied.Add(denied);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(denied, ScanCategory.WindowsUpdateCache, 5_000_000)]),
            ScanMode.Quick);

        Assert.Equal(0, record.FreedBytes);
        Assert.Equal(1, record.SkippedCount);

        var skipped = Assert.Single(record.Skipped);
        Assert.Equal(denied, skipped.Path);
        Assert.Equal(ScanIssueKind.AccessDenied, skipped.Kind);

        var breakdown = Assert.Single(record.Categories);
        Assert.Equal(ScanCategory.WindowsUpdateCache, breakdown.Category);
        Assert.Equal(1, breakdown.SkippedCount);
        Assert.Equal(0, breakdown.FreedBytes);
    }

    [Fact]
    public async Task A_path_that_vanished_is_skipped_as_already_gone()
    {
        var fixture = new Fixture();
        var gone = Local + @"\Temp\gone";
        fixture.Deletion.Missing.Add(gone);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(gone, ScanCategory.TemporaryFiles, 10)]),
            ScanMode.Quick);

        Assert.Equal(ScanIssueKind.NotFound, Assert.Single(record.Skipped).Kind);
        Assert.Equal("cleanup.already-gone", Assert.Single(record.Skipped).Reason);
        Assert.Equal(0, record.FreedBytes);
    }

    [Fact]
    public async Task A_protected_path_is_refused_even_if_it_reached_the_plan()
    {
        // Defense in depth: the plan is normally validated when it is built, but the
        // executor re-checks its own policy instead of trusting the stored decision.
        // The plan here was built with a permissive policy on purpose.
        var fixture = new Fixture();
        var plan = fixture.Plan(new PermissivePolicy(),
            fixture.Op(@"C:\Windows\System32\drivers\etc\hosts", ScanCategory.Unknown, 1_000, kind: ScanItemKind.File));

        Assert.Single(plan.Operations);

        var record = await fixture.CreateExecutor().ExecuteAsync(plan, ScanMode.Deep);

        Assert.Equal(0, record.FreedBytes);
        Assert.Equal(1, record.SkippedCount);
        Assert.Empty(fixture.Deletion.Requests);
        Assert.Equal("cleanup.refused-by-policy", Assert.Single(record.Skipped).Reason);
    }

    [Fact]
    public async Task Cancellation_stops_the_run_and_marks_the_rest_as_cancelled()
    {
        var fixture = new Fixture();
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        var plan = fixture.Plan(operations:
        [
            fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000),
            fixture.Op(Local + @"\CrashDumps", ScanCategory.CrashDumps, 2_000),
        ]);

        var record = await fixture.CreateExecutor().ExecuteAsync(plan, ScanMode.Quick, null, cts.Token);

        Assert.True(record.WasCancelled);
        Assert.Equal(0, record.FreedBytes);
        Assert.Empty(fixture.Deletion.Requests);
        Assert.All(plan.Operations, o => Assert.Equal(CleanupOperationStatus.Cancelled, o.Status));
    }

    // ------------------------------------------------------- deletion method

    [Fact]
    public async Task Temporary_data_is_deleted_permanently_and_user_data_is_recycled()
    {
        var fixture = new Fixture();

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations:
            [
                fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000, DeletionMethod.Permanent),
                fixture.Op(Local + @"\Packages\Some.App\LocalState", ScanCategory.Unknown, 2_000, DeletionMethod.RecycleBin),
            ]),
            ScanMode.Quick);

        Assert.Equal(DeletionMethod.Permanent, fixture.Deletion.Requests[0].Method);
        Assert.Equal(DeletionMethod.RecycleBin, fixture.Deletion.Requests[1].Method);
    }

    [Fact]
    public async Task The_recycle_bin_setting_overrides_the_default_choice()
    {
        var never = new Fixture { Settings = { RecycleBinBehavior = RecycleBinBehavior.Never } };
        await never.CreateExecutor().ExecuteAsync(
            never.Plan(operations: [never.Op(Local + @"\Packages\Some.App", ScanCategory.Unknown, 1_000, DeletionMethod.RecycleBin)]),
            ScanMode.Quick);
        Assert.Equal(DeletionMethod.Permanent, Assert.Single(never.Deletion.Requests).Method);

        var always = new Fixture { Settings = { RecycleBinBehavior = RecycleBinBehavior.Always } };
        await always.CreateExecutor().ExecuteAsync(
            always.Plan(operations: [always.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000, DeletionMethod.Permanent)]),
            ScanMode.Quick);
        Assert.Equal(DeletionMethod.RecycleBin, Assert.Single(always.Deletion.Requests).Method);
    }

    [Fact]
    public async Task Recycle_bin_requests_fall_back_to_permanent_where_no_bin_exists()
    {
        var fixture = new Fixture();
        var path = Local + @"\Packages\Some.App";
        fixture.Deletion.NoRecycleBin.Add(path);

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(path, ScanCategory.Unknown, 1_000, DeletionMethod.RecycleBin)]),
            ScanMode.Quick);

        Assert.Equal(DeletionMethod.Permanent, Assert.Single(fixture.Deletion.Requests).Method);
    }

    [Fact]
    public async Task The_recycle_bin_itself_is_emptied_through_the_system_api()
    {
        var fixture = new Fixture();

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(@"C:\$Recycle.Bin", ScanCategory.RecycleBin, 900_000, DeletionMethod.SystemApi, ScanItemKind.VirtualTarget)]),
            ScanMode.Quick);

        Assert.Equal(1, fixture.Deletion.EmptyRecycleBinCalls);
        Assert.Equal(@"C:\", fixture.Deletion.LastEmptyRecycleBinVolume);
        Assert.Equal(900_000, record.FreedBytes);
        Assert.Empty(fixture.Deletion.Requests);
    }

    // --------------------------------------------------------------- history

    [Fact]
    public async Task The_run_is_written_to_history_with_a_breakdown_and_the_volume_state()
    {
        var fixture = new Fixture();

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000_000)]),
            ScanMode.Quick);

        var record = Assert.Single(fixture.History.Records);
        Assert.Equal(1_000_000, record.FreedBytes);

        // The fake volume does not change, so before == after: the record reports what it
        // actually observed instead of claiming the freed bytes as a measured delta.
        Assert.Equal(record.FreeBytesBefore, record.FreeBytesAfter);
        Assert.Equal(ScanCategory.TemporaryFiles, Assert.Single(record.Categories).Category);
        Assert.False(record.RanElevated);
        Assert.Equal(ScanMode.Quick, record.Mode);
        Assert.Equal(fixture.Clock.UtcNow, record.StartedAtUtc);
    }

    [Fact]
    public async Task History_is_not_written_when_the_user_turned_it_off()
    {
        var fixture = new Fixture { Settings = { SaveHistoryAutomatically = false } };

        await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000)]),
            ScanMode.Quick);

        Assert.Empty(fixture.History.Records);
    }

    [Fact]
    public async Task An_empty_plan_produces_an_empty_record_without_touching_anything()
    {
        var fixture = new Fixture();

        var record = await fixture.CreateExecutor().ExecuteAsync(fixture.Plan(), ScanMode.Quick);

        Assert.Equal(0, record.FreedBytes);
        Assert.Empty(record.Categories);
        Assert.Empty(fixture.Deletion.Requests);
    }

    [Fact]
    public async Task Two_concurrent_runs_are_impossible()
    {
        var fixture = new Fixture();
        var executor = fixture.CreateExecutor();
        var plan = fixture.Plan(operations: [fixture.Op(Local + @"\Temp", ScanCategory.TemporaryFiles, 1_000)]);

        // Hold the first run open so the second attempt is guaranteed to overlap it.
        var block = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        fixture.Deletion.BlockUntil = block;

        var first = executor.ExecuteAsync(plan, ScanMode.Quick);

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => executor.ExecuteAsync(plan, ScanMode.Quick));

        Assert.True(executor.IsRunning);

        block.SetResult();
        await first;

        Assert.False(executor.IsRunning);
    }

    [Fact]
    public async Task The_record_lists_exactly_what_was_deleted()
    {
        var fixture = new Fixture();
        var dir = Local + @"\Cache";
        var file = Local + @"\stray.dat";
        fixture.Fs.AddDirectory(dir);
        fixture.Fs.AddFile(file, 700);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations:
            [
                fixture.Op(dir, ScanCategory.ApplicationCache, 1_000),
                fixture.Op(file, ScanCategory.ApplicationCache, 700, kind: ScanItemKind.File),
            ]),
            ScanMode.Quick);

        Assert.Equal(2, record.Deleted.Count);
        Assert.Contains(record.Deleted, d => d.Path == dir && d.Kind == ScanItemKind.Directory && d.Bytes == 1_000);
        Assert.Contains(record.Deleted, d => d.Path == file && d.Kind == ScanItemKind.File);
    }

    [Fact]
    public async Task Skipped_operations_never_reach_the_deleted_ledger_of_the_record()
    {
        var fixture = new Fixture();
        var locked = Local + @"\Temp\locked.tmp";
        fixture.Deletion.InUse.Add(locked);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(locked, ScanCategory.TemporaryFiles, 10, kind: ScanItemKind.File)]),
            ScanMode.Quick);

        Assert.Empty(record.Deleted);
        Assert.Equal(1, record.SkippedCount);
    }

    [Fact]
    public async Task Access_denied_on_a_path_that_needs_elevation_says_so()
    {
        var fixture = new Fixture();
        var enclave = @"C:\Windows\Temp\old.log";
        fixture.Deletion.Denied.Add(enclave);

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(enclave, ScanCategory.TemporaryFiles, 10, kind: ScanItemKind.File)]),
            ScanMode.Quick);

        // The path lives under C:\Windows, so the plan marked it as needing elevation;
        // an access-denied failure there is a permissions problem, and the reason must
        // say exactly that instead of a generic "denied".
        var skipped = Assert.Single(record.Skipped);
        Assert.Equal("cleanup.needs-elevation", skipped.Reason);
        Assert.Equal(ScanIssueKind.AccessDenied, skipped.Kind);
    }

    [Fact]
    public async Task A_recycled_deletion_is_marked_as_restorable_in_the_record()
    {
        var fixture = new Fixture();
        fixture.Settings.RecycleBinBehavior = RecycleBinBehavior.Always;
        var path = Local + @"\Something\data.bin";

        var record = await fixture.CreateExecutor().ExecuteAsync(
            fixture.Plan(operations: [fixture.Op(path, ScanCategory.ApplicationCache, 500, kind: ScanItemKind.File)]),
            ScanMode.Quick);

        var deleted = Assert.Single(record.Deleted);
        Assert.True(deleted.Recycled);
    }
}
