using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The safe-category analyzers are the product's promise: what it claims is junk must
/// really be junk, and a folder must never be offered just because of its name.
/// </summary>
public class SafeCategoryAnalyzerTests
{
    private const string Profile = @"C:\Users\alice";
    private const string Local = @"C:\Users\alice\AppData\Local";

    private sealed class Fixture
    {
        public InMemoryFileSystem Fs { get; } = new();
        public FakeEnvironmentInfo Env { get; } = FakeEnvironmentInfo.DefaultWindows();
        public AppSettings Settings { get; } = new();
        public List<DriveSnapshot> Drives { get; } = [FakeDriveService.Fixed(@"C:\", 512, 100, "System")];

        /// <summary>One context per fixture, so several analyzers accumulate into one report.</summary>
        private AnalyzerContext? _context;

        public SafetyPolicy Policy { get; }

        public DirectoryMeasurer Measurer { get; }

        public Fixture()
        {
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]), Env);
            Measurer = new DirectoryMeasurer(new FileSystemScanner(Fs), Fs);
        }

        public IReadOnlyList<ScanItem> Items => _context?.Items ?? [];

        public AnalyzerContext Context() => _context ??= new AnalyzerContext(
            new ScanOptions { Mode = ScanMode.Quick },
            Settings,
            Drives,
            directories: [],
            largestFiles: [],
            Env,
            Fs,
            Measurer,
            Policy);

        public AnalyzerPipeline Pipeline(params IAnalyzer[] analyzers) =>
            new(analyzers, Env, Fs, Measurer, Policy);

        public ScanItem Single(string path) =>
            Items.Single(i => string.Equals(i.Path, path, PathUtils.Comparison));
    }

    // ---------------------------------------------------------------- matcher

    [Theory]
    [InlineData("thumbcache_1234.db", "thumbcache_*.db", true)]
    [InlineData("thumbcache_1234.db", "THUMBCACHE_*.DB", true)]
    [InlineData("iconcache_1.db", "thumbcache_*.db", false)]
    [InlineData("MEMORY.DMP", "*.dmp", true)]         // matching is case-insensitive
    [InlineData("kernel.dmp", "*.dmp", true)]
    [InlineData("a.txt", "?.txt", true)]
    [InlineData("ab.txt", "?.txt", false)]
    [InlineData("anything", "*", true)]
    [InlineData("anything", null, true)]
    public void WildcardMatcher_handles_the_patterns_the_catalog_uses(string input, string? pattern, bool expected)
    {
        Assert.Equal(expected, WildcardMatcher.IsMatch(input, pattern));
    }

    // --------------------------------------------------------------- resolver

    [Fact]
    public void Resolver_substitutes_known_folders_and_skips_unresolvable_ones()
    {
        var fixture = new Fixture();
        var resolver = new LocationResolver(fixture.Env, fixture.Fs);

        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\Temp\a.tmp", 10);

        var resolved = resolver.Resolve(new SafeLocation
        {
            PathTemplate = "{UserTemp}",
            Category = ScanCategory.TemporaryFiles,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "temp.user",
            Explanation = "temp",
        }).ToArray();

        Assert.Equal([@"C:\Users\alice\AppData\Local\Temp"], resolved);
    }

    [Fact]
    public void Resolver_expands_any_profile_and_wildcard_profile_directories()
    {
        var env = new FakeEnvironmentInfo(
            FakeEnvironmentInfo.Windows(),
            [@"C:\Users\alice", @"C:\Users\bob"]);
        var fs = new InMemoryFileSystem()
            .AddFile(@"C:\Users\bob\AppData\Local\Temp\b.tmp", 5)
            .AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\f1", 100)
            .AddFile(Local + @"\Google\Chrome\User Data\Profile 1\Cache\f2", 200)
            .AddFile(Local + @"\Google\Chrome\User Data\Default\Bookmarks", 300);

        var resolver = new LocationResolver(env, fs);

        var temp = resolver.Resolve(new SafeLocation
        {
            PathTemplate = @"{AnyProfile}\AppData\Local\Temp",
            Category = ScanCategory.TemporaryFiles,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "temp.profile",
            Explanation = "temp",
        }).ToArray();

        // alice's TEMP does not exist in the fixture, bob's does: only real paths survive.
        Assert.Equal([@"C:\Users\bob\AppData\Local\Temp"], temp);

        var caches = resolver.Resolve(new SafeLocation
        {
            PathTemplate = @"{LocalAppData}\Google\Chrome\User Data\*\Cache",
            Category = ScanCategory.BrowserCache,
            Confidence = CleanupConfidence.Safe,
            Risk = RiskLevel.Low,
            Method = DeletionMethod.Permanent,
            ReasonKey = "cache.browser.chromium",
            Explanation = "chrome cache",
        }).ToArray();

        Assert.Equal(2, caches.Length);
        Assert.Contains(Local + @"\Google\Chrome\User Data\Default\Cache", caches);
        Assert.Contains(Local + @"\Google\Chrome\User Data\Profile 1\Cache", caches);
    }

    // ------------------------------------------------------------ TEMP

    [Fact]
    public async Task TempAnalyzer_reports_user_temp_with_the_promised_classification()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\scratch1.tmp", 1_000);
        fixture.Fs.AddFile(Local + @"\Temp\nested\scratch2.tmp", 2_500);

        await new TempAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        var item = fixture.Single(Local + @"\Temp");
        Assert.Equal(ScanCategory.TemporaryFiles, item.Category);
        Assert.Equal(CleanupConfidence.Safe, item.Confidence);
        Assert.Equal(RiskLevel.Low, item.RiskLevel);
        Assert.Equal(DeletionMethod.Permanent, item.DeletionMethod);
        Assert.True(item.IsDeletable);
        Assert.Equal(3_500, item.Size);
        Assert.Equal(2, item.FileCount);
        Assert.Equal("temp.user", item.Reason);
        Assert.Equal(WellKnownAnalyzers.Temp, item.SourceAnalyzer);
        Assert.False(item.RequiresElevation);
    }

    [Fact]
    public async Task TempAnalyzer_marks_windows_temp_as_needing_elevation()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Windows\Temp\setup.tmp", 4_096);

        await new TempAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        var item = fixture.Single(@"C:\Windows\Temp");
        Assert.Equal(CleanupConfidence.Safe, item.Confidence);
        Assert.True(item.RequiresElevation, "C:\\Windows\\Temp cannot be written to as a standard user");
        Assert.True(item.IsDeletable);
    }

    [Fact]
    public async Task Empty_locations_are_not_offered()
    {
        var fixture = new Fixture();
        fixture.Fs.AddDirectory(Local + @"\Temp");       // exists but holds nothing

        await new TempAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Empty(fixture.Items);
    }

    [Fact]
    public async Task The_same_folder_reached_by_two_rules_is_counted_once()
    {
        // {UserTemp} and {AnyProfile}\AppData\Local\Temp resolve to the same path for
        // the current user. Counting it twice would double the promised space.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\a.tmp", 1_000);

        await new TempAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        var item = Assert.Single(fixture.Items);
        Assert.Equal(1_000, item.Size);
    }

    // ------------------------------------------------------------ browsers

    [Fact]
    public async Task BrowserCacheAnalyzer_finds_real_browser_caches()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 10_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Code Cache\js\x", 5_000);
        fixture.Fs.AddFile(Local + @"\Microsoft\Edge\User Data\Default\GPUCache\index", 7_000);
        fixture.Fs.AddFile(Local + @"\Mozilla\Firefox\Profiles\ab12cd.default-release\cache2\entries\x", 3_000);

        await new BrowserCacheAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Equal(4, fixture.Items.Count);
        Assert.All(fixture.Items, i =>
        {
            Assert.Equal(ScanCategory.BrowserCache, i.Category);
            Assert.Equal(CleanupConfidence.Safe, i.Confidence);
            Assert.Equal(RiskLevel.Low, i.RiskLevel);
            Assert.True(i.IsDeletable);
            Assert.NotNull(i.OwnerApplication);
        });

        Assert.Contains(fixture.Items, i => i.OwnerApplication == "Google Chrome" && i.Size == 10_000);
        Assert.Contains(fixture.Items, i => i.OwnerApplication == "Microsoft Edge" && i.Size == 7_000);
        Assert.Contains(fixture.Items, i => i.OwnerApplication == "Mozilla Firefox" && i.Size == 3_000);
    }

    [Fact]
    public async Task BrowserCacheAnalyzer_never_touches_profiles_history_or_passwords()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 10_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 900_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Login Data", 40_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Bookmarks", 12_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Local State", 8_000);

        await new BrowserCacheAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        var item = Assert.Single(fixture.Items);
        Assert.EndsWith("Cache", item.Path, StringComparison.Ordinal);
        Assert.Equal(10_000, item.Size);
    }

    [Fact]
    public async Task A_folder_merely_named_cache_is_not_reported()
    {
        // The rule the spec forbids: name contains "cache" => junk.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Profile + @"\Documents\MyProjects\Cache\important.bin", 50_000);
        fixture.Fs.AddFile(Local + @"\SomeUnknownApp\CacheBlob\data", 60_000);

        await new BrowserCacheAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);
        await new TempAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Empty(fixture.Items);
    }

    // ------------------------------------------------------------ dumps

    [Fact]
    public async Task CrashDumpAnalyzer_finds_dumps_and_wer_queues()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Windows\MEMORY.DMP", 3_000_000_000);
        fixture.Fs.AddFile(@"C:\Windows\Minidump\010125-0.dmp", 262_144);
        fixture.Fs.AddFile(Local + @"\CrashDumps\app.exe.1234.dmp", 1_048_576);
        fixture.Fs.AddFile(Local + @"\Microsoft\Windows\WER\ReportQueue\Report1\Report.wer", 2_048);

        await new CrashDumpAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Equal(4, fixture.Items.Count);
        Assert.All(fixture.Items, i => Assert.Equal(ScanCategory.CrashDumps, i.Category));

        var memoryDump = fixture.Single(@"C:\Windows\MEMORY.DMP");
        Assert.Equal(ScanItemKind.File, memoryDump.Kind);
        Assert.Equal(3_000_000_000, memoryDump.Size);
        Assert.Equal(RiskLevel.Medium, memoryDump.RiskLevel);
        Assert.True(memoryDump.RequiresElevation);

        var localDumps = fixture.Single(Local + @"\CrashDumps");
        Assert.False(localDumps.RequiresElevation);
    }

    // ------------------------------------------------------------ thumbnails

    [Fact]
    public async Task ThumbnailAnalyzer_reports_only_the_cache_databases()
    {
        var fixture = new Fixture();
        var explorer = Local + @"\Microsoft\Windows\Explorer";
        fixture.Fs.AddFile(explorer + @"\thumbcache_1234.db", 500_000);
        fixture.Fs.AddFile(explorer + @"\iconcache_16.db", 100_000);
        fixture.Fs.AddFile(explorer + @"\something_else.dat", 999_999);   // must not be offered

        await new ThumbnailAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Equal(2, fixture.Items.Count);
        Assert.All(fixture.Items, i =>
        {
            Assert.Equal(ScanItemKind.File, i.Kind);
            Assert.Equal(ScanCategory.Thumbnails, i.Category);
        });
        Assert.Equal(600_000, fixture.Items.Sum(i => i.Size));
        Assert.DoesNotContain(fixture.Items, i => i.Path.EndsWith("something_else.dat", StringComparison.Ordinal));
    }

    [Fact]
    public async Task Two_rules_over_one_folder_do_not_double_count()
    {
        var fixture = new Fixture();
        var explorer = Local + @"\Microsoft\Windows\Explorer";
        fixture.Fs.AddFile(explorer + @"\thumbcache_1.db", 1_000);
        fixture.Fs.AddFile(explorer + @"\iconcache_1.db", 2_000);

        await new ThumbnailAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        Assert.Equal(3_000, fixture.Items.Sum(i => i.Size));
        Assert.Equal(2, fixture.Items.Count);
    }

    // ------------------------------------------------------------ recycle bin

    [Fact]
    public async Task RecycleBinAnalyzer_emits_a_virtual_target_emptied_through_the_shell_api()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\$Recycle.Bin\S-1-5-21-1\$I1234", 512);
        fixture.Fs.AddFile(@"C:\$Recycle.Bin\S-1-5-21-1\$R1234.zip", 5_000_000);

        await new RecycleBinAnalyzer().AnalyzeAsync(fixture.Context(), CancellationToken.None);

        var item = fixture.Single(@"C:\$Recycle.Bin");
        Assert.Equal(ScanItemKind.VirtualTarget, item.Kind);
        Assert.Equal(ScanCategory.RecycleBin, item.Category);
        Assert.Equal(DeletionMethod.SystemApi, item.DeletionMethod);
        Assert.True(item.IsDeletable);
        Assert.Equal(5_000_512, item.Size);
        Assert.Contains("cannot be restored", item.Explanation, StringComparison.Ordinal);
    }

    [Fact]
    public async Task Recycle_bin_denials_for_other_users_are_not_reported_as_actionable()
    {
        // $Recycle.Bin holds one ACL'd subfolder per SID. Even an elevated administrator is
        // denied on other users' bins, so those denials are structural: reporting them would
        // suggest an action that cannot succeed.
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\$Recycle.Bin\S-1-5-21-own\$R1.zip", 5_000);
        fixture.Fs.AddDirectory(@"C:\$Recycle.Bin\S-1-5-21-other");
        fixture.Fs.DeniedDirectories.Add(@"C:\$Recycle.Bin\S-1-5-21-other");

        var pipeline = fixture.Pipeline(new RecycleBinAnalyzer());
        var outcome = await pipeline.RunAsync(
            AnalyzerInput.Empty(new ScanOptions { Mode = ScanMode.Quick }, fixture.Settings, fixture.Drives),
            ScanMode.Quick,
            CancellationToken.None);

        Assert.Empty(outcome.Issues);

        var item = Assert.Single(outcome.Items);
        Assert.Equal(5_000, item.Size);
        // The number is honest about being partial.
        Assert.Contains("lower bound", item.Explanation, StringComparison.Ordinal);
    }

    [Fact]
    public void The_recycle_bin_exception_is_narrow()
    {
        var fixture = new Fixture();

        // Allowed: emptying the bin through the shell API.
        var allowed = fixture.Policy.Evaluate(
            @"C:\$Recycle.Bin", ScanCategory.RecycleBin, ScanItemKind.VirtualTarget);
        Assert.True(allowed.IsAllowed);
        Assert.Equal("recycle-bin.system-api", allowed.RuleName);

        // Refused: deleting files inside it directly, whatever the claimed category.
        Assert.False(fixture.Policy.Evaluate(@"C:\$Recycle.Bin\S-1-5-21-1\$R1.zip", ScanCategory.RecycleBin, ScanItemKind.File).IsAllowed);
        Assert.False(fixture.Policy.Evaluate(@"C:\$Recycle.Bin", ScanCategory.TemporaryFiles, ScanItemKind.Directory).IsAllowed);
        Assert.False(fixture.Policy.Evaluate(@"C:\$Recycle.Bin", ScanCategory.RecycleBin, ScanItemKind.Directory).IsAllowed);
    }

    // ------------------------------------------------------------ pipeline

    [Fact]
    public async Task Pipeline_runs_in_order_and_isolates_a_broken_analyzer()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\a.tmp", 1_000);
        fixture.Fs.AddFile(@"C:\Windows\Minidump\x.dmp", 2_000);

        var pipeline = fixture.Pipeline(
            new CrashDumpAnalyzer(),
            new ThrowingAnalyzer(),
            new TempAnalyzer());

        var outcome = await pipeline.RunAsync(
            AnalyzerInput.Empty(new ScanOptions { Mode = ScanMode.Quick }, fixture.Settings, fixture.Drives),
            ScanMode.Quick,
            CancellationToken.None);

        // Both working analyzers produced results; the broken one is reported, not fatal.
        Assert.Equal(2, outcome.Items.Count);
        Assert.Equal(["BoomAnalyzer"], outcome.FailedAnalyzers);
        Assert.Equal(2, outcome.ExecutedAnalyzers.Count(i => i != "BoomAnalyzer"));
    }

    [Fact]
    public async Task Quick_scan_end_to_end_produces_a_classified_report_without_walking_the_volume()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\a.tmp", 1_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 20_000);
        fixture.Fs.AddFile(@"C:\Windows\Minidump\x.dmp", 3_000);
        // Noise that no rule covers: must not appear anywhere in the report.
        fixture.Fs.AddFile(Profile + @"\Documents\MyProjects\Cache\important.bin", 500_000);
        fixture.Fs.AddFile(Local + @"\SomeApp\unknown.bin", 700_000);

        var service = new ScanService(
            new FileSystemScanner(fixture.Fs),
            fixture.Pipeline(new TempAnalyzer(), new BrowserCacheAnalyzer(), new CrashDumpAnalyzer(), new RecycleBinAnalyzer()),
            new FakeSettingsService(),
            new FakeDriveService { Drives = { FakeDriveService.Fixed(@"C:\", 512, 100, "System") } },
            new Infrastructure.Time.ManualClock(new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc)));

        var result = await service.RunAsync(ScanMode.Quick, []);

        Assert.Equal(ScanMode.Quick, result.Mode);
        Assert.Equal(24_000, result.PotentialCleanupBytes);
        Assert.Equal(24_000, result.SafeBytes);
        Assert.Equal(0, result.LikelyBytes);
        Assert.Equal(0, result.NeedsReviewBytes);

        Assert.Equal(3, result.Items.Count);
        Assert.Contains(result.BytesByCategory, kv => kv.Key == ScanCategory.BrowserCache && kv.Value == 20_000);
        Assert.Contains(result.BytesByCategory, kv => kv.Key == ScanCategory.TemporaryFiles && kv.Value == 1_000);

        // The unknown 1.2 MB was never enumerated, so it is not in the report at all.
        Assert.DoesNotContain(result.Items, i => i.Path.Contains("MyProjects", StringComparison.Ordinal));
        Assert.DoesNotContain(result.Items, i => i.Path.Contains("unknown.bin", StringComparison.Ordinal));
    }

    private sealed class ThrowingAnalyzer : IAnalyzer
    {
        public string Name => "BoomAnalyzer";

        public string Description => "Always fails; used to prove isolation.";

        public IReadOnlyCollection<ScanMode> SupportedModes { get; } = [ScanMode.Quick];

        public int Order => 15;

        public bool IsEnabled(AppSettings settings) => true;

        public Task AnalyzeAsync(AnalyzerContext context, CancellationToken cancellationToken) =>
            throw new InvalidOperationException("analyzer exploded");
    }
}
