using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Models;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// Orchestration-level guarantees: a scan must survive a broken subscriber, must
/// report an honest byte total, and must hand back the report it built.
/// </summary>
public class ScanServiceTests
{
    private static ScanService CreateService(
        out FakeDriveService drives,
        out RecordingLogger<ScanService> logger,
        InMemoryFileSystem? fileSystem = null)
    {
        var fs = fileSystem ?? new InMemoryFileSystem();
        drives = new FakeDriveService();
        logger = new RecordingLogger<ScanService>();

        var environment = FakeEnvironmentInfo.DefaultWindows();
        var measurer = new DirectoryMeasurer(new Scanning.FileSystemScanner(fs), fs);
        var policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(environment, [@"C:\", @"D:\"]), environment);

        // No analyzers registered: these tests exercise the orchestration, not the rules.
        var pipeline = new AnalyzerPipeline([], environment, fs, measurer, policy);

        return new ScanService(
            new Scanning.FileSystemScanner(fs),
            pipeline,
            new FakeSettingsService(),
            drives,
            new ManualClock(new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc)),
            logger);
    }

    [Fact]
    public async Task A_throwing_subscriber_does_not_fail_an_otherwise_successful_scan()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/data/a.txt", 10)
            .AddFile("/data/nested/b.txt", 20);

        var service = CreateService(out _, out var logger, fs);
        service.ScanCompleted += (_, _) => throw new InvalidOperationException("subscriber blew up");

        var result = await service.RunAsync(ScanMode.Custom, ["/data"]);

        Assert.Equal(2, result.Statistics.FilesScanned);
        Assert.Equal(30, result.Statistics.BytesScanned);
        Assert.False(result.WasCancelled);

        // The failure is recorded, but it is attributed to the subscriber, not to the scan.
        Assert.True(logger.HasErrors);
        Assert.Contains("subscriber", logger.LastErrorMessage, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task The_completed_scan_is_exposed_as_the_last_result()
    {
        var fs = new InMemoryFileSystem().AddFile("/data/a.txt", 1024);
        var service = CreateService(out _, out _, fs);

        Assert.Null(service.LastResult);

        var result = await service.RunAsync(ScanMode.Custom, ["/data"]);

        Assert.Same(result, service.LastResult);
        Assert.Equal(ScanMode.Custom, result.Mode);
    }

    [Fact]
    public async Task A_pre_cancelled_token_surfaces_as_cancellation_not_as_a_failure()
    {
        var fs = new InMemoryFileSystem();
        for (var i = 0; i < 200; i++)
        {
            fs.AddFile($"/data/d{i:000}/f{i:0000}.bin", 64);
        }

        var service = CreateService(out _, out _, fs);
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        // The caller distinguishes cancellation from failure; mid-scan cancellation is
        // covered end-to-end in ScanViewModelTests.
        await Assert.ThrowsAnyAsync<OperationCanceledException>(
            () => service.RunAsync(ScanMode.Custom, ["/data"], cancellationToken: cts.Token));

        Assert.Null(service.LastResult);
    }

    [Fact]
    public void Expected_bytes_are_only_promised_for_whole_volumes()
    {
        var service = CreateService(out var drives, out _);
        drives.Drives.Add(new DriveSnapshot
        {
            RootPath = "/",
            DriveType = "Fixed",
            TotalBytes = 1_000,
            FreeBytes = 400,
            IsReady = true,
            IsScannableByDefault = true,
        });

        // A whole volume gives a real denominator for the progress percentage.
        var volume = service.BuildOptions(ScanMode.Custom, ["/"], drives.GetDrives());
        Assert.Equal(600, volume.ExpectedTotalBytes);

        // A folder does not: the UI must stay indeterminate rather than invent a number.
        var folder = service.BuildOptions(ScanMode.Custom, ["/data/projects"], drives.GetDrives());
        Assert.Equal(0, folder.ExpectedTotalBytes);
    }

    [Fact]
    public void Settings_are_projected_onto_the_scan_options()
    {
        var service = CreateService(out var drives, out _);
        drives.Drives.Add(new DriveSnapshot
        {
            RootPath = "/",
            DriveType = "Fixed",
            TotalBytes = 1_000,
            FreeBytes = 400,
            IsReady = true,
            IsScannableByDefault = true,
        });

        var options = service.BuildOptions(ScanMode.Deep, ["/"], drives.GetDrives());

        Assert.Equal(ScanMode.Deep, options.Mode);
        Assert.Equal(["/"], options.Roots);
        Assert.True(options.LargeFileThresholdBytes > 0);
        Assert.False(options.FollowReparsePoints);
        Assert.InRange(options.ResolveParallelism(), 1, ScanOptions.MaxUsefulParallelism);
    }

    [Fact]
    public async Task The_result_carries_the_volume_snapshots_taken_at_scan_start()
    {
        // The "freed space" math in history compares free bytes before and after,
        // so the report must carry the snapshots it was produced with.
        var fs = new InMemoryFileSystem().AddFile("/data/a.txt", 10);
        var service = CreateService(out var drives, out _, fs);
        drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100, "System"));

        var result = await service.RunAsync(ScanMode.Custom, ["/data"]);

        var snapshot = Assert.Single(result.Drives);
        Assert.Equal(@"C:\", snapshot.RootPath);
        Assert.Equal(100L * 1024 * 1024 * 1024, snapshot.FreeBytes);
    }
}
