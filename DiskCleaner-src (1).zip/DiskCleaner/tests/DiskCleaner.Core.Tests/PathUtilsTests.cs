using System.Runtime.InteropServices;
using DiskCleaner.Core.Infrastructure.IO;
using Xunit;

namespace DiskCleaner.Core.Tests;

public class PathUtilsTests
{
    [Theory]
    [InlineData(@"C:\Users\\alice\", @"C:\Users\alice")]
    [InlineData(@"C:/Users/alice", @"C:\Users\alice")]
    [InlineData(@"C:\", @"C:\")]
    [InlineData(@"C:\\", @"C:\")]
    [InlineData(@"\\server\share\\dir\", @"\\server\share\dir")]
    [InlineData("   ", "")]
    [InlineData("", "")]
    public void Normalize_collapses_separators_and_trims(string input, string expected) =>
        Assert.Equal(expected, PathUtils.Normalize(input));

    [Theory]
    [InlineData(@"C:\", true)]
    [InlineData(@"C:\Users", false)]
    [InlineData(@"\\srv\share", true)]
    [InlineData(@"\\srv\share\dir", false)]
    [InlineData("/", true)]
    [InlineData("/tmp", false)]
    public void IsRoot_recognises_roots(string input, bool expected) =>
        Assert.Equal(expected, PathUtils.IsRoot(input));

    [Theory]
    [InlineData(@"C:\Users\alice\AppData", @"C:\Users\alice", true)]
    [InlineData(@"C:\Users\alice", @"C:\Users\alice", true)]
    [InlineData(@"C:\Users\alice2", @"C:\Users\alice", false)]   // prefix trap
    [InlineData(@"C:\Users\bob", @"C:\Users\alice\AppData", false)]
    [InlineData(@"C:\Users\alice\AppData\Local\Temp\x.tmp", @"C:\Users\alice\AppData\Local\Temp", true)]
    public void IsUnder_handles_prefix_traps(string child, string parent, bool expected) =>
        Assert.Equal(expected, PathUtils.IsUnder(child, parent));

    [Fact]
    public void IsUnder_is_case_insensitive_on_windows_only()
    {
        var result = PathUtils.IsUnder(@"C:\Users\ALICE\AppData", @"C:\Users\alice");
        Assert.Equal(RuntimeInformation.IsOSPlatform(OSPlatform.Windows), result);
    }

    [Theory]
    [InlineData(@"C:\Users\alice", @"C:\Users")]
    [InlineData(@"C:\Users", @"C:\")]
    [InlineData(@"C:\", null)]
    [InlineData("/tmp/x", "/tmp")]
    [InlineData("/tmp", "/")]
    public void GetParent_walks_up(string path, string? expected) =>
        Assert.Equal(expected, PathUtils.GetParent(path));

    [Theory]
    [InlineData(@"C:\Users\alice\AppData", @"C:\", 3)]
    [InlineData(@"C:\Users", @"C:\", 1)]
    [InlineData(@"C:\", @"C:\", 0)]
    public void GetDepth_counts_segments_below_root(string path, string root, int expected) =>
        Assert.Equal(expected, PathUtils.GetDepth(path, root));

    [Theory]
    [InlineData(@"C:\a\b", @"\\?\C:\a\b")]
    [InlineData(@"\\?\C:\a\b", @"\\?\C:\a\b")]                                  // idempotent
    [InlineData(@"\\server\share\dir", @"\\?\UNC\server\share\dir")]
    [InlineData(@"\\?\UNC\server\share", @"\\?\UNC\server\share")]              // idempotent
    public void ToExtendedLengthPath_prefixes_windows_paths(string input, string expected) =>
        Assert.Equal(expected, PathUtils.ToExtendedLengthPath(input));

    [Theory]
    [InlineData(@"\\?\C:\a\b", @"C:\a\b")]
    [InlineData(@"\\?\UNC\server\share\dir", @"\\server\share\dir")]
    [InlineData(@"C:\a\b", @"C:\a\b")]
    public void FromExtendedLengthPath_is_the_inverse(string input, string expected) =>
        Assert.Equal(expected, PathUtils.FromExtendedLengthPath(input));

    [Theory]
    [InlineData(@"C:\Users\alice\AppData", @"C:\")]
    [InlineData(@"C:\a", @"C:\")]
    [InlineData(@"\\server\share\a\b", @"\\server\share\")]
    [InlineData("/tmp/x", "/")]
    public void GetDriveRoot_extracts_volume(string path, string expected) =>
        Assert.Equal(expected, PathUtils.GetDriveRoot(path));

    [Theory]
    [InlineData("archive.tar.gz", ".gz")]
    [InlineData("photo.JPG", ".jpg")]
    [InlineData("Makefile", null)]
    [InlineData(".gitignore", null)]          // dot-file, not an extension
    [InlineData("trailing.", null)]
    [InlineData("", null)]
    public void GetExtensionOrNull_normalises(string name, string? expected) =>
        Assert.Equal(expected, PathUtils.GetExtensionOrNull(name));

    [Theory]
    [InlineData(@"C:\Users\alice\AppData\Local\Temp\x.tmp", "x.tmp")]
    [InlineData(@"C:\Users\alice\", @"alice")]
    [InlineData("x.tmp", "x.tmp")]
    public void GetFileName_returns_leaf(string path, string expected) =>
        Assert.Equal(expected, PathUtils.GetFileName(path));

    [Fact]
    public void Combine_respects_rooted_segments()
    {
        Assert.Equal(@"C:\Windows\Temp", PathUtils.Combine(@"C:\Windows", "Temp"));
        Assert.Equal(@"C:\Other", PathUtils.Combine(@"C:\Windows", @"C:\Other"));
        Assert.Equal("/tmp/x", PathUtils.Combine("/tmp", "x"));
    }

    [Fact]
    public void ShortenForDisplay_keeps_short_paths_and_abbreviates_long_ones()
    {
        const string shortPath = @"C:\a\b.txt";
        Assert.Equal(shortPath, PathUtils.ShortenForDisplay(shortPath));

        var longPath = @"C:\Users\alice\AppData\Local\Microsoft\Windows\INetCache\IE\ABCDEFGH\" + new string('x', 120) + ".dat";
        var shortened = PathUtils.ShortenForDisplay(longPath, 90);

        Assert.True(shortened.Length <= 96, $"shortened length was {shortened.Length}");
        Assert.Contains("...", shortened, StringComparison.Ordinal);
        Assert.EndsWith(".dat", shortened, StringComparison.Ordinal);
    }

    [Fact]
    public void Normalize_is_stable_when_applied_twice()
    {
        const string input = @"C:\Users\\alice\AppData\\\Local\";
        var once = PathUtils.Normalize(input);
        Assert.Equal(once, PathUtils.Normalize(once));
    }
}
