using System.Globalization;
using DiskCleaner.Core.Infrastructure.Formatting;
using Xunit;

namespace DiskCleaner.Core.Tests;

public class BytesFormatterTests
{
    [Theory]
    [InlineData(0, "0 B")]
    [InlineData(512, "512 B")]
    [InlineData(1023, "1023 B")]
    [InlineData(1024, "1.0 KB")]
    [InlineData(1536, "1.5 KB")]
    [InlineData(1048576, "1.0 MB")]
    [InlineData(1073741824, "1.0 GB")]
    [InlineData(-2048, "-2.0 KB")]
    public void Format_uses_binary_units(long bytes, string expected) =>
        Assert.Equal(expected, BytesFormatter.Format(bytes, CultureInfo.InvariantCulture));

    [Fact]
    public void Format_matches_the_product_example()
    {
        // The spec shows "Chrome — 11.2 GB"; make sure we render exactly that.
        var bytes = (long)(11.2 * 1024 * 1024 * 1024);
        Assert.Equal("11.2 GB", BytesFormatter.Format(bytes, CultureInfo.InvariantCulture));
    }

    [Fact]
    public void FormatPrecise_keeps_two_decimals() =>
        Assert.Equal("1.50 GB", BytesFormatter.FormatPrecise(1610612736, CultureInfo.InvariantCulture));

    [Theory]
    [InlineData(0, "0B")]
    [InlineData(1536, "1.5K")]
    [InlineData(5242880, "5M")]
    public void FormatCompact_is_short(long bytes, string expected) =>
        Assert.Equal(expected, BytesFormatter.FormatCompact(bytes, CultureInfo.InvariantCulture));

    [Fact]
    public void FormatRate_renders_zero_as_a_dash() =>
        Assert.Equal("—", BytesFormatter.FormatRate(0, CultureInfo.InvariantCulture));

    [Fact]
    public void FormatRate_appends_per_second() =>
        Assert.Equal("1.0 MB/s", BytesFormatter.FormatRate(1024 * 1024, CultureInfo.InvariantCulture));

    [Theory]
    [InlineData("256 MB", 268435456L)]
    [InlineData("1.5gb", 1610612736L)]
    [InlineData("4096", 4096L)]
    [InlineData("10K", 10240L)]
    [InlineData("2 TB", 2199023255552L)]
    public void TryParseHuman_accepts_common_input(string input, long expected)
    {
        Assert.True(BytesFormatter.TryParseHuman(input, out var actual, CultureInfo.InvariantCulture));
        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("abc")]
    [InlineData("10 QB")]
    [InlineData("-5 MB")]
    public void TryParseHuman_rejects_garbage(string? input) =>
        Assert.False(BytesFormatter.TryParseHuman(input, out _, CultureInfo.InvariantCulture));

    [Fact]
    public void Format_never_uses_the_current_culture_by_default()
    {
        // A German/Russian locale would otherwise produce "1,5 KB" and break tests and logs.
        var value = BytesFormatter.Format(1536);
        Assert.Equal("1.5 KB", value);
    }
}
