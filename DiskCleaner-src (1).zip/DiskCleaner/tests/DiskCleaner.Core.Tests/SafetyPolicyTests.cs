using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Models;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The safety policy is the last line of defence before anything is deleted, so
/// these assertions are written as the product rules in §14 of the spec, not as
/// implementation details.
/// </summary>
public class SafetyPolicyTests
{
    private static readonly FakeEnvironmentInfo Env = FakeEnvironmentInfo.DefaultWindows();

    private static readonly ISafetyPolicy Policy = new SafetyPolicy(
        ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]),
        Env);

    // --- tier 1: never touched ----------------------------------------------

    [Theory]
    [InlineData(@"C:\Windows\System32\drivers\etc\hosts")]
    [InlineData(@"C:\Windows\System32\config\SYSTEM")]
    [InlineData(@"C:\Windows\System32\DriverStore\FileRepository\x.inf")]
    [InlineData(@"C:\Windows\WinSxS\amd64_microsoft-windows-x_1.0\file.dll")]
    [InlineData(@"C:\Windows\Installer\$PatchCache$\Managed\x")]
    [InlineData(@"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\mscorlib.dll")]
    [InlineData(@"C:\Windows")]
    [InlineData(@"C:\Program Files\SomeApp\app.exe")]
    [InlineData(@"C:\Program Files (x86)\SomeApp\lib\unknown.dll")]
    [InlineData(@"C:\ProgramData\Microsoft\Windows Defender\Scans\mpcache.dat")]
    [InlineData(@"C:\$Recycle.Bin\S-1-5-21-x")]
    [InlineData(@"C:\System Volume Information\{guid}")]
    [InlineData(@"C:\pagefile.sys")]
    [InlineData(@"D:\hiberfil.sys")]
    [InlineData(@"C:\")]
    [InlineData(@"D:\")]
    [InlineData(@"C:\Users")]
    [InlineData(@"C:\ProgramData")]
    public void HardBlocked_locations_are_refused_even_on_explicit_request(string path)
    {
        var verdict = Policy.Evaluate(path, ScanCategory.TemporaryFiles, ScanItemKind.Directory, explicitUserChoice: true);

        Assert.False(verdict.IsAllowed);
        Assert.Equal(RiskLevel.Critical, verdict.MinRisk);
        Assert.NotNull(verdict.RejectionReason);
        Assert.True(Policy.IsProtected(path));
    }

    [Fact]
    public void Empty_and_unknown_paths_are_refused()
    {
        Assert.False(Policy.Evaluate(string.Empty).IsAllowed);
        Assert.False(Policy.Evaluate("   ").IsAllowed);
        Assert.True(Policy.IsProtected(string.Empty));
    }

    [Fact]
    public void SystemData_category_is_refused_wherever_it_lives()
    {
        // Even inside a location that would otherwise be cleanable.
        var verdict = Policy.Evaluate(@"C:\Users\alice\AppData\Local\Temp\x.tmp", ScanCategory.SystemData);

        Assert.False(verdict.IsAllowed);
        Assert.Equal("category.system-data", verdict.RuleName);
    }

    // --- whitelisted enclaves inside blocked trees ---------------------------

    [Theory]
    [InlineData(@"C:\Windows\Temp\setup_1234.tmp")]
    [InlineData(@"C:\Windows\SoftwareDistribution\Download\abcdef\package.cab")]
    [InlineData(@"C:\Windows\Minidump\010125-0.dmp")]
    [InlineData(@"C:\Windows\LiveKernelReports\WATCHDOG\WD-01.dmp")]
    [InlineData(@"C:\Windows\MEMORY.DMP")]
    public void Known_windows_cleanup_locations_are_allowed_but_need_elevation(string path)
    {
        var verdict = Policy.Evaluate(path, ScanCategory.TemporaryFiles);

        Assert.True(verdict.IsAllowed);
        Assert.Equal("hard-blocked.enclave", verdict.RuleName);
        Assert.True(verdict.RequiresElevation);
        Assert.Equal(CleanupConfidence.Safe, verdict.MaxConfidence);
    }

    [Fact]
    public void A_name_that_merely_looks_like_a_cache_inside_windows_stays_blocked()
    {
        // "folder name contains cache => delete" is explicitly forbidden by the spec.
        var verdict = Policy.Evaluate(@"C:\Windows\System32\Cache\whatever.dat", ScanCategory.ApplicationCache);

        Assert.False(verdict.IsAllowed);
    }

    // --- tier 2: user data ---------------------------------------------------

    [Theory]
    [InlineData(@"C:\Users\alice\Documents\report.docx")]
    [InlineData(@"C:\Users\alice\Desktop\notes.txt")]
    [InlineData(@"C:\Users\alice\Pictures\holiday\IMG_0001.cr2")]
    [InlineData(@"C:\Users\alice\Videos\recording.mp4")]
    [InlineData(@"C:\Users\alice\Music\track.flac")]
    [InlineData(@"C:\Users\alice\Downloads\installer.exe")]
    public void User_libraries_are_never_offered_automatically(string path)
    {
        var automatic = Policy.Evaluate(path, ScanCategory.LargeFiles, ScanItemKind.File, explicitUserChoice: false);

        Assert.False(automatic.IsAllowed);
        Assert.Equal("user-data", automatic.RuleName);
        Assert.True(Policy.IsProtected(path));

        var explicitChoice = Policy.Evaluate(path, ScanCategory.LargeFiles, ScanItemKind.File, explicitUserChoice: true);

        Assert.True(explicitChoice.IsAllowed);
        Assert.True(explicitChoice.RequiresExplicitUserChoice);
        Assert.Equal(CleanupConfidence.NeedsReview, explicitChoice.MaxConfidence);
        Assert.Equal(RiskLevel.High, explicitChoice.MinRisk);
    }

    [Fact]
    public void AppData_is_not_treated_as_a_user_library()
    {
        // AppData is the primary analysis target; blocking it would defeat the product.
        var verdict = Policy.Evaluate(@"C:\Users\alice\AppData\Local\Temp\dotnet\tmp.tmp", ScanCategory.TemporaryFiles);

        Assert.True(verdict.IsAllowed);
        Assert.Equal(CleanupConfidence.Safe, verdict.MaxConfidence);
        Assert.False(verdict.RequiresElevation);
        Assert.False(Policy.IsProtected(@"C:\Users\alice\AppData\Local\Temp\x"));
    }

    // --- ordinary locations --------------------------------------------------

    [Theory]
    [InlineData(@"C:\Users\alice\AppData\Local\Google\Chrome\User Data\Default\Cache\f_000001")]
    [InlineData(@"C:\Users\alice\AppData\Local\npm-cache\_cacache\content-v2\sha512\x")]
    [InlineData(@"D:\Builds\project\obj\Debug\net10.0\app.dll")]
    public void Ordinary_locations_are_allowed_without_elevation(string path)
    {
        var verdict = Policy.Evaluate(path, ScanCategory.DeveloperData);

        Assert.True(verdict.IsAllowed);
        Assert.Equal("default", verdict.RuleName);
        Assert.False(verdict.RequiresElevation);
        Assert.False(verdict.RequiresExplicitUserChoice);
    }

    [Fact]
    public void ProgramData_requires_elevation_but_is_not_globally_blocked()
    {
        var verdict = Policy.Evaluate(@"C:\ProgramData\Package Cache\{guid}\installer.exe", ScanCategory.InstallerPackages);

        Assert.True(verdict.IsAllowed);
        Assert.True(verdict.RequiresElevation);
    }

    [Fact]
    public void Another_users_profile_requires_elevation()
    {
        var verdict = Policy.Evaluate(@"C:\Users\bob\AppData\Local\Temp\x.tmp", ScanCategory.TemporaryFiles);

        Assert.True(verdict.IsAllowed);
        Assert.True(verdict.RequiresElevation);
    }

    [Fact]
    public void Resolver_produces_the_expected_tier_lists()
    {
        var roots = ProtectedRootsResolver.Resolve(Env, [@"C:\"]);

        Assert.Contains(@"C:\Windows\System32", roots.HardBlocked);
        Assert.Contains(@"C:\Windows\WinSxS", roots.HardBlocked);
        Assert.Contains(@"C:\Windows\Installer", roots.HardBlocked);
        Assert.Contains(@"C:\Windows\Temp", roots.HardBlockedEnclaves);
        Assert.Contains(@"C:\Users\alice\Documents", roots.UserData);
        Assert.Contains("pagefile.sys", roots.BlockedFileNames);
        Assert.Contains(@"C:\$Recycle.Bin", roots.HardBlocked);
        Assert.DoesNotContain(@"C:\Users\alice\AppData", roots.UserData);

        // Container roots are self-only, otherwise AppData would be unanalysable.
        Assert.Contains(@"C:\Users", roots.SelfOnlyBlocked);
        Assert.Contains(@"C:\ProgramData", roots.SelfOnlyBlocked);
        Assert.Contains(@"C:\", roots.SelfOnlyBlocked);
        Assert.DoesNotContain(@"C:\Users", roots.HardBlocked);
        Assert.DoesNotContain(@"C:\ProgramData", roots.HardBlocked);
    }
}
