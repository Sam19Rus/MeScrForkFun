using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The scanner is the component that has to survive a real machine: unreadable
/// directories, vanishing files, junction cycles, millions of entries and a user
/// who presses Cancel. Every one of those is asserted here.
/// </summary>
public class FileSystemScannerTests
{
    private static FileSystemScanner CreateScanner(IFileSystem fileSystem) => new(fileSystem);

    [Fact]
    public async Task Counts_every_file_directory_and_byte_of_a_real_tree()
    {
        using var temp = new TempDirectory();
        temp.WriteFile("a.txt", 100);
        temp.WriteFile("sub/b.bin", 2_000);
        temp.WriteFile("sub/deep/c.dat", 300);
        temp.CreateDir("sub/empty");

        var sink = new RecordingSink();
        var stats = await CreateScanner(new PhysicalFileSystem())
            .ScanAsync(new ScanOptions { Roots = [temp.Root] }, sink);

        Assert.Equal(3, stats.FilesScanned);
        Assert.Equal(2_400, stats.BytesScanned);
        Assert.Equal(4, stats.DirectoriesScanned);   // root + sub + deep + empty
        Assert.Equal(0, stats.IssuesCount);
        Assert.False(stats.WasCancelled);
        Assert.Equal(2_400, sink.TotalBytes);
    }

    [Fact]
    public async Task Does_not_follow_reparse_points_by_default()
    {
        var fs = new InMemoryFileSystem()
            .AddDirectory("/data")
            .AddFile("/data/real.txt", 10)
            .AddLink("/data/loop", "/data");

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/data"] }, sink);

        Assert.Equal(1, stats.FilesScanned);
        Assert.Equal(1, stats.ReparsePointsSkipped);
        Assert.False(sink.VisitedDirectory("/data/loop"));
        Assert.Equal(1, fs.EnumerateCallCount);   // the link was never enumerated
    }

    [Fact]
    public async Task Followed_reparse_points_cannot_create_a_cycle()
    {
        // /data/loop -> /data : following it naively would recurse forever.
        var fs = new InMemoryFileSystem()
            .AddDirectory("/data")
            .AddFile("/data/real.txt", 10)
            .AddLink("/data/loop", "/data");

        var sink = new RecordingSink();
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(15));

        var stats = await CreateScanner(fs).ScanAsync(
            new ScanOptions { Roots = ["/data"], FollowReparsePoints = true },
            sink,
            cancellationToken: cts.Token);

        Assert.False(stats.WasCancelled);          // terminated by the guard, not by the timeout
        Assert.Equal(1, stats.FilesScanned);       // real.txt counted exactly once
        Assert.Equal(1, stats.ReparsePointsSkipped);
        Assert.Contains(sink.Issues, i => i.Kind == ScanIssueKind.ReparsePointSkipped);
    }

    [Fact]
    public async Task A_denied_directory_is_reported_and_does_not_stop_the_scan()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/ok/keep.txt", 111)
            .AddFile("/root/secret/hidden.txt", 999)
            .AddFile("/root/other/also.txt", 222);

        fs.DeniedDirectories.Add("/root/secret");

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/root"] }, sink);

        Assert.Equal(2, stats.FilesScanned);                 // the readable ones
        Assert.Equal(333, stats.BytesScanned);
        Assert.Equal(1, stats.InaccessibleDirectories);

        var issue = Assert.IsType<ScanIssue>(sink.FirstIssueOfKind(ScanIssueKind.AccessDenied));
        Assert.Equal("/root/secret", issue.Path);
        Assert.Equal("Access denied", issue.Reason);
        Assert.Equal(5, issue.ErrorCode);                    // ERROR_ACCESS_DENIED
        Assert.Equal("UnauthorizedAccessException", issue.ExceptionType);
        Assert.True(issue.MayRequireElevation);
    }

    [Fact]
    public async Task Sharing_violations_are_classified_as_file_in_use()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/locked/x.dat", 1)
            .AddFile("/root/fine/y.dat", 2);

        fs.InUseDirectories.Add("/root/locked");

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/root"] }, sink);

        var issue = sink.FirstIssueOfKind(ScanIssueKind.FileInUse);
        Assert.NotNull(issue);
        Assert.Equal(32, issue.ErrorCode);                   // ERROR_SHARING_VIOLATION
        Assert.False(issue!.MayRequireElevation);            // elevation would not help here
        Assert.Equal(1, stats.FilesScanned);
    }

    [Fact]
    public async Task Vanishing_directories_and_too_long_paths_are_reported_not_thrown()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/a/x.txt", 1)
            .AddFile("/root/b/y.txt", 2)
            .AddFile("/root/c/z.txt", 3);

        fs.MissingDirectories.Add("/root/b");
        fs.TooLongPathDirectories.Add("/root/c");

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/root"] }, sink);

        Assert.Equal(1, stats.FilesScanned);
        Assert.NotNull(sink.FirstIssueOfKind(ScanIssueKind.NotFound));
        Assert.NotNull(sink.FirstIssueOfKind(ScanIssueKind.PathTooLong));
        Assert.Equal(2, stats.IssuesCount);
    }

    [Fact]
    public async Task Missing_root_is_reported_as_an_issue()
    {
        var fs = new InMemoryFileSystem().AddDirectory("/exists").AddFile("/exists/a.txt", 5);
        var sink = new RecordingSink();

        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/does-not-exist", "/exists"] }, sink);

        Assert.Equal(1, stats.FilesScanned);
        Assert.NotNull(sink.FirstIssueOfKind(ScanIssueKind.NotFound));
    }

    [Fact]
    public async Task Excluded_paths_are_never_entered()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/keep/a.txt", 10)
            .AddFile("/root/skip/node_modules/pkg/index.js", 20)
            .AddFile("/root/skip/b.txt", 30);

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(
            new ScanOptions { Roots = ["/root"], ExcludedPaths = ["/root/skip/node_modules"] },
            sink);

        Assert.Equal(2, stats.FilesScanned);
        Assert.Equal(40, stats.BytesScanned);
        Assert.False(sink.VisitedDirectory("/root/skip/node_modules"));
        Assert.True(sink.ContainsFile("/root/skip/b.txt"));
    }

    [Fact]
    public async Task MaxDepth_limits_descent()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/l0.txt", 1)
            .AddFile("/root/a/l1.txt", 2)
            .AddFile("/root/a/b/l2.txt", 4)
            .AddFile("/root/a/b/c/l3.txt", 8);

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/root"], MaxDepth = 2 }, sink);

        Assert.Equal(3, stats.FilesScanned);        // l0, l1, l2
        Assert.Equal(7, stats.BytesScanned);
        Assert.False(sink.ContainsFile("/root/a/b/c/l3.txt"));
    }

    [Fact]
    public async Task Cancellation_stops_promptly_and_is_reported_honestly()
    {
        using var temp = new TempDirectory();
        for (var d = 0; d < 40; d++)
        {
            temp.WriteFiles($"d{d:00}", 50, 64);
        }

        using var cts = new CancellationTokenSource();
        var sink = new RecordingSink { Cancellation = cts, CancelAfterFiles = 25 };

        var stats = await CreateScanner(new PhysicalFileSystem())
            .ScanAsync(new ScanOptions { Roots = [temp.Root] }, sink, cancellationToken: cts.Token);

        Assert.True(stats.WasCancelled);
        Assert.True(stats.FilesScanned < 2_000, $"scan should have stopped early but saw {stats.FilesScanned} files");
    }

    [Fact]
    public async Task Progress_reports_are_published_and_never_fake_a_percentage()
    {
        using var temp = new TempDirectory();
        for (var d = 0; d < 10; d++)
        {
            temp.WriteFiles($"p{d}", 100, 1024);
        }

        // No expected total => the percentage must stay unknown (indeterminate UI).
        var unknownTotal = new CollectingProgress();
        var stats = await CreateScanner(new PhysicalFileSystem())
            .ScanAsync(
                new ScanOptions { Roots = [temp.Root], ProgressInterval = TimeSpan.FromMilliseconds(5) },
                new RecordingSink(),
                unknownTotal);

        Assert.Equal(1_000, stats.FilesScanned);
        Assert.NotEmpty(unknownTotal.Snapshots);
        Assert.All(unknownTotal.Snapshots, s => Assert.Null(s.PercentComplete));
        Assert.All(unknownTotal.Snapshots, s => Assert.True(s.IsIndeterminate));

        // With a known total the percentage is derived from bytes actually walked,
        // and stays below 100% while running.
        var withTotal = new CollectingProgress();
        await CreateScanner(new PhysicalFileSystem())
            .ScanAsync(
                new ScanOptions { Roots = [temp.Root], ExpectedTotalBytes = 1024L * 1000 * 4, ProgressInterval = TimeSpan.FromMilliseconds(5) },
                new RecordingSink(),
                withTotal);

        Assert.NotEmpty(withTotal.Snapshots);
        Assert.All(withTotal.Snapshots, s => Assert.NotNull(s.PercentComplete));
        Assert.All(withTotal.Snapshots, s => Assert.InRange(s.PercentComplete!.Value, 0d, 0.99d));

        // The final snapshot must say the scan is over.
        Assert.Equal(ScanPhase.Completed, withTotal.Snapshots[^1].Phase);
        Assert.Equal(1_000, withTotal.Snapshots[^1].FilesScanned);
    }

    [Fact]
    public async Task Handles_a_large_tree_without_losing_entries()
    {
        using var temp = new TempDirectory();
        const int directories = 60;
        const int filesPerDirectory = 100;
        for (var d = 0; d < directories; d++)
        {
            temp.WriteFiles($"bulk/{d:000}", filesPerDirectory, 512);
        }

        var collector = new ScanResultCollector(new ScanOptions
        {
            Roots = [temp.Root],
            LargeFileThresholdBytes = 400,
        });

        var stats = await CreateScanner(new PhysicalFileSystem())
            .ScanAsync(new ScanOptions { Roots = [temp.Root], LargeFileThresholdBytes = 400 }, collector);

        var expectedFiles = directories * filesPerDirectory;
        Assert.Equal(expectedFiles, stats.FilesScanned);
        Assert.Equal(expectedFiles * 512L, stats.BytesScanned);

        var aggregates = collector.Aggregator.BuildAggregates();
        var bulkRoot = aggregates.FirstOrDefault(a => a.Path.EndsWith("bulk", StringComparison.Ordinal));
        Assert.NotNull(bulkRoot);
        Assert.Equal(expectedFiles * 512L, bulkRoot!.SubtreeBytes);
        Assert.Equal(expectedFiles, bulkRoot.SubtreeFileCount);

        // The ranking stays bounded no matter how many files were seen.
        Assert.True(collector.GetLargestFiles().Count <= 200);
        Assert.Equal(200, collector.GetLargestFiles().Count);
        Assert.Equal(directories + 2, collector.Aggregator.TrackedCount);   // root + "bulk" + 60 leaves
    }

    [Fact]
    public void Parallelism_is_bounded()
    {
        // A spinning disk does not get faster with 64 threads; verify the cap holds.
        var automatic = new ScanOptions { Roots = ["/x"], MaxDegreeOfParallelism = 0 };
        Assert.InRange(automatic.ResolveParallelism(), 1, ScanOptions.MaxUsefulParallelism);

        var excessive = new ScanOptions { Roots = ["/x"], MaxDegreeOfParallelism = 512 };
        Assert.Equal(64, excessive.ResolveParallelism());

        var negative = new ScanOptions { Roots = ["/x"], MaxDegreeOfParallelism = -4 };
        Assert.InRange(negative.ResolveParallelism(), 1, ScanOptions.MaxUsefulParallelism);
    }

    [Fact]
    public async Task Real_symlink_cycle_on_the_file_system_terminates()
    {
        using var temp = new TempDirectory();
        temp.WriteFile("real.txt", 10);

        var linkPath = temp.PathOf("loop");
        try
        {
            Directory.CreateSymbolicLink(linkPath, temp.Root);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return; // The platform refuses symlinks; the in-memory test covers the guard.
        }

        var attributes = new DirectoryInfo(linkPath).Attributes;
        if ((attributes & FileAttributes.ReparsePoint) == 0)
        {
            return; // This platform does not mark symlinks as reparse points.
        }

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        var sink = new RecordingSink();

        var stats = await CreateScanner(new PhysicalFileSystem()).ScanAsync(
            new ScanOptions { Roots = [temp.Root], FollowReparsePoints = true, MaxDepth = 32 },
            sink,
            cancellationToken: cts.Token);

        Assert.False(stats.WasCancelled);           // finished on its own, not by the timeout
        Assert.Equal(1, stats.FilesScanned);        // real.txt counted exactly once
        Assert.True(stats.ReparsePointsSkipped >= 1);
    }

    [Fact]
    public async Task Scan_of_no_roots_is_a_no_op()
    {
        var stats = await CreateScanner(new PhysicalFileSystem()).ScanAsync(new ScanOptions { Roots = [] }, new RecordingSink());

        Assert.Equal(0, stats.FilesScanned);
        Assert.Equal(0, stats.DirectoriesScanned);
    }

    [Fact]
    public async Task Hidden_and_system_entries_are_seen()
    {
        var fs = new InMemoryFileSystem()
            .AddFile("/root/.hidden-cache/data.idx", 500, FileAttributes.Hidden)
            .AddFile("/root/System Volume Info/x.dat", 700, FileAttributes.System | FileAttributes.Hidden);

        var sink = new RecordingSink();
        var stats = await CreateScanner(fs).ScanAsync(new ScanOptions { Roots = ["/root"] }, sink);

        Assert.Equal(2, stats.FilesScanned);
        Assert.Equal(1_200, stats.BytesScanned);
        Assert.Contains(sink.Files, f => f.IsHidden);
    }
}
