using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The remaining safe categories. The emphasis is on what these analyzers must NOT do:
/// claim bytes they could not read, invent log locations from a file extension, or count
/// the same data twice alongside another analyzer.
/// </summary>
public class WindowsUpdateAndLogAnalyzerTests
{
    private sealed class Fixture
    {
        public InMemoryFileSystem Fs { get; } = new();
        public FakeEnvironmentInfo Env { get; } = FakeEnvironmentInfo.DefaultWindows();
        public AppSettings Settings { get; } = new();
        public List<DriveSnapshot> Drives { get; } = [FakeDriveService.Fixed(@"C:\", 512, 100, "System")];
        public SafetyPolicy Policy { get; }
        public AnalyzerRunOutcome? LastOutcome { get; private set; }

        public Fixture()
        {
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]), Env);
        }

        public IReadOnlyList<ScanItem> Items => LastOutcome?.Items ?? [];

        public async Task RunAsync(ScanMode mode, params IAnalyzer[] analyzers)
        {
            var measurer = new DirectoryMeasurer(new FileSystemScanner(Fs), Fs);
            var pipeline = new AnalyzerPipeline(analyzers, Env, Fs, measurer, Policy);

            LastOutcome = await pipeline.RunAsync(
                AnalyzerInput.Empty(new ScanOptions { Mode = mode }, Settings, Drives),
                mode,
                CancellationToken.None);
        }
    }

    // ------------------------------------------------------------ Windows Update

    [Fact]
    public async Task The_update_download_cache_is_safe_but_needs_elevation()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Windows\SoftwareDistribution\Download\abc123\windows10.0-kb5001.cab", 800_000_000);
        fixture.Fs.AddFile(@"C:\Windows\SoftwareDistribution\Download\def456\update.msu", 200_000_000);

        await fixture.RunAsync(ScanMode.Quick, new WindowsUpdateAnalyzer());

        var item = Assert.Single(fixture.Items);
        Assert.Equal(@"C:\Windows\SoftwareDistribution\Download", item.Path);
        Assert.Equal(ScanCategory.WindowsUpdateCache, item.Category);
        Assert.Equal(CleanupConfidence.Safe, item.Confidence);
        Assert.Equal(1_000_000_000, item.Size);
        Assert.True(item.RequiresElevation);
        Assert.True(item.IsDeletable);
        Assert.Equal(DeletionMethod.Permanent, item.DeletionMethod);
    }

    [Fact]
    public async Task An_unreadable_delivery_optimization_cache_is_not_claimed()
    {
        // The DO cache lives under a service profile that is usually SYSTEM-only.
        // The honest result is "nothing reported", not an invented size.
        var fixture = new Fixture();
        var cache = @"C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache";
        fixture.Fs.AddDirectory(cache);
        fixture.Fs.DeniedDirectories.Add(cache);

        await fixture.RunAsync(ScanMode.Quick, new WindowsUpdateAnalyzer());

        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("DeliveryOptimization", StringComparison.Ordinal));
    }

    [Fact]
    public async Task The_rest_of_software_distribution_stays_blocked()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Windows\SoftwareDistribution\Download\x.cab", 1_000);
        fixture.Fs.AddFile(@"C:\Windows\SoftwareDistribution\DataStore\DataStore.edb", 50_000_000);

        await fixture.RunAsync(ScanMode.Quick, new WindowsUpdateAnalyzer());

        var item = Assert.Single(fixture.Items);
        Assert.EndsWith("Download", item.Path, StringComparison.Ordinal);
        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("DataStore", StringComparison.Ordinal));
    }

    // ------------------------------------------------------------------- logs

    [Fact]
    public async Task Npm_debug_logs_are_reported_from_their_known_locations()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Users\alice\.npm\_logs\2026-05-01T10_00_00_000Z-debug.log", 4_000_000);
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\npm-cache\_logs\other.log", 1_000_000);

        await fixture.RunAsync(ScanMode.Quick, new LogAnalyzer());

        Assert.Equal(2, fixture.Items.Count);
        Assert.All(fixture.Items, i =>
        {
            Assert.Equal(ScanCategory.Logs, i.Category);
            Assert.Equal(CleanupConfidence.Likely, i.Confidence);
            Assert.Equal("npm", i.OwnerApplication);
            Assert.True(i.IsDeletable);
        });
        Assert.Equal(5_000_000, fixture.Items.Sum(i => i.Size));
    }

    [Fact]
    public async Task Log_files_elsewhere_are_never_claimed_by_name()
    {
        // The forbidden heuristic: "*.log => junk".
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Users\alice\Documents\Projects\MyApp\build.log", 90_000_000);
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\SomeUnknownTool\debug.log", 70_000_000);
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Roaming\SomeUnknownTool\trace.log", 60_000_000);

        await fixture.RunAsync(ScanMode.Quick, new LogAnalyzer());

        Assert.Empty(fixture.Items);
    }

    [Fact]
    public void Log_analysis_follows_the_developer_analysis_switch()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Users\alice\.npm\_logs\x.log", 1_000_000);

        var analyzer = new LogAnalyzer();
        Assert.True(analyzer.IsEnabled(new AppSettings { EnableDeveloperAnalysis = true }));
        Assert.False(analyzer.IsEnabled(new AppSettings { EnableDeveloperAnalysis = false }));
    }

    [Fact]
    public async Task Temp_logs_are_counted_once_when_both_analyzers_run()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\Temp\setup.log", 2_000_000);
        fixture.Fs.AddFile(@"C:\Users\alice\.npm\_logs\x.log", 1_000_000);

        await fixture.RunAsync(ScanMode.Quick, new TempAnalyzer(), new LogAnalyzer());

        // TEMP owns its whole folder (including setup.log); npm logs are separate.
        Assert.Equal(3_000_000, fixture.Items.Sum(i => i.Size));
        Assert.Contains(fixture.Items, i => i.Path.EndsWith("Temp", StringComparison.Ordinal));
        Assert.Contains(fixture.Items, i => i.Path.EndsWith("_logs", StringComparison.Ordinal));
        Assert.DoesNotContain(fixture.Items, i => i.Path.EndsWith("setup.log", StringComparison.Ordinal));
    }

    // ------------------------------------------------------------- integration

    [Fact]
    public async Task The_full_safe_catalog_produces_a_tiered_report()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\Temp\a.tmp", 1_000);
        fixture.Fs.AddFile(@"C:\Windows\SoftwareDistribution\Download\x.cab", 2_000);
        fixture.Fs.AddFile(@"C:\Windows\Minidump\010125-0.dmp", 3_000);
        fixture.Fs.AddFile(@"C:\Users\alice\.npm\_logs\x.log", 4_000);
        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\Google\Chrome\User Data\Default\Cache\d", 5_000);

        await fixture.RunAsync(
            ScanMode.Quick,
            new TempAnalyzer(),
            new WindowsUpdateAnalyzer(),
            new CrashDumpAnalyzer(),
            new LogAnalyzer(),
            new BrowserCacheAnalyzer());

        Assert.Equal(5, fixture.Items.Count);
        Assert.Equal(15_000, fixture.Items.Sum(i => i.Size));
        Assert.Empty(fixture.LastOutcome!.FailedAnalyzers);

        // Four are whitelisted-safe, the npm log is a "likely" candidate.
        Assert.Equal(4, fixture.Items.Count(i => i.Confidence == CleanupConfidence.Safe));
        Assert.Equal(1, fixture.Items.Count(i => i.Confidence == CleanupConfidence.Likely));
        Assert.Equal(11_000, fixture.Items.Where(i => i.Confidence == CleanupConfidence.Safe).Sum(i => i.Size));
    }
}
