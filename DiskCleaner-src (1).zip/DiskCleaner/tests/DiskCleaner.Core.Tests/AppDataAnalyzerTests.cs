using DiskCleaner.Core.Analyzers;
using DiskCleaner.Core.Analyzers.AppData;
using DiskCleaner.Core.Application;
using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure;
using DiskCleaner.Core.Infrastructure.IO;
using DiskCleaner.Core.Models;
using DiskCleaner.Core.Scanning;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// AppData is where user data and reclaimable cache live side by side, so the tests focus
/// on the boundary: what is attributed, what is offered, and what must never be offered.
/// </summary>
public class AppDataAnalyzerTests
{
    private const string Local = @"C:\Users\alice\AppData\Local";
    private const string Roaming = @"C:\Users\alice\AppData\Roaming";
    private const string LocalLow = @"C:\Users\alice\AppData\LocalLow";

    private sealed class Fixture
    {
        public InMemoryFileSystem Fs { get; } = new();
        public FakeEnvironmentInfo Env { get; set; } = FakeEnvironmentInfo.DefaultWindows();
        public AppSettings Settings { get; } = new();
        public AnalyzerRunOutcome? LastOutcome { get; private set; }

        /// <summary>Items the pipeline actually accepted (deduplicated, policy-checked).</summary>
        public IReadOnlyList<ScanItem> Items => LastOutcome?.Items ?? [];
        public List<DriveSnapshot> Drives { get; } = [FakeDriveService.Fixed(@"C:\", 512, 100, "System")];
        public SafetyPolicy Policy { get; set; }

        public Fixture()
        {
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]), Env);
        }

        /// <summary>Direct context for tests that drive the analyzer without the pipeline.</summary>
        public AnalyzerContext Context(ScanMode mode = ScanMode.Deep) => new(
            new ScanOptions { Mode = mode },
            Settings,
            Drives,
            [],
            [],
            Env,
            Fs,
            new DirectoryMeasurer(new FileSystemScanner(Fs), Fs),
            Policy);

        public AnalyzerPipeline Pipeline(params IAnalyzer[] analyzers) =>
            new(analyzers, Env, Fs, new DirectoryMeasurer(new FileSystemScanner(Fs), Fs), Policy);

        public async Task<AppDataReport> RunAsync(ScanMode mode = ScanMode.Deep, params IAnalyzer[] extra)
        {
            var pipeline = Pipeline([new AppDataAnalyzer(), .. extra]);

            var outcome = await pipeline.RunAsync(
                AnalyzerInput.Empty(new ScanOptions { Mode = mode }, Settings, Drives),
                mode,
                CancellationToken.None);

            LastOutcome = outcome;
            Assert.Contains(WellKnownAnalyzers.AppData, outcome.ExecutedAnalyzers);
            Assert.Empty(outcome.FailedAnalyzers);
            return Assert.IsType<AppDataReport>(outcome.Reports[AppDataAnalyzer.ReportKey]);
        }
    }

    // ------------------------------------------------------------ attribution

    [Fact]
    public async Task A_known_browser_is_attributed_by_catalog_not_by_name()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 900_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 4_000_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Login Data", 500_000);

        var report = await fixture.RunAsync();

        var chrome = report.Applications.Single(a => a.DisplayName == "Google Chrome");
        Assert.True(chrome.IsKnown);
        Assert.Equal(AppDataRoot.Local, chrome.Root);
        Assert.Equal("Google", chrome.Vendor);
        Assert.Equal(5_400_000, chrome.Bytes);
        Assert.Contains("profile", chrome.Explanation, StringComparison.OrdinalIgnoreCase);

        // Only the cache is reclaimable; history and passwords are not.
        var cache = chrome.Contents.Single(c => c.Kind == AppDataContentKind.Cache);
        Assert.Equal(900_000, cache.Bytes);
        Assert.Equal(CleanupConfidence.Safe, cache.Confidence);
        Assert.True(cache.IsReclaimable);

        Assert.Equal(900_000, chrome.ReclaimableBytes);
    }

    [Fact]
    public async Task Profile_data_of_a_browser_is_never_offered()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 900_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 4_000_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Login Data", 500_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Bookmarks", 100_000);

        await fixture.RunAsync();

        // Exactly one candidate: the cache. Nothing else may be deletable.
        var item = Assert.Single(fixture.Items);
        Assert.EndsWith("Cache", item.Path, StringComparison.Ordinal);
        Assert.Equal(ScanCategory.BrowserCache, item.Category);
        Assert.True(item.IsDeletable);
    }

    [Fact]
    public async Task VsCode_history_and_backups_are_protected_while_caches_are_offered()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Roaming + @"\Code\Cache\x", 300_000);
        fixture.Fs.AddFile(Roaming + @"\Code\CachedData\abc\y", 700_000);
        fixture.Fs.AddFile(Roaming + @"\Code\logs\20260501\main.log", 50_000);
        fixture.Fs.AddFile(Roaming + @"\Code\User\workspaceStorage\hash1\state.vscdb", 200_000);
        // User data that must never be offered:
        fixture.Fs.AddFile(Roaming + @"\Code\User\History\file1.txt", 8_000_000);
        fixture.Fs.AddFile(Roaming + @"\Code\Backups\workspace\unsaved.txt", 2_000_000);
        fixture.Fs.AddFile(Roaming + @"\Code\User\settings.json", 4_000);

        var report = await fixture.RunAsync();

        var vscode = report.Applications.Single(a => a.DisplayName == "Visual Studio Code");

        var reclaimable = vscode.Contents.Where(c => c.IsReclaimable).ToArray();
        Assert.Equal(300_000 + 700_000 + 50_000 + 200_000, reclaimable.Sum(c => c.Bytes));

        var paths = reclaimable.Select(c => c.Path).ToArray();
        Assert.Contains(Roaming + @"\Code\Cache", paths);
        Assert.Contains(Roaming + @"\Code\CachedData", paths);
        Assert.Contains(Roaming + @"\Code\logs", paths);
        Assert.Contains(Roaming + @"\Code\User\workspaceStorage", paths);

        // The user-data folders are not reclaimable and not emitted as items.
        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("History", StringComparison.Ordinal));
        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("Backups", StringComparison.Ordinal));
        Assert.DoesNotContain(fixture.Items, i => i.Path.EndsWith("settings.json", StringComparison.Ordinal));

        // Workspace storage is a candidate, but a cautious one.
        var workspace = reclaimable.Single(c => c.Path.EndsWith("workspaceStorage", StringComparison.Ordinal));
        Assert.Equal(CleanupConfidence.Likely, workspace.Confidence);
        Assert.Equal(RiskLevel.Medium, workspace.Risk);
    }

    [Fact]
    public async Task Unknown_folders_are_reported_with_their_size_and_no_invented_purpose()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\SomeMysteryApp\data.bin", 1_500_000);
        fixture.Fs.AddFile(Local + @"\SomeMysteryApp\Cache\big.bin", 2_500_000);

        var report = await fixture.RunAsync();

        var unknown = report.Applications.Single(a => a.Path == Local + @"\SomeMysteryApp");
        Assert.False(unknown.IsKnown);
        Assert.Equal("SomeMysteryApp", unknown.DisplayName);
        Assert.Equal(4_000_000, unknown.Bytes);
        Assert.Equal(4_000_000, report.UnknownBytes);

        // "Cache" in the name changes nothing: no rule, no candidate.
        Assert.Empty(fixture.Items);

        var group = Assert.Single(unknown.Contents);
        Assert.Equal(AppDataContentKind.Unknown, group.Kind);
        Assert.False(group.IsReclaimable);
        Assert.Equal(CleanupConfidence.NeedsReview, group.Confidence);
        Assert.Contains("could not be determined", group.Explanation, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task Docker_and_wsl_virtual_disks_are_described_but_never_offered()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Docker\wsl\data\ext4.vhdx", 40L * 1024 * 1024 * 1024);
        fixture.Fs.AddFile(Local + @"\wsl\Ubuntu\ext4.vhdx", 8L * 1024 * 1024 * 1024);

        var report = await fixture.RunAsync();

        Assert.Equal(2, report.Applications.Count);
        Assert.All(report.Applications, app =>
        {
            Assert.DoesNotContain(app.Contents, c => c.IsReclaimable);
            Assert.All(app.Contents, c =>
            {
                Assert.Equal(AppDataContentKind.Data, c.Kind);
                Assert.Equal(RiskLevel.Critical, c.Risk);
                Assert.Equal(DeletionMethod.None, c.Method);
                Assert.Contains("not a cache", c.Explanation, StringComparison.OrdinalIgnoreCase);
            });
        });

        Assert.Empty(fixture.Items);
        Assert.Equal(0, report.ReclaimableBytes);
    }

    [Fact]
    public async Task A_vendor_folder_splits_into_products_plus_an_unattributed_remainder()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\x", 1_000);
        fixture.Fs.AddFile(Local + @"\Google\SomethingElse\blob.dat", 4_000);

        var report = await fixture.RunAsync();

        var chrome = report.Applications.Single(a => a.DisplayName == "Google Chrome");
        Assert.Equal(1_000, chrome.Bytes);

        var other = report.Applications.Single(a => a.DisplayName == "Google" && !a.IsKnown);
        Assert.Equal(4_000, other.Bytes);
        Assert.False(other.IsKnown);

        // The vendor folder is not counted twice.
        Assert.Equal(5_000, report.Applications.Sum(a => a.Bytes));
    }

    // ------------------------------------------------------------ roots & totals

    [Fact]
    public async Task All_three_roots_are_analysed_separately()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\scratch.tmp", 1_000);
        fixture.Fs.AddFile(Roaming + @"\Code\Cache\x", 2_000);
        fixture.Fs.AddFile(LocalLow + @"\Oracle\Java\Deployment\cache\y", 3_000);

        var report = await fixture.RunAsync();

        Assert.Equal(3, report.Roots.Count);
        Assert.Contains(report.Roots, r => r.Root == AppDataRoot.Local && r.Bytes == 1_000);
        Assert.Contains(report.Roots, r => r.Root == AppDataRoot.Roaming && r.Bytes == 2_000);
        Assert.Contains(report.Roots, r => r.Root == AppDataRoot.LocalLow && r.Bytes == 3_000);

        Assert.Equal(6_000, report.TotalBytes);
    }

    [Fact]
    public async Task Quick_scan_covers_only_the_current_profile()
    {
        var fixture = new Fixture
        {
            Env = new FakeEnvironmentInfo(FakeEnvironmentInfo.Windows(), [@"C:\Users\alice", @"C:\Users\bob"]),
        };
        fixture.Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(fixture.Env, [@"C:\"]), fixture.Env);

        fixture.Fs.AddFile(@"C:\Users\alice\AppData\Local\Temp\a.tmp", 1_000);
        fixture.Fs.AddFile(@"C:\Users\bob\AppData\Local\Temp\b.tmp", 2_000);

        var quick = await fixture.RunAsync(ScanMode.Quick);
        Assert.Equal(1_000, quick.TotalBytes);
        Assert.All(quick.Roots, r => Assert.Equal(@"C:\Users\alice", r.Profile));

        var deep = await fixture.RunAsync(ScanMode.Deep);
        Assert.Equal(3_000, deep.TotalBytes);
        Assert.Contains(deep.Roots, r => r.Profile == @"C:\Users\bob");
    }

    [Fact]
    public async Task The_content_kind_summary_separates_cache_from_real_data()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\x", 1_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 9_000);
        fixture.Fs.AddFile(Local + @"\npm-cache\_cacache\y", 5_000);

        var report = await fixture.RunAsync();

        var cache = report.ByContentKind.Single(k => k.Kind == AppDataContentKind.Cache);
        Assert.Equal(1_000, cache.Bytes);

        var dev = report.ByContentKind.Single(k => k.Kind == AppDataContentKind.DeveloperCache);
        Assert.Equal(5_000, dev.Bytes);
        Assert.Equal(5_000, dev.ReclaimableBytes);

        Assert.Equal(6_000, report.ReclaimableBytes);
        Assert.Equal(1_000, report.SafeReclaimableBytes);
        Assert.Equal(15_000, report.TotalBytes);
    }

    [Fact]
    public async Task Developer_caches_are_candidates_but_only_likely_never_safe()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\npm-cache\_cacache\content\sha512\ab", 12_000);
        fixture.Fs.AddFile(Local + @"\NuGet\http-cache\pkg", 7_000);

        var report = await fixture.RunAsync();

        var devGroups = report.Applications
            .SelectMany(a => a.Contents)
            .Where(c => c.Kind == AppDataContentKind.DeveloperCache)
            .ToArray();

        Assert.Equal(2, devGroups.Length);
        Assert.All(devGroups, g =>
        {
            Assert.Equal(CleanupConfidence.Likely, g.Confidence);
            Assert.Equal(RiskLevel.Medium, g.Risk);
            Assert.True(g.IsReclaimable);
        });

        Assert.Equal(2, fixture.Items.Count);
        Assert.All(fixture.Items, i =>
        {
            Assert.Equal(ScanCategory.DeveloperData, i.Category);
            Assert.Equal(CleanupConfidence.Likely, i.Confidence);
            Assert.True(i.IsDeletable);
        });

        Assert.Equal(0, report.SafeReclaimableBytes);
    }

    [Fact]
    public async Task Aggregate_application_entries_are_never_emitted_as_cleanup_items()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 9_000_000);

        var report = await fixture.RunAsync();

        Assert.Single(report.Applications);
        Assert.Empty(fixture.Items);          // 9 MB of profile data is an explanation, not a candidate
        Assert.Equal(0, report.ReclaimableBytes);
    }

    // ------------------------------------------------------------ cooperation

    [Fact]
    public async Task Running_together_with_the_browser_analyzer_does_not_double_count()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\data_1", 900_000);

        var report = await fixture.RunAsync(ScanMode.Deep, new BrowserCacheAnalyzer());

        // Both analyzers see the same cache; deduplication leaves exactly one candidate.
        var cacheItems = fixture.Items.Where(i => i.Path.EndsWith("Cache", StringComparison.Ordinal)).ToArray();
        Assert.Single(cacheItems);
        Assert.Equal(900_000, cacheItems[0].Size);
    }

    [Fact]
    public async Task The_tree_view_exposes_the_largest_subdirectories()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Cache\a", 1_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 5_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Profile 1\Cache\b", 2_000);

        var report = await fixture.RunAsync();

        var chrome = report.Applications.Single(a => a.DisplayName == "Google Chrome");
        Assert.NotEmpty(chrome.LargestDirectories);

        var userData = chrome.LargestDirectories.Single(n => n.Name == "User Data");
        Assert.Equal(8_000, userData.SubtreeBytes);
        Assert.NotEmpty(userData.Children);

        var defaultProfile = userData.Children.Single(n => n.Name == "Default");
        Assert.Equal(6_000, defaultProfile.SubtreeBytes);

        // Tree nodes are directories; the History *file* contributes to Default's own size.
        var cache = Assert.Single(defaultProfile.Children);
        Assert.Equal("Cache", cache.Name);
        Assert.Equal(1_000, cache.SubtreeBytes);
        Assert.Equal(5_000, defaultProfile.OwnBytes);
    }

    // ------------------------------------------------- defects found in review

    [Fact]
    public async Task Thumbnail_caches_are_counted_once_when_both_analyzers_run()
    {
        // ThumbnailAnalyzer offers the individual .db files; the AppData rule for the
        // Explorer family must stay explanatory only, or the same bytes are promised twice.
        var fixture = new Fixture();
        var explorer = Local + @"\Microsoft\Windows\Explorer";
        fixture.Fs.AddFile(explorer + @"\thumbcache_1234.db", 500_000);
        fixture.Fs.AddFile(explorer + @"\iconcache_16.db", 100_000);

        var report = await fixture.RunAsync(ScanMode.Deep, new ThumbnailAnalyzer());

        var candidates = fixture.Items.Where(i => i.Category == ScanCategory.Thumbnails).ToArray();
        Assert.Equal(2, candidates.Length);                       // two database files
        Assert.Equal(600_000, candidates.Sum(i => i.Size));       // counted once
        Assert.All(candidates, c => Assert.Equal(ScanItemKind.File, c.Kind));

        // The report still explains the folder, but marks it as not directly reclaimable.
        var app = report.Applications.Single(a => a.DisplayName == "Explorer caches");
        var group = Assert.Single(app.Contents);
        Assert.Equal(AppDataContentKind.Cache, group.Kind);
        Assert.False(group.IsReclaimable);
        Assert.Equal(0, app.ReclaimableBytes);
    }

    [Fact]
    public async Task The_pnpm_home_is_described_but_never_offered()
    {
        // It contains the executable and shims, not only the store: deleting it uninstalls pnpm.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\pnpm\store\v3\files\ab", 9_000_000);
        fixture.Fs.AddFile(Local + @"\pnpm\pnpm.exe", 40_000_000);

        var report = await fixture.RunAsync();

        var pnpm = report.Applications.Single(a => a.Path == Local + "\\pnpm");
        Assert.Equal(49_000_000, pnpm.Bytes);
        Assert.DoesNotContain(pnpm.Contents, c => c.IsReclaimable);
        // The catalog explains what it is; the content group only says "application data".
        Assert.Contains("uninstalls pnpm", pnpm.Explanation, StringComparison.OrdinalIgnoreCase);
        Assert.Equal(KnownApplications.FamilyData, pnpm.Family);
        Assert.Empty(fixture.Items);
    }

    [Fact]
    public async Task A_known_child_of_a_catalog_folder_wins_over_the_parent_rule()
    {
        // "Packages" is a catalog entry with reclaimable rules, but it also contains the
        // WSL distribution package, which must be treated as a virtual disk, not a cache.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc\LocalState\ext4.vhdx", 6L * 1024 * 1024 * 1024);
        fixture.Fs.AddFile(Local + @"\Packages\Some.OtherApp_8wekyb3d8bbwe\LocalCache\x", 30_000);
        fixture.Fs.AddFile(Local + @"\Packages\Some.OtherApp_8wekyb3d8bbwe\Settings\settings.dat", 4_000);

        var report = await fixture.RunAsync();

        var wsl = report.Applications.Single(a => a.DisplayName.StartsWith("WSL", StringComparison.Ordinal));
        Assert.Equal(6L * 1024 * 1024 * 1024, wsl.Bytes);
        Assert.DoesNotContain(wsl.Contents, c => c.IsReclaimable);
        Assert.All(wsl.Contents, c => Assert.Equal(RiskLevel.Critical, c.Risk));

        var other = report.Applications.Single(a => a.Path == Local + @"\Packages\Some.OtherApp_8wekyb3d8bbwe");
        Assert.Contains(other.Contents, c => c.IsReclaimable && c.Bytes == 30_000);

        // The virtual disk must never reach the cleanup candidates.
        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("ext4.vhdx", StringComparison.Ordinal));
        Assert.DoesNotContain(fixture.Items, i => i.Path.Contains("CanonicalGroupLimited", StringComparison.Ordinal));
    }

    [Fact]
    public async Task Quick_scan_statistics_cover_everything_examined_not_only_the_candidates()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\scratch.tmp", 1_000);
        // Real data that is examined but must never be offered:
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\History", 9_000_000);
        fixture.Fs.AddFile(Local + @"\Google\Chrome\User Data\Default\Login Data", 500_000);

        var service = new ScanService(
            new FileSystemScanner(fixture.Fs),
            fixture.Pipeline(new TempAnalyzer(), new AppDataAnalyzer()),
            new FakeSettingsService(),
            new FakeDriveService { Drives = { FakeDriveService.Fixed(@"C:\", 512, 100, "System") } },
            new Infrastructure.Time.ManualClock(new DateTime(2026, 5, 1, 10, 0, 0, DateTimeKind.Utc)));

        var result = await service.RunAsync(ScanMode.Quick, []);

        // Targeted passes can overlap (TEMP is also inside the Local AppData pass), so the
        // counters describe work done rather than unique files. What matters is that they
        // cover everything examined, not just the single candidate that survived.
        Assert.True(result.Statistics.FilesScanned >= 3, $"examined {result.Statistics.FilesScanned} files");
        Assert.True(result.Statistics.BytesScanned >= 9_501_000, $"examined {result.Statistics.BytesScanned} bytes");

        // Only the TEMP file is a candidate.
        var candidate = Assert.Single(result.Items);
        Assert.Equal(1_000, candidate.Size);
        Assert.Equal(1_000, result.PotentialCleanupBytes);
    }

    [Fact]
    public async Task A_partially_unreadable_root_is_marked_incomplete()
    {
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\ok.tmp", 1_000);
        fixture.Fs.AddDirectory(Local + @"\Locked");
        fixture.Fs.DeniedDirectories.Add(Local + @"\Locked");

        var report = await fixture.RunAsync();

        var local = report.Roots.Single(r => r.Root == AppDataRoot.Local);
        Assert.False(local.IsComplete);
        Assert.False(report.IsComplete);
        Assert.NotEmpty(local.Issues);
    }

    [Fact]
    public async Task A_large_appdata_tree_is_attributed_completely_and_fast()
    {
        // Guards the grouping pass: 400 applications x 12 folders each must not degrade
        // into matching every directory against every application.
        var fixture = new Fixture();
        const int applications = 400;
        const int foldersEach = 12;

        for (var a = 0; a < applications; a++)
        {
            for (var d = 0; d < foldersEach; d++)
            {
                fixture.Fs.AddFile(Local + $@"\App{a:000}\sub{d:00}\data.bin", 1_000);
            }
        }

        var stopwatch = System.Diagnostics.Stopwatch.StartNew();
        var report = await fixture.RunAsync();
        stopwatch.Stop();

        Assert.Equal(applications, report.Applications.Count);
        Assert.Equal((long)applications * foldersEach * 1_000, report.TotalBytes);
        Assert.Equal(report.TotalBytes, report.UnknownBytes);      // none of them are in the catalog
        Assert.Equal(0, report.ReclaimableBytes);
        Assert.Empty(fixture.Items);

        Assert.True(stopwatch.Elapsed < TimeSpan.FromSeconds(20),
            $"attribution of {applications * (foldersEach + 1)} directories took {stopwatch.Elapsed}");
    }

    [Fact]
    public async Task A_parent_claim_supersedes_a_child_claim_instead_of_double_counting()
    {
        // LogAnalyzer (order 35) claims npm-cache\_logs; AppDataAnalyzer (order 60) claims
        // the whole npm-cache. The outer claim is more complete, so the inner one is
        // retracted — otherwise the same bytes are promised twice.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\npm-cache\_cacache\content\ab", 5_000_000);
        fixture.Fs.AddFile(Local + @"\npm-cache\_logs\2026-05-01.log", 200_000);

        await fixture.RunAsync(ScanMode.Deep, new LogAnalyzer());

        var candidate = Assert.Single(fixture.Items, i => i.Path.Contains("npm-cache", StringComparison.Ordinal));
        Assert.EndsWith("npm-cache", candidate.Path, StringComparison.Ordinal);
        Assert.Equal(5_200_000, candidate.Size);
        Assert.Equal(1, fixture.LastOutcome!.SupersededCount);
    }

    [Fact]
    public async Task A_child_claim_inside_an_already_claimed_folder_is_dropped()
    {
        // The reverse order: TEMP is claimed as a whole first, so a nested claim adds nothing.
        var fixture = new Fixture();
        fixture.Fs.AddFile(Local + @"\Temp\a.tmp", 1_000);
        fixture.Fs.AddFile(Local + @"\Temp\nested\b.tmp", 2_000);

        var measurer = new DirectoryMeasurer(new FileSystemScanner(fixture.Fs), fixture.Fs);
        var pipeline = fixture.Pipeline(new TempAnalyzer());

        var outcome = await pipeline.RunAsync(
            AnalyzerInput.Empty(new ScanOptions { Mode = ScanMode.Quick }, fixture.Settings, fixture.Drives),
            ScanMode.Quick,
            CancellationToken.None);

        var temp = Assert.Single(outcome.Items, i => i.Path.EndsWith("Temp", StringComparison.Ordinal));
        Assert.Equal(3_000, temp.Size);
        Assert.Equal(0, outcome.SupersededCount);
        _ = measurer;
    }

    // ------------------------------------------------------------ matcher

    [Theory]
    [InlineData(@"User Data\*\Cache", new[] { "User Data", "Default", "Cache" }, true)]
    [InlineData(@"User Data\*\Cache", new[] { "User Data", "Default", "Code Cache" }, false)]
    [InlineData(@"User Data\*\Cache", new[] { "User Data", "Cache" }, false)]
    [InlineData("Cache", new[] { "Cache" }, true)]
    [InlineData("Cache", new string[0], false)]
    [InlineData("", new string[0], true)]
    [InlineData("", new[] { "Cache" }, false)]
    [InlineData(@"*\caches", new[] { "IntelliJIdea2025.1", "caches" }, true)]
    [InlineData(@"Packages\*\TempState", new[] { "Packages", "Some.App", "TempState" }, true)]
    public void Content_rules_match_segment_by_segment(string pattern, string[] segments, bool expected) =>
        Assert.Equal(expected, AppDataContentRules.Matches(pattern, segments));

    [Fact]
    public void Relative_segments_are_computed_against_the_application_root()
    {
        var segments = AppDataContentRules.RelativeSegments(
            Local + @"\Google\Chrome\User Data\Default\Cache",
            Local + @"\Google\Chrome");

        Assert.Equal(["User Data", "Default", "Cache"], segments);
    }

    [Fact]
    public void Families_without_rules_produce_no_candidates()
    {
        // VM disks and plain data folders have no rules at all — that absence is the guarantee.
        Assert.Empty(AppDataContentRules.For(KnownApplications.FamilyVmDisk));
        Assert.Empty(AppDataContentRules.For(KnownApplications.FamilyData));
        Assert.NotEmpty(AppDataContentRules.For(KnownApplications.FamilyChromium));
    }
}
