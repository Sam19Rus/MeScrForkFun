using DiskCleaner.Core.Classification;
using DiskCleaner.Core.Infrastructure.Time;
using DiskCleaner.Core.Moving;
using DiskCleaner.Testing;
using Xunit;

namespace DiskCleaner.Core.Tests;

/// <summary>
/// The mover promises three things and every test here pins one of them down:
/// (1) a successful move leaves a working junction and the data on the new volume;
/// (2) a failed move changes nothing — the original folder survives byte for byte;
/// (3) refusals are honest, translated by key, and cover the dangerous cases
/// (Store apps, protected locations, same volume, not enough space).
/// </summary>
public class AppMoverTests
{
    private const string Programs = @"C:\Users\alice\AppData\Local\Programs";
    private const string Ollama = Programs + @"\Ollama";
    private const string DestRoot = @"D:\MovedApps";
    private const string Dest = DestRoot + @"\Ollama";

    private sealed class Fixture
    {
        public InMemoryFileSystem Fs { get; } = new();
        public FakeJunctionService Junctions { get; }
        public FakeEnvironmentInfo Env { get; } = FakeEnvironmentInfo.DefaultWindows();
        public FakeDriveService Drives { get; } = new();
        public ManualClock Clock { get; } = new(new DateTime(2026, 9, 1, 12, 0, 0, DateTimeKind.Utc));
        public SafetyPolicy Policy { get; }

        public Fixture()
        {
            Junctions = new FakeJunctionService(Fs);
            Policy = new SafetyPolicy(ProtectedRootsResolver.Resolve(Env, [@"C:\", @"D:\"]), Env);
            Drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100));
            Drives.Drives.Add(FakeDriveService.Fixed(@"D:\", 1024, 500));
        }

        public AppMover CreateMover() => new(Fs, Junctions, Drives, Policy, Env, Clock);

        /// <summary>A small but representative application folder: nested dirs, several files.</summary>
        public Fixture WithOllama()
        {
            Fs.AddFile(Ollama + @"\ollama.exe", 100_000);
            Fs.AddFile(Ollama + @"\ollama runner\ollama runner.exe", 50_000);
            Fs.AddFile(Ollama + @"\ollama runner\api\server.dll", 25_000);
            Fs.AddFile(Ollama + @"\version.txt", 12);
            return this;
        }

        public long OllamaBytes => 100_000 + 50_000 + 25_000 + 12;
    }

    // ------------------------------------------------------------------ happy path

    [Fact]
    public async Task A_successful_move_copies_everything_removes_the_original_and_leaves_a_junction()
    {
        var f = new Fixture().WithOllama();
        var mover = f.CreateMover();

        var record = await mover.MoveAsync(Ollama, DestRoot);

        Assert.True(record.Succeeded, record.FailureReasonKey + " " + record.FailureDetails);
        Assert.True(record.LinkCreated);
        Assert.Equal(f.OllamaBytes, record.Bytes);
        Assert.Equal(4, record.Files);

        // The data lives on D: now, file for file.
        Assert.True(f.Fs.FileExists(Dest + @"\ollama.exe"));
        Assert.True(f.Fs.FileExists(Dest + @"\ollama runner\api\server.dll"));
        Assert.Equal(f.OllamaBytes, f.Fs.CopiedFiles.Sum(c => Size(f, c.Destination)));

        // The original files are gone; the original path is a junction to the new home.
        Assert.False(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.Contains(Ollama, f.Fs.DeletedDirectories);
        Assert.True(f.Junctions.IsLink(Ollama));
        Assert.Equal(Dest, f.Junctions.TryGetLinkTarget(Ollama));
    }

    [Fact]
    public async Task Progress_walks_through_every_phase()
    {
        var f = new Fixture().WithOllama();
        var mover = f.CreateMover();

        var phases = new List<AppMovePhase>();
        var progress = new ProgressRecorder(p => phases.Add(p.Phase));

        await mover.MoveAsync(Ollama, DestRoot, progress);

        Assert.Contains(AppMovePhase.Preparing, phases);
        Assert.Contains(AppMovePhase.Copying, phases);
        Assert.Contains(AppMovePhase.Verifying, phases);
        Assert.Contains(AppMovePhase.ReplacingSource, phases);
        Assert.Contains(AppMovePhase.CreatingLink, phases);
        Assert.Equal(AppMovePhase.Completed, phases[^1]);
    }

    [Fact]
    public async Task An_inner_junction_is_recreated_not_followed()
    {
        var f = new Fixture().WithOllama();
        // A pre-existing junction inside the app pointing outside the tree.
        f.Fs.AddDirectory(@"E:\Shared\models");
        f.Fs.AddFile(@"E:\Shared\models\llama.bin", 777);
        f.Fs.AddLink(Ollama + @"\models", @"E:\Shared\models");
        f.Drives.Drives.Add(FakeDriveService.Fixed(@"E:\", 100, 50));

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot);

        Assert.True(record.Succeeded, record.FailureReasonKey);

        // The external data was NOT dragged along…
        Assert.False(f.Fs.FileExists(Dest + @"\models\llama.bin"));
        Assert.True(f.Fs.FileExists(@"E:\Shared\models\llama.bin"));

        // …the junction was recreated at the destination.
        Assert.True(f.Junctions.IsLink(Dest + @"\models"));
        Assert.Equal(@"E:\Shared\models", f.Junctions.TryGetLinkTarget(Dest + @"\models"));
    }

    // ------------------------------------------------------------------ refusals

    [Fact]
    public async Task The_same_volume_is_refused_because_it_frees_nothing()
    {
        var f = new Fixture().WithOllama();

        var validation = await f.CreateMover().ValidateMoveAsync(Ollama, @"C:\Elsewhere");

        Assert.False(validation.IsValid);
        Assert.Equal("move.same-volume", validation.ReasonKey);
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
    }

    [Fact]
    public async Task Not_enough_space_is_refused_with_the_numbers()
    {
        var f = new Fixture().WithOllama();
        f.Drives.Drives.Clear();
        f.Drives.Drives.Add(FakeDriveService.Fixed(@"C:\", 512, 100));
        // Free space below the 64 MB safety margin.
        f.Drives.Drives.Add(new DiskCleaner.Core.Models.DriveSnapshot
        {
            RootPath = @"D:\", DriveType = "Fixed", TotalBytes = 1_000_000_000,
            FreeBytes = 1_000_000, IsReady = true, IsScannableByDefault = true,
        });

        var validation = await f.CreateMover().ValidateMoveAsync(Ollama, DestRoot);

        Assert.False(validation.IsValid);
        Assert.Equal("move.not-enough-space", validation.ReasonKey);
        Assert.True(validation.RequiredBytes >= f.OllamaBytes);
        Assert.Equal(1_000_000, validation.AvailableBytes);
    }

    [Fact]
    public async Task An_existing_destination_folder_is_refused()
    {
        var f = new Fixture().WithOllama();
        f.Fs.AddDirectory(Dest);

        var validation = await f.CreateMover().ValidateMoveAsync(Ollama, DestRoot);

        Assert.False(validation.IsValid);
        Assert.Equal("move.destination-exists", validation.ReasonKey);
    }

    [Fact]
    public async Task A_missing_source_is_refused()
    {
        var f = new Fixture();

        var record = await f.CreateMover().MoveAsync(Programs + @"\Ghost", DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.source-missing", record.FailureReasonKey);
    }

    [Fact]
    public async Task An_already_moved_app_reports_source_is_link_instead_of_moving_again()
    {
        var f = new Fixture().WithOllama();
        var mover = f.CreateMover();
        Assert.True((await mover.MoveAsync(Ollama, DestRoot)).Succeeded);

        var second = await mover.MoveAsync(Ollama, DestRoot);

        Assert.False(second.Succeeded);
        Assert.Equal("move.source-is-link", second.FailureReasonKey);
    }

    [Fact]
    public async Task Store_apps_are_refused_with_a_pointer_to_windows_settings()
    {
        var f = new Fixture();
        var package = @"C:\Users\alice\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc";
        f.Fs.AddFile(package + @"\LocalState\ext4.vhdx", 1_000_000);

        var record = await f.CreateMover().MoveAsync(package, DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.store-app", record.FailureReasonKey);
        Assert.True(f.Fs.FileExists(package + @"\LocalState\ext4.vhdx"));
    }

    [Fact]
    public async Task Protected_locations_are_refused_by_the_safety_policy()
    {
        var f = new Fixture();
        f.Fs.AddFile(@"C:\Program Files\App\app.exe", 1_000);
        f.Fs.AddFile(@"C:\Windows\Temp\x.tmp", 10);

        var programFiles = await f.CreateMover().MoveAsync(@"C:\Program Files\App", DestRoot);
        Assert.False(programFiles.Succeeded);
        Assert.Equal("move.source-protected", programFiles.FailureReasonKey);

        // C:\Windows\Temp is a deletable enclave but must never be *moved*.
        var windowsTemp = await f.CreateMover().MoveAsync(@"C:\Windows\Temp", DestRoot);
        Assert.False(windowsTemp.Succeeded);
    }

    [Fact]
    public async Task A_volume_root_can_never_be_moved()
    {
        var f = new Fixture().WithOllama();

        var record = await f.CreateMover().MoveAsync(@"C:\", DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.source-protected", record.FailureReasonKey);
    }

    [Fact]
    public async Task A_destination_inside_the_source_is_refused()
    {
        var f = new Fixture().WithOllama();
        f.Drives.Drives.Add(FakeDriveService.Fixed(@"E:\", 100, 50));

        var validation = await f.CreateMover().ValidateMoveAsync(Ollama, Ollama + @"\sub");

        // Same volume in this layout, but the ordering of checks must never let a
        // destination under the source pass: it is refused one way or another.
        Assert.False(validation.IsValid);
    }

    // ------------------------------------------------------------------ failures & rollback

    [Fact]
    public async Task A_locked_file_aborts_the_copy_and_leaves_the_original_untouched()
    {
        var f = new Fixture().WithOllama();
        // The classic case: the app is running and its executable is locked.
        f.Fs.CopyFailures.Add(Ollama + @"\ollama.exe");

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.copy-failed", record.FailureReasonKey);
        Assert.True(record.RolledBack);
        Assert.Contains("ollama.exe", record.FailureDetails, StringComparison.Ordinal);

        // Nothing changed anywhere: the source is whole, no partial copy survives.
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama runner\api\server.dll"));
        Assert.False(f.Fs.DirectoryExists(Dest));
        Assert.False(f.Junctions.IsLink(Ollama));
    }

    [Fact]
    public async Task When_the_original_cannot_be_deleted_the_copy_is_removed_and_nothing_is_lost()
    {
        var f = new Fixture().WithOllama();
        f.Fs.DeleteFailures.Add(Ollama);

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.source-delete-failed", record.FailureReasonKey);
        Assert.True(record.RolledBack);
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.False(f.Fs.DirectoryExists(Dest));
        Assert.False(f.Junctions.IsLink(Ollama));
    }

    [Fact]
    public async Task When_the_junction_fails_the_data_is_moved_back_and_the_move_is_undone()
    {
        var f = new Fixture().WithOllama();
        f.Junctions.FailCreate.Add(Ollama);

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.link-failed", record.FailureReasonKey);
        Assert.True(record.RolledBack);
        Assert.False(record.DataAtDestinationOnly);

        // The original location is whole again and D: holds nothing.
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama runner\api\server.dll"));
        Assert.False(f.Fs.DirectoryExists(Dest));
    }

    [Fact]
    public async Task When_even_the_restore_fails_the_record_says_where_the_data_is()
    {
        var f = new Fixture().WithOllama();
        f.Junctions.FailCreate.Add(Ollama);
        // The copy back to C: fails as well (e.g. the disk just went read-only).
        f.Fs.CopyFailures.Add(Dest + @"\ollama.exe");

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot);

        Assert.False(record.Succeeded);
        Assert.Equal("move.link-failed-data-safe", record.FailureReasonKey);
        Assert.True(record.DataAtDestinationOnly);

        // The bytes are provably at the destination — nothing was lost silently.
        Assert.True(f.Fs.FileExists(Dest + @"\ollama.exe"));
        Assert.True(f.Fs.FileExists(Dest + @"\ollama runner\api\server.dll"));
    }

    [Fact]
    public async Task Cancellation_before_anything_happens_returns_a_cancelled_record()
    {
        var f = new Fixture().WithOllama();
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        var record = await f.CreateMover().MoveAsync(Ollama, DestRoot, null, cts.Token);

        Assert.False(record.Succeeded);
        Assert.Equal("move.cancelled", record.FailureReasonKey);
        Assert.Equal(AppMovePhase.Cancelled, record.FinalPhase);
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.False(f.Fs.DirectoryExists(Dest));
    }

    // ------------------------------------------------------------------ move back

    [Fact]
    public async Task Move_back_returns_the_folder_and_removes_the_junction()
    {
        var f = new Fixture().WithOllama();
        var mover = f.CreateMover();
        Assert.True((await mover.MoveAsync(Ollama, DestRoot)).Succeeded);

        var back = await mover.MoveBackAsync(Ollama);

        Assert.True(back.Succeeded, back.FailureReasonKey + " " + back.FailureDetails);
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama runner\api\server.dll"));
        Assert.False(f.Fs.DirectoryExists(Dest));
        Assert.False(f.Junctions.IsLink(Ollama));
    }

    [Fact]
    public async Task Move_back_refuses_a_folder_that_is_not_a_junction()
    {
        var f = new Fixture().WithOllama();

        var back = await f.CreateMover().MoveBackAsync(Ollama);

        Assert.False(back.Succeeded);
        Assert.Equal("move.back-not-a-link", back.FailureReasonKey);
        Assert.True(f.Fs.FileExists(Ollama + @"\ollama.exe"));
    }

    [Fact]
    public async Task Move_back_restores_the_junction_when_the_copy_back_fails()
    {
        var f = new Fixture().WithOllama();
        var mover = f.CreateMover();
        Assert.True((await mover.MoveAsync(Ollama, DestRoot)).Succeeded);

        f.Fs.CopyFailures.Add(Dest + @"\ollama.exe");

        var back = await mover.MoveBackAsync(Ollama);

        Assert.False(back.Succeeded);
        Assert.True(back.RolledBack);
        Assert.True(f.Junctions.IsLink(Ollama));
        Assert.True(f.Fs.FileExists(Dest + @"\ollama.exe"));
    }

    // ------------------------------------------------------------------ discovery

    [Fact]
    public async Task Discovery_lists_apps_with_sizes_and_marks_already_moved_ones()
    {
        var f = new Fixture().WithOllama();
        f.Fs.AddFile(Programs + @"\SmallApp\app.exe", 1_000);
        var mover = f.CreateMover();
        Assert.True((await mover.MoveAsync(Programs + @"\SmallApp", DestRoot)).Succeeded);

        var apps = await mover.DiscoverAsync();

        Assert.Equal(2, apps.Count);

        var ollama = apps.Single(a => a.Name == "Ollama");
        Assert.False(ollama.IsAlreadyMoved);
        Assert.Equal(f.OllamaBytes, ollama.Bytes);
        Assert.Equal(4, ollama.FileCount);

        var small = apps.Single(a => a.Name == "SmallApp");
        Assert.True(small.IsAlreadyMoved);
        Assert.Equal(DestRoot + @"\SmallApp", small.LinkTarget);
        Assert.Equal(1_000, small.Bytes); // measured through the real location
    }

    [Fact]
    public async Task Discovery_orders_by_size_largest_first()
    {
        var f = new Fixture().WithOllama();
        f.Fs.AddFile(Programs + @"\Big\blob.bin", 10_000_000);
        f.Fs.AddFile(Programs + @"\Tiny\a.txt", 5);

        var apps = await f.CreateMover().DiscoverAsync();

        Assert.Equal(["Big", "Ollama", "Tiny"], apps.Select(a => a.Name).ToArray());
    }

    [Fact]
    public async Task Discovery_of_a_missing_root_is_an_empty_list_not_an_error()
    {
        var f = new Fixture();

        var apps = await f.CreateMover().DiscoverAsync();

        Assert.Empty(apps);
    }

    [Fact]
    public void DefaultRoot_is_the_per_user_programs_folder()
    {
        var f = new Fixture();
        Assert.Equal(Programs, f.CreateMover().DefaultRoot);
    }

    // ------------------------------------------------------------------ helpers

    private static long Size(Fixture f, string path) => f.Fs.TryGetFileMetadata(path)?.Size ?? 0;

    private sealed class ProgressRecorder(Action<AppMoveProgress> onReport) : IProgress<AppMoveProgress>
    {
        public void Report(AppMoveProgress value) => onReport(value);
    }
}
