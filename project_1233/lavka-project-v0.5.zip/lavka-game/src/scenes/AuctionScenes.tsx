/* AuctionScenes.tsx — зал аукциона:
   HallScene — осмотр лотов (упаковки на столах, улики, оценка, бейджи мотивации);
   BiddingScene — ЖИВЫЕ торги: ведущий, лот под софитом, NPC с эмоциями и репликами,
                  табло цены, молоток;
   LossScene — обучающий экран проигрыша (кто забрал, правда о цене, подсказка архетипа). */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { game } from '../app/store';
import { AuctionHall } from '../components/art/backdrops';
import { NpcFigure, Auctioneer } from '../components/art/NpcFigure';
import { Btn, Face, Modal, Badge } from '../components/ui/Basics';
import { CONFIG } from '../game/data/config';
import { HOUSES, NPCS, PACK_SVG } from '../game/data/world';
import { ITEMS_BY_ID } from '../game/data/items';
import * as E from '../game/economy';
import type { LotInst, NpcId } from '../game/types';

const packName = (id: string) => (CONFIG.packs.find(p => p.id === id) || { name: 'Ящик' }).name;

/* ================= осмотр лотов ================= */
export function HallScene() {
  const s = game.getSnapshot();
  const day = s.day!;
  const house = HOUSES[day.houseId];
  const save = s.save;
  const modalLot = s.inspectIdx != null ? day.lots[s.inspectIdx] : null;

  const roster = useMemo(() => {
    const ids = new Set<NpcId>();
    day.lots.forEach(l => l.npcs.forEach(b => ids.add(b.id)));
    return [...ids];
  }, [day.lots]);

  return (
    <div className="scene hall-scene">
      <AuctionHall />
      <div className="hall-layer">
        <div style={{ textAlign: 'center', padding: '6px 12px 0', zIndex: 5 }}>
          <div className="title" style={{ margin: 0 }}>{house.name}</div>
          <div className="subtitle" style={{ margin: 0 }}>Осмотр перед торгами: изучите улики и прикиньте цену. Точная оценка — +{CONFIG.clue.estimateReward} ₽</div>
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 4, overflowY: 'auto' }}>
          <div className="lots-table">
            {day.lots.map((l, i) => {
              const badges = game.lotBadges(l);
              return (
                <div className={`lot-crate ${l.estimated ? 'estimated' : ''}`} key={l.id} onClick={() => game.openLotModal(i)}>
                  <div style={{ lineHeight: 0 }} dangerouslySetInnerHTML={{ __html: PACK_SVG[l.packId] || PACK_SVG.crate }} />
                  <div className="lc-n">Лот {i + 1}{l.estimated ? ` · ${E.bandLabel(l.estimateBand!)}` : ''}</div>
                  <div className="lc-start">старт ~{l.start} ₽</div>
                  <div className="lc-badges">{badges.slice(0, 2).map((b, bi) => <Badge key={bi} cls={b.cls}>{b.text}</Badge>)}</div>
                  {save.day === 1 && !save.ftue.done && i === 0 && <div className="ftue-arrow" style={{ position: 'static', fontSize: 26 }}>⬆</div>}
                </div>
              );
            })}
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 18, zIndex: 5, paddingBottom: 4 }}>
          {roster.map(id => (
            <div key={id} style={{ textAlign: 'center' }}>
              <NpcFigure id={id} emo="idle" size={84} />
              <div className="npc-name">{NPCS[id].name}</div>
              <div className="npc-state" style={{ fontSize: 10 }}>{NPCS[id].role}</div>
            </div>
          ))}
        </div>
        <div className="bid-controls">
          <Btn big variant="gold" onClick={() => game.startBidding()}>🔔 Начать торги</Btn>
          <Btn variant="secondary" onClick={() => game.leaveHall()}>← В город</Btn>
        </div>
      </div>
      {modalLot && s.inspectIdx != null && <LotModal lot={modalLot} idx={s.inspectIdx} />}
    </div>
  );
}

function LotModal({ lot, idx }: { lot: LotInst; idx: number }) {
  const item = ITEMS_BY_ID[lot.itemId];
  const range = game.estimateRangeFor(lot);
  const viewed = (lot.clues || []).filter((c, ci) => c.free || ci < lot.revealedClues).length;
  const paidLeft = (lot.clues || []).filter((c, ci) => !c.free && ci >= lot.revealedClues).length;
  const badges = game.lotBadges(lot);

  return (
    <Modal onClose={() => game.closeLotModal()}>
      <div className="title" style={{ fontSize: 20 }}>Лот {idx + 1} · {packName(lot.packId)}</div>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', margin: '6px 0 10px' }}>
        <div style={{ width: 92, height: 92, lineHeight: 0, flex: '0 0 auto' }} dangerouslySetInnerHTML={{ __html: PACK_SVG[lot.packId] || PACK_SVG.crate }} />
        <div>
          <div style={{ fontSize: 14 }}>Старт: <b style={{ color: 'var(--gold)' }}>~{lot.start} ₽</b></div>
          <div className="hint">{item.clues.seller}</div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 5 }}>
            {badges.map((b, i) => <Badge key={i} cls={b.cls}>{b.text}</Badge>)}
          </div>
        </div>
      </div>
      {(lot.clues || []).map((c, ci) => {
        const visible = c.free || ci < lot.revealedClues;
        return visible ? (
          <div className="clue" key={ci}>
            🔎 {c.text}
            {c.sprite && lot.photo && (
              <div style={{ width: 84, height: 84, marginTop: 6, filter: 'brightness(.7) sepia(.5)', lineHeight: 0 }}
                dangerouslySetInnerHTML={{ __html: item.svg }} />
            )}
          </div>
        ) : <div className="clue hidden-clue" key={ci}>▒▒▒ платная улика</div>;
      })}
      {paidLeft > 0 && (
        <Btn variant="secondary" small style={{ marginBottom: 8 }} onClick={() => game.buyExtraClue()}>
          👁 Ещё улика (реклама, {Math.max(0, CONFIG.ads.rewarded.extra_clue - game.cluesPaidToday())}/{CONFIG.ads.rewarded.extra_clue} сегодня)
        </Btn>
      )}
      <div className="est-range">Ваш диапазон по уликам: <b>{range[0]}–{range[1]} ₽</b> <small>(улик: {viewed})</small></div>
      <div className="hint">Ваша оценка (для статистики и +{CONFIG.economy.estimateReward} ₽ за точность):</div>
      <div className="bands">
        {CONFIG.estimateBands.map((b, bi) => (
          <Btn key={bi} className={`band ${lot.estimateBand === bi ? 'sel' : ''}`}
            variant={lot.estimateBand === bi ? 'gold' : 'primary'}
            onClick={() => game.submitEstimate(bi)}>
            {E.bandLabel(bi)}
          </Btn>
        ))}
      </div>
      <Btn variant="secondary" onClick={() => game.closeLotModal()}>Закрыть</Btn>
    </Modal>
  );
}

/* ================= живые торги ================= */
export function BiddingScene() {
  const s = game.getSnapshot();
  const lot = s.lot!;
  const view = s.auction;
  const save = s.save;
  const badges = game.lotBadges(lot);
  const priceRef = useRef<HTMLDivElement>(null);
  const prevPrice = useRef(view ? view.price : 0);
  const [tipShown, setTipShown] = useState(false);

  useEffect(() => {
    if (!view) return;
    if (view.price !== prevPrice.current) {
      prevPrice.current = view.price;
      const el = priceRef.current;
      if (el) { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
    }
  }, [view && view.price]);

  useEffect(() => {
    if (save.day === 1 && !save.tips?.bid) { setTipShown(true); game.markBidTip(); }
  }, []);

  if (!view) return null;
  const now = Date.now();

  return (
    <div className={`scene hall-scene ${view.gavel ? 'gavel-flash' : ''}`}>
      <AuctionHall close />
      <div className="bid-stage">
        <div className="price-board">
          <div className="pb-price" ref={priceRef}>{view.price} ₽</div>
          <div className="pb-step">{lot.price ? `шаг ${view.step} ₽` : 'стартовая цена'}</div>
        </div>

        <div className="podium-area">
          <div className="spotlight" />
          <div style={{ position: 'absolute', left: '63%', bottom: '24%', zIndex: 4 }}>
            <Auctioneer strike={view.gavel} size={110} />
          </div>
          <div className="podium-lot" style={{ marginTop: '10%' }}>
            <div className="crate" style={{ lineHeight: 0 }} dangerouslySetInnerHTML={{ __html: PACK_SVG[lot.packId] || PACK_SVG.crate }} />
            <div style={{ fontSize: 13, color: 'var(--paper2)', marginTop: 2 }}>
              Лот {s.day ? Math.max(1, s.day.idx) : 1}/{s.day ? s.day.lots.length : '?'}
            </div>
            <div style={{ display: 'flex', gap: 4, justifyContent: 'center', flexWrap: 'wrap', marginTop: 3 }}>
              {badges.map((b, i) => <Badge key={i} cls={b.cls}>{b.text}</Badge>)}
            </div>
            <div className="hint" style={{ fontSize: 11.5 }}>Ваша оценка: {lot.estimateBand != null ? E.bandLabel(lot.estimateBand) : 'не дана'}</div>
          </div>
        </div>

        <div className="npc-row">
          {lot.npcs.map(b => {
            const nv = view.npcs[b.id];
            if (!nv) return null;
            const def = NPCS[b.id];
            const bubble = nv.bubble && now < nv.bubbleUntil ? nv.bubble : null;
            return (
              <div className={`npc-slot ${!nv.active ? 'out' : ''} ${nv.leader ? 'leader' : ''}`} key={b.id}>
                {bubble && <div className="bubble">«{bubble}»</div>}
                <NpcFigure id={b.id} emo={nv.emotion} size={110} />
                <div className="npc-name">{def.name} {nv.wants && def.loves ? '♥' : ''}</div>
                <div className="npc-state">
                  {!nv.active ? 'пас' : nv.leader ? `лидер: ${nv.lastBid}` : (nv.lastBid ? `до ${nv.lastBid}` : 'думает…')}
                </div>
              </div>
            );
          })}
        </div>

        <div className="bid-log">
          {view.log.slice(-4).map((x, i) => <div key={i}>— {x}</div>)}
        </div>

        {/* силуэт игрока (вид со спины) */}
        <div className="player-fig">
          <svg viewBox="0 0 140 96" width={126} xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="70" cy="92" rx="46" ry="6" fill="#000" opacity=".35" />
            <path d="M26 96 Q70 44 114 96 Z" fill="#5a4632" />
            <path d="M40 60 q30 -18 60 0 l-6 14 q-24 -12 -48 0 z" fill="#6e4f33" />
            <circle cx="70" cy="38" r="24" fill="#4a3620" />
            <path d="M46 40 q24 -30 48 0 q-4 -26 -24 -26 q-20 0 -24 26" fill="#3a2c1d" />
            <g transform="rotate(18 112 40)">
              <rect x="108" y="34" width="9" height="34" rx="4" fill="#8a6a48" />
              <rect x="102" y="12" width="24" height="22" rx="5" fill="#d9b23f" stroke="#8a6c1e" strokeWidth="2" />
            </g>
          </svg>
        </div>

        <div className="bid-controls">
          {!view.resolved && view.playerTurn && !view.isLeader && (
            view.canAfford ? (
              <>
                <Btn big variant="gold" onClick={() => game.playerBid()}>✋ Поднять до {view.nextPrice} ₽</Btn>
                <Btn big variant="secondary" onClick={() => game.playerPass()}>Пас</Btn>
              </>
            ) : (
              <>
                <div className="you-hint">Не хватает монет на ставку — придётся пасовать</div>
                <Btn variant="secondary" onClick={() => game.playerPass()}>Пас</Btn>
              </>
            )
          )}
          {!view.resolved && view.playerTurn && view.isLeader && (
            <div className="you-hint">Вы — лидер. Соперники думают…</div>
          )}
          {!view.resolved && !view.playerTurn && view.playerIn && (
            <div className="you-hint dim">Торги идут…</div>
          )}
          {!view.resolved && !view.playerIn && (
            <div className="you-hint">Вы пасуете — смотрите, как торгуются другие</div>
          )}
          {view.resolved && view.winner === 'player' && (
            <div className="you-hint" style={{ color: 'var(--gold)' }}>🔨 Молоток! Лот ваш за {view.price} ₽</div>
          )}
        </div>

        {tipShown && (
          <div className="lesson-card bid-lesson">
            💡 Поднимайте ставку или пасуйте. У каждого соперника свой предел цены — угадывайте его по словам и повадкам и не переплачивайте.
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= экран проигрыша ================= */
export function LossScene() {
  const s = game.getSnapshot();
  const loss = s.loss!;
  const lot = s.lot!;
  const def = lot.winner ? (NPCS as any)[lot.winner] : null;
  const item = ITEMS_BY_ID[lot.itemId];
  return (
    <div className="scene hall-scene">
      <AuctionHall />
      <div className="result-scene hall-layer">
        <div className="item-card-big" style={{ textAlign: 'left' }}>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            {loss.face && <Face svg={loss.face} size={72} />}
            <div>
              <div className="item-name" style={{ margin: 0 }}>{def ? `${def.name} забрал лот` : loss.title}</div>
              {def && <div className="hint">{def.role}</div>}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center', margin: '10px 0' }}>
            <div style={{ width: 64, height: 64, lineHeight: 0, flex: '0 0 auto' }} dangerouslySetInnerHTML={{ __html: item.svg }} />
            <div>
              <b>{item.name}</b>
              <div className="hint">ушёл за {lot.price} ₽ · настоящая стоимость: {lot.trueValue} ₽</div>
            </div>
          </div>
          <div className="item-story" style={{ textAlign: 'left' }}>
            {loss.lines.map((x, i) => <div key={i}>— {x}</div>)}
          </div>
          {loss.estOk != null && (
            <div className="hint" style={{ marginTop: 8 }}>
              {loss.estOk
                ? <>✅ Ваша оценка ({loss.estBandLabel}) верна: <b style={{ color: '#a8d0a0' }}>+{loss.estReward} ₽</b></>
                : <>Оценка ({loss.estBandLabel}) мимо: правда была {E.bandLabel(E.bandOf(lot.trueValue))}</>}
            </div>
          )}
          <div className="btn-row" style={{ marginTop: 14, justifyContent: 'flex-start' }}>
            <Btn big onClick={() => game.lossContinue()}>Следующий лот →</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
