/* CityMap.tsx — город «Лавки»: диорама в единой перспективе (1-point, камера чуть сверху).
   Слои: небо/дальний план с ориентирами → верхняя улица и дальний ряд → средний ряд с
   дворами → рыночная площадь и переулки → главный ряд (лавка-герой) → улица с движением →
   ближний тротуар с горожанами → передний план. Свет: низкое вечернее солнце слева.
   Desktop 1600×900 и portrait 800×1400 — две самостоятельные композиции. */
import React from 'react';
import {
  CityDefs, proj, VP, StreetLamp, Tree, Bench, Bin, Bike, Car, Truck, Crate, Barrel, Mailbox,
  PosterCol, Stall, Fountain, Fence, Hedge, Manhole, Puddle, Cat, Bird, Chimney, Wires, Pole,
  WaterTower, Factory, ClockTower, GroundShadow, DirShadow,
} from './kit';
import { Person, Walker } from './people';
import {
  ShopBld, PartsBld, GarageBld, WarehouseBld, EstateBld, BakeryBld, ClosedShopBld,
  ClockmakerBld, HouseBld, ApartmentBld, ShedBld, KioskBld,
} from './buildings';

export interface CityAnchor { id: string; x: number; y: number; }
export function cityAnchors(portrait: boolean): CityAnchor[] {
  return portrait
    ? [{ id: 'shop', x: 270, y: 980 }, { id: 'parts', x: 105, y: 800 }, { id: 'city_warehouse', x: 560, y: 860 },
    { id: 'garage', x: 680, y: 760 }, { id: 'estate', x: 655, y: 690 }]
    : [{ id: 'shop', x: 450, y: 612 }, { id: 'parts', x: 150, y: 606 }, { id: 'city_warehouse', x: 905, y: 600 },
    { id: 'garage', x: 1495, y: 610 }, { id: 'estate', x: 1245, y: 584 }];
}

/* клин улицы, уходящий к точке схода */
function StreetWedge({ x1, x2, y1, y2, vp, fill }: { x1: number; x2: number; y1: number; y2: number; vp: VP; fill: string }) {
  const k = (y2 - vp[1]) / (y1 - vp[1]);
  const [bx1] = proj(x1, y2, k, vp), [bx2] = proj(x2, y2, k, vp);
  return <polygon points={`${x1},${y1} ${x2},${y1} ${bx2},${y2} ${bx1},${y2}`} fill={fill} />;
}
function Crosswalk({ x, y, w, vp, hgt = 82 }: { x: number; y: number; w: number; vp: VP; hgt?: number }) {
  const k = (y - hgt - vp[1]) / (y - vp[1]);
  return <g opacity=".45">{Array.from({ length: 6 }).map((_, i) => {
    const sx = x + (i + .18) * (w / 6), sw = w / 6 * .56;
    const [tx] = proj(sx, y - hgt, k, vp), [tx2] = proj(sx + sw, y - hgt, k, vp);
    return <polygon key={i} points={`${sx},${y} ${sx + sw},${y} ${tx2},${y - hgt} ${tx},${y - hgt}`} fill="#d8ccb0" />;
  })}</g>;
}
/* ветка-передний план */
function Branch({ dx = 0, dy = 0, s = 1, flip = false }: { dx?: number; dy?: number; s?: number; flip?: boolean }) {
  return <g transform={`translate(${dx} ${dy}) scale(${flip ? -s : s} ${s})`} opacity=".96">
    <path d="M-30 20 q150 34 250 104 q64 44 92 100" stroke="#2f3d26" strokeWidth="13" fill="none" strokeLinecap="round" />
    {[[70, 66], [140, 92], [206, 126], [262, 164], [312, 210], [104, 44], [180, 72], [240, 108],
      [46, 52], [92, 78], [160, 106], [224, 140], [286, 182], [128, 60], [196, 90], [258, 128], [330, 226], [86, 96], [150, 122]].map(([x, y], i) =>
      <path key={i} d={`M${x} ${y} q${14 + (i % 3) * 4} -${14 + (i % 2) * 6} ${30 + (i % 3) * 6} -${6 + (i % 2) * 3} q-${5 + (i % 2) * 3} ${18 + (i % 3) * 4} -${22 + (i % 3) * 5} ${15 + (i % 2) * 3} q-${8} -1 -${8} -${9 + (i % 2) * 3}z`} fill={i % 3 ? '#3a4a2c' : i % 2 ? '#46582f' : '#51653a'}
        className="leaf-sway" style={{ animationDelay: `${(i % 7) * .45}s`, transformOrigin: `${x}px ${y}px` }} />)}
    <path d="M120 78 q60 8 108 40" stroke="#2f3d26" strokeWidth="6" fill="none" strokeLinecap="round" />
  </g>;
}
function SidewalkBoard({ x, y, text, hidden }: { x: number; y: number; text: string; hidden?: boolean }) {
  return <g className="ui-label" transform={`translate(${x} ${y})`} opacity={hidden ? .55 : 1}>
    <path d="M-20 0 l4 -26 M20 0 l-4 -26" stroke="#3a2c1d" strokeWidth="3" />
    <g transform="rotate(-2)">
      <rect x="-30" y="-26" width="60" height="20" rx="3" fill="#241a12" stroke="#57432c" strokeWidth="1.4" />
      <text textAnchor="middle" y="-12" fontSize="10.5" fontFamily="Georgia, serif" fill={hidden ? '#9a8c74' : '#f2d788'} fontWeight="bold">{text}</text>
    </g>
  </g>;
}
const Laundry = ({ x, y }: { x: number; y: number }) => <g transform={`translate(${x} ${y})`}>
  <path d="M0 0 v-34 M86 0 v-34" stroke="#5c4f38" strokeWidth="3.4" />
  <path d="M0 -32 q43 8 86 0" stroke="#3a3226" strokeWidth="1.6" fill="none" />
  {[12, 34, 56].map((dx, i) => <path key={dx} d={`M${dx} -30 q6 12 0 18 q-6 -6 0 -18z`} fill={['#c8b898', '#b5533c', '#8aa0b0'][i]} transform={`rotate(${i * 3 - 3} ${dx} -30)`} />)}
</g>;

/* ============================== DESKTOP ============================== */
export function CityMapDesktop({ lockedIds, vp = [800, 415] }: { lockedIds: Set<string>; vp?: VP }) {
  const L = (id: string) => lockedIds.has(id);
  const bld = (id: string, el: React.ReactNode) =>
    <g className={`building ${L(id) ? 'locked' : ''}`} data-id={id}>{el}</g>;
  return <g>
    <CityDefs />
    {/* ===== небо ===== */}
    <rect width="1600" height="900" fill="url(#c-sky)" />
    <circle cx="240" cy="118" r="160" fill="url(#c-sun)" />
    <circle cx="240" cy="118" r="42" fill="#fff6cc" opacity=".95" />
    <g className="cloud" style={{ animationDuration: '95s' }} opacity=".75">
      <ellipse cx="430" cy="86" rx="74" ry="18" fill="#fff" opacity=".7" /><ellipse cx="484" cy="74" rx="46" ry="13" fill="#fff" opacity=".65" />
    </g>
    <g className="cloud" style={{ animationDuration: '135s', animationDelay: '-70s' }} opacity=".6">
      <ellipse cx="1060" cy="64" rx="88" ry="18" fill="#fff" opacity=".65" /><ellipse cx="1122" cy="52" rx="48" ry="12" fill="#fff" opacity=".6" />
    </g>
    <g className="cloud" style={{ animationDuration: '115s', animationDelay: '-30s' }} opacity=".55">
      <ellipse cx="1430" cy="104" rx="62" ry="14" fill="#fff" opacity=".65" />
    </g>
    <g transform="translate(0 -40)">
    <g className="cw" style={{ animationName: 'cwR', animationDuration: '120s', animationDelay: '-30s', ['--from' as any]: '-120px', ['--to' as any]: '1720px' }}>
      <g transform="translate(0 210)"><path d="M0 0 q6 -6 12 0 q-6 -2 -12 0z M22 -8 q5 -5 10 0 q-5 -2 -10 0z M40 4 q5 -5 10 0 q-5 -2 -10 0z" fill="#5d6a74" opacity=".7" /></g>
    </g>
    {/* ===== дальний город + ориентиры ===== */}
    <g opacity=".5" fill="#7c8c9c">
      <path d="M0 368 h44 v-13 h30 l10 -12 10 12 h26 v-17 h34 l12 -14 12 14 h30 v-10 h44 l8 -10 8 10 h36 v-15 h30 l10 -12 10 12 h40 v-8 h48 l10 -12 10 12 h34 v-14 h28 l9 -11 9 11 h38 v-9 h44 l10 -12 10 12 h32 v-15 h30 l10 -12 10 12 h40 v-8 h46 l9 -11 9 11 h36 v-13 h30 l10 -12 10 12 h44 v-9 h40 l10 -12 10 12 h34 v60 H0z" />
      <path d="M180 342 l10 -44 10 44z M1240 332 l12 -52 12 52z" />
      <rect x="520" y="330" width="8" height="26" /><rect x="980" y="324" width="7" height="24" />
    </g>
    <WaterTower x={215} y={382} s={.95} />
    <Factory x={1345} y={388} s={1} />
    <g opacity=".32" fill="#64788a">
      <path d="M0 402 h80 v-10 h60 v-8 h70 v-12 h56 v-6 h80 v-10 h64 v-8 h72 v-12 h58 v-6 h80 v-10 h66 v-8 h70 v-12 h60 v-6 h78 v-10 h64 v74 H0z" />
    </g>
    <rect y="306" width="1600" height="160" fill="url(#c-haze)" />
    {/* ===== земля: склон, верхняя улица, дальний ряд ===== */}
    <path d="M0 412 q800 -26 1600 -10 v90 H0z" fill="#93a468" />
    <path d="M0 440 q800 -22 1600 -8 v60 H0z" fill="#84955c" />
    <g opacity=".94">
      <HouseBld x={140} y={450} s={.4} v={1} vp={vp} /><ApartmentBld x={322} y={444} s={.36} vp={vp} />
      <HouseBld x={472} y={450} s={.38} v={2} vp={vp} /><ClockTower x={706} y={454} s={.78} />
      <HouseBld x={884} y={448} s={.38} v={0} vp={vp} /><HouseBld x={1032} y={450} s={.4} v={2} vp={vp} />
      <ApartmentBld x={1182} y={444} s={.36} vp={vp} /><HouseBld x={1332} y={450} s={.38} v={1} vp={vp} />
      <HouseBld x={1482} y={446} s={.4} v={0} vp={vp} />
      <Tree x={248} y={452} s={.42} tone={1} /><Tree x={960} y={452} s={.4} tone={2} /><Tree x={1420} y={452} s={.42} />
    </g>
    <path d="M0 452 q800 -20 1600 -8 v14 q-800 -14 -1600 10z" fill="#d2c09a" opacity=".85" />
    <path d="M0 466 q800 -18 1600 -8 v22 H0z" fill="#8d8474" opacity=".9" />
    <Car x={392} y={482} s={.5} col="#8a4a3c" /><Car x={1108} y={480} s={.48} col="#6e7f8a" flip />
    <Walker v={4} y={464} s={.5} mode="slow" dur={95} delay={-30} from={-60} to={1660} />
    <Walker v={7} y={462} s={.48} mode="cross" dur={70} delay={-52} from={1660} to={-60} />
    {/* ===== средний ряд с дворами ===== */}
    <path d="M0 488 q800 -16 1600 -6 v120 H0z" fill="#aa9878" />
    <path d="M0 488 q800 -16 1600 -6 v8 q-800 -12 -1600 8z" fill="#d2c09a" opacity=".75" />
    <KioskBld x={70} y={512} s={.58} vp={vp} />
    <BakeryBld x={250} y={514} s={.62} vp={vp} />
    <ClockmakerBld x={322} y={506} s={.56} vp={vp} />
    <HouseBld x={524} y={500} s={.5} v={1} vp={vp} />
    <ApartmentBld x={1040} y={504} s={.55} vp={vp} />
    <HouseBld x={1122} y={498} s={.5} v={2} vp={vp} />
    <ShedBld x={1362} y={504} s={.62} vp={vp} />
    <HouseBld x={700} y={470} s={.42} v={0} vp={vp} />
    <ClosedShopBld x={600} y={502} s={.55} vp={vp} />
    <Fence x={120} y={518} n={6} s={.6} /><Fence x={300} y={520} n={5} s={.6} col="#7a6a4c" />
    <Hedge x={452} y={508} w={70} s={.6} /><Hedge x={1180} y={510} w={80} s={.6} />
    <Laundry x={430} y={510} /><Laundry x={1150} y={504} />
    <Tree x={600} y={508} s={.5} tone={2} /><Tree x={980} y={510} s={.46} /><Tree x={1240} y={504} s={.5} tone={1} />
    <Barrel x={1210} y={508} s={.6} /><Crate x={60} y={516} s={.6} />
    {/* ===== улица: мостовая, тротуары, площадкa ===== */}
    <StreetWedge x1={596} x2={864} y1={656} y2={588} vp={vp} fill="#9a8c72" />
    <polygon points="640,592 840,592 828,498 688,498" fill="#b8a888" />
    <polygon points="640,592 840,592 836,560 646,560" fill="#c2b292" opacity=".8" />
    {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M${652 + i * 40} 590 l6 -90`} stroke="#9a8c72" strokeWidth="2" opacity=".5" />)}
    <StreetWedge x1={1332} x2={1412} y1={656} y2={546} vp={vp} fill="#8a7c62" />
    <Bin x={1352} y={624} s={.7} /><Bin x={1368} y={602} s={.6} /><Crate x={1394} y={612} s={.62} />
    <StreetWedge x1={-40} x2={48} y1={656} y2={554} vp={vp} fill="#8a7c62" />
    <path d="M0 616 h1600 v124 H0z" fill="url(#c-road)" />
    <path d="M0 616 h1600 v7 H0z" fill="#b0a288" />
    {Array.from({ length: 6 }).map((_, r) => <path key={r} d={`M0 ${636 + r * 17} h1600`} stroke="#5d554a" strokeWidth="1.8" opacity=".4" />)}
    {Array.from({ length: 40 }).map((_, i) => <path key={i} d={`M${i * 41 + (i % 2) * 20} 624 l-3 110`} stroke="#5d554a" strokeWidth="1.4" opacity=".22" />)}
    <path d="M0 660 h1600 v20 H0z" fill="#9a9082" opacity=".35" />
    <path d="M0 731 h1600 v9 H0z" fill="#4a4438" opacity=".22" />
    <path d="M0 630 h1600" stroke="#d8ccb0" strokeWidth="2.2" opacity=".4" strokeDasharray="26 34" />
    {[[180, 652], [260, 686], [640, 670], [760, 694], [1120, 656], [1240, 688], [1420, 664], [880, 642], [500, 696], [1020, 680]].map(([x, y], i) =>
      <ellipse key={i} cx={x} cy={y} rx={5 + (i % 3) * 3} ry={2 + (i % 2)} fill="#57504a" opacity=".3" />)}
    <Manhole x={352} y={674} s={.9} /><Manhole x={1180} y={668} s={.85} />
    <g className="smoke-puff" style={{ animationDelay: '.5s' }}><circle cx="1180" cy="654" r="8" fill="#e8e0cc" opacity=".45" /></g>
    <g className="smoke-puff" style={{ animationDelay: '1.9s' }}><circle cx="1186" cy="648" r="6" fill="#e8e0cc" opacity=".36" /></g>
    <Puddle x={960} y={698} rx={70} ry={8} />
    <path d="M700 618 h26 v6 h-26z M1300 618 h26 v6 h-26z" fill="#3a3630" opacity=".7" />
    <Crosswalk x={602} y={702} w={256} vp={vp} hgt={70} />
    {/* ближний тротуар и передний газон */}
    <path d="M0 740 h1600 v116 H0z" fill="url(#c-walk)" />
    <path d="M0 740 h1600 v6 H0z" fill="#d8ccb0" opacity=".85" />
    {Array.from({ length: 26 }).map((_, i) => <path key={i} d={`M${i * 64} 746 l-6 104`} stroke="#9a8c72" strokeWidth="2" opacity=".35" />)}
    <path d="M0 856 h1600 v96 H0z" fill="#60804c" />
    {Array.from({ length: 10 }).map((_, i) => <path key={i} d={`M${i * 160 + 40} 856 h80 v96 h-80z`} fill="#6b8a56" opacity=".26" />)}
    <path d="M0 924 h1600 v40 H0z" fill="#4f6b42" opacity=".5" />
    <path d="M0 856 h1600 v5 H0z" fill="#b0a288" />
    {Array.from({ length: 46 }).map((_, i) => <path key={i} d={`M${i * 36 + (i % 3) * 6} 860 q2 -9 5 -11 M${i * 36 + 8} 860 q-1 -7 -4 -9`} stroke="#46582f" strokeWidth="2" fill="none" />)}
    {Array.from({ length: 30 }).map((_, i) => <path key={i} d={`M${i * 54 + (i % 4) * 7} 926 q2 -10 6 -12 M${i * 54 + 10} 926 q-1 -8 -5 -10`} stroke="#3f5229" strokeWidth="2" fill="none" />)}
    {[[140, 862], [520, 866], [1080, 864]].map(([x, y], i) => <g key={i} transform={`translate(${x} ${y})`}>
      <circle r="3" fill={['#d9784a', '#c8b898', '#b5533c'][i]} /><circle cx="5" cy="2" r="2.4" fill="#e8c9a8" /></g>)}
    {[[220, 932], [610, 938], [980, 930], [1380, 936]].map(([x, y], i) => <g key={i} transform={`translate(${x} ${y})`}>
      <circle r="2.6" fill={['#e8c9a8', '#d9784a', '#c8b898', '#b5533c'][i]} /><circle cx="4" cy="2" r="2" fill="#efe3cc" /></g>)}
    {/* ===== рыночная площадь (композиционный центр) ===== */}
    <Fountain x={700} y={534} s={.78} />
    <Stall x={636} y={552} s={.7} /><Stall x={762} y={544} s={.64} col="#4f6a6a" />
    <PosterCol x={600} y={560} s={.72} />
    <g transform="translate(654 560) scale(.62)"><Person v={2} pose="stand" /></g>
    <g transform="translate(746 552) scale(.6)"><Person v={5} pose="stand" flip /></g>
    <g transform="translate(726 568) scale(.55)"><Person v={1} pose="look" /></g>
    <g className="flag-wave" style={{ transformOrigin: '700px 492px' }}>
      <path d="M600 506 q100 22 186 2" stroke="#3a3226" strokeWidth="1.8" fill="none" />
      {Array.from({ length: 9 }).map((_, i) => {
        const t = (i + .5) / 9, x = 600 + t * 186, y = 506 + Math.sin(t * Math.PI) * 17;
        return <path key={i} d={`M${x} ${y} l5 12 l-10 0z`} fill={['#b5533c', '#d9b23f', '#4f6a6a'][i % 3]} />;
      })}
    </g>
    {/* ===== главный ряд ===== */}
    {bld('estate', <EstateBld x={1245} y={624} s={.82} locked={L('estate')} vp={vp} />)}
    {bld('city_warehouse', <WarehouseBld x={905} y={640} s={.96} locked={L('city_warehouse')} vp={vp} />)}
    {bld('parts', <PartsBld x={150} y={646} s={.82} locked={L('parts')} vp={vp} />)}
    {bld('garage', <GarageBld x={1495} y={650} s={.88} locked={L('garage')} vp={vp} />)}
    {bld('shop', <ShopBld x={450} y={652} s={1.06} locked={L('shop')} vp={vp} />)}
    {!L('shop') && <ellipse cx="498" cy="654" rx="46" ry="9" fill="#ffd98a" opacity=".2" />}
    {!L('city_warehouse') && <ellipse cx="905" cy="642" rx="52" ry="9" fill="#ffd98a" opacity=".16" />}
    {!L('parts') && <ellipse cx="186" cy="648" rx="36" ry="8" fill="#ffd98a" opacity=".16" />}
    {/* ===== утварь дальнего тротуара ===== */}
    <Pole x={320} y={650} s={.95} /><Pole x={1105} y={642} s={.9} />
    <Wires x1={320} y1={450} x2={1105} y2={444} sag={22} birds={4} />
    <Wires x1={1105} y1={444} x2={1600} y2={462} sag={18} birds={0} />
    <StreetLamp x={620} y={648} s={.9} /><StreetLamp x={1080} y={640} s={.86} />
    <Bike x={368} y={652} s={.9} />
    <g transform="translate(392 652) scale(.9)"><Person v={3} pose="look" /></g>
    <g transform="translate(852 634) scale(.88)"><Person v={6} pose="carry" /></g>
    <g transform="translate(1424 648) scale(.9)"><Person v={4} pose="crouch" /></g>
    <Cat x={536} y={656} s={.9} />
    <Walker v={2} y={650} s={.78} mode="cross" dur={62} delay={-18} />
    <Walker v={6} y={646} s={.72} mode="alt" dur={88} delay={-60} from={420} to={1240} />
    </g>
    {/* ===== транспорт ===== */}
    <Car x={520} y={642} s={.9} col="#6e7f8a" /><Car x={1052} y={638} s={.85} col="#8a4a3c" flip />
    <g className="cw-truck" style={{ animationDelay: '-18s' }}><g transform="translate(0 692) scale(1.02)"><Truck x={0} y={0} col="#8a6a48" /></g></g>
    <Bird x={690} y={702} i={0} />
    {/* штендеры-указатели у входов (diegetic-маркеры) */}
    <SidewalkBoard x={512} y={628} text="Ваша лавка" hidden={L('shop')} />
    <SidewalkBoard x={204} y={622} text="Запчасти" hidden={L('parts')} />
    <SidewalkBoard x={962} y={616} text="Аукцион" hidden={L('city_warehouse')} />
    <SidewalkBoard x={1300} y={600} text="Усадьба" hidden={L('estate')} />
    <SidewalkBoard x={1536} y={626} text="Гараж" hidden={L('garage')} />
    {/* ===== ближний тротуар: жизнь ===== */}
    {/* вечернее солнце слева: длинные тени вправо от утвари */}
    <DirShadow x={180} y={818} w={10} len={64} /><DirShadow x={980} y={814} w={10} len={60} />
    <DirShadow x={430} y={816} w={62} len={46} /><DirShadow x={488} y={818} w={16} len={26} />
    <DirShadow x={1244} y={812} w={14} len={30} /><DirShadow x={704} y={820} w={18} len={34} />
    <DirShadow x={1180} y={814} w={40} len={74} /><DirShadow x={620} y={814} w={36} len={66} />
    <DirShadow x={1330} y={816} w={40} len={40} /><DirShadow x={1420} y={816} w={62} len={46} />
    <DirShadow x={46} y={828} w={100} len={40} /><DirShadow x={760} y={822} w={22} len={18} o={.4} />
    <path d="M268 754 q8 16 2 30 q-5 12 3 26 M1046 760 q-7 14 -1 28 q5 10 -2 22" stroke="#8a7c62" strokeWidth="1.6" fill="none" opacity=".5" />
    {[[320, 800, 24], [700, 806, -40], [934, 796, 70], [1298, 802, 12], [566, 792, -24], [1120, 806, 48]].map(([x, y, r], i) =>
      <path key={i} d={`M${x} ${y} q4 -3 8 0 q-4 3 -8 0z`} fill={i % 2 ? '#7a6a3c' : '#8a5a34'} opacity=".55" transform={`rotate(${r} ${x} ${y})`} />)}
    <StreetLamp x={180} y={816} s={1.05} /><StreetLamp x={980} y={812} s={1.02} />
    <Bench x={430} y={814} /><g transform="translate(424 806) scale(.95)"><Person v={7} pose="sit" /></g>
    <Bin x={488} y={816} /><Mailbox x={1244} y={810} /><PosterCol x={704} y={818} s={.95} />
    <Tree x={1180} y={812} s={1} tone={1} />
    <Hedge x={40} y={826} w={110} s={.9} />
    <Bike x={1330} y={814} s={1} col="#4f6a6a" />
    <g transform="translate(536 816)"><Person v={0} pose="sweep" /></g>
    <Cat x={760} y={820} s={1} col="#7a6a4c" />
    <Tree x={620} y={812} s={.95} tone={2} />
    <Bench x={1420} y={814} flip />
    <g transform="translate(1160 812) scale(.98)"><Person v={1} pose="stand" /></g>
    <g transform="translate(860 818) scale(.8)"><Person v={2} pose="look" /></g>
    <Mailbox x={640} y={816} />
    <Walker v={0} y={814} s={1.12} mode="cross" dur={48} />
    <Walker v={3} y={818} s={1.18} mode="alt" dur={72} delay={-24} from={240} to={1420} />
    <Walker v={5} y={810} s={1.04} mode="slow" dur={80} delay={-46} />
    {/* ===== передний план ===== */}
    <Tree x={92} y={896} s={1.75} tone={0} />
    <StreetLamp x={1566} y={924} s={1.65} />
    <g transform="translate(1716 906) scale(1.85)"><Car x={0} y={0} col="#5a5f7a" flip /></g>
    <Branch dx={-20} dy={-6} s={1.05} />
    <rect y="872" width="1600" height="28" fill="#241a10" opacity=".14" pointerEvents="none" />
    <rect width="1600" height="900" fill="url(#c-dusk)" pointerEvents="none" />
  </g>;
}

/* ============================== PORTRAIT ============================== */
export function CityMapPortrait({ lockedIds, vp = [400, 470] }: { lockedIds: Set<string>; vp?: VP }) {
  const L = (id: string) => lockedIds.has(id);
  const bld = (id: string, el: React.ReactNode) =>
    <g className={`building ${L(id) ? 'locked' : ''}`} data-id={id}>{el}</g>;
  return <g>
    <CityDefs />
    <rect width="800" height="1400" fill="url(#c-sky)" />
    <circle cx="240" cy="196" r="150" fill="url(#c-sun)" />
    <circle cx="240" cy="196" r="38" fill="#fff6cc" opacity=".95" />
    <g className="cloud" style={{ animationDuration: '100s' }} opacity=".7">
      <ellipse cx="300" cy="130" rx="64" ry="17" fill="#fff" opacity=".7" /><ellipse cx="350" cy="120" rx="40" ry="12" fill="#fff" opacity=".6" />
    </g>
    <g className="cloud" style={{ animationDuration: '140s', animationDelay: '-60s' }} opacity=".55">
      <ellipse cx="620" cy="96" rx="70" ry="16" fill="#fff" opacity=".6" />
    </g>
    <g transform="translate(0 -70)">
    <g className="cw" style={{ animationName: 'cwR', animationDuration: '110s', animationDelay: '-40s', ['--from' as any]: '-100px', ['--to' as any]: '900px' }}>
      <g transform="translate(0 250)"><path d="M0 0 q6 -6 12 0 q-6 -2 -12 0z M22 -8 q5 -5 10 0 q-5 -2 -10 0z M40 4 q5 -5 10 0 q-5 -2 -10 0z" fill="#5d6a74" opacity=".7" /></g>
    </g>
    {/* дальний план */}
    <g opacity=".5" fill="#7c8c9c">
      <path d="M0 512 l40 -8 26 -22 20 18 34 -10 26 16 44 -26 22 20 38 -8 30 14 50 -20 26 18 42 -12 34 14 50 -18 28 16 44 -12 34 14 50 -16 34 12 v50 H0z" />
    </g>
    <WaterTower x={118} y={522} s={.8} /><Factory x={668} y={518} s={.85} />
    <rect y="470" width="800" height="100" fill="url(#c-haze)" />
    <path d="M0 552 q400 -20 800 -8 v80 H0z" fill="#93a468" />
    <path d="M0 578 q400 -18 800 -6 v56 H0z" fill="#84955c" />
    <g opacity=".94">
      <HouseBld x={118} y={592} s={.42} v={1} vp={vp} /><ApartmentBld x={292} y={586} s={.4} vp={vp} />
      <ClockTower x={408} y={596} s={.8} />
      <HouseBld x={524} y={592} s={.42} v={2} vp={vp} /><HouseBld x={684} y={588} s={.4} v={0} vp={vp} />
      <Tree x={210} y={594} s={.42} tone={1} /><Tree x={600} y={594} s={.4} />
    </g>
    <rect y="452" width="800" height="150" fill="url(#c-haze)" />
    <path d="M0 596 q400 -16 800 -6 v12 q-400 -12 -800 10z" fill="#c9b995" opacity=".8" />
    <path d="M0 608 q400 -14 800 -6 v20 H0z" fill="#8d8474" opacity=".85" />
    <Walker v={4} y={606} s={.5} mode="slow" dur={90} delay={-20} from={-50} to={850} />
    {/* средний ряд */}
    <path d="M0 628 q400 -12 800 -4 v110 H0z" fill="#a89878" />
    <BakeryBld x={108} y={670} s={.6} vp={vp} /><ClockmakerBld x={248} y={664} s={.55} vp={vp} />
    <ClosedShopBld x={584} y={666} s={.58} vp={vp} /><ShedBld x={694} y={670} s={.6} vp={vp} />
    <Fence x={30} y={678} n={5} s={.6} /><Hedge x={300} y={672} w={60} s={.6} /><Hedge x={630} y={676} w={60} s={.6} />
    <Tree x={330} y={672} s={.5} tone={2} /><Tree x={500} y={676} s={.46} />
    <Laundry x={150} y={676} />
    </g>
    {/* земля главного ряда */}
    <path d="M0 668 q400 -8 800 -2 v330 H0z" fill="#b0a084" />
    <path d="M0 668 q400 -8 800 -2 v7 q-400 -6 -800 8z" fill="#c9b995" opacity=".6" />
    <StreetWedge x1={384} x2={462} y1={990} y2={760} vp={vp} fill="#9a8c72" />
    <Crosswalk x={386} y={1046} w={76} vp={vp} hgt={52} />
    {/* площадь */}
    <StreetWedge x1={330} x2={500} y1={760} y2={700} vp={vp} fill="#9a8c72" />
    <polygon points="300,704 520,704 508,624 330,624" fill="#b8a888" />
    <Fountain x={414} y={656} s={.7} />
    <Stall x={352} y={668} s={.62} /><PosterCol x={474} y={664} s={.62} />
    <g transform="translate(372 672) scale(.58)"><Person v={2} pose="stand" /></g>
    <g transform="translate(452 668) scale(.56)"><Person v={5} pose="look" flip /></g>
    {/* главный ряд */}
    {bld('estate', <EstateBld x={655} y={690} s={.5} locked={L('estate')} vp={vp} />)}
    {bld('garage', <GarageBld x={700} y={760} s={.62} locked={L('garage')} vp={vp} />)}
    {bld('parts', <PartsBld x={105} y={800} s={.68} locked={L('parts')} vp={vp} />)}
    {bld('city_warehouse', <WarehouseBld x={560} y={860} s={.85} locked={L('city_warehouse')} vp={vp} />)}
    {bld('shop', <ShopBld x={270} y={980} s={1.05} locked={L('shop')} vp={vp} />)}
    {!L('shop') && <ellipse cx="318" cy="982" rx="48" ry="9" fill="#ffd98a" opacity=".2" />}
    {/* props */}
    <Pole x={140} y={952} s={1.15} /><Pole x={660} y={940} s={1.1} />
    <Wires x1={140} y1={716} x2={660} y2={708} sag={20} birds={3} />
    <StreetLamp x={430} y={952} s={.85} />
    <g transform="translate(212 976) scale(.92)"><Person v={3} pose="look" /></g>
    <g transform="translate(516 868) scale(.84)"><Person v={6} pose="carry" /></g>
    <g transform="translate(648 768) scale(.7)"><Person v={4} pose="crouch" /></g>
    <Cat x={352} y={978} s={.9} />
    {/* улица */}
    <path d="M0 990 h800 v130 H0z" fill="url(#c-road)" />
    <path d="M0 990 h800 v7 H0z" fill="#b0a288" />
    {Array.from({ length: 6 }).map((_, r) => <path key={r} d={`M0 ${1012 + r * 18} h800`} stroke="#5d554a" strokeWidth="1.8" opacity=".4" />)}
    {Array.from({ length: 22 }).map((_, i) => <path key={i} d={`M${i * 38 + (i % 2) * 19} 998 l-3 116`} stroke="#5d554a" strokeWidth="1.4" opacity=".22" />)}
    <Manhole x={300} y={1064} s={.9} /><Puddle x={560} y={1092} rx={64} ry={10} />
    <path d="M0 1112 h800 v8 H0z" fill="#4a4438" opacity=".22" />
    <Crosswalk x={372} y={1112} w={104} vp={vp} hgt={110} />
    <Car x={680} y={1016} s={.9} col="#6e7f8a" />
    <g className="cw-truck" style={{ ['--from' as any]: '-260px', ['--to' as any]: '1060px', animationDuration: '46s', animationDelay: '-12s' }}><g transform="translate(0 1082) scale(1.05)"><Truck x={0} y={0} col="#8a6a48" /></g></g>
    {/* ближний тротуар */}
    <path d="M0 1120 h800 v90 H0z" fill="url(#c-walk)" />
    <path d="M0 1120 h800 v6 H0z" fill="#d8ccb0" opacity=".8" />
    {Array.from({ length: 14 }).map((_, i) => <path key={i} d={`M${i * 60} 1126 l-6 78`} stroke="#9a8c72" strokeWidth="2" opacity=".5" />)}
    {/* вечернее солнце слева: длинные тени вправо */}
    <DirShadow x={150} y={1170} w={10} len={58} /><DirShadow x={606} y={1162} w={10} len={54} />
    <DirShadow x={352} y={1174} w={60} len={44} /><DirShadow x={408} y={1176} w={16} len={24} />
    <DirShadow x={508} y={1178} w={18} len={32} /><DirShadow x={212} y={1172} w={40} len={38} />
    {[[120, 1160, 20], [440, 1166, -30], [660, 1158, 55], [260, 1152, -15]].map(([x, y, r], i) =>
      <path key={i} d={`M${x} ${y} q4 -3 8 0 q-4 3 -8 0z`} fill={i % 2 ? '#7a6a3c' : '#8a5a34'} opacity=".55" transform={`rotate(${r} ${x} ${y})`} />)}
    <StreetLamp x={150} y={1168} s={1.05} /><StreetLamp x={606} y={1160} s={1} />
    <Bench x={352} y={1172} /><Bin x={408} y={1174} /><PosterCol x={508} y={1176} s={.95} />
    <Bike x={212} y={1170} s={1} />
    <g transform="translate(300 1176)"><Person v={0} pose="sweep" /></g>
    <Walker v={1} y={1170} s={1.12} mode="cross" dur={44} from={-70} to={870} />
    <Walker v={6} y={1176} s={1.16} mode="alt" dur={66} delay={-18} from={500} to={740} />
    <Walker v={2} y={1002} s={.76} mode="cross" dur={58} delay={-30} from={-60} to={860} />
    {/* передний план */}
    <path d="M0 1210 h800 v190 H0z" fill="#60804c" />
    {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M${i * 160 + 30} 1210 h80 v190 h-80z`} fill="#6b8a56" opacity=".26" />)}
    <path d="M0 1330 h800 v70 H0z" fill="#4f6b42" opacity=".45" />
    <path d="M0 1210 h800 v5 H0z" fill="#b0a288" />
    {Array.from({ length: 26 }).map((_, i) => <path key={i} d={`M${i * 32 + (i % 3) * 5} 1214 q2 -9 5 -11 M${i * 32 + 8} 1214 q-1 -7 -4 -9`} stroke="#46582f" strokeWidth="2" fill="none" />)}
    <DirShadow x={64} y={1272} w={60} len={90} /><DirShadow x={742} y={1256} w={12} len={70} />
    <DirShadow x={620} y={1288} w={66} len={50} /><DirShadow x={180} y={1294} w={110} len={44} /><DirShadow x={470} y={1304} w={130} len={48} />
    <Tree x={64} y={1268} s={1.5} tone={0} />
    <StreetLamp x={742} y={1252} s={1.35} />
    <Hedge x={180} y={1290} w={120} s={1.1} /><Hedge x={470} y={1300} w={140} s={1.2} />
    <Cat x={360} y={1286} s={1.1} col="#5d584c" />
    {[[240, 1284], [420, 1292], [560, 1286], [660, 1296]].map(([x, y], i) => <g key={i} transform={`translate(${x} ${y})`}>
      <circle r="3.4" fill={['#d9784a', '#c8b898', '#b5533c', '#e8c9a8'][i]} /><circle cx="6" cy="2" r="2.6" fill="#e8c9a8" /></g>)}
    <Bench x={620} y={1284} s={1.1} />
    <g transform="translate(842 1338) scale(1.55)"><Car x={0} y={0} col="#5a5f7a" flip /></g>
    <Branch dx={-16} dy={-4} s={.9} />
    <rect y="1352" width="800" height="48" fill="#241a10" opacity=".14" pointerEvents="none" />
    <rect width="800" height="1400" fill="url(#c-dusk)" pointerEvents="none" />
  </g>;
}
