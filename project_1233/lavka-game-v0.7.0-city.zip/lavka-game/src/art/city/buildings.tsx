/* buildings.tsx — здания города: коробки в единой перспективе, разные арх. характеры.
   Локальные координаты фасада: (0,0) — центр основания, вверх = −y. */
import React from 'react';
import { boxGeom, Shell, LongShadow, Win, Door, SignBoard, SignMast, Chimney, WinV, GroundShadow, VP } from './kit';

export interface BldProps { x: number; y: number; s?: number; locked?: boolean; vp?: VP; }

/* оболочка: тень → боковина/крыша → фасад с материалом → тёплый свет.
   Рисуется в локальных координатах обёртки здания; точка схода сцены
   пересчитывается в локальную, поэтому перспектива едина для всей карты. */
export function BldShell({ x, y, w, h, d = 26, face, side, roof, roofLit, type = 'hip', rh = 26, tex = 'plaster', s = 1, vp }: {
  x: number; y: number; w: number; h: number; d?: number; face: string; side: string; roof: string; roofLit?: string;
  type?: 'flat' | 'hip' | 'gable'; rh?: number; tex?: TexKind; s?: number; vp?: VP;
}) {
  const V: VP = vp || [800, 415];
  const vplx = (V[0] - x) / s;
  const g = boxGeom(0, 0, w, h, d, vplx);
  return <g>
    <LongShadow x={0} y={0} w={w} h={h} />
    <Shell g={g} sideCol={side} roofCol={roof} roofLit={roofLit} type={type} rh={rh} />
    <rect x={g.x1} y={g.yt} width={g.x2 - g.x1} height={g.yb - g.yt} fill={face} />
    {type === 'gable' && <polygon points={`${g.x1},${g.yt} ${g.x2},${g.yt} ${(g.x1 + g.x2) / 2},${g.yt - rh + 2}`} fill={face} />}
    {type === 'gable' && <polygon points={`${g.x1},${g.yt} ${g.x2},${g.yt} ${(g.x1 + g.x2) / 2},${g.yt - rh + 2}`} fill="url(#c-facadewarm)" />}
    <Tex kind={tex} x1={g.x1} yt={g.yt} w={g.x2 - g.x1} h={g.yb - g.yt} />
    <rect x={g.x1} y={g.yt} width={g.x2 - g.x1} height={g.yb - g.yt} fill="url(#c-facadewarm)" />
    <rect x={g.x1} y={g.yb - 7} width={g.x2 - g.x1} height={7} fill="rgba(30,18,8,.22)" />
  </g>;
}

export type TexKind = 'plaster' | 'brick' | 'brickB' | 'wood' | 'stone' | 'metal' | 'paint';
function Tex({ kind, x1, yt, w, h }: { kind: TexKind; x1: number; yt: number; w: number; h: number }) {
  if (kind === 'brick' || kind === 'brickB') {
    const a = kind === 'brick' ? 'rgba(60,26,16,.28)' : 'rgba(120,96,64,.3)';
    return <g opacity=".8">{Array.from({ length: Math.floor(h / 12) }).map((_, r) =>
      <path key={r} d={`M${x1} ${yt + r * 12} h${w}`} stroke={a} strokeWidth="1.4" />)}
      {Array.from({ length: Math.floor(h / 12) }).map((_, r) =>
        Array.from({ length: Math.floor(w / 26) }).map((_, c) =>
          <path key={`${r}-${c}`} d={`M${x1 + c * 26 + (r % 2) * 13} ${yt + r * 12} v12`} stroke={a} strokeWidth="1.2" />))}
    </g>;
  }
  if (kind === 'wood') return <g opacity=".55">{Array.from({ length: Math.floor(w / 16) }).map((_, i) =>
    <path key={i} d={`M${x1 + i * 16} ${yt} v${h}`} stroke="rgba(50,30,14,.4)" strokeWidth="1.6" />)}</g>;
  if (kind === 'metal') return <g opacity=".6">{Array.from({ length: Math.floor(w / 14) }).map((_, i) =>
    <path key={i} d={`M${x1 + i * 14 + 4} ${yt + 4} v${h - 8}`} stroke="rgba(20,20,16,.35)" strokeWidth="3" />)}</g>;
  if (kind === 'stone') return <g opacity=".5">{Array.from({ length: Math.floor(h / 20) }).map((_, r) =>
    <path key={r} d={`M${x1} ${yt + r * 20} h${w}`} stroke="rgba(40,30,20,.35)" strokeWidth="1.6" />)}
    {Array.from({ length: Math.floor(h / 20) }).map((_, r) =>
      Array.from({ length: Math.floor(w / 44) }).map((_, c) =>
        <path key={`${r}-${c}`} d={`M${x1 + c * 44 + (r % 2) * 22} ${yt + r * 20} v20`} stroke="rgba(40,30,20,.3)" strokeWidth="1.4" />))}</g>;
  if (kind === 'paint') return <g opacity=".5">
    <path d={`M${x1} ${yt + h * .3} h${w} M${x1} ${yt + h * .62} h${w}`} stroke="rgba(255,244,214,.25)" strokeWidth="2.4" />
    <path d={`M${x1 + w * .2} ${yt} v${h * .3} M${x1 + w * .7} ${yt + h * .62} v${h * .38}`} stroke="rgba(30,18,8,.14)" strokeWidth="5" />
  </g>;
  return <g opacity=".4">
    <path d={`M${x1 + w * .12} ${yt + 6} q10 ${h * .3} -4 ${h * .5}`} stroke="rgba(30,18,8,.12)" strokeWidth="7" fill="none" />
    <path d={`M${x1 + w * .8} ${yt + h * .4} q-8 ${h * .25} 6 ${h * .45}`} stroke="rgba(30,18,8,.1)" strokeWidth="6" fill="none" />
  </g>;
}

/* табличка-подпись (diegetic: эмалевая табличка на столбиках) */
export function NamePlate({ text, locked }: { text: string; locked?: boolean }) {
  return <g className="ui-label" transform="translate(0 30)">
    <path d="M-40 -6 v14 M40 -6 v14" stroke="#3a2c1d" strokeWidth="3" />
    <rect x="-62" y="-15" width="124" height="24" rx="6" fill="#241a12d9" stroke="#57432c" strokeWidth="1.6" />
    <text textAnchor="middle" y="2" fontSize="13" fontFamily="Georgia, serif" fill={locked ? '#9a8c74' : '#efe3cc'} fontWeight="bold">{text}</text>
  </g>;
}
export function ClosedSign() {
  return <g transform="translate(0 -70)">
    <path d="M-2 -14 v8 M14 -14 v8" stroke="#3a2c1d" strokeWidth="2" />
    <rect x="-26" y="-8" width="52" height="18" rx="3" fill="#8a4a32" stroke="#5a2c1c" strokeWidth="1.6" transform="rotate(-3)" />
    <text textAnchor="middle" y="5" fontSize="11" fontFamily="Georgia, serif" fill="#f0e0c0" letterSpacing="2" transform="rotate(-3)">ЗАКРЫТО</text>
  </g>;
}

/* ================= ЛАВКА (герой) ================= */
export function ShopBld({ x, y, s = 1, locked = false, vp }: BldProps) {
  const w = 216, h = 196;
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={w} h={h} d={34} face="#b0855a" side="#6e5138" roof="#8a5a44" roofLit="#a06a4c" type="gable" rh={46} tex="plaster" />
    {/* мансардное окно */}
    <g transform="translate(0 -214)"><rect x="-13" y="-16" width="26" height="22" rx="2" fill="#5a4632" />
      <rect x="-10" y="-13" width="20" height="16" fill={locked ? '#39485a' : '#ffd98a'} opacity={locked ? 1 : .9} /></g>
    <Chimney x={62} y={-212} smoke={!locked} />
    {/* второй этаж */}
    <Win x={-64} y={-176} v={locked ? 'shut' : 'curtain'} w={26} h={34} frame="#5a4632" />
    <Win x={-13} y={-176} v={locked ? 'shut' : 'lit'} w={26} h={34} frame="#5a4632" />
    <Win x={38} y={-176} v={locked ? 'shut' : 'flower'} w={26} h={34} frame="#5a4632" />
    <path d="M-108 -136 h216" stroke="#8a6a48" strokeWidth="4" />
    {/* витрина */}
    <rect x="-96" y="-118" width="118" height="86" rx="4" fill="#2c3542" />
    <rect x="-90" y="-112" width="106" height="74" rx="3" fill={locked ? '#39485a' : '#54402a'} />
    {!locked && <rect x="-90" y="-112" width="106" height="74" rx="3" fill="url(#c-winglow)" opacity=".5" />}
    {!locked && <>
      <g transform="translate(-66 -86)"><circle r="11" fill="#d9b23f" /><circle r="7.8" fill="#efe3cc" /><path d="M0 0 v-5 M0 0 l3.2 2.2" stroke="#5a4632" strokeWidth="1.5" /></g>
      <g transform="translate(-28 -84)"><path d="M-8 8 q-3 -12 8 -14 q11 2 8 14z" fill="#b08968" /></g>
      <g transform="translate(2 -80)"><rect x="-8" y="-7" width="16" height="13" rx="3" fill="#4f6a6a" /><circle cx="0" cy="-1.6" r="3.6" fill="#cfe0e0" /></g>
      <path d="M-90 -70 h106" stroke="#5a4632" strokeWidth="3" />
    </>}
    {locked && <path d="M-90 -112 l106 74 M16 -112 l-106 74" stroke="#a08054" strokeWidth="7" strokeLinecap="round" />}
    {/* кот на подоконной планке */}
    <path d="M-100 -34 h126 v7 h-126z" fill="#6e4f33" />
    {!locked && <g transform="translate(6 -27)">
      <ellipse rx="11" ry="6" fill="#5d584c" /><circle cx="-8.6" cy="-4.4" r="5" fill="#5d584c" />
      <path d="M-12 -7.6 l-1.6 -4.6 4 2.2 M-5.6 -8.4 l1 -4.6 3.2 3.8" fill="#5d584c" />
      <path d="M10 -1.6 q7.4 0 5.6 6.4" stroke="#5d584c" strokeWidth="3.2" fill="none" strokeLinecap="round" className="cat-tail" />
    </g>}
    {/* навес */}
    <path d="M-104 -124 h134 l9 24 h-152z" fill={locked ? '#7a6a5a' : '#b5533c'} />
    {Array.from({ length: 8 }).map((_, i) => i % 2 ? null : <polygon key={i}
      points={`${-104 + i * 16.75},-124 ${-104 + i * 16.75 + 8.4},-124 ${-104 + i * 16.75 + 6.2},-100 ${-104 + i * 16.75 - 2.2},-100`} fill="#efe3cc" opacity=".92" />)}
    <path d="M-112 -100 h150" stroke="#7c3a2a" strokeWidth="3.6" />
    {/* дверь */}
    <Door x={44} y={0} w={40} h={92} col="#6e4f33" open={!locked} boarded={locked} />
    <path d="M40 0 h56 v6 h-56z M36 6 h64 v6 h-64z" fill="#8a7a5a" />
    <rect x={30} y={-4} width={52} height={8} rx={3} fill="#7c2a1c" opacity=".85" />
    {/* вывеска */}
    <SignBoard x={0} y={-146} w={104} h={28} text="ЛАВКА" fs={16} />
    {/* качающийся самовар */}
    <g className="swing-sign" style={{ transformOrigin: '-104px -168px' }}>
      <path d="M-104 -174 v9" stroke="#3a2c1d" strokeWidth="3.4" />
      <rect x="-124" y="-165" width="40" height="36" rx="4" fill="#2c2117" stroke="#d9b23f" strokeWidth="2" />
      <g transform="translate(-104 -147)">
        <path d="M-7 -9 q-3.4 7 -1.6 12 q1.6 5 8.6 5 q7 0 8.6 -5 q1.6 -5 -1.6 -12z" fill="#d9b23f" />
        <path d="M-8.6 -5 q-5 1.6 -4.2 7 M8.6 -5 q5 1.6 4.2 7" stroke="#d9b23f" strokeWidth="2.2" fill="none" />
      </g>
    </g>
    <path d="M-108 -174 h16" stroke="#3a2c1d" strokeWidth="3.4" />
    {/* доска объявлений у двери */}
    <g transform="translate(96 -58)"><rect x="-12" y="-20" width="24" height="32" rx="2" fill="#6e5638" />
      <rect x="-9" y="-16" width="18" height="11" fill="#e3d3b3" transform="rotate(-2)" />
      <rect x="-9" y="-2" width="18" height="10" fill="#d8c8a8" transform="rotate(1.6)" /></g>
    {locked && <ClosedSign />}
  </g>;
}

/* ================= ЗАПЧАСТИ ================= */
export function PartsBld({ x, y, s = 1, locked = false, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={168} h={148} d={28} face="#4f6a6a" side="#33484a" roof="#3f5656" roofLit="#4c6666" type="flat" tex="paint" />
    <SignMast x={70} y={-148} h={64} text="ДЕТАЛИ" col="#3f5656" />
    {/* витраж с шестерёнкой */}
    <rect x="-66" y="-112" width="86" height="62" rx="4" fill="#22303a" />
    <rect x="-61" y="-107" width="76" height="52" rx="3" fill={locked ? '#39485a' : 'url(#c-winglow)'} opacity={locked ? .9 : .28} />
    <g transform="translate(-24 -81)" className={locked ? '' : 'gear-spin'}>
      <circle r="14" fill="none" stroke="#d9b23f" strokeWidth="4.4" /><circle r="4.4" fill="#d9b23f" />
      {[0, 60, 120, 180, 240, 300].map(a => <rect key={a} x="-3" y="-18.6" width="6" height="7" fill="#d9b23f" transform={`rotate(${a})`} />)}
    </g>
    <g transform="translate(-52 -70)"><circle r="7" fill="none" stroke="#b08968" strokeWidth="3" /><circle r="2.4" fill="#b08968" /></g>
    <path d="M-66 -78 h86" stroke="#33484a" strokeWidth="2.6" />
    <Door x={44} y={0} w={36} h={82} col="#33484a" open={!locked} boarded={locked} />
    <SignBoard x={-14} y={-132} w={120} h={24} text="ЗАПЧАСТИ" fs={13} />
    {/* ящики и каталог у входа */}
    <g transform="translate(74 -14)"><rect x="-13" y="-13" width="26" height="26" rx="2" fill="#a67c52" stroke="#5a4632" strokeWidth="2" />
      <path d="M-13 -13 l26 26 M13 -13 l-26 26" stroke="#c8a97e" strokeWidth="2.4" /></g>
    <g transform="translate(80 -36)"><rect x="-10" y="-10" width="20" height="20" rx="2" fill="#c8a97e" stroke="#5a4632" strokeWidth="1.8" /></g>
    {locked && <ClosedSign />}
  </g>;
}

/* ================= ГАРАЖ ================= */
export function GarageBld({ x, y, s = 1, locked = false, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={192} h={126} d={26} face="#6e6258" side="#4a4238" roof="#4a4238" roofLit="#57504a" type="flat" tex="metal" />
    {/* ворота */}
    <rect x="-58" y="-92" width="116" height="92" rx="3" fill="#57504a" />
    {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M-58 ${-78 + i * 16} h116`} stroke="#3a3630" strokeWidth="2.6" />)}
    <rect x="-58" y="-92" width="116" height="92" rx="3" fill="none" stroke="#3a3630" strokeWidth="2.6" />
    {locked && <path d="M-58 -70 h116 M-58 -34 h116" stroke="#a08054" strokeWidth="8" strokeLinecap="round" />}
    {!locked && <rect x="-58" y="-16" width="116" height="16" fill="rgba(255,220,150,.14)" />}
    {/* фара-вывеска */}
    <g transform="translate(0 -108)">
      <circle r="13" fill="#2c2117" stroke="#d9b23f" strokeWidth="2.2" />
      <circle r="8" fill={locked ? '#6a6a5a' : '#ffe9a3'} opacity=".9" />
      {!locked && <circle r="20" fill="url(#c-lamp)" opacity=".7" />}
    </g>
    <text x="0" y="-104" textAnchor="middle" fontSize="12.5" fontFamily="Georgia, serif" fill="#e3d3b3" letterSpacing="3">ГАРАЖ</text>
    {/* колесо, инструменты, канистра */}
    <g transform="translate(80 -16)"><circle r="15" fill="none" stroke="#2a2620" strokeWidth="6" /><circle r="5" fill="none" stroke="#2a2620" strokeWidth="2.6" />
      <path d="M0 -13 v26 M-13 0 h26" stroke="#2a2620" strokeWidth="2.6" /></g>
    <g transform="translate(-82 -10)"><rect x="-8" y="-16" width="16" height="16" rx="2" fill="#8a4a32" /><path d="M-4 -16 v-4 h8 v4" stroke="#5a2c1c" strokeWidth="2" fill="none" /></g>
    <path d="M-96 0 h192 v4 h-192z" fill="rgba(30,18,8,.3)" />
    {locked && <ClosedSign />}
  </g>;
}

/* ================= СКЛАД-АУКЦИОН ================= */
export function WarehouseBld({ x, y, s = 1, locked = false, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={232} h={168} d={36} face="#8a5a44" side="#5a3a2c" roof="#4a3226" roofLit="#5c4030" type="hip" rh={22} tex="brick" />
    {/* арочные ворота */}
    <path d="M-46 0 v-72 a46 34 0 0 1 92 0 v72z" fill="#4a3620" />
    <path d="M-46 -40 l92 46 M46 -40 l-92 46" stroke="#6e4f33" strokeWidth="6" />
    <path d="M-46 0 v-72 a46 34 0 0 1 92 0 v72" fill="none" stroke="#33261a" strokeWidth="3.4" />
    {locked && <path d="M-50 -64 h100 M-50 -28 h100" stroke="#a08054" strokeWidth="9" strokeLinecap="round" />}
    {/* окна-продухи */}
    <Win x={-102} y={-140} w={28} h={22} v={locked ? 'dark' : 'lit'} frame="#4a3226" arc />
    <Win x={74} y={-140} w={28} h={22} v={locked ? 'dark' : 'lit'} frame="#4a3226" arc />
    <SignBoard x={0} y={-122} w={150} h={26} text="АУКЦИОН · СКЛАД" fs={12.5} />
    {/* афиша сегодняшних торгов */}
    {!locked && <g transform="translate(94 -66) rotate(2)">
      <rect x="-20" y="-26" width="40" height="52" rx="3" fill="#e3d3b3" stroke="#8a6c1e" strokeWidth="2" />
      <text x="0" y="-8" textAnchor="middle" fontSize="10" fontFamily="Georgia, serif" fill="#5a1c12" letterSpacing="1">АУКЦИОН</text>
      <text x="0" y="6" textAnchor="middle" fontSize="8.4" fontFamily="Georgia, serif" fill="#3a2c1d">сегодня</text>
      <text x="0" y="17" textAnchor="middle" fontSize="8.4" fontFamily="Georgia, serif" fill="#3a2c1d">18:00</text>
    </g>}
    {/* пандус, поддоны, бочки */}
    <path d="M-46 0 l-26 0 l0 -8 l26 -6z" fill="#8a7a5a" />
    <g transform="translate(-92 -12)"><rect x="-16" y="-22" width="32" height="22" rx="2" fill="#8a6a48" stroke="#5a4632" strokeWidth="2" />
      <path d="M-16 -11 h32" stroke="#5a4632" strokeWidth="2" /></g>
    <g transform="translate(102 -16)"><rect x="-12" y="-34" width="24" height="34" rx="5" fill="#5d584c" />
      <path d="M-12 -25 h24 M-12 -10 h24" stroke="#3a3630" strokeWidth="2.2" /><ellipse cx="0" cy="-34" rx="12" ry="4" fill="#7a7568" /></g>
    {locked && <ClosedSign />}
  </g>;
}

/* ================= УСАДЬБА ================= */
export function EstateBld({ x, y, s = 1, locked = false, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={212} h={148} d={32} face="#d4bc94" side="#a08c68" roof="#8a5a44" roofLit="#9c664a" type="hip" rh={18} tex="plaster" />
    {/* фронтон */}
    <path d="M-70 -148 l70 -34 70 34z" fill="#c8b898" stroke="#a89878" strokeWidth="2.4" />
    <circle cx="0" cy="-160" r="9" fill={locked ? '#39485a' : '#ffd98a'} stroke="#8a7858" strokeWidth="2" opacity={locked ? 1 : .95} />
    {/* колонны */}
    {[-78, -39, 0, 39, 78].map(cx => <g key={cx}>
      <rect x={cx - 6} y={-140} width={12} height={134} rx={2.6} fill="#efe3cc" stroke="#b0a488" strokeWidth="1.6" />
      <rect x={cx - 8.4} y={-142} width={16.8} height={5} rx={1.6} fill="#c8b898" />
    </g>)}
    <path d="M-92 -140 h184 v-7 h-184z" fill="#c8b898" />
    {/* окна */}
    {[-58, -19, 19, 58].map((cx, i) => <Win key={cx} x={cx - 11} y={-124} w={22} h={34} arc v={locked ? 'shut' : i === 1 ? 'lit' : 'curtain'} frame="#a89878" />)}
    <Door x={-17} y={0} w={34} h={74} col="#5a4632" open={!locked} boarded={locked} />
    <circle cx={-26} cy={-52} r={4} fill={locked ? '#8a8a7a' : '#ffe9a3'} stroke="#8a6c1e" strokeWidth="1.6" />
    <circle cx={26} cy={-52} r={4} fill={locked ? '#8a8a7a' : '#ffe9a3'} stroke="#8a6c1e" strokeWidth="1.6" />
    <text x="0" y="-186" textAnchor="middle" fontSize="12" fontFamily="Georgia, serif" fill="#5a4632" letterSpacing="3.4">УСАДЬБА</text>
    {/* ограда с воротами */}
    <g transform="translate(-104 0)">
      {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M${i * 13} 0 v-20 l3 -4.6 3 4.6 v20z`} fill="#b0a488" />)}
      <path d="M-2 -15 h66 M-2 -7 h66" stroke="#b0a488" strokeWidth="2.4" />
    </g>
    <g transform="translate(44 0)">
      {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M${i * 13} 0 v-20 l3 -4.6 3 4.6 v20z`} fill="#b0a488" />)}
      <path d="M-2 -15 h66 M-2 -7 h66" stroke="#b0a488" strokeWidth="2.4" />
    </g>
    {locked && <ClosedSign />}
  </g>;
}

/* ================= второстепенные ================= */
export function BakeryBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={128} h={112} d={22} face="#c8a070" side="#8a6a48" roof="#7c4a32" roofLit="#94583c" type="gable" rh={30} tex="plaster" />
    <Chimney x={38} y={-128} smoke />
    <Win x={-46} y={-84} w={26} h={30} v="lit" frame="#6e4f33" />
    <Win x={12} y={-84} w={26} h={30} v="curtain" frame="#6e4f33" />
    <Door x={-14} y={0} w={28} h={56} col="#6e4f33" open awning="#8a4a32" />
    <SignBoard x={0} y={-102} w={84} h={20} text="БУЛОЧНАЯ" fs={11} bg="#5a2c1c" />
    {/* крендель */}
    <g transform="translate(52 -66)"><path d="M-8 4 q-8 -2 -6 -10 q2 -7 8 -5 q4 1 6 5 q2 -4 6 -5 q6 -2 8 5 q2 8 -6 10 q-8 2 -16 0z" fill="none" stroke="#c8862c" strokeWidth="4.4" /></g>
    <g transform="translate(-52 -8)"><rect x="-10" y="-8" width="20" height="8" rx="2" fill="#8a6a48" />
      <ellipse cx="-4" cy="-10" rx="4" ry="2.6" fill="#c8862c" /><ellipse cx="3" cy="-10" rx="4" ry="2.6" fill="#b0742a" /></g>
  </g>;
}
export function ClosedShopBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={118} h={104} d={20} face="#8a8072" side="#5d584c" roof="#4a4238" type="flat" tex="paint" />
    <Win x={-44} y={-76} w={30} h={34} v="shut" frame="#57504a" />
    <Win x={8} y={-76} w={30} h={34} v="shut" frame="#57504a" />
    <Door x={-13} y={0} w={26} h={52} col="#57504a" boarded />
    <SignBoard x={0} y={-92} w={92} h={18} text="· · · · ·" fs={11} bg="#4a4238" fg="#8a8072" />
    <g transform="translate(40 -40) rotate(-4)"><rect x="-9" y="-12" width="18" height="24" fill="#d8c8a8" opacity=".8" />
      <path d="M-6 -7 h12 M-6 -2 h10 M-6 3 h12" stroke="#8a6c52" strokeWidth="1.6" /></g>
  </g>;
}
export function ClockmakerBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={104} h={118} d={18} face="#6e7f56" side="#4a5a3c" roof="#5a4632" roofLit="#6e5638" type="gable" rh={26} tex="wood" />
    <Win x={-34} y={-92} w={22} h={26} v="lit" frame="#4a3620" />
    <Win x={10} y={-92} w={22} h={26} v="dark" frame="#4a3620" />
    <Door x={-12} y={0} w={24} h={50} col="#4a3620" open />
    {/* часы-вывеска */}
    <g transform="translate(0 -108)"><circle r="12" fill="#efe3cc" stroke="#3a2c1d" strokeWidth="2.4" />
      <path d="M0 0 v-7 M0 0 l4.6 2.6" stroke="#3a2c1d" strokeWidth="1.8" /><path d="M-3 -14 q3 -4 6 0" stroke="#3a2c1d" strokeWidth="2" fill="none" /></g>
    <g transform="translate(34 -60)"><circle r="7" fill="#d8c8a8" stroke="#3a2c1d" strokeWidth="1.8" /><path d="M0 0 v-4 M0 0 l2.6 1.6" stroke="#3a2c1d" strokeWidth="1.4" /></g>
  </g>;
}
export function HouseBld({ x, y, s = 1, v = 0, vp }: BldProps & { v?: number }) {
  const faces = ['#b09878', '#9aa888', '#c0a088'], sides = ['#7c6a52', '#68785c', '#8a6c58'];
  const wvs: WinV[][] = [['curtain', 'lit', 'flower'], ['lit', 'dark', 'curtain'], ['flower', 'curtain', 'lit']];
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={124} h={118} d={22} face={faces[v % 3]} side={sides[v % 3]} roof="#7c4a32" roofLit="#94583c" type="gable" rh={32} tex="plaster" />
    {v % 2 === 0 && <Chimney x={-34} y={-132} smoke={v === 0} delay={1.2} />}
    <Win x={-44} y={-96} w={24} h={30} v={wvs[v % 3][0]} frame="#5d5240" />
    <Win x={-12} y={-96} w={24} h={30} v={wvs[v % 3][1]} frame="#5d5240" />
    <Win x={20} y={-96} w={24} h={30} v={wvs[v % 3][2]} frame="#5d5240" />
    <Door x={-13} y={0} w={26} h={52} col="#5a4632" />
    <path d="M-62 0 h124 v4 h-124z" fill="rgba(30,18,8,.25)" />
    <Win x={20} y={-52} w={24} h={30} v={v === 1 ? 'lit' : 'curtain'} frame="#5d5240" />
    <Win x={-44} y={-52} w={24} h={30} v="open" frame="#5d5240" />
  </g>;
}
export function ApartmentBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <BldShell vp={vp} x={0} y={0} w={150} h={172} d={28} face="#a89878" side="#78684c" roof="#5d5240" type="flat" tex="paint" />
    {[-52, -14, 24].map((cx, r) => <g key={cx}>
      <Win x={cx} y={-150} w={24} h={28} v={(['lit', 'curtain', 'dark'] as WinV[])[r]} frame="#6e5f42" />
      <Win x={cx} y={-108} w={24} h={28} v={(['curtain', 'flower', 'lit'] as WinV[])[r]} frame="#6e5f42" />
      <Win x={cx} y={-66} w={24} h={28} v={(['dark', 'lit', 'curtain'] as WinV[])[r]} frame="#6e5f42" />
    </g>)}
    <Door x={52} y={0} w={30} h={58} col="#5d5240" open />
    <g transform="translate(70 -74)"><rect x="-9" y="-13" width="18" height="26" rx="2" fill="#6e5638" />
      <rect x="-6" y="-10" width="12" height="8" fill="#e3d3b3" transform="rotate(-2)" /><rect x="-6" y="0" width="12" height="8" fill="#d8c8a8" /></g>
    <path d="M-75 -172 h150 v-6 h-150z" fill="#8a7a5a" />
  </g>;
}
export function ShedBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <GroundShadow x={0} y={1} rx={40} ry={6} />
    <rect x="-36" y="-52" width="72" height="52" fill="#7a6248" />
    <Tex kind="wood" x1={-36} yt={-52} w={72} h={52} />
    <polygon points="-40,-52 40,-52 44,-58 -34,-62" fill="#57504a" />
    <rect x="-12" y="-40" width="24" height="40" fill="#5d4a34" />
    <path d="M-14 -30 l28 -6" stroke="#8a7a5a" strokeWidth="4" />
    <path d="M36 -52 h14 l6 -6 h-16z" fill="#4a4238" />
  </g>;
}
export function KioskBld({ x, y, s = 1, vp }: BldProps) {
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <GroundShadow x={0} y={1} rx={30} ry={5} />
    <rect x="-26" y="-64" width="52" height="64" rx="3" fill="#4f6a6a" />
    <rect x="-20" y="-54" width="40" height="26" rx="2" fill="#22303a" />
    <rect x="-17" y="-51" width="34" height="20" fill="url(#c-winglow)" opacity=".3" />
    {[-12, -2, 8].map(dx => <rect key={dx} x={dx} y={-48} width="7" height="10" fill={['#b5533c', '#d9b23f', '#6e7f56'][Math.round(dx + 12) / 10 | 0]} opacity=".85" />)}
    <path d="M-26 -40 h52" stroke="#33484a" strokeWidth="2.4" />
    <SignBoard x={0} y={-72} w={64} h={16} text="ПРЕССА" fs={10} />
    <path d="M-30 -64 h60 l4 -8 h-68z" fill="#3f5656" />
  </g>;
}
