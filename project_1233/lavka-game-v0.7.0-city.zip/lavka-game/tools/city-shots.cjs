/* city-shots.cjs — QA-скриншоты города: desktop/portrait, без UI, бенчмарк-квартал,
   hover, camera move, жизнь через 4с, lock-состояния, console errors. */
const puppeteer = require('puppeteer');
const fs = require('fs');
const _sh = fs.readdirSync('/tmp/.cache/puppeteer/chrome-headless-shell')[0];
const SHELL_EXE = `/tmp/.cache/puppeteer/chrome-headless-shell/${_sh}/chrome-headless-shell-linux64/chrome-headless-shell`;
const OUT = process.env.SHOT_DIR || 'screenshots/city';
const BASE = 'http://localhost:4173/?dev=1';
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/* art(1600x900 / 800x1400 slice) → css px окна */
function mapper(w, h, portrait) {
  const W = portrait ? 800 : 1600, H = portrait ? 1400 : 900;
  const hh = h - 46;
  const scale = Math.max(w / W, hh / H);
  const Vw = w / scale, Vh = hh / scale;
  const x0 = (W - Vw) / 2, y0 = (H - Vh) / 2;
  return (x, y) => [ (x - x0) * scale, (y - y0) * scale + 46 ];
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({ headless: 'shell', executablePath: SHELL_EXE, protocolTimeout: 180000, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu'] });
  const errors = [];
  const hook = (page, tag) => {
    page.on('console', m => { if (m.type() === 'error') errors.push(`[${tag}] ${m.text()}`); });
    page.on('pageerror', e => errors.push(`[${tag}] pageerror: ${e.message}`));
  };

  /* ---- desktop ---- */
  let page = await browser.newPage();
  hook(page, 'desk');
  await page.setViewport({ width: 1280, height: 780, deviceScaleFactor: 2 });
  await page.goto(BASE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => window.game.introDone && window.game.introDone());
  await sleep(500);
  await page.evaluate(() => window.game.goToCity());
  await sleep(1200);
  await page.screenshot({ path: `${OUT}/desk-city.png` });
  const M = mapper(1280, 780, false);
  // бенчмарк-квартал 1/3: лавка + площадь + склад, hi-dpi
  const [bx, by] = M(240, 360), [bx2, by2] = M(920, 900);
  await page.screenshot({ path: `${OUT}/desk-bench-block.png`, clip: { x: bx, y: by, width: bx2 - bx, height: by2 - by } });
  // главная улица крупно
  const [sx, sy] = M(300, 620), [sx2, sy2] = M(1100, 900);
  await page.screenshot({ path: `${OUT}/desk-mainstreet.png`, clip: { x: sx, y: sy, width: sx2 - sx, height: sy2 - sy } });
  // главные здания крупно
  const [gx, gy] = M(700, 420), [gx2, gy2] = M(1600, 780);
  await page.screenshot({ path: `${OUT}/desk-buildings.png`, clip: { x: gx, y: gy, width: gx2 - gx, height: gy2 - gy } });
  // hover на лавку
  const [hx, hy] = M(450, 560);
  await page.mouse.move(hx, hy);
  await sleep(450);
  await page.screenshot({ path: `${OUT}/desk-hover.png` });
  await page.close();

  /* ---- camera move: стоп-кадр середины наезда (zoompause) ---- */
  page = await browser.newPage();
  hook(page, 'desk-zoom');
  await page.setViewport({ width: 1280, height: 780, deviceScaleFactor: 2 });
  await page.goto(BASE + '&slowzoom=1&zoompause=1', { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => window.game.introDone && window.game.introDone());
  await sleep(400);
  await page.evaluate(() => window.game.goToCity());
  await sleep(900);
  const [zx, zy] = M(450, 560);
  await page.mouse.click(zx, zy);
  await sleep(2600);
  await page.screenshot({ path: `${OUT}/desk-cameramove.png` });
  await page.close();

  /* ---- camera move: приезд в лавку (обычная скорость) + жизнь через 4с ---- */
  page = await browser.newPage();
  hook(page, 'desk-arrive');
  await page.setViewport({ width: 1280, height: 780, deviceScaleFactor: 2 });
  await page.goto(BASE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => window.game.introDone && window.game.introDone());
  await sleep(400);
  await page.evaluate(() => window.game.goToCity());
  await sleep(900);
  await page.mouse.click(zx, zy);
  await sleep(3200);
  await page.screenshot({ path: `${OUT}/desk-camera-arrive.png` });
  await page.evaluate(() => window.game.goToCity());
  await sleep(4200);
  await page.screenshot({ path: `${OUT}/desk-city-4s.png` });
  await page.close();

  /* ---- desktop без UI ---- */
  page = await browser.newPage();
  hook(page, 'desk-noui');
  await page.setViewport({ width: 1280, height: 780, deviceScaleFactor: 2 });
  await page.goto(BASE + '&noui=1', { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => window.game.introDone && window.game.introDone());
  await sleep(400);
  await page.evaluate(() => window.game.goToCity());
  await sleep(1500);
  await page.screenshot({ path: `${OUT}/desk-city-noui.png` });
  await page.close();

  /* ---- portrait ---- */
  page = await browser.newPage();
  hook(page, 'port');
  await page.setViewport({ width: 420, height: 860, deviceScaleFactor: 2 });
  await page.goto(BASE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => window.game.introDone && window.game.introDone());
  await sleep(400);
  await page.evaluate(() => window.game.goToCity());
  await sleep(1500);
  await page.screenshot({ path: `${OUT}/port-city.png` });
  await sleep(3500);
  await page.screenshot({ path: `${OUT}/port-city-4s.png` });
  await page.close();

  await browser.close();
  fs.writeFileSync(`${OUT}/errors.txt`, errors.join('\n') || 'no errors');
  console.log('city shots done; errors:', errors.length);
  if (errors.length) console.log(errors.slice(0, 12).join('\n'));
})();
