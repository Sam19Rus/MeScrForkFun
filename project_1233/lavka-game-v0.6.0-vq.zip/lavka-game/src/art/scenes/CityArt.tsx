/* CityArt.tsx — ГОРОД-ДИОРАМА: маленький ретро-квартал, а не меню зданий.
   Слои: дальний город и небо → улица с домами разной глубины (лавка — герой) →
   жизнь (прохожие с циклом ходьбы, кот, птицы, дым, качающиеся вывески) →
   передний план (фонарь, ветка, бордюр). Свет: вечернее солнце слева, длинные тени вправо.
   Здания кликабельны (g.building data-id), locked — гасятся. */
import React from 'react';

export interface CityBuildingAnchor { id: string; x: number; y: number; s: number; z: number; }

export function cityBuildings(portrait: boolean): CityBuildingAnchor[] {
  return portrait
    ? [
      { id: 'parts', x: 640, y: 648, s: .62, z: 1 },
      { id: 'shop', x: 800, y: 668, s: .95, z: 3 },
      { id: 'garage', x: 952, y: 640, s: .62, z: 2 },
      { id: 'city_warehouse', x: 1064, y: 606, s: .5, z: 1 },
      { id: 'estate', x: 1160, y: 566, s: .4, z: 0 },
    ]
    : [
      { id: 'estate', x: 1420, y: 560, s: .7, z: 0 },
      { id: 'city_warehouse', x: 1130, y: 600, s: .9, z: 1 },
      { id: 'garage', x: 820, y: 630, s: .95, z: 2 },
      { id: 'parts', x: 175, y: 645, s: .95, z: 2 },
      { id: 'shop', x: 480, y: 672, s: 1.18, z: 3 },
    ];
}

/* ---------- фасады ---------- */
function ShopFacade() {
  return <g>
    {/* дом лавки: тёплое дерево, витрина, черепица */}
    <rect x="-120" y="-230" width="240" height="230" rx="6" fill="#a67c52" />
    <rect x="-120" y="-230" width="240" height="230" rx="6" fill="none" stroke="#5a4632" strokeWidth="3" />
    <path d="M-60 -230 v230 M0 -230 v230 M60 -230 v230" stroke="#8a6a48" strokeWidth="2" opacity=".5" />
    <path d="M-120 -230 h240 v-6 h-240z" fill="#5a4632" />
    {/* крыша черепицей */}
    <path d="M-136 -230 L0 -318 L136 -230 z" fill="#8a5a44" />
    {Array.from({ length: 5 }).map((_, r) => (
      <path key={r} d={`M${-118 + r * 14} ${-238 - r * 15} h${236 - r * 28}`} stroke="#6e4234" strokeWidth="3" opacity=".8" />
    ))}
    <path d="M-136 -230 L0 -318 L136 -230" fill="none" stroke="#5a3a2a" strokeWidth="4" />
    {/* труба + дым */}
    <rect x="52" y="-300" width="22" height="46" fill="#6e4f33" />
    <rect x="48" y="-306" width="30" height="10" rx="3" fill="#5a4632" />
    <g className="smoke-puff"><circle cx="63" cy="-312" r="7" fill="#d8d0c0" opacity=".7" /></g>
    <g className="smoke-puff" style={{ animationDelay: '1.1s' }}><circle cx="66" cy="-318" r="6" fill="#d8d0c0" opacity=".6" /></g>
    <g className="smoke-puff" style={{ animationDelay: '2.2s' }}><circle cx="60" cy="-316" r="5" fill="#d8d0c0" opacity=".5" /></g>
    {/* витрина с товаром и котом */}
    <rect x="-102" y="-150" width="118" height="92" rx="5" fill="#2c3542" />
    <rect x="-96" y="-144" width="106" height="80" rx="3" fill="url(#g-glass)" opacity=".85" />
    <path d="M-96 -104 h106" stroke="#5a4632" strokeWidth="3" />
    {/* товары в витрине: часы и кувшин */}
    <g transform="translate(-72 -118)"><circle r="12" fill="url(#g-brass)" /><circle r="8.6" fill="#efe3cc" /><path d="M0 0 v-5.4 M0 0 l3.4 2.4" stroke="#5a4632" strokeWidth="1.6" /></g>
    <g transform="translate(-30 -116)"><path d="M-8 8 q-3 -12 8 -14 q11 2 8 14z" fill="#b08968" /></g>
    <g transform="translate(0 -112)"><rect x="-9" y="-8" width="18" height="14" rx="3" fill="#4f6a6a" /><circle cx="0" cy="-2" r="4" fill="#cfe0e0" /></g>
    {/* кот на подоконнике */}
    <g transform="translate(6 -62)">
      <ellipse rx="13" ry="7" fill="#5d584c" />
      <circle cx="-10" cy="-5" r="6" fill="#5d584c" />
      <path d="M-14 -9 l-2 -6 5 3 M-7 -10 l1 -6 4 5" fill="#5d584c" />
      <path d="M12 -2 q9 0 7 8" stroke="#5d584c" strokeWidth="4" fill="none" strokeLinecap="round" className="cat-tail" />
      <path d="M-12 -5 q2 2 4 0" stroke="#241a12" strokeWidth="1.2" fill="none" />
    </g>
    <path d="M-104 -56 h122 v8 h-122z" fill="#6e4f33" />
    {/* дверь */}
    <rect x="34" y="-128" width="62" height="128" rx="4" fill="#6e4f33" stroke="#4a3620" strokeWidth="3" />
    <rect x="42" y="-118" width="46" height="64" rx="3" fill="none" stroke="#4a3620" strokeWidth="3" opacity=".8" />
    <circle cx="88" cy="-62" r="4" fill="url(#g-brass)" />
    <path d="M34 -128 q31 -14 62 0" fill="#5a4632" />
    {/* навес над витриной */}
    <path d="M-112 -156 h136 l10 26 h-156z" fill="#b5533c" />
    {Array.from({ length: 7 }).map((_, i) => <path key={i} d={`M${-112 + i * 19.4} -156 l-2.4 26`} stroke="#efe3cc" strokeWidth={i % 2 ? 0 : 9} opacity=".9" />)}
    <path d="M-122 -130 h156" stroke="#7c3a2a" strokeWidth="4" />
    {/* вывеска-фондюр над дверью */}
    <rect x="26" y="-176" width="80" height="30" rx="5" fill="#241a12" stroke="#d9b23f" strokeWidth="2.4" />
    <text x="66" y="-155" textAnchor="middle" fontSize="17" fontFamily="Georgia, serif" fill="#f2d788" letterSpacing="3">ЛАВКА</text>
    {/* качающаяся вывеска-самовор */}
    <g className="swing-sign" style={{ transformOrigin: '-118px -190px' }}>
      <path d="M-118 -196 v10" stroke="#3a2c1d" strokeWidth="4" />
      <path d="M-140 -186 h44 v40 h-44z" fill="#2c2117" stroke="#d9b23f" strokeWidth="2.4" />
      <g transform="translate(-118 -166)">
        <path d="M-8 -10 q-4 8 -2 14 q2 6 10 6 q8 0 10 -6 q2 -6 -2 -14z" fill="url(#g-brass)" />
        <path d="M-10 -6 q-6 2 -5 8 M10 -6 q6 2 5 8" stroke="url(#g-brass)" strokeWidth="2.6" fill="none" />
        <path d="M-4 -12 q4 -6 8 0z" fill="url(#g-brass)" />
      </g>
    </g>
    <path d="M-120 -196 h20" stroke="#3a2c1d" strokeWidth="4" />
    {/* ступени + коврик */}
    <path d="M30 0 h70 v8 h-70z M26 8 h78 v8 h-78z" fill="#8a7a5a" />
    <rect x="-96" y="-2" width="70" height="10" rx="3" fill="#7c2a1c" opacity=".8" />
    {/* тень справа */}
    <path d="M60 -230 h60 v230 h-60z" fill="rgba(20,12,6,.16)" />
  </g>;
}

function PartsFacade() {
  return <g>
    <rect x="-110" y="-190" width="220" height="190" rx="5" fill="#4f6a6a" />
    <rect x="-110" y="-190" width="220" height="190" rx="5" fill="none" stroke="#33484a" strokeWidth="3" />
    <path d="M-110 -190 h220 v-8 h-220z" fill="#33484a" />
    <path d="M-122 -196 h244 l-10 -26 h-224z" fill="#3f5656" />
    {/* витраж-окно с шестерёнкой */}
    <rect x="-88" y="-150" width="96" height="70" rx="4" fill="#22303a" />
    <rect x="-82" y="-144" width="84" height="58" rx="3" fill="url(#g-glass)" opacity=".8" />
    <g transform="translate(-40 -115)" className="gear-spin">
      <circle r="16" fill="none" stroke="#d9b23f" strokeWidth="5" />
      <circle r="5" fill="#d9b23f" />
      {[0, 60, 120, 180, 240, 300].map(a => <rect key={a} x="-3.4" y="-21" width="6.8" height="8" fill="#d9b23f" transform={`rotate(${a})`} />)}
    </g>
    <path d="M-88 -116 h96" stroke="#33484a" strokeWidth="3" />
    {/* дверь */}
    <rect x="30" y="-112" width="56" height="112" rx="4" fill="#33484a" stroke="#22303a" strokeWidth="3" />
    <rect x="38" y="-102" width="40" height="52" rx="3" fill="url(#g-glass)" opacity=".5" />
    <circle cx="78" cy="-54" r="3.6" fill="url(#g-brass)" />
    {/* вывеска */}
    <rect x="-96" y="-184" width="150" height="26" rx="4" fill="#241a12" stroke="#d9b23f" strokeWidth="2" />
    <text x="-21" y="-166" textAnchor="middle" fontSize="14" fontFamily="Georgia, serif" fill="#f2d788" letterSpacing="2">ЗАПЧАСТИ</text>
    {/* ящики у входа */}
    <g transform="translate(96 -18)"><rect x="-16" y="-16" width="32" height="32" rx="3" fill="#a67c52" stroke="#5a4632" strokeWidth="2.4" /><path d="M-16 -16 l32 32 M16 -16 l-32 32" stroke="#c8a97e" strokeWidth="3" /></g>
    <g transform="translate(102 -44)"><rect x="-12" y="-12" width="24" height="24" rx="3" fill="#c8a97e" stroke="#5a4632" strokeWidth="2.2" /><path d="M-12 0 h24" stroke="#a67c52" strokeWidth="2.4" /></g>
    <path d="M50 -190 h60 v190 h-60z" fill="rgba(20,12,6,.16)" />
  </g>;
}

function GarageFacade() {
  return <g>
    <rect x="-100" y="-150" width="200" height="150" rx="4" fill="#6e6258" />
    <rect x="-100" y="-150" width="200" height="150" rx="4" fill="none" stroke="#4a4238" strokeWidth="3" />
    {/* профлист */}
    {Array.from({ length: 9 }).map((_, i) => <path key={i} d={`M${-92 + i * 22} -146 v142`} stroke="#5d584c" strokeWidth="3" opacity=".7" />)}
    <path d="M-108 -150 q108 -34 216 0 l-8 10 q-100 -28 -200 0z" fill="#4a4238" />
    {/* ворота */}
    <rect x="-64" y="-104" width="128" height="104" rx="3" fill="#57504a" />
    {Array.from({ length: 5 }).map((_, i) => <path key={i} d={`M-64 ${-88 + i * 18} h128`} stroke="#3a3630" strokeWidth="3" />)}
    <rect x="-64" y="-104" width="128" height="104" rx="3" fill="none" stroke="#3a3630" strokeWidth="3" />
    {/* фара-вывеска */}
    <g transform="translate(0 -122)">
      <circle r="15" fill="#2c2117" stroke="#d9b23f" strokeWidth="2.4" />
      <circle r="9" fill="#ffe9a3" opacity=".85" />
      <path d="M-4 -4 q4 -3 8 0" stroke="#fff" strokeWidth="2" fill="none" opacity=".7" />
    </g>
    <text x="0" y="-120" textAnchor="middle" fontSize="15" fontFamily="Georgia, serif" fill="#e3d3b3" letterSpacing="4" opacity=".9">ГАРАЖ</text>
    {/* колесо у стены */}
    <g transform="translate(84 -20)"><circle r="18" fill="none" stroke="#2a2620" strokeWidth="7" /><circle r="6" fill="none" stroke="#2a2620" strokeWidth="3" /><path d="M0 -16 v32 M-16 0 h32" stroke="#2a2620" strokeWidth="3" /></g>
    <path d="M40 -150 h60 v150 h-60z" fill="rgba(20,12,6,.18)" />
  </g>;
}

function WarehouseFacade() {
  return <g>
    <rect x="-120" y="-170" width="240" height="170" rx="4" fill="url(#p-brick)" />
    <rect x="-120" y="-170" width="240" height="170" rx="4" fill="none" stroke="#4a3226" strokeWidth="3" />
    <path d="M-128 -170 h256 l-12 -22 h-232z" fill="#4a3226" />
    {/* большие ворота */}
    <rect x="-52" y="-110" width="104" height="110" rx="4" fill="#4a3620" />
    <path d="M-52 -110 l104 110 M52 -110 l-104 110" stroke="#6e4f33" strokeWidth="7" />
    <rect x="-52" y="-110" width="104" height="110" rx="4" fill="none" stroke="#33261a" strokeWidth="4" />
    {/* окна-продухи */}
    <rect x="-102" y="-146" width="30" height="24" rx="2" fill="#22303a" />
    <rect x="72" y="-146" width="30" height="24" rx="2" fill="#22303a" />
    <path d="M-102 -134 h30 M72 -134 h30" stroke="#4a3226" strokeWidth="2.4" />
    {/* надпись по стене */}
    <text x="0" y="-128" textAnchor="middle" fontSize="20" fontFamily="Georgia, serif" fill="#e3d3b3" opacity=".85" letterSpacing="6">СКЛАД</text>
    {/* поддоны и бочки */}
    <g transform="translate(-92 -16)">
      <rect x="-18" y="-26" width="36" height="26" rx="3" fill="#8a6a48" stroke="#5a4632" strokeWidth="2.2" />
      <path d="M-18 -13 h36" stroke="#5a4632" strokeWidth="2.2" />
    </g>
    <g transform="translate(92 -20)">
      <rect x="-14" y="-40" width="28" height="40" rx="6" fill="#5d584c" />
      <path d="M-14 -30 h28 M-14 -12 h28" stroke="#3a3630" strokeWidth="2.6" />
      <ellipse cx="0" cy="-40" rx="14" ry="4.6" fill="#7a7568" />
    </g>
    <path d="M60 -170 h60 v170 h-60z" fill="rgba(20,12,6,.2)" />
  </g>;
}

function EstateFacade() {
  return <g>
    {/* усадебный дом с колоннами */}
    <rect x="-110" y="-160" width="220" height="160" rx="3" fill="#d9c9a8" />
    <rect x="-110" y="-160" width="220" height="160" rx="3" fill="none" stroke="#a89878" strokeWidth="3" />
    <path d="M-122 -160 L0 -216 L122 -160z" fill="#8a5a44" />
    <path d="M-122 -160 L0 -216 L122 -160" fill="none" stroke="#5a3a2a" strokeWidth="4" />
    <path d="M-110 -150 h220" stroke="#c8b898" strokeWidth="6" />
    {[-84, -42, 0, 42, 84].map(x => <rect key={x} x={x - 7} y="-146" width="14" height="140" rx="3" fill="#efe3cc" stroke="#b0a488" strokeWidth="2" />)}
    <path d="M-118 -146 h236 v-8 h-236z" fill="#c8b898" />
    {/* дверь + фонари */}
    <rect x="-24" y="-84" width="48" height="84" rx="3" fill="#5a4632" />
    <path d="M-24 -84 q24 -18 48 0" fill="#4a3620" />
    <circle cx="-38" cy="-70" r="5" fill="#ffe9a3" stroke="#8a6c1e" strokeWidth="2" />
    <circle cx="38" cy="-70" r="5" fill="#ffe9a3" stroke="#8a6c1e" strokeWidth="2" />
    {/* окна верхнего этажа */}
    {[-63, -21, 21, 63].map(x => <g key={x}><rect x={x - 12} y="-136" width="24" height="34" rx="2" fill="#3f4a5a" /><path d={`M${x} -136 v34 M${x - 12} -119 h24`} stroke="#c8b898" strokeWidth="2" /></g>)}
    <text x="0" y="-168" textAnchor="middle" fontSize="14" fontFamily="Georgia, serif" fill="#5a4632" letterSpacing="4">УСАДЬБА</text>
    {/* ограда */}
    {Array.from({ length: 9 }).map((_, i) => <path key={i} d={`M${-116 + i * 29} 0 v-22 l4 -6 4 6 v22`} fill="#b0a488" />)}
    <path d="M-120 -16 h240" stroke="#b0a488" strokeWidth="3" />
    <path d="M50 -160 h60 v160 h-60z" fill="rgba(20,12,6,.14)" />
  </g>;
}

const FACADES: Record<string, () => React.JSX.Element> = {
  shop: ShopFacade, parts: PartsFacade, garage: GarageFacade, warehouse: WarehouseFacade, estate: EstateFacade,
};
const FACADE_BY_BUILDING: Record<string, string> = { city_warehouse: 'warehouse' };

/* ---------- сцена ---------- */
export function CityArt({ lockedIds, onSelect, portrait = false }: {
  lockedIds: Set<string>;
  onSelect: (id: string, el: SVGGElement | null) => void;
  portrait?: boolean;
}) {
  const blds = [...cityBuildings(portrait)].sort((a, b) => a.z - b.z);
  const PR = {
    poleA: portrait ? 660 : 310, poleB: portrait ? 940 : 1250,
    lamp: portrait ? 986 : 1512, treeA: portrait ? 606 : 90, treeB: portrait ? 996 : 1490,
    bench: portrait ? 700 : 1240, urn: portrait ? 730 : 1310,
    bike: portrait ? 864 : 380, hedge: portrait ? 952 : 668,
    poster: portrait ? 1080 : 985, manhole: portrait ? 900 : 1180,
    bushA: portrait ? 926 : 905, bushB: portrait ? 958 : 945,
    sunX: portrait ? 700 : 240, branchDx: portrait ? 600 : 0,
  };
  return (
    <svg className="city-svg" viewBox={portrait ? '600 100 400 800' : '0 0 1600 900'} preserveAspectRatio="xMidYMid slice"
      onClick={e => {
        const g = (e.target as Element).closest('.building');
        if (g) onSelect(g.getAttribute('data-id')!, g as unknown as SVGGElement);
      }}>
      <defs>
        <linearGradient id="ct-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7ca8c0" /><stop offset=".5" stopColor="#c8c8a8" /><stop offset="1" stopColor="#f0d8ae" />
        </linearGradient>
        <linearGradient id="ct-road" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8a8072" /><stop offset="1" stopColor="#6e665a" />
        </linearGradient>
        <linearGradient id="ct-walk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c0b294" /><stop offset="1" stopColor="#a89878" />
        </linearGradient>
        <radialGradient id="ct-sun" cx=".5" cy=".5" r=".5">
          <stop offset="0" stopColor="#fff2c0" stopOpacity=".9" /><stop offset=".5" stopColor="#ffe9a3" stopOpacity=".35" /><stop offset="1" stopColor="#ffe9a3" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* ===== небо и дальний город ===== */}
      <rect width="1600" height="900" fill="url(#ct-sky)" />
      <circle cx={PR.sunX} cy="150" r="150" fill="url(#ct-sun)" />
      <circle cx={PR.sunX} cy="150" r="46" fill="#fff2c0" opacity=".95" />
      <g className="cloud" style={{ animationDuration: '90s' }} opacity=".8">
        <ellipse cx="420" cy="120" rx="70" ry="20" fill="#fff" opacity=".75" />
        <ellipse cx="470" cy="108" rx="44" ry="15" fill="#fff" opacity=".7" />
      </g>
      <g className="cloud" style={{ animationDuration: '130s', animationDelay: '-60s' }} opacity=".65">
        <ellipse cx="1050" cy="90" rx="84" ry="20" fill="#fff" opacity=".7" />
        <ellipse cx="1110" cy="78" rx="46" ry="14" fill="#fff" opacity=".65" />
      </g>
      <g className="cloud" style={{ animationDuration: '110s', animationDelay: '-20s' }} opacity=".6">
        <ellipse cx="1440" cy="140" rx="60" ry="16" fill="#fff" opacity=".7" />
      </g>
      {/* дальний силуэт города */}
      <g opacity=".5" fill="#8a9aa8">
        <path d="M0 470 l60 -8 30 -26 24 22 40 -12 30 18 52 -30 26 24 44 -10 36 16 60 -24 30 20 50 -14 40 18 66 -26 30 22 48 -12 40 16 60 -22 34 20 52 -14 40 16 60 -20 40 18 60 -14 40 14 v60 H0z" />
        <path d="M180 440 l10 -46 10 46z M1240 430 l12 -56 12 56z" />
        <rect x="700" y="404" width="14" height="60" />
        <circle cx="707" cy="398" r="12" />
      </g>
      <g opacity=".35" fill="#6e8090">
        <path d="M0 500 l90 -12 50 -20 40 16 70 -24 50 20 80 -18 60 16 90 -22 60 18 80 -16 70 14 90 -20 70 16 90 -14 80 12 120 -16 v70 H0z" />
      </g>
      {/* холм под улицей */}
      <path d="M0 560 q400 -60 800 -34 q400 26 800 -12 v386 H0z" fill="#93a878" />
      <path d="M0 588 q420 -46 820 -26 q380 20 780 -16 v354 H0z" fill="#7c9464" />

      {/* ===== улица: тротуар и мостовая ===== */}
      <path d="M0 640 q800 -46 1600 -18 v278 H0z" fill="url(#ct-walk)" />
      {Array.from({ length: 26 }).map((_, i) => <path key={i} d={`M${i * 64} 646 l-8 60`} stroke="#9a8c72" strokeWidth="2.4" opacity=".6" />)}
      <path d="M0 640 q800 -46 1600 -18 v10 q-800 -28 -1600 18z" fill="#d8ccb0" opacity=".7" />
      <path d="M0 748 q800 -36 1600 -12 v172 H0z" fill="url(#ct-road)" />
      {/* брусчатка */}
      {Array.from({ length: 4 }).map((_, r) => (
        <path key={r} d={`M0 ${772 + r * 32} q800 -30 1600 -10`} stroke="#5d554a" strokeWidth="2.2" fill="none" opacity=".5" />
      ))}
      {Array.from({ length: 30 }).map((_, i) => (
        <path key={i} d={`M${i * 56 + (i % 2) * 26} 752 l-6 146`} stroke="#5d554a" strokeWidth="1.8" opacity=".28" />
      ))}
      <path d="M0 742 q800 -36 1600 -12 v8 q-800 -24 -1600 12z" fill="#b0a288" />
      {/* лужа с отражением неба */}
      <ellipse cx="960" cy="842" rx="86" ry="15" fill="#8fb4c8" opacity=".55" />
      <ellipse cx="940" cy="839" rx="40" ry="6" fill="#c8d8e8" opacity=".5" />
      {/* воробей на мостовой */}
      <g transform="translate(690 828)">
        <ellipse rx="8" ry="6" fill="#7a7568" /><circle cx="7" cy="-5" r="4" fill="#8d887c" />
        <path d="M10 -5 l5 1.4 -5 1.4z" fill="#d9b23f" /><path d="M-7 -2 q-5 -5 -1 -7" stroke="#7a7568" strokeWidth="2.2" fill="none" />
        <path d="M-2 6 v4 M3 6 v4" stroke="#8a6c1e" strokeWidth="1.6" />
      </g>
      {/* люк + пар */}
      <ellipse cx={PR.manhole} cy="806" rx="34" ry="10" fill="#57504a" stroke="#3a3630" strokeWidth="3" />
      <g className="smoke-puff" style={{ animationDelay: '.4s' }}><circle cx="1180" cy="790" r="8" fill="#e8e0cc" opacity=".5" /></g>
      <g className="smoke-puff" style={{ animationDelay: '1.6s' }}><circle cx="1186" cy="784" r="6" fill="#e8e0cc" opacity=".4" /></g>

      {/* ===== здания (по глубине) ===== */}
      {blds.map(b => {
        const F = FACADES[FACADE_BY_BUILDING[b.id] || b.id] || ShopFacade;
        const locked = lockedIds.has(b.id);
        return (
          <g key={b.id} className={`building ${locked ? 'locked' : ''}`} data-id={b.id}
            transform={`translate(${b.x} ${b.y}) scale(${b.s})`}>
            {/* тень на тротуаре */}
            <path d="M-120 0 h240 l70 26 h-320z" fill="#3a3226" opacity=".28" />
            <F />
            {/* эмалевая табличка */}
            <g transform="translate(0 34)">
              <rect x="-64" y="-14" width="128" height="26" rx="6" fill="#241a12d9" stroke="#57432c" strokeWidth="1.6" />
              <text textAnchor="middle" y="4" fontSize="14" fontFamily="Georgia, serif" fill="#efe3cc" fontWeight="bold">
                {{ shop: 'Ваша лавка', parts: 'Запчасти «У Шпуля»', garage: 'Гараж мастеров', city_warehouse: 'Городской склад', estate: 'Усадьба' }[b.id]}
              </text>
            </g>
            {locked && <g transform="translate(0 -64)">
              <rect x="-15" y="-8" width="30" height="24" rx="5" fill="url(#g-brass)" stroke="#8a6c1e" strokeWidth="2" />
              <path d="M-8 -8 v-7 a8 8 0 0 1 16 0 v7" fill="none" stroke="#8a6c1e" strokeWidth="4" />
              <circle cx="0" cy="4" r="3.4" fill="#5a4632" />
            </g>}
          </g>
        );
      })}

      {/* изгородь с калиткой между лавкой и гаражом */}
      <g transform={`translate(${PR.hedge} 664)`} display={portrait ? "none" : undefined}>
        {Array.from({ length: 8 }).map((_, i) => <path key={i} d={`M${i * 16} 0 v-30 l4 -6 4 6 v30`} fill="#8a7a5a" />)}
        <path d="M-4 -22 h124 M-4 -10 h124" stroke="#8a7a5a" strokeWidth="3.4" />
        <rect x="52" y="-40" width="30" height="40" rx="2" fill="#6e5f42" />
        <circle cx="76" cy="-20" r="2.6" fill="#3a2c1d" />
      </g>
      {/* афиша аукциона */}
      <g transform={`translate(${PR.poster} 662) rotate(-2)`} display={portrait ? "none" : undefined}>
        <rect x="-4" y="-8" width="8" height="70" fill="#5c4f38" />
        <rect x="-52" y="-86" width="104" height="80" rx="6" fill="#e3d3b3" stroke="#8a6c1e" strokeWidth="3" />
        <rect x="-44" y="-78" width="88" height="64" rx="3" fill="none" stroke="#b5533c" strokeWidth="2.4" />
        <text x="0" y="-56" textAnchor="middle" fontSize="17" fontFamily="Georgia, serif" fill="#5a1c12" letterSpacing="2">АУКЦИОН</text>
        <text x="0" y="-38" textAnchor="middle" fontSize="11.5" fontFamily="Georgia, serif" fill="#3a2c1d">сегодня · 18:00</text>
        <g transform="translate(0 -26) rotate(-20)" fill="#5a4632"><rect x="-9" y="-3" width="18" height="7" rx="3" /><rect x="-1.6" y="4" width="3.2" height="10" rx="1.6" /></g>
      </g>

      {/* ===== жизнь улицы ===== */}
      {/* столбы */}
      {[[PR.poleA, 640], [PR.poleB, 628]].map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          <rect x="-5" y="-330" width="10" height="330" rx="3" fill="#5c4f38" />
          <rect x="-4" y="-330" width="4" height="330" fill="#6e5f42" opacity=".8" />
          <path d="M-34 -318 h68 M-26 -300 h52" stroke="#5c4f38" strokeWidth="6" />
          <circle cx="-30" cy="-322" r="4" fill="#3a3226" /><circle cx="30" cy="-322" r="4" fill="#3a3226" />
        </g>
      ))}
      {/* провода с птицами */}
      <path d="M120 322 q110 20 220 22 q440 26 910 -6 q180 -12 350 6" stroke="#3a3226" strokeWidth="2.4" fill="none" opacity=".65" />
      <path d="M120 340 q110 22 220 24 q440 28 910 -4 q180 -10 350 8" stroke="#3a3226" strokeWidth="2" fill="none" opacity=".45" />
      {[[420, 342], [468, 346], [980, 344], [1320, 352]].map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`} className={i === 1 ? 'bird-hop' : ''}>
          <ellipse rx="7" ry="5" fill={i % 2 ? '#5d584c' : '#7a7568'} />
          <circle cx="6" cy="-4" r="3.4" fill={i % 2 ? '#5d584c' : '#7a7568'} />
          <path d="M9 -4 l4 1 -4 1z" fill="#d9b23f" />
          <path d="M-6 -2 q-4 -4 -1 -6" stroke="#5d584c" strokeWidth="2" fill="none" />
        </g>
      ))}
      {/* прохожие */}
      <g className="walker w1"><g transform="translate(0 668) scale(1.05)"><Walker v={0} /></g></g>
      <g className="walker w2"><g transform="translate(0 700) scale(1.2)"><Walker v={1} flip /></g></g>
      <g className="walker w3"><g transform="translate(0 664) scale(.9)"><Walker v={2} /></g></g>
      {/* велосипед у лавки */}
      <g transform={`translate(${PR.bike} 690) scale(1.05)`}>
        <circle cx="-22" cy="0" r="17" fill="none" stroke="#3a3630" strokeWidth="4" />
        <circle cx="22" cy="0" r="17" fill="none" stroke="#3a3630" strokeWidth="4" />
        <path d="M-22 0 l10 -22 h24 l10 22 M-12 -22 l-4 -10 M12 -22 l6 -12 h8" stroke="#7c2a1c" strokeWidth="4" fill="none" strokeLinecap="round" />
        <path d="M-16 -32 h10 M26 -34 h8" stroke="#3a3630" strokeWidth="4" strokeLinecap="round" />
        <circle cx="-22" cy="0" r="3.4" fill="#8d887c" /><circle cx="22" cy="0" r="3.4" fill="#8d887c" />
      </g>
      {/* скамейка и урна у фонаря */}
      <g transform={`translate(${PR.bench} 686)`}>
        <path d="M-44 0 v-20 M44 0 v-20" stroke="#3a3630" strokeWidth="5" />
        <path d="M-50 -20 h100 v8 h-100z M-50 -34 h100 v8 h-100z" fill="#8a6a48" />
        <path d="M-50 -44 h100 v7 h-100z" fill="#8a6a48" />
        <path d="M-44 -44 v24 M44 -44 v24" stroke="#3a3630" strokeWidth="4" />
      </g>
      <g transform={`translate(${PR.urn} 692)`}>
        <rect x="-13" y="-34" width="26" height="34" rx="5" fill="#4f6a6a" />
        <ellipse cx="0" cy="-34" rx="13" ry="4.6" fill="#3f5656" />
        <path d="M-13 -22 h26" stroke="#33484a" strokeWidth="2.4" />
      </g>
      {/* деревья */}
      <g transform={`translate(${PR.treeA} 660)`}>
        <rect x="-7" y="-52" width="14" height="54" rx="4" fill="#6e4f33" />
        <circle cx="0" cy="-84" r="40" fill="#5c7a4a" />
        <circle cx="-24" cy="-64" r="24" fill="#6e8a56" />
        <circle cx="24" cy="-68" r="22" fill="#4f6a3f" />
        <circle cx="-8" cy="-98" r="18" fill="#7c9464" opacity=".9" />
      </g>
      <g transform={`translate(${PR.treeB} 652) scale(.9)`}>
        <rect x="-7" y="-52" width="14" height="54" rx="4" fill="#6e4f33" />
        <circle cx="0" cy="-84" r="38" fill="#5c7a4a" />
        <circle cx="22" cy="-64" r="22" fill="#6e8a56" />
        <circle cx="-22" cy="-68" r="20" fill="#4f6a3f" />
      </g>
      {/* кусты */}
      {[[PR.bushA, 668], [PR.bushB, 672]].map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          <circle cx="-12" cy="-10" r="14" fill="#6e8a56" /><circle cx="8" cy="-12" r="16" fill="#5c7a4a" /><circle cx="22" cy="-8" r="11" fill="#7c9464" />
        </g>
      ))}

      {/* ===== передний план ===== */}
      {/* фонарь справа */}
      <g transform={`translate(${PR.lamp} 900)`}>
        <path d="M-16 0 h32 l-6 -26 h-20z" fill="#24221c" />
        <rect x="-6" y="-330" width="12" height="310" rx="4" fill="#2c2a24" />
        <path d="M-6 -300 q-26 -6 -30 -30 M6 -300 q26 -6 30 -30" stroke="#2c2a24" strokeWidth="6" fill="none" />
        <g transform="translate(0 -352)">
          <path d="M-20 22 q20 -30 40 0 l-6 10 h-28z" fill="#24221c" />
          <circle cx="0" cy="26" r="12" fill="#ffe9a3" opacity=".95" />
          <circle cx="0" cy="26" r="30" fill="url(#ct-sun)" opacity=".7" />
          <path d="M-4 -12 q4 -8 8 0z" fill="#24221c" />
        </g>
      </g>
      {/* ветка слева сверху */}
      <g opacity=".92" transform={`translate(${PR.branchDx} 0)`}>
        <path d="M-20 40 q140 30 240 96 q60 40 84 92" stroke="#3a4a2f" strokeWidth="10" fill="none" strokeLinecap="round" />
        {[[60, 62], [130, 84], [196, 116], [252, 152], [300, 196], [96, 40], [170, 66]].map(([x, y], i) => (
          <path key={i} d={`M${x} ${y} q18 -18 40 -8 q-6 24 -30 20 q-10 -2 -10 -12z`} fill={i % 2 ? '#4f6a3f' : '#5c7a4a'} className="leaf-sway" style={{ animationDelay: `${i * .4}s`, transformOrigin: `${x}px ${y}px` }} />
        ))}
      </g>
      {/* бордюр и трава внизу */}
      <path d="M0 872 q800 -22 1600 -8 v36 H0z" fill="#b0a288" />
      <path d="M0 880 q800 -22 1600 -8" stroke="#8a7c62" strokeWidth="3" fill="none" />
      {Array.from({ length: 40 }).map((_, i) => (
        <path key={i} d={`M${i * 41 + (i % 3) * 7} 874 q2 -10 5 -12 M${i * 41 + 8} 874 q-1 -8 -4 -10`} stroke="#6e8a56" strokeWidth="2" fill="none" />
      ))}
      {/* солнечная дымка */}
      <rect width="1600" height="900" fill="url(#g-roomwarm)" opacity=".55" pointerEvents="none" />
    </svg>
  );
}

function Walker({ v, flip = false }: { v: number; flip?: boolean }) {
  const skins = ['#e8c9a8', '#f0d5b8', '#dcb08c'];
  const coats = ['#4f6a6a', '#8a4a3c', '#6e7f56'];
  const coat = coats[v % 3], skin = skins[v % 3];
  return (
    <svg viewBox="0 0 60 104" width="60" height="104" className="passer2" style={flip ? { transform: 'scaleX(-1)' } : undefined}>
      <ellipse cx="30" cy="100" rx="14" ry="3" fill="#140d07" opacity=".3" />
      <g className="p-bob">
        <g className="p-legA" style={{ transformOrigin: '30px 62px' }}>
          <path d="M30 62 q-1 16 -2 26 l-1 9" stroke="#3a3128" strokeWidth="7" fill="none" strokeLinecap="round" />
          <path d="M26 96 h9 q2 3 -1 3.6 h-9z" fill="#241a12" />
        </g>
        <g className="p-legB" style={{ transformOrigin: '30px 62px' }}>
          <path d="M30 62 q1 16 2 26 l1 9" stroke="#2c251e" strokeWidth="7" fill="none" strokeLinecap="round" />
          <path d="M32 96 h9 q2 3 -1 3.6 h-9z" fill="#1a120b" />
        </g>
        <path d="M22 34 Q30 29 38 34 L41 66 L19 66 Z" fill={coat} />
        <path d="M33 31 q6 3 7 7 l3 28 h-8z" fill="rgba(20,12,6,.25)" />
        <g className="p-armA" style={{ transformOrigin: '24px 38px' }}>
          <path d="M24 38 q-2 12 -1 20" stroke={coat} strokeWidth="6" fill="none" strokeLinecap="round" />
          <circle cx="23" cy="59" r="3.4" fill={skin} />
        </g>
        <g className="p-armB" style={{ transformOrigin: '36px 38px' }}>
          <path d="M36 38 q2 12 1 20" stroke={coat} strokeWidth="6" fill="none" strokeLinecap="round" />
          <circle cx="37" cy="59" r="3.4" fill={skin} />
          {v === 1 && <g transform="translate(37 60)"><path d="M0 1 v3" stroke="#4a3620" strokeWidth="1.4" /><path d="M-5 4 q5 -4 10 0 l1 9 q-6 2.6 -12 0z" fill="#6e4f33" /></g>}
        </g>
        <g transform="translate(30 22)">
          <circle r="9.6" fill={skin} />
          <path d="M3 -9 q7 3 6.4 10 q0 6 -4 9 q6 -2 6.6 -9 q.6 -8 -9 -10z" fill="rgba(20,12,6,.2)" />
          {v === 0 && <><path d="M-9.6 -2 q0 -9 9.6 -9 q9.6 0 9.6 9 q-5 -3 -9.6 -3 q-4.6 0 -9.6 3z" fill="#3f4a5a" /><path d="M-10.6 -1.4 q6 -2.6 14 -1.4 q4 .6 6.4 2.4 q-.6 1.8 -2.6 1.6 q-8 -2 -16 0 q-2 .2 -2.6 -2.6z" fill="#2c3542" /></>}
          {v === 1 && <><path d="M-10 -1 q-1 -10 10 -10 q11 0 10 10 q-.6 3.4 -1.8 4.6 q-.6 -7.6 -8.2 -7.6 q-7.6 0 -8.2 7.6 q-1.2 -1.2 -1.8 -4.6z" fill="#8a4a3c" /><path d="M-6 6 q-3 4 -1 6 q2 1.6 4 -.6 M6 6 q3 4 1 6 q-2 1.6 -4 -.6" fill="#8a4a3c" /></>}
          {v === 2 && <><path d="M-9.6 -3 q0 -8 9.6 -8 q9.6 0 9.6 8z" fill="#6e7f56" /><rect x="-11" y="-4.6" width="22" height="3.4" rx="1.7" fill="#4f6a3f" /></>}
          <circle cx="-3.4" cy="0.6" r="1.2" fill="#3a2c1d" /><circle cx="3.6" cy="0.6" r="1.2" fill="#3a2c1d" />
          <path d="M-2 5 q2.6 1.6 5 0" stroke="#3a2c1d" strokeWidth="1.2" fill="none" strokeLinecap="round" />
        </g>
      </g>
    </svg>
  );
}
