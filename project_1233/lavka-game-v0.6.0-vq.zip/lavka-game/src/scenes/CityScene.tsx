/* CityScene.tsx — город-диорама: квартал с перспективой и жизнью.
   PartsScene.tsx — магазин запчастей «У Шпуля» (интерьер переработан отдельно). */
import React, { useMemo, useRef, useState } from 'react';
import { game } from '../app/store';
import { CityArt } from '../art/scenes/CityArt';
import { PartsArt } from '../art/scenes/PartsArt';
import { Btn } from '../components/ui/Basics';
import { Icon, PartIcon } from '../art/core';
import { CITY_BUILDINGS, PARTS, BASIC_PARTS, SPECIAL_PARTS } from '../game/data/parts';
import { CONFIG } from '../game/data/config';
import { Goals } from '../game/systems/goals';
import { OrdersSystem } from '../game/systems/orders';
import { RestorationSystem } from '../game/systems/restoration';
import type { PartId } from '../game/types';

function usePortrait() {
  const [p, setP] = useState(() => window.matchMedia('(orientation: portrait)').matches);
  React.useEffect(() => {
    const mq = window.matchMedia('(orientation: portrait)');
    const fn = () => setP(mq.matches);
    mq.addEventListener('change', fn);
    return () => mq.removeEventListener('change', fn);
  }, []);
  return p;
}

export function CityScene() {
  const s = game.getSnapshot();
  const save = s.save;
  const portrait = usePortrait();
  const [zooming, setZooming] = useState<string | null>(null);
  const lockedIds = useMemo(() => {
    const set = new Set<string>();
    CITY_BUILDINGS.forEach(b => {
      if (b.house && !Goals.houseUnlocked(save, b.house)) set.add(b.id);
      else if (b.unlockLevel > Goals.shopLevel(save)) set.add(b.id);
    });
    return set;
  }, [save.shopLevel]);

  const goal = useMemo(() => {
    const orders = save.orders || [];
    if (!orders.length) return null;
    const o = [...orders].sort((a, b) => CONFIG.economy.orderMult[b.mult] - CONFIG.economy.orderMult[a.mult])[0];
    return `${o.who}: ${OrdersSystem.wantLabel(o.want)} — выплата ×${CONFIG.economy.orderMult[o.mult]}`;
  }, [save.orders]);

  const zoomTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  function select(id: string) {
    if (zooming) return;
    if (lockedIds.has(id)) { game.enterBuilding(id); return; }
    setZooming(id);
    zoomTimer.current = setTimeout(() => { setZooming(null); game.enterBuilding(id); }, 330);
  }

  return (
    <div className={`scene city-scene ${zooming ? 'zoom-in' : ''}`}>
      <div className="city-pan">
        <CityArt lockedIds={lockedIds} onSelect={select} portrait={portrait} />
      </div>
      <div className="city-goal-chip">
        {goal ? <><Icon n="note" s={14} /> <b>Цель дня:</b> {goal}</> : <>Свободный день: ищите лоты для наборов и перепродажи</>}
      </div>
      {zooming && <div style={{ position: 'absolute', inset: 0, background: '#17100a', opacity: 0.01 }} />}
    </div>
  );
}

export function PartsScene() {
  const s = game.getSnapshot();
  const save = s.save;
  const specials = useMemo(() => RestorationSystem.shopSpecialsToday(save.day), [save.day]);
  const fromWorkbench = !!s.lot;

  function buy(p: PartId, n: number) { game.buyPart(p, n); }

  const card = (p: PartId, special: boolean) => (
    <div className={`part-card ${special ? 'special' : ''}`} key={p}>
      <div className="p-icon"><PartIcon p={p} s={22} /></div>
      <div style={{ minWidth: 0 }}>
        <div className="p-name">{PARTS[p].name}</div>
        <div className="p-desc">{PARTS[p].desc}</div>
        <div className="p-have">в наличии: {save.parts[p] || 0} · {PARTS[p].price} ₽</div>
      </div>
      <div className="part-buy">
        <Btn small variant="gold" disabled={save.coins < PARTS[p].price} onClick={() => buy(p, 1)}>Купить</Btn>
        {!special && <Btn small variant="secondary" disabled={save.coins < PARTS[p].price * 5} onClick={() => buy(p, 5)}>×5</Btn>}
      </div>
    </div>
  );

  return (
    <div className="scene parts-scene">
      <PartsArt />
      <div className="shop-layer parts-layer">
        <div className="panel parts-panel">
          <div className="title" style={{ fontSize: 22 }}>Прилавок Шпуля</div>
          <div className="hint" style={{ marginBottom: 10 }}>
            Базовые детали — всегда. Особые — что удалось достать сегодня.
            Особые детали часто дешевле выторговать на аукционе в лотах-донорах
          </div>
          <div className="parts-grid">
            {BASIC_PARTS.map(p => card(p, false))}
          </div>
          <div className="subtitle" style={{ margin: '12px 0 6px', fontFamily: 'var(--font)', fontSize: 16 }}>Сегодня в ассортименте</div>
          <div className="parts-grid">
            {specials.length ? specials.map(p => card(p, true)) : <div className="hint">Сегодня особых деталей нет — загляните завтра.</div>}
            {specials.length < SPECIAL_PARTS.length && (
              <div className="hint" style={{ alignSelf: 'center' }}>
                Остальные особые ({SPECIAL_PARTS.filter(p => !specials.includes(p)).map(p => PARTS[p].name).join(', ')}) — ищите доноров на торгах
              </div>
            )}
          </div>
          <div className="btn-row" style={{ marginTop: 14 }}>
            <Btn big onClick={() => game.leaveParts()}><Icon n="arrowL" s={16} /> {fromWorkbench ? 'К верстаку' : 'Назад'}</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
