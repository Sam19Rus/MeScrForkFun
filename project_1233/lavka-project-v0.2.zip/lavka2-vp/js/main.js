/* main.js — bootstrap + dev-панель (?dev=1) + ?speed=fast для тестов */
(function () {
  const params = new URLSearchParams(location.search);
  window.DEV = params.get('dev') === '1';
  const fast = params.get('speed') === 'fast';

  function metrics() {
    const buf = window.Telemetry.buffer();
    const m = { wins: 0, losses: 0, marginSum: 0, estN: 0, estOk: 0, motivated: 0, orders: 0,
                bids: 0, passes: 0, rv: 0, inter: 0, clues: 0, bailouts: 0 };
    buf.forEach(e => {
      if (e.event === 'lot_won') { m.wins++; m.marginSum += (e.params.margin || 0); if (e.params.motivated) m.motivated++; }
      if (e.event === 'lot_lost') m.losses++;
      if (e.event === 'estimate_resolved') { m.estN++; if (e.params.ok) m.estOk++; }
      if (e.event === 'order_completed') m.orders++;
      if (e.event === 'bid_placed') m.bids++;
      if (e.event === 'bid_passed') m.passes++;
      if (e.event === 'ad_rewarded_call') m.rv++;
      if (e.event === 'ad_interstitial_call') m.inter++;
      if (e.event === 'clue_revealed') m.clues++;
      if (e.event === 'bailout') m.bailouts++;
    });
    return m;
  }

  function buildDevPanel() {
    const p = document.getElementById('devpanel');
    p.classList.remove('hidden');
    function refresh() {
      const s = window.Game.getSave ? window.Game.getSave() : null;
      const m = metrics();
      const c = window.Telemetry.counters();
      p.innerHTML = `
        <b>DEV · ${window.CONFIG.meta.version}</b> · сессия ${c.session_s}s<br>
        день: ${s ? s.day : '?'} · монеты: ${s ? s.coins : '?'} · лавка ур.${s ? s.shopLevel : '?'}<br>
        лоты: выиграно ${m.wins} / упущено ${m.losses} · ср.маржа ${m.wins ? Math.round(m.marginSum / m.wins) : '—'}<br>
        <b>точность оценок: ${m.estN ? Math.round(100 * m.estOk / m.estN) + '%' : '—'} (${m.estOk}/${m.estN})</b><br>
        <b>мотивиров. победы: ${m.wins ? Math.round(100 * m.motivated / m.wins) + '%' : '—'}</b> (заказ/набор/фикстура)<br>
        заказы: ${s ? s.stats.ordersDone : '?'} · ставки: ${m.bids} · пасы: ${m.passes} · улики+: ${m.clues}<br>
        RV: ${m.rv} · inter: ${m.inter} · bailouts: ${m.bailouts}<br>
        <button id="d_csv">CSV</button><button id="d_mute">звук</button>
        <button id="d_reset">сброс</button><button id="d_speed">${fast ? 'slow' : 'fast'}</button>`;
      document.getElementById('d_csv').onclick = () => window.Telemetry.exportCSV();
      document.getElementById('d_mute').onclick = () => window.SFX.toggleMute();
      document.getElementById('d_reset').onclick = async () => { await window.SDK.clearSave(); location.reload(); };
      document.getElementById('d_speed').onclick = () => {
        const u = new URL(location.href);
        if (u.searchParams.get('speed') === 'fast') u.searchParams.delete('speed'); else u.searchParams.set('speed', 'fast');
        location.href = u.toString();
      };
    }
    refresh(); setInterval(refresh, 1000);
  }

  async function boot() {
    await window.SDK.ready();
    if (window.DEV) buildDevPanel();
    window.Telemetry.log('boot', { dev: window.DEV, fast, items: window.ITEMS.length, version: window.CONFIG.meta.version });
    await window.Game.start({ speed: fast ? 40 : 550 });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
